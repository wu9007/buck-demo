/**
 * 会话内 step-up：校验当前登录密码。
 * 成功返回 { verifiedAt, expiresAt }；失败抛错且不回传密码。
 * 建议配合 transportProtected（与改密/登录一致）。
 */
export async function verifySessionPassword(request, password, options = {}) {
  if (typeof request !== 'function') {
    throw new Error('verifySessionPassword requires request(path, options)');
  }
  if (password == null || String(password).trim() === '') {
    throw new Error('password is required');
  }
  const path = options.path || '/brick/session/verify-password';
  return request(path, {
    method: 'POST',
    transportProtected: options.transportProtected !== false,
    body: JSON.stringify({ password: String(password) }),
    ...options.requestInit,
  });
}

export function createAuthRequestClient({
  state,
  clearSession,
  adoptPasswordChangeRequiredState,
  onStatus,
  readJson = safeReadJson,
  transportSecurityProvider = createLoginTransportSecurityProvider(),
  transportModuleLoader = loadTransportModule,
  /**
   * Optional silent refresh before terminal handling on 401.
   * Used by login-adjacent authenticated calls (MFA / password change).
   * Business SDK traffic uses configureHttp({ tokenRefresh }) instead.
   */
  tryRefresh,
  /**
   * Terminal after refresh fails (or no RT). Prefer this over clearSession so
   * SCREEN_LOCK soft-suspends; LOGIN_OUT still clears via lifecycle.
   * When omitted, falls back to clearSession (legacy shells only).
   */
  onSessionTerminal,
}) {
  async function request(path, options = {}, isRetry = false) {
    const { anonymous, transportProtected, ...fetchOptions } = options;
    const headers = {
      'Content-Type': 'application/json',
      ...fetchOptions.headers,
    };
    if (!anonymous && state.token) {
      headers.Authorization = `Bearer ${state.token}`;
    }
    let requestInit = { ...fetchOptions, headers };
    let transportSecurity = null;
    if (transportProtected) {
      transportSecurity = await transportSecurityProvider();
      if (transportSecurity.enabled) {
        requestInit = await prepareTransportRequest(requestInit, transportSecurity, transportModuleLoader);
      }
    }
    const response = await fetch(path, requestInit);
    const body = await readResponseBody(response, transportProtected, transportSecurity, {
      readJson,
      transportModuleLoader,
    });
    if (!response.ok) {
      const message = typeof body === 'object' && (body?.recovery || body?.message)
        ? body.recovery || body.message
        : `HTTP ${response.status}`;
      const error = new Error(message);
      error.status = response.status;
      error.code = typeof body === 'object' ? body?.code : undefined;
      error.body = body;
      error.payload = typeof body === 'object' ? body : undefined;
      error.headers = response.headers;
      if (!anonymous && error.code === 'BRICK_PASSWORD_CHANGE_REQUIRED') {
        adoptPasswordChangeRequiredState(error);
      } else if (!anonymous && response.status === 401) {
        if (
          !isRetry
          && typeof tryRefresh === 'function'
          && !String(path || '').includes('/brick/token/refresh')
        ) {
          const refreshed = await tryRefresh();
          if (refreshed) {
            return request(path, options, true);
          }
        }
        // Single terminal path: strategy branch when wired; never hard-clear when soft-suspend applies.
        if (typeof onSessionTerminal === 'function') {
          await onSessionTerminal(error);
        } else if (typeof clearSession === 'function') {
          clearSession(message);
        }
      } else {
        onStatus(message, 'error');
      }
      throw error;
    }
    return body;
  }

  return { request };
}

export function createLoginTransportSecurityProvider({
  metadataLoader = loadTransportMetadata,
  cryptoApi = globalThis.crypto,
  smCryptoLoader = loadSmCrypto,
} = {}) {
  let metadataPromise;

  return async function resolveTransportSecurity() {
    const metadata = await (metadataPromise ??= metadataLoader());
    if (metadata?.enabled === false) {
      return { enabled: false };
    }
    const cryptoLibrary = await smCryptoLoader();
    const sessionKey = cryptoApi.getRandomValues(new Uint8Array(16));
    const publicKey = metadata.keyMetadata?.publicKey;
    const encryptionKey = deriveTransportEncryptionKey(sessionKey, cryptoLibrary.sm3);
    return {
      enabled: true,
      headerName: metadata.metadataHeaderName || 'X-Brick-Transport-Key',
      headerValue: encryptTransportSessionKey(sessionKey, publicKey, cryptoLibrary.sm2),
      envelopeOptions: {
        version: metadata.version || 'v1',
        timestamp: Date.now(),
        nonce: randomNonce(cryptoApi),
        encrypt: (value) => encryptLoginTransportData(value, encryptionKey, cryptoLibrary.sm4, cryptoApi),
        decrypt: (value) => decryptLoginTransportData(value, encryptionKey, cryptoLibrary.sm4),
        tag: (envelope) => hmacSm3Hex(sessionKey, envelope, cryptoLibrary.sm3),
      },
    };
  };
}

async function prepareTransportRequest(requestInit, transportSecurity, transportModuleLoader) {
  const { createBrickTransportEnvelope } = await transportModuleLoader();
  const plaintext = String(requestInit.body ?? '');
  const envelope = await createBrickTransportEnvelope(plaintext, transportSecurity.envelopeOptions);
  return {
    ...requestInit,
    headers: {
      ...requestInit.headers,
      [transportSecurity.headerName]: transportSecurity.headerValue,
    },
    body: JSON.stringify(envelope),
  };
}

async function readResponseBody(response, transportProtected, transportSecurity, { readJson, transportModuleLoader }) {
  const text = await response.text();
  const payload = text ? readJson(text) ?? text : undefined;
  if (!transportProtected || !isTransportEnvelope(payload)) {
    return payload;
  }
  const { openBrickTransportEnvelope } = await transportModuleLoader();
  const plaintext = await openBrickTransportEnvelope(payload, transportSecurity.envelopeOptions);
  return readJson(plaintext) ?? plaintext;
}

async function loadTransportModule() {
  return import('@wildbuck/core-transport-frontend');
}

async function loadTransportMetadata() {
  const response = await fetch('/transport/meta', {
    headers: {
      Accept: 'application/json',
    },
  });
  if (!response.ok) {
    throw new Error(`无法读取登录传输配置：HTTP ${response.status}`);
  }
  return response.json();
}

function safeReadJson(text) {
  if (!text) {
    return null;
  }
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function isTransportEnvelope(payload) {
  return payload != null
    && typeof payload === 'object'
    && !Array.isArray(payload)
    && Object.hasOwn(payload, 'version')
    && Object.hasOwn(payload, 'timestamp')
    && Object.hasOwn(payload, 'nonce')
    && Object.hasOwn(payload, 'data')
    && Object.hasOwn(payload, 'tag');
}

function encryptLoginTransportData(plaintext, encryptionKey, sm4, cryptoApi) {
  const iv = cryptoApi.getRandomValues(new Uint8Array(16));
  const ciphertext = sm4.encrypt(plaintext, encryptionKey, {
    mode: 'cbc',
    iv: Array.from(iv),
    output: 'array',
  });
  return `${bytesToHex(iv)}:${bytesToHex(ciphertext)}`;
}

function decryptLoginTransportData(data, encryptionKey, sm4) {
  const [ivHex, cipherHex] = String(data || '').split(':', 2);
  return sm4.decrypt(cipherHex, encryptionKey, {
    mode: 'cbc',
    iv: hexToBytes(ivHex),
  });
}

function encryptTransportSessionKey(sessionKey, publicKey, sm2) {
  return sm2.doEncrypt(Array.from(sessionKey), publicKey, 1);
}

function hmacSm3Hex(sessionKey, envelope, sm3) {
  const macKey = deriveTransportMacKey(sessionKey, sm3);
  return sm3(canonicalizeTransportEnvelope(envelope), {
    key: macKey,
  });
}

function deriveTransportMacKey(sessionKey, sm3) {
  return hexToBytes(sm3([...sessionKey, 58, 109, 97, 99]));
}

function deriveTransportEncryptionKey(sessionKey, sm3) {
  return hexToBytes(sm3([...sessionKey, 58, 101, 110, 99])).slice(0, 16);
}

let smCryptoPromise;

async function loadSmCrypto() {
  const resolveLibrary = async () => {
    const module = await import('sm-crypto');
    const candidate = module?.default || module?.['module.exports'] || module;
    if (typeof candidate?.sm2?.doEncrypt !== 'function') {
      throw new TypeError('sm-crypto does not expose sm2.doEncrypt as a callable function');
    }
    if (typeof candidate?.sm3 !== 'function') {
      throw new TypeError('sm-crypto does not expose sm3 as a callable function');
    }
    if (typeof candidate?.sm4?.encrypt !== 'function') {
      throw new TypeError('sm-crypto does not expose sm4.encrypt as a callable function');
    }
    return candidate;
  };
  smCryptoPromise ??= resolveLibrary();
  return smCryptoPromise;
}

function canonicalizeTransportEnvelope(envelope) {
  return [
    String(envelope?.version ?? ''),
    String(envelope?.timestamp ?? ''),
    String(envelope?.nonce ?? ''),
    String(envelope?.data ?? ''),
  ].join('\n');
}

function randomNonce(cryptoApi) {
  const bytes = cryptoApi.getRandomValues(new Uint8Array(16));
  return bytesToHex(bytes);
}

function bytesToHex(bytes) {
  return Array.from(bytes).map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

function hexToBytes(hex) {
  if (!hex || hex.length % 2 !== 0) {
    throw new Error('Transport hex payload is invalid');
  }
  const bytes = new Uint8Array(hex.length / 2);
  for (let index = 0; index < hex.length; index += 2) {
    bytes[index / 2] = Number.parseInt(hex.slice(index, index + 2), 16);
  }
  return bytes;
}
