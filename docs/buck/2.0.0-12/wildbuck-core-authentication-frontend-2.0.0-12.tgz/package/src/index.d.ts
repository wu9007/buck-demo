export interface BrickAuthRequestClient {
  request: (path: string, options?: Record<string, any>) => Promise<any>;
}

export interface BrickLoginTransportSecurityProviderDescriptor {
  enabled: boolean;
  headerName?: string;
  headerValue?: string;
  envelopeOptions?: Record<string, any>;
}

export declare function verifySessionPassword(
  request: (path: string, options?: Record<string, any>) => Promise<any>,
  password: string,
  options?: {
    path?: string;
    transportProtected?: boolean;
    requestInit?: Record<string, any>;
  }
): Promise<{ verifiedAt?: string; expiresAt?: string }>;

export declare function createAuthRequestClient(options: {
  state: Record<string, any>;
  /** Fallback when onSessionTerminal is omitted (legacy LOGIN_OUT-only shells). */
  clearSession?: (message?: string) => void;
  adoptPasswordChangeRequiredState: (error: any) => void;
  onStatus: (message: string, type?: string) => void;
  readJson?: (text: string | null) => unknown;
  transportSecurityProvider?: () => Promise<BrickLoginTransportSecurityProviderDescriptor>;
  transportModuleLoader?: () => Promise<Record<string, any>>;
  /** Optional silent refresh before terminal handling on authenticated 401. */
  tryRefresh?: () => boolean | Promise<boolean | null | undefined | void | object>;
  /**
   * Preferred terminal after refresh fails. Wire to session lifecycle
   * (LOGIN_OUT / SCREEN_LOCK) — do not hard-clear for SCREEN_LOCK soft-suspend.
   */
  onSessionTerminal?: (error: any) => void | Promise<void>;
}): BrickAuthRequestClient;

export declare function createLoginTransportSecurityProvider(options?: {
  metadataLoader?: () => Promise<Record<string, any>>;
  cryptoApi?: Crypto;
  smCryptoLoader?: () => Promise<Record<string, any>>;
}): () => Promise<BrickLoginTransportSecurityProviderDescriptor>;
