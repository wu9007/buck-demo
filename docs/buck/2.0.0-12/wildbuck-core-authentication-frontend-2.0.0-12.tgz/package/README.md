# @wildbuck/core-authentication-frontend

Buck 登录链路使用的前端认证运行时。

职责边界：

- 提供登录请求客户端，统一 bearer token、可选 `tryRefresh` 静默续期、401 终态清理、强制改密切换和错误读取。
- 提供登录传输保护运行时，负责 `/transport/meta` 读取、SM2/SM3/SM4 封装和 envelope 解封。
- 业务 SDK 的静默续期与会话终态分流由 `@wildbuck/core-api-frontend` 的 `tokenRefresh` + `createBrickSessionErrorHandler()` 处理；登录链路本身继续由本包的 `createAuthRequestClient()` 管理。
- **邻域边界**：`createAuthRequestClient` 在 refresh 失败后走 `clearSession`（login / MFA / 改密邻域）。业务列表与管理页主路径必须用 `configureHttp({ tokenRefresh, responseErrorHandler })`，由壳层按 `expirationStrategy` 做 `LOGIN_OUT` / `SCREEN_LOCK` 分流（历史 `VERIFY_PASS` 归一 soft）；不要用本客户端冒充业务会话生命周期。
- 不承载登录页面、MFA 交互、认证状态 UI 编排或业务模块路由。
- 上层应用或模块可在自己的 workspace/composable 中组合它，但不应再自建本地 `request-client`。

```ts
import { createAuthRequestClient } from '@wildbuck/core-authentication-frontend';

const authClient = createAuthRequestClient({
  state,
  clearSession,
  adoptPasswordChangeRequiredState,
  onStatus,
});
```
