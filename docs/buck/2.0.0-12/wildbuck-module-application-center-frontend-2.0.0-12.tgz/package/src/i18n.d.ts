import type { ComputedRef, Ref } from 'vue';

export declare const APPLICATION_CENTER_MESSAGES_ZH_CN: Readonly<Record<string, string>>;
export declare const APPLICATION_CENTER_MESSAGES_EN_US: Readonly<Record<string, string>>;
export declare const APPLICATION_CENTER_MESSAGES: Readonly<Record<string, Readonly<Record<string, string>>>>;

export declare function resolveApplicationCenterMessages(locale?: string): Readonly<Record<string, string>>;
export declare function translateApplicationCenter(
  runtime: unknown,
  key: string,
  params?: Record<string, unknown>,
  fallbackLocale?: string,
): string;

export declare function useApplicationCenterI18n(): {
  t: (key: string, params?: Record<string, unknown>) => string;
  i18n: unknown;
  locale: ComputedRef<string>;
  revision: Ref<number>;
};
