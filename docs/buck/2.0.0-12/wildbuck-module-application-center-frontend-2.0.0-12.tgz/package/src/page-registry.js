export const brickRouteComponentLoaders = {
  'application-center.apps': () => import('./features/applications/pages/ApplicationCenterPage.vue'),
};
