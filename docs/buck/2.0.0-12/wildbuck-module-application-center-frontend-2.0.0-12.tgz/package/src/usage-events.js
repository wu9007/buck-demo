import { createModuleUsageTracker } from '@wildbuck/core-usage-event-frontend';

export const APPLICATION_CENTER_USAGE_EVENT_MODULE_CODE = 'application-center';

export const applicationCenterUsageEventMatrix = deepFreeze({
  pages: {
    applications: {
      featureCode: 'application-list',
      pageCode: 'application-center-page',
      routeName: 'application-center.apps',
    },
  },
  features: {
    applicationList: {
      featureCode: 'application-list',
      pageCode: 'application-center-page',
      routeName: 'application-center.apps',
    },
    applicationProfile: {
      featureCode: 'application-profile',
      pageCode: 'application-center-page',
      routeName: 'application-center.apps',
    },
    applicationAuthorization: {
      featureCode: 'application-authorization',
      pageCode: 'application-center-page',
      routeName: 'application-center.apps',
    },
    applicationSecret: {
      featureCode: 'application-secret',
      pageCode: 'application-center-page',
      routeName: 'application-center.apps',
    },
    applicationCallRecord: {
      featureCode: 'application-call-record',
      pageCode: 'application-center-page',
      routeName: 'application-center.apps',
    },
  },
});

export const applicationCenterUsageTracker = createModuleUsageTracker(
  APPLICATION_CENTER_USAGE_EVENT_MODULE_CODE,
  applicationCenterUsageEventMatrix,
);

function deepFreeze(value) {
  if (value == null || typeof value !== 'object') {
    return value;
  }
  for (const child of Object.values(value)) {
    deepFreeze(child);
  }
  return Object.freeze(value);
}
