export type ApplicationCenterUsageEventPageKey = 'applications';
export type ApplicationCenterUsageEventFeatureKey =
  | 'applicationList'
  | 'applicationProfile'
  | 'applicationAuthorization'
  | 'applicationSecret'
  | 'applicationCallRecord';
export type ApplicationCenterUsageEventActionCode =
  | 'search'
  | 'reset-filters'
  | 'open-detail'
  | 'open-create'
  | 'open-authorization'
  | 'open-secret'
  | 'open-call-records'
  | 'create'
  | 'update'
  | 'enable'
  | 'disable'
  | 'delete'
  | 'rotate-secret'
  | 'save-authorization'
  | 'export-authorization';

export interface ApplicationCenterUsageEventPageEntry {
  featureCode: string;
  pageCode: string;
  routeName: string;
}

export type ApplicationCenterUsageEventFeatureEntry = ApplicationCenterUsageEventPageEntry;

export declare const APPLICATION_CENTER_USAGE_EVENT_MODULE_CODE: 'application-center';
export declare const applicationCenterUsageEventMatrix: Readonly<{
  pages: Record<ApplicationCenterUsageEventPageKey, Readonly<ApplicationCenterUsageEventPageEntry>>;
  features: Record<ApplicationCenterUsageEventFeatureKey, Readonly<ApplicationCenterUsageEventFeatureEntry>>;
}>;
export declare const applicationCenterUsageTracker: import('@wildbuck/core-usage-event-frontend').BrickModuleUsageTracker;
