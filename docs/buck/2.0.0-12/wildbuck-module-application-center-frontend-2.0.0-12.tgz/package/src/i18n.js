export {
  APPLICATION_CENTER_MESSAGES,
  APPLICATION_CENTER_MESSAGES_EN_US,
  APPLICATION_CENTER_MESSAGES_ZH_CN,
  resolveApplicationCenterMessages,
  translateApplicationCenter,
  useApplicationCenterI18n,
} from './features/application-center-i18n.js';
