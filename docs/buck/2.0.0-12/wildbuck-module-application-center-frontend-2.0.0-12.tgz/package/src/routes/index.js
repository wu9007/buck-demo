export const applicationRoutes = [
  {
    id: 'application-center.apps',
    featureKey: 'applications',
    path: '/application-center/apps',
    title: '应用中心',
    abbr: '应',
    eyebrow: 'EIAM / 应用中心',
    summary: '维护应用目录、OAuth client、回调地址、scope 和凭据生命周期。',
    guide: {
      title: '应用中心任务路径',
      steps: [
        {
          anchor: 'filters',
          title: '先定位应用',
          body: '按应用类型、状态或关键字筛选，找到要治理的接入应用。',
        },
        {
          anchor: 'list',
          title: '再进入应用资料',
          body: '打开应用后维护授权范围、凭据和回调地址。',
        },
        {
          anchor: 'primary-action',
          title: '新增应用从这里开始',
          body: '新建后再配置凭据、回调地址和授权范围。',
        },
      ],
    },
    permission: 'application-center:app:list',
    component: () => import('../features/applications/pages/ApplicationCenterPage.vue'),
  },
];

export default function registerApplicationCenterRoutes() {
  return applicationRoutes.map((route) => ({
    path: route.path,
    name: route.id,
    component: route.component,
  }));
}
