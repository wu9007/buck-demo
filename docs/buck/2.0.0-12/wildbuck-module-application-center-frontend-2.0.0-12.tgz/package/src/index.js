import { applicationsFeature } from './features/applications/index.js';
import registerApplicationCenterRoutes, { applicationRoutes } from './routes/index.js';

export const applicationCenterFeatureRegistry = {
  applications: applicationsFeature,
};

export const applicationCenterPermissionMap = {
  applications: applicationsFeature.permissions,
};

export default {
  name: 'application-center',
  register() {
    return {
      routes: registerApplicationCenterRoutes(),
    };
  },
};

export const brickModuleKey = 'application-center';
export const brickModuleMeta = {
  displayName: '应用中心',
};
export const brickFeatureRegistry = applicationCenterFeatureRegistry;
export const brickPermissionMap = applicationCenterPermissionMap;
export const brickRoutes = applicationRoutes;
export {
  APPLICATION_CENTER_USAGE_EVENT_MODULE_CODE,
  applicationCenterUsageEventMatrix,
  applicationCenterUsageTracker,
} from './usage-events.js';
