<script setup lang="ts">
import { onMounted, ref, watch } from 'vue';
import { BrickListPageActions, BrickPageHeader } from '@wildbuck/core-ui-frontend/patterns';
import ApplicationDrawerPanel from '../components/ApplicationDrawerPanel.vue';
import ApplicationFilterToolbar from '../components/ApplicationFilterToolbar.vue';
import ApplicationGalleryPanel from '../components/ApplicationGalleryPanel.vue';
import { useApplicationWorkspace } from '../composables/useApplicationWorkspace';
import {
  applicationCenterUsageTracker,
} from '../../../usage-events';
import { useApplicationCenterI18n } from '../../../i18n.js';

const { t } = useApplicationCenterI18n();

const {
  activeFilterChips,
  applicationTypeFilter,
  applicationTypeOptions,
  applications,
  applicationLogoUrls,
  callRecordDetailLoading,
  callRecordFilters,
  callRecordLoading,
  callRecordResultOptions,
  callRecordTotal,
  callRecords,
  authorizationRows,
  authorizationDetail,
  authorizationSaving,
  canDeleteApplication,
  canExportAuthorization,
  canRotateSecret,
  canSaveAuthorization,
  changePage,
  changePageSize,
  clearFilterChip,
  copyCredential,
  currentDetail,
  detailLoading,
  deleteCurrentApplication,
  deleting,
  editorMode,
  ensureCallRecordsLoaded,
  enabledFilter,
  exportAccessProfile,
  focusedScope,
  form,
  initialize,
  keyword,
  latestSecret,
  listError,
  listLoading,
  logoPreviewUrl,
  logoUploading,
  page,
  pageSize,
  pageSizeOptions,
  pageSummary,
  redirectUrisText,
  refreshCallRecords,
  resetFilters,
  rotateApplicationSecret,
  rotateReason,
  rotating,
  selectCallRecord,
  saving,
  scopesText,
  selectApplication,
  selectedCallRecordId,
  selectedScopes,
  selectedApplication,
  selectedApplicationId,
  selectedApplicationTypeLabel,
  startCreateApplication,
  submitAuthorizations,
  submitForm,
  submitSearch,
  total,
  clearApplicationLogo,
  currentCallRecord,
  uploadApplicationLogo,
} = useApplicationWorkspace();

const activeTab = ref('detail');
const drawerVisible = ref(false);

function updateRotateReason(value: string) {
  rotateReason.value = value;
}

function updateScopesText(value: string) {
  scopesText.value = value;
}

function updateRedirectUrisText(value: string) {
  redirectUrisText.value = value;
}

function updateSelectedScopes(value: string[]) {
  selectedScopes.value = value;
}

async function openApplication(applicationId: string) {
  activeTab.value = focusedScope.value ? 'authorization' : 'detail';
  drawerVisible.value = true;
  const loaded = await selectApplication(applicationId);
  const featureKey = activeTab.value === 'authorization' ? 'applicationAuthorization' : 'applicationProfile';
  const actionCode = activeTab.value === 'authorization' ? 'open-authorization' : 'open-detail';
  void applicationCenterUsageTracker.trackOpen(featureKey, actionCode, loaded ? 'SUCCESS' : 'FAILURE');
}

function openCreateDrawer() {
  activeTab.value = 'detail';
  drawerVisible.value = true;
  startCreateApplication();
  void applicationCenterUsageTracker.trackOpen('applicationProfile', 'open-create');
}

function closeDrawer() {
  drawerVisible.value = false;
}

async function handleDelete() {
  await deleteCurrentApplication();
  if (!selectedApplicationId.value) {
    drawerVisible.value = false;
  }
}

async function handleSave() {
  await submitForm();
  drawerVisible.value = true;
}

function updateActiveTab(value: string) {
  activeTab.value = value;
  if (!drawerVisible.value || editorMode.value === 'create') {
    return;
  }
  if (value === 'authorization') {
    void applicationCenterUsageTracker.trackOpen('applicationAuthorization', 'open-authorization');
  }
  if (value === 'credentials') {
    void applicationCenterUsageTracker.trackOpen('applicationSecret', 'open-secret');
  }
  if (value === 'call-records') {
    void applicationCenterUsageTracker.trackOpen('applicationCallRecord', 'open-call-records');
  }
}

watch([activeTab, drawerVisible, selectedApplicationId], async ([tab, visible, applicationId]) => {
  if (tab === 'call-records' && visible && applicationId) {
    await ensureCallRecordsLoaded();
  }
});

onMounted(() => {
  void applicationCenterUsageTracker.trackPage('applications');
  initialize();
});
</script>

<template>
  <article class="application-center-page">
    <BrickPageHeader
      :eyebrow="t('module.application-center.page.eyebrow')"
      :title="t('module.application-center.page.title')"
      :description="t('module.application-center.page.description')"
    >
      <template #actions>
        <BrickListPageActions>
          <template #primary>
            <el-button type="primary" data-guide-anchor="primary-action" @click="openCreateDrawer()">
              {{ t('module.application-center.filter.create') }}
            </el-button>
          </template>
        </BrickListPageActions>
      </template>
    </BrickPageHeader>

    <ApplicationFilterToolbar
      :application-type-filter="applicationTypeFilter"
      :application-type-options="applicationTypeOptions"
      :enabled-filter="enabledFilter"
      :keyword="keyword"
      @reset="resetFilters()"
      @search="submitSearch()"
      @update:application-type-filter="applicationTypeFilter = $event"
      @update:enabled-filter="enabledFilter = $event"
      @update:keyword="keyword = $event"
    />

    <div v-if="activeFilterChips.length" class="active-filters" data-guide-anchor="active-filters">
      <span class="active-filters__label">{{ t('module.application-center.filter.activeLabel') }}</span>
      <button
        v-for="chip in activeFilterChips"
        :key="`${chip.key}-${chip.value}`"
        type="button"
        class="active-filters__chip"
        @click="clearFilterChip(chip.key)"
      >
        <span>{{ chip.label }}: {{ chip.value }}</span>
        <span aria-hidden="true">×</span>
      </button>
    </div>

    <ApplicationGalleryPanel
      :applications="applications"
      :application-logo-urls="applicationLogoUrls"
      :application-type-options="applicationTypeOptions"
      :list-error="listError"
      :list-loading="listLoading"
      :page="page"
      :page-size="pageSize"
      :page-size-options="pageSizeOptions"
      :page-summary="pageSummary"
      :selected-application-id="selectedApplicationId"
      :total="total"
      @update:page="changePage"
      @update:page-size="changePageSize"
      @select="openApplication"
    />
    <p v-if="detailLoading && drawerVisible" class="feedback">{{ t('module.application-center.loading.detail') }}</p>

    <ApplicationDrawerPanel
      :visible="drawerVisible"
      :active-tab="activeTab"
      :call-record-detail="currentCallRecord"
      :call-record-detail-loading="callRecordDetailLoading"
      :call-record-loading="callRecordLoading"
      :call-record-result-options="callRecordResultOptions"
      :call-record-total="callRecordTotal"
      :call-records="callRecords"
      :authorization-detail="authorizationDetail"
      :authorization-saving="authorizationSaving"
      :can-delete-application="canDeleteApplication"
      :can-export-authorization="canExportAuthorization"
      :can-rotate-secret="canRotateSecret"
      :can-save-authorization="canSaveAuthorization"
      :current-detail="currentDetail"
      :deleting="deleting"
      :editor-mode="editorMode"
      :focused-scope="focusedScope"
      :form="form"
      :logo-preview-url="logoPreviewUrl"
      :logo-uploading="logoUploading"
      :latest-secret="latestSecret"
      :panel-loading="detailLoading"
      :application-type-options="applicationTypeOptions"
      :request-path-keyword="callRecordFilters.requestPathKeyword"
      :redirect-uris-text="redirectUrisText"
      :result-filter="callRecordFilters.result"
      :rotate-reason="rotateReason"
      :rotating="rotating"
      :saving="saving"
      :scopes-text="scopesText"
      :selected-call-record-id="selectedCallRecordId"
      :selected-scopes="selectedScopes"
      :selected-application="selectedApplication"
      :selected-application-type-label="selectedApplicationTypeLabel"
      :trace-id-filter="callRecordFilters.traceId"
      @clear-logo="clearApplicationLogo()"
      @close="closeDrawer"
      @copy-client-id="copyCredential(latestSecret?.clientId || currentDetail?.clientId, 'module.application-center.copy.clientId')"
      @copy-secret="copyCredential(latestSecret?.clientSecret, 'module.application-center.copy.clientSecret')"
      @delete="handleDelete()"
      @export="exportAccessProfile()"
      @refresh-call-records="refreshCallRecords()"
      @rotate="rotateApplicationSecret()"
      @save="handleSave()"
      @save-authorization="submitAuthorizations()"
      @select-call-record="selectCallRecord"
      @upload-logo="uploadApplicationLogo"
      @update:activeTab="updateActiveTab"
      @update:request-path-keyword="callRecordFilters.requestPathKeyword = $event"
      @update:redirect-uris-text="updateRedirectUrisText"
      @update:result-filter="callRecordFilters.result = $event"
      @update:rotate-reason="updateRotateReason"
      @update:scopes-text="updateScopesText"
      @update:selected-scopes="updateSelectedScopes"
      @update:trace-id-filter="callRecordFilters.traceId = $event"
    />
  </article>
</template>

<style scoped>
.application-center-page {
  display: grid;
  gap: 20px;
  padding: 4px 0 12px;
  background: var(--console-page-bg, #f6f8f8);
}

.active-filters {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
}

.active-filters__label {
  color: var(--console-muted, #7e8ba0);
  font-size: 12px;
  font-weight: 700;
}

.active-filters__chip {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  min-height: 30px;
  padding: 0 12px;
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: 999px;
  color: var(--console-title, #172033);
  background: var(--console-card-bg, #ffffff);
  font-size: 12px;
  cursor: pointer;
}

.active-filters__chip:hover {
  border-color: rgba(24, 129, 104, 0.35);
  color: var(--console-primary, #188168);
}

.feedback {
  margin: 0;
  padding: 16px 18px;
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: var(--console-card-radius, 8px);
  color: var(--console-text, #4a5a70);
  background: var(--console-card-bg, #ffffff);
  box-shadow: none;
}

.feedback.error {
  color: var(--console-danger, #b4232f);
}

.feedback.success {
  color: var(--console-primary, #188168);
  background: var(--console-accent-soft, rgba(24, 129, 104, 0.08));
  border-color: rgba(61, 137, 98, 0.18);
  box-shadow: none;
}

</style>
