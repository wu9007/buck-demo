export type ApplicationEnabledFilterValue = 'all' | 'enabled' | 'disabled';

type Translate = (key: string, params?: Record<string, unknown>) => string;

export function buildApplicationEnabledFilterOptions(t: Translate): ReadonlyArray<{
  label: string;
  value: ApplicationEnabledFilterValue;
}> {
  return [
    { label: t('module.application-center.filter.statusAll'), value: 'all' },
    { label: t('module.application-center.filter.statusEnabled'), value: 'enabled' },
    { label: t('module.application-center.filter.statusDisabled'), value: 'disabled' },
  ];
}
