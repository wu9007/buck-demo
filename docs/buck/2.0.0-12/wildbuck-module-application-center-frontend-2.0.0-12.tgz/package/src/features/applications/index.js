import { applicationPermissions } from './permission/index.js';
import { applicationRoutes } from '../../routes/index.js';

export const applicationsFeature = {
  featureKey: 'applications',
  routes: applicationRoutes,
  permissions: applicationPermissions,
};
