<script setup lang="ts">
import { computed } from 'vue';
import type { ApplicationAuthorizationDetail } from '../../../generated/types';
import { useApplicationCenterI18n } from '../../../i18n.js';

const props = defineProps<{
  authorizationDetail: ApplicationAuthorizationDetail | null;
  authorizationSaving: boolean;
  canExportAuthorization: boolean;
  canSaveAuthorization: boolean;
  editorMode: 'edit' | 'create';
  focusedScope: string;
  selectedScopes: string[];
}>();

defineEmits<{
  export: [];
  save: [];
  'update:selectedScopes': [value: string[]];
}>();

const { t } = useApplicationCenterI18n();

const groupedScopes = computed(() => {
  const groups = new Map<string, {
    groupName: string;
    scopes: ApplicationAuthorizationDetail['openApiScopes'];
  }>();
  const ungrouped = t('module.application-center.authorization.ungrouped');
  for (const scopeEntry of props.authorizationDetail?.openApiScopes || []) {
    const key = scopeEntry.groupName || ungrouped;
    if (!groups.has(key)) {
      groups.set(key, {
        groupName: key,
        scopes: [],
      });
    }
    groups.get(key)?.scopes.push(scopeEntry);
  }
  return [...groups.values()];
});
</script>

<template>
  <el-card shadow="never" class="card">
    <template #header>
      <div class="card-header">
        <div>
          <h2>{{ t('module.application-center.authorization.title') }}</h2>
          <p>{{ t('module.application-center.authorization.description') }}</p>
        </div>
        <div class="card-header__actions">
          <el-button :disabled="!canExportAuthorization" @click="$emit('export')">
            {{ t('module.application-center.authorization.export') }}
          </el-button>
          <el-button type="primary" :disabled="!canSaveAuthorization" :loading="authorizationSaving" @click="$emit('save')">
            {{ t('module.application-center.authorization.save') }}
          </el-button>
        </div>
      </div>
    </template>

    <div v-if="authorizationDetail && editorMode === 'edit'" class="action-grid">
      <el-checkbox-group
        :model-value="selectedScopes"
        class="action-grid__group"
        @update:model-value="$emit('update:selectedScopes', $event)"
      >
        <section v-for="group in groupedScopes" :key="group.groupName" class="action-group">
          <header class="action-group__header">
            <h3>{{ group.groupName }}</h3>
            <span>{{ t('module.application-center.authorization.scopeCount', { count: group.scopes.length }) }}</span>
          </header>

          <article
            v-for="scopeEntry in group.scopes"
            :key="scopeEntry.scope"
            class="action-card"
            :class="{ 'is-focused': focusedScope === scopeEntry.scope }"
          >
            <div class="action-card__head">
              <div>
                <strong>{{ scopeEntry.interfaceName }}</strong>
                <p v-if="scopeEntry.description" class="action-card__description">{{ scopeEntry.description }}</p>
                <p>{{ scopeEntry.pathPattern }}</p>
              </div>
              <el-tag effect="plain" round>{{ scopeEntry.httpMethod }}</el-tag>
            </div>

            <div class="action-card__meta">
              <span>{{ t('module.application-center.authorization.scopeLabel', { scope: scopeEntry.scope }) }}</span>
            </div>

            <el-checkbox
              :value="scopeEntry.scope"
              :label="t('module.application-center.authorization.allowScope')"
              size="large"
            />
          </article>
        </section>
      </el-checkbox-group>
    </div>

    <el-empty v-else :description="t('module.application-center.authorization.empty')" />
  </el-card>
</template>

<style scoped>
.card {
  border: 1px solid var(--console-card-border, #e6ebf2);
  background: var(--console-card-bg, #ffffff);
}

.card-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
}

.card-header__actions {
  display: flex;
  align-items: center;
  gap: 12px;
}

.card-header h2,
.card-header h3,
.card-header p,
.action-group__header span {
  margin: 0;
}

.card-header p {
  margin-top: 6px;
  color: var(--console-text, #4a5a70);
}

.card :deep(.el-card__header) {
  padding: var(--console-card-header-y, 14px) var(--console-card-header-x, 18px);
  border-bottom: 1px solid var(--console-card-border, #e6ebf2);
}

.card :deep(.el-card__body) {
  padding: var(--console-card-body-y, 18px) var(--console-card-body-x, 18px);
}

.card-header :deep(.el-button) {
  min-height: 42px;
  padding: 0 18px;
  border-radius: 999px;
  font-weight: 700;
}

.action-grid__group,
.action-group {
  display: grid;
  gap: 14px;
}

.action-group__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.action-group__header h3 {
  color: var(--console-title, #172033);
  font-size: 15px;
}

.action-group__header span {
  color: var(--console-muted, #7e8ba0);
  font-size: 12px;
}

.action-card {
  display: grid;
  gap: 12px;
  padding: 16px;
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: var(--console-block-radius, 8px);
  background: var(--console-block-bg, var(--console-card-bg, #ffffff));
}

.action-card.is-focused {
  border-color: var(--console-field-hover-border, var(--console-primary, #188168));
  box-shadow: inset 3px 0 0 var(--console-primary, #188168);
}

.action-card__head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
}

.action-card__head strong,
.action-card__head p {
  margin: 0;
}

.action-card__head strong {
  color: var(--console-title, #172033);
}

.action-card__head p {
  margin-top: 6px;
  color: var(--console-text, #4a5a70);
  font-family: 'SFMono-Regular', 'Roboto Mono', monospace;
  font-size: 12px;
  word-break: break-all;
}

.action-card__description {
  font-family: inherit !important;
  font-size: 13px !important;
  line-height: 1.5;
}

.action-card__meta {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  color: var(--console-text, #4a5a70);
  font-size: 13px;
}

.action-card :deep(.el-checkbox) {
  align-items: flex-start;
}

.action-card :deep(.el-checkbox__label) {
  color: var(--console-title, #172033);
  font-weight: 700;
  white-space: normal;
}

@media (max-width: 760px) {
  .card-header,
  .card-header__actions,
  .action-group__header {
    display: grid;
  }
}
</style>
