export const applicationPermissions = {
  list: 'application-center:app:list',
  edit: 'application-center:app:edit',
  grant: 'application-center:app:grant',
};
