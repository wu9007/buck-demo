<script setup lang="ts">
import { computed } from 'vue';
import { CopyDocument } from '@element-plus/icons-vue';
import { ElMessage } from 'element-plus';
import type { ApplicationCallRecordDetail, ApplicationCallRecordSummary } from '../../../generated/types';
import { useApplicationCenterI18n } from '../../../i18n.js';

type OptionItem = { label: string; value: string };

const props = defineProps<{
  callRecordDetail: ApplicationCallRecordDetail | null;
  callRecordDetailLoading: boolean;
  callRecordLoading: boolean;
  callRecordResultOptions: OptionItem[];
  callRecordTotal: number;
  callRecords: ApplicationCallRecordSummary[];
  editorMode: 'edit' | 'create';
  requestPathKeyword: string;
  resultFilter: string;
  selectedCallRecordId: string;
  traceIdFilter: string;
}>();

defineEmits<{
  refresh: [];
  select: [callRecordId: string];
  'update:requestPathKeyword': [value: string];
  'update:resultFilter': [value: string];
  'update:traceIdFilter': [value: string];
}>();

const { t } = useApplicationCenterI18n();

const resultTagType = computed(() => (result: string) => {
  if (result === 'SUCCESS') {
    return 'success';
  }
  if (result === 'FAILURE') {
    return 'danger';
  }
  return 'info';
});

function prettyJson(raw?: string) {
  if (!raw || !raw.trim()) {
    return '';
  }
  try {
    return JSON.stringify(JSON.parse(raw), null, 2);
  } catch {
    return raw;
  }
}

function display(value?: string) {
  return value && value.trim() ? value : '-';
}

function parseBusinessData(raw?: string) {
  if (!raw || !raw.trim()) {
    return null;
  }
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function resolveText(value: unknown) {
  if (value == null) {
    return '';
  }
  return typeof value === 'string' ? value : JSON.stringify(value, null, 2);
}

const detailPayload = computed(() => {
  const payload = parseBusinessData(props.callRecordDetail?.businessDataJson);
  return {
    scope: resolveText(payload?.scope),
    requestQuery: resolveText(payload?.requestQuery),
    requestBody: resolveText(payload?.requestBody),
    responseBody: resolveText(payload?.responseBody),
    exceptionType: resolveText(payload?.exceptionType),
    exceptionMessage: resolveText(payload?.exceptionMessage),
    exceptionStack: resolveText(payload?.exceptionStack),
    rawBusinessData: prettyJson(props.callRecordDetail?.businessDataJson),
  };
});

async function copyText(text: string, successMessage: string) {
  if (!text || !text.trim() || typeof navigator === 'undefined' || !navigator.clipboard) {
    return;
  }
  await navigator.clipboard.writeText(text);
  ElMessage.success(successMessage);
}
</script>

<template>
  <el-card shadow="never" class="card">
    <template #header>
      <div class="card-header">
        <div>
          <h2>{{ t('module.application-center.callRecords.title') }}</h2>
          <p>{{ t('module.application-center.callRecords.description') }}</p>
        </div>
        <el-button :disabled="editorMode === 'create'" :loading="callRecordLoading" @click="$emit('refresh')">
          {{ t('module.application-center.callRecords.refresh') }}
        </el-button>
      </div>
    </template>

    <el-empty v-if="editorMode === 'create'" :description="t('module.application-center.callRecords.createEmpty')" />

    <template v-else>
      <div class="filter-row">
        <el-select
          :model-value="resultFilter"
          :placeholder="t('module.application-center.callRecords.resultPlaceholder')"
          clearable
          @update:model-value="$emit('update:resultFilter', $event || '')"
        >
          <el-option
            v-for="option in callRecordResultOptions"
            :key="option.value"
            :label="option.label"
            :value="option.value"
          />
        </el-select>
        <el-input
          :model-value="traceIdFilter"
          :placeholder="t('module.application-center.callRecords.traceIdPlaceholder')"
          clearable
          @keyup.enter="$emit('refresh')"
          @update:model-value="$emit('update:traceIdFilter', $event)"
        />
        <el-input
          :model-value="requestPathKeyword"
          :placeholder="t('module.application-center.callRecords.pathPlaceholder')"
          clearable
          @keyup.enter="$emit('refresh')"
          @update:model-value="$emit('update:requestPathKeyword', $event)"
        />
      </div>

      <div class="call-record-layout">
        <section class="list-panel">
          <div class="section-caption">
            <strong>{{ t('module.application-center.callRecords.recentTitle') }}</strong>
            <span>{{ t('module.application-center.callRecords.count', { count: callRecordTotal }) }}</span>
          </div>

          <el-table
            v-loading="callRecordLoading"
            :data="callRecords"
            row-key="callRecordId"
            highlight-current-row
            height="360"
            @row-click="$emit('select', $event.callRecordId)"
          >
            <el-table-column :label="t('module.application-center.callRecords.column.time')" min-width="168">
              <template #default="{ row }">{{ row.eventTime }}</template>
            </el-table-column>
            <el-table-column :label="t('module.application-center.callRecords.column.result')" min-width="96">
              <template #default="{ row }">
                <el-tag :type="resultTagType(row.result)" effect="plain" round>{{ row.result }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="requestMethod" :label="t('module.application-center.callRecords.column.method')" min-width="92" />
            <el-table-column prop="requestPath" :label="t('module.application-center.callRecords.column.path')" min-width="220" show-overflow-tooltip />
            <el-table-column prop="traceId" label="Trace ID" min-width="170" show-overflow-tooltip />
          </el-table>

          <el-empty
            v-if="!callRecordLoading && callRecords.length === 0"
            :description="t('module.application-center.callRecords.listEmpty')"
          />
        </section>

        <section class="detail-panel">
          <div class="section-caption">
            <strong>{{ t('module.application-center.callRecords.detailTitle') }}</strong>
            <span>{{ selectedCallRecordId || t('module.application-center.callRecords.notSelected') }}</span>
          </div>

          <p v-if="callRecordDetailLoading" class="state-text">{{ t('module.application-center.loading.callRecordDetail') }}</p>
          <el-empty v-else-if="!callRecordDetail" :description="t('module.application-center.callRecords.detailEmpty')" />

          <div v-else class="detail-stack">
            <el-descriptions :column="2" border class="detail-grid">
              <el-descriptions-item :label="t('module.application-center.callRecords.field.result')">{{ callRecordDetail.result }}</el-descriptions-item>
              <el-descriptions-item :label="t('module.application-center.callRecords.field.eventTime')">{{ callRecordDetail.eventTime }}</el-descriptions-item>
              <el-descriptions-item :label="t('module.application-center.callRecords.field.requestMethod')">{{ display(callRecordDetail.requestMethod) }}</el-descriptions-item>
              <el-descriptions-item :label="t('module.application-center.callRecords.field.requestPath')">{{ display(callRecordDetail.requestPath) }}</el-descriptions-item>
              <el-descriptions-item label="Trace ID">{{ display(callRecordDetail.traceId) }}</el-descriptions-item>
              <el-descriptions-item label="Client ID">{{ display(callRecordDetail.clientId) }}</el-descriptions-item>
              <el-descriptions-item :label="t('module.application-center.callRecords.field.remoteAddress')">{{ display(callRecordDetail.remoteAddress) }}</el-descriptions-item>
              <el-descriptions-item label="User Agent">{{ display(callRecordDetail.userAgent) }}</el-descriptions-item>
              <el-descriptions-item label="Scope">{{ display(detailPayload.scope) }}</el-descriptions-item>
              <el-descriptions-item :label="t('module.application-center.callRecords.field.summary')" :span="2">{{ display(callRecordDetail.summary) }}</el-descriptions-item>
              <el-descriptions-item :label="t('module.application-center.callRecords.field.reason')" :span="2">{{ display(callRecordDetail.reason) }}</el-descriptions-item>
            </el-descriptions>

            <section v-if="detailPayload.requestQuery || detailPayload.requestBody" class="detail-card">
              <div class="detail-card__header">
                <h3>{{ t('module.application-center.callRecords.requestPayload') }}</h3>
                <el-button
                  circle
                  plain
                  :icon="CopyDocument"
                  @click="copyText([detailPayload.requestQuery, detailPayload.requestBody].filter(Boolean).join('\n\n'), t('module.application-center.callRecords.copy.request'))"
                />
              </div>
              <div class="detail-card__body">
                <div v-if="detailPayload.requestQuery" class="detail-block">
                  <strong>{{ t('module.application-center.callRecords.queryParams') }}</strong>
                  <pre>{{ detailPayload.requestQuery }}</pre>
                </div>
                <div v-if="detailPayload.requestBody" class="detail-block">
                  <strong>{{ t('module.application-center.callRecords.requestBody') }}</strong>
                  <pre>{{ detailPayload.requestBody }}</pre>
                </div>
              </div>
            </section>

            <section v-if="detailPayload.responseBody" class="detail-card">
              <div class="detail-card__header">
                <h3>{{ t('module.application-center.callRecords.responsePayload') }}</h3>
                <el-button circle plain :icon="CopyDocument" @click="copyText(detailPayload.responseBody, t('module.application-center.callRecords.copy.response'))" />
              </div>
              <pre>{{ detailPayload.responseBody }}</pre>
            </section>

            <section v-if="detailPayload.exceptionType || detailPayload.exceptionMessage || detailPayload.exceptionStack" class="detail-card">
              <div class="detail-card__header">
                <h3>{{ t('module.application-center.callRecords.exception') }}</h3>
                <el-button
                  circle
                  plain
                  :icon="CopyDocument"
                  @click="copyText([detailPayload.exceptionType, detailPayload.exceptionMessage, detailPayload.exceptionStack].filter(Boolean).join('\n'), t('module.application-center.callRecords.copy.exception'))"
                />
              </div>
              <div class="detail-card__body">
                <div v-if="detailPayload.exceptionType" class="detail-block">
                  <strong>{{ t('module.application-center.callRecords.exceptionType') }}</strong>
                  <pre>{{ detailPayload.exceptionType }}</pre>
                </div>
                <div v-if="detailPayload.exceptionMessage" class="detail-block">
                  <strong>{{ t('module.application-center.callRecords.exceptionMessage') }}</strong>
                  <pre>{{ detailPayload.exceptionMessage }}</pre>
                </div>
                <div v-if="detailPayload.exceptionStack" class="detail-block">
                  <strong>{{ t('module.application-center.callRecords.exceptionStack') }}</strong>
                  <pre>{{ detailPayload.exceptionStack }}</pre>
                </div>
              </div>
            </section>

            <section v-if="detailPayload.rawBusinessData" class="detail-card">
              <div class="detail-card__header">
                <h3>{{ t('module.application-center.callRecords.rawBusinessData') }}</h3>
                <el-button circle plain :icon="CopyDocument" @click="copyText(detailPayload.rawBusinessData, t('module.application-center.callRecords.copy.raw'))" />
              </div>
              <pre>{{ detailPayload.rawBusinessData }}</pre>
            </section>
          </div>
        </section>
      </div>
    </template>
  </el-card>
</template>

<style scoped>
.card {
  border: 1px solid var(--console-card-border, #e6ebf2);
  background: var(--console-card-bg, #ffffff);
}

.card-header,
.filter-row,
.section-caption {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
}

.card-header h2,
.card-header p,
.section-caption strong,
.section-caption span {
  margin: 0;
}

.card-header p,
.section-caption span,
.state-text {
  color: var(--console-text, #4a5a70);
}

.filter-row {
  margin-bottom: 16px;
}

.filter-row > * {
  flex: 1 1 0;
}

.call-record-layout {
  display: grid;
  grid-template-columns: minmax(0, 1.2fr) minmax(320px, 0.8fr);
  gap: 16px;
}

.list-panel,
.detail-panel,
.detail-stack {
  display: grid;
  gap: 12px;
}

.detail-card {
  padding: 14px 16px;
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: var(--console-block-radius, 8px);
  background: var(--console-block-bg, var(--console-card-bg, #ffffff));
}

.detail-card h3,
.detail-card pre {
  margin: 0;
}

.detail-card__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 8px;
}

.detail-card__body,
.detail-block {
  display: grid;
  gap: 8px;
}

.detail-block strong {
  color: var(--console-text, #4a5a70);
  font-size: 12px;
  font-weight: 700;
}

.detail-card h3 {
  color: var(--console-title, #172033);
  font-size: 14px;
}

.detail-card pre {
  overflow: auto;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: 'SFMono-Regular', 'Roboto Mono', monospace;
  font-size: 12px;
  line-height: 1.6;
}

.state-text {
  margin: 0;
  padding: 12px 0;
}

@media (max-width: 960px) {
  .filter-row,
  .call-record-layout,
  .card-header,
  .section-caption {
    display: grid;
  }
}
</style>
