import {
  createOptionRequest,
  loadBrickOptions,
  normalizeOptionItems,
  withAllOption,
} from '@wildbuck/core-option-frontend';
import { downloadTextFile } from '@wildbuck/core-ui-frontend/download';
import { showBrickStatus } from '@wildbuck/core-ui-frontend/status';
import { computed, onScopeDispose, reactive, ref } from 'vue';
import type {
  ApplicationCallRecordDetail,
  ApplicationCallRecordSummary,
  ApplicationAuthorizationDetail,
  ApplicationDetail,
  ApplicationSummary,
  ApplicationUpsertRequest,
  RotateApplicationSecretResult,
} from '../../../generated/types';
import {
  loadApplicationCallRecordDetail,
  loadApplicationCallRecords,
  loadApplicationAuthorizationDetail,
  loadApplicationDetail,
  loadApplications,
  loadImageResourceBlob,
  removeApplication,
  rotateSecret,
  saveApplicationAuthorizations,
  saveExistingApplication,
  saveNewApplication,
  uploadImageResource,
} from '../api/application';
import { resolveApplicationErrorMessage } from '../lib/application-errors';
import {
  buildAccessProfileFileName,
  buildAccessProfileMarkdown,
} from '../lib/application-export.js';
import {
  normalizeApplicationFormInput,
  validateApplicationForm,
} from '../lib/application-form.js';
import {
  listApplicationFilterChips,
  resolveEnabledFilterLabel,
} from '../lib/application-metrics.js';
import { copyTextToClipboard } from '../lib/application-clipboard.js';
import {
  applicationCenterUsageTracker,
} from '../../../usage-events';
import { useApplicationCenterI18n } from '../../../i18n.js';

type EditorMode = 'edit' | 'create';
type EnabledFilter = 'all' | 'enabled' | 'disabled';
type OptionItem = { label: string; value: string };

const APPLICATION_TYPE_OPTION_CODE = 'application_center_application_type';
const CALL_RECORD_RESULT_OPTION_CODE = 'application_center_call_record_result';
const FALLBACK_APPLICATION_TYPE_OPTIONS: OptionItem[] = [
  { label: 'OIDC Web', value: 'oidc_web' },
  { label: 'OIDC SPA', value: 'oidc_spa' },
  { label: 'Machine Client', value: 'machine_client' },
];
const APPLICATION_PAGE_SIZE_OPTIONS = [12, 24, 48];

export interface AuthorizationScopeRow {
  scope: string;
  description?: string;
  interfaceName: string;
  groupName: string;
  granted: boolean;
  httpMethod: string;
  pathPattern: string;
}

export function useApplicationWorkspace() {
  const { t, i18n } = useApplicationCenterI18n();

  function fallbackCallRecordResultOptions(): OptionItem[] {
    return [
      { label: t('module.application-center.result.all'), value: '' },
      { label: t('module.application-center.result.SUCCESS'), value: 'SUCCESS' },
      { label: t('module.application-center.result.FAILURE'), value: 'FAILURE' },
    ];
  }

  const applicationTypeOptions = ref<OptionItem[]>([...FALLBACK_APPLICATION_TYPE_OPTIONS]);
  const callRecordResultOptions = ref<OptionItem[]>(fallbackCallRecordResultOptions());
  const applications = ref<ApplicationSummary[]>([]);
  const total = ref(0);
  const keyword = ref('');
  const applicationTypeFilter = ref('');
  const enabledFilter = ref<EnabledFilter>('all');
  const page = ref(1);
  const pageSize = ref(12);
  const listLoading = ref(true);
  const detailLoading = ref(false);
  const saving = ref(false);
  const deleting = ref(false);
  const rotating = ref(false);
  const authorizationSaving = ref(false);
  const listError = ref('');
  const selectedApplicationId = ref('');
  const editorMode = ref<EditorMode>('edit');
  const currentDetail = ref<ApplicationDetail | null>(null);
  const authorizationDetail = ref<ApplicationAuthorizationDetail | null>(null);
  const callRecords = ref<ApplicationCallRecordSummary[]>([]);
  const callRecordTotal = ref(0);
  const callRecordLoading = ref(false);
  const callRecordDetailLoading = ref(false);
  const currentCallRecord = ref<ApplicationCallRecordDetail | null>(null);
  const selectedCallRecordId = ref('');
  const callRecordLoadedForApplicationId = ref('');
  const latestSecret = ref<RotateApplicationSecretResult | null>(null);
  const selectedScopes = ref<string[]>([]);
  const focusedScope = ref('');
  const redirectUrisText = ref('');
  const scopesText = ref('');
  const rotateReason = ref('');
  const logoPreviewUrl = ref('');
  const logoUploading = ref(false);
  const applicationLogoUrls = ref<Record<string, string>>({});
  const callRecordFilters = reactive({
    result: '',
    traceId: '',
    requestPathKeyword: '',
  });
  const logoObjectUrlLoads = new Map<string, Promise<string>>();
  let localLogoPreviewUrl = '';

  const form = reactive<ApplicationUpsertRequest>({
    applicationName: '',
    applicationCode: '',
    applicationType: 'machine_client',
    logoResourceId: undefined,
    description: '',
    enabled: true,
    redirectUris: [],
    scopes: [],
  });

  const selectedApplication = computed(() =>
    applications.value.find((item) => item.applicationId === selectedApplicationId.value) ?? null,
  );
  const pageSummary = computed(() => t('module.application-center.list.pageSummary', {
    count: applications.value.length,
    total: total.value,
  }));
  const canRotateSecret = computed(() => editorMode.value === 'edit' && Boolean(selectedApplicationId.value));
  const canDeleteApplication = computed(() => editorMode.value === 'edit' && Boolean(selectedApplicationId.value) && !deleting.value);
  const canSaveAuthorization = computed(
    () => editorMode.value === 'edit' && Boolean(selectedApplicationId.value) && !authorizationSaving.value,
  );
  const canExportAuthorization = computed(
    () => editorMode.value === 'edit' && Boolean(selectedApplicationId.value) && Boolean(authorizationDetail.value),
  );
  const selectedApplicationTypeLabel = computed(() => {
    return applicationTypeOptions.value.find((option) => option.value === form.applicationType)?.label || form.applicationType;
  });
  const authorizationRows = computed<AuthorizationScopeRow[]>(() => {
    const allowedScopes = new Set(selectedScopes.value);
    return (authorizationDetail.value?.openApiScopes || []).map((scopeEntry) => ({
      scope: scopeEntry.scope,
      description: scopeEntry.description,
      interfaceName: scopeEntry.interfaceName,
      groupName: scopeEntry.groupName,
      granted: allowedScopes.has(scopeEntry.scope),
      httpMethod: scopeEntry.httpMethod,
      pathPattern: scopeEntry.pathPattern,
    }));
  });

  async function initialize() {
    const routeIntent = consumeManagementRouteIntent('application-center.apps');
    const preferredApplicationId = routeIntent?.applicationId;
    focusedScope.value = routeIntent?.scope || '';
    await loadApplicationTypeOptions();
    await reloadApplications(preferredApplicationId);
    if (selectedApplicationId.value) {
      await selectApplication(selectedApplicationId.value);
    } else if (applications.value.length > 0) {
      await selectApplication(applications.value[0].applicationId);
    } else {
      startCreateApplication();
    }
  }

  async function loadApplicationTypeOptions() {
    try {
      const options = await loadBrickOptions([
        createOptionRequest(APPLICATION_TYPE_OPTION_CODE),
        createOptionRequest(CALL_RECORD_RESULT_OPTION_CODE),
      ]);
      const loadedOptions = normalizeOptionItems(options[APPLICATION_TYPE_OPTION_CODE]);
      applicationTypeOptions.value = loadedOptions.length > 0 ? loadedOptions : [...FALLBACK_APPLICATION_TYPE_OPTIONS];
      callRecordResultOptions.value = withAllOption(
        { label: t('module.application-center.result.all'), value: '' },
        normalizeOptionItems(options[CALL_RECORD_RESULT_OPTION_CODE]),
        fallbackCallRecordResultOptions(),
      );
    } catch {
      applicationTypeOptions.value = [...FALLBACK_APPLICATION_TYPE_OPTIONS];
      callRecordResultOptions.value = fallbackCallRecordResultOptions();
    }
  }

  async function reloadApplications(preferredId?: string, actionCode?: 'search' | 'reset-filters') {
    listLoading.value = true;
    listError.value = '';
    try {
      const response = await loadApplications({
        keyword: keyword.value.trim() || undefined,
        applicationType: applicationTypeFilter.value || undefined,
        enabled: enabledFilter.value === 'all' ? undefined : enabledFilter.value === 'enabled',
        page: page.value,
        size: pageSize.value,
      });
      applications.value = response.records || [];
      total.value = response.total || 0;
      if (preferredId && applications.value.some((item) => item.applicationId === preferredId)) {
        selectedApplicationId.value = preferredId;
      } else if (!applications.value.some((item) => item.applicationId === selectedApplicationId.value)) {
        selectedApplicationId.value = applications.value[0]?.applicationId || '';
      }
      await syncVisibleApplicationLogoUrls();
      trackApplicationListActionResult(actionCode, true);
    } catch (error) {
      applications.value = [];
      total.value = 0;
      selectedApplicationId.value = '';
      listError.value = resolveApplicationErrorMessage(error, i18n);
      trackApplicationListActionResult(actionCode, false);
    } finally {
      listLoading.value = false;
    }
  }

  async function submitSearch() {
    page.value = 1;
    await reloadApplications(undefined, 'search');
    if (selectedApplicationId.value) {
      await selectApplication(selectedApplicationId.value);
    } else {
      startCreateApplication();
    }
  }

  async function resetFilters() {
    keyword.value = '';
    applicationTypeFilter.value = '';
    enabledFilter.value = 'all';
    page.value = 1;
    await reloadApplications(undefined, 'reset-filters');
    if (selectedApplicationId.value) {
      await selectApplication(selectedApplicationId.value);
    } else {
      startCreateApplication();
    }
  }

  async function changePage(nextPage: number) {
    if (nextPage < 1 || nextPage === page.value) {
      return;
    }
    page.value = nextPage;
    await reloadApplications();
    if (selectedApplicationId.value) {
      await selectApplication(selectedApplicationId.value);
    }
  }

  async function changePageSize(nextSize: number) {
    if (nextSize < 1 || nextSize === pageSize.value) {
      return;
    }
    pageSize.value = nextSize;
    page.value = 1;
    await reloadApplications();
    if (selectedApplicationId.value) {
      await selectApplication(selectedApplicationId.value);
    }
  }

  async function selectApplication(applicationId: string) {
    if (!applicationId) {
      return false;
    }
    selectedApplicationId.value = applicationId;
    editorMode.value = 'edit';
    detailLoading.value = true;
    latestSecret.value = null;
    resetCallRecordState();
    try {
      const [detail, authorization] = await Promise.all([
        loadApplicationDetail(applicationId),
        loadApplicationAuthorizationDetail(applicationId),
      ]);
      currentDetail.value = detail;
      authorizationDetail.value = authorization;
      selectedScopes.value = [...authorization.assignedScopes];
      fillForm(detail);
      return true;
    } catch (error) {
      showBrickStatus(resolveApplicationErrorMessage(error, i18n), 'error');
      return false;
    } finally {
      detailLoading.value = false;
    }
  }

  function startCreateApplication() {
    editorMode.value = 'create';
    selectedApplicationId.value = '';
    currentDetail.value = null;
    authorizationDetail.value = null;
    selectedScopes.value = [];
    focusedScope.value = '';
    latestSecret.value = null;
    resetCallRecordState();
    fillForm({
      applicationId: '',
      applicationName: '',
      applicationCode: '',
      applicationType: 'machine_client',
      logoResourceId: undefined,
      description: '',
      enabled: true,
      clientId: '',
      redirectUris: [],
      scopes: ['openapi.read'],
    });
  }

  async function submitForm() {
    const actionCode = resolveSubmitActionCode();
    const payload = normalizeForm();
    const validation = validateApplicationForm(payload);
    if (!validation.valid) {
      if (validation.errors.includes('redirectUris')) {
        showBrickStatus(t('module.application-center.validation.redirectUris', {
          values: validation.redirectUris.invalid.join(', '),
        }), 'error');
      } else if (validation.errors.includes('scopes')) {
        showBrickStatus(t('module.application-center.validation.scopes', {
          values: validation.scopes.invalid.join(', '),
        }), 'error');
      } else {
        showBrickStatus(t('module.application-center.validation.required'), 'error');
      }
      void applicationCenterUsageTracker.trackActionResult('applicationProfile', actionCode, 'FAILURE');
      return false;
    }
    saving.value = true;
    try {
      const detail =
        editorMode.value === 'create'
          ? await saveNewApplication(payload)
          : await saveExistingApplication(selectedApplicationId.value, payload);
      await reloadApplications(detail.applicationId);
      await selectApplication(detail.applicationId);
      void applicationCenterUsageTracker.trackActionResult('applicationProfile', actionCode, 'SUCCESS');
      showBrickStatus(t('module.application-center.status.saved', { name: detail.applicationName }), 'success');
      return true;
    } catch (error) {
      void applicationCenterUsageTracker.trackActionResult('applicationProfile', actionCode, 'FAILURE');
      showBrickStatus(resolveApplicationErrorMessage(error, i18n), 'error');
      return false;
    } finally {
      saving.value = false;
    }
  }

  async function uploadApplicationLogo(file: File) {
    logoUploading.value = true;
    try {
      const uploaded = await uploadImageResource(file);
      form.logoResourceId = uploaded.resourceId;
      replaceLocalLogoPreview(window.URL.createObjectURL(file));
      showBrickStatus(t('module.application-center.status.logoUploaded'), 'success');
    } catch (error) {
      showBrickStatus(resolveApplicationErrorMessage(error, i18n), 'error');
    } finally {
      logoUploading.value = false;
    }
  }

  function clearApplicationLogo() {
    form.logoResourceId = undefined;
    releaseLocalLogoPreview();
    logoPreviewUrl.value = '';
  }

  async function rotateApplicationSecret() {
    if (!selectedApplicationId.value || editorMode.value !== 'edit') {
      return;
    }
    if (typeof window !== 'undefined') {
      const confirmed = window.confirm(t('module.application-center.credentials.rotateConfirm'));
      if (!confirmed) {
        void applicationCenterUsageTracker.trackActionResult('applicationSecret', 'rotate-secret', 'FAILURE');
        return;
      }
    }
    rotating.value = true;
    try {
      latestSecret.value = await rotateSecret(selectedApplicationId.value, {
        reason: rotateReason.value.trim() || undefined,
      });
      rotateReason.value = '';
      void applicationCenterUsageTracker.trackActionResult('applicationSecret', 'rotate-secret', 'SUCCESS');
      showBrickStatus(t('module.application-center.status.secretRotated', {
        name: currentDetail.value?.applicationName || selectedApplication.value?.applicationName || '',
      }), 'success');
    } catch (error) {
      void applicationCenterUsageTracker.trackActionResult('applicationSecret', 'rotate-secret', 'FAILURE');
      showBrickStatus(resolveApplicationErrorMessage(error, i18n), 'error');
    } finally {
      rotating.value = false;
    }
  }

  async function copyCredential(value: string | undefined, labelKey: string) {
    const label = t(labelKey);
    const result = await copyTextToClipboard(value);
    if (result.ok) {
      showBrickStatus(t('module.application-center.copy.success', { label }), 'success');
      return;
    }
    if (result.reason === 'empty') {
      return;
    }
    showBrickStatus(t('module.application-center.copy.unsupported', { label }), 'error');
  }

  async function submitAuthorizations() {
    if (!selectedApplicationId.value || editorMode.value !== 'edit') {
      return;
    }
    authorizationSaving.value = true;
    try {
      await saveApplicationAuthorizations(selectedApplicationId.value, {
        scopes: [...selectedScopes.value],
      });
      authorizationDetail.value = await loadApplicationAuthorizationDetail(selectedApplicationId.value);
      selectedScopes.value = [...(authorizationDetail.value?.assignedScopes || [])];
      void applicationCenterUsageTracker.trackActionResult('applicationAuthorization', 'save-authorization', 'SUCCESS');
      showBrickStatus(t('module.application-center.status.authorizationSaved', {
        name: currentDetail.value?.applicationName || selectedApplication.value?.applicationName || '',
      }), 'success');
    } catch (error) {
      void applicationCenterUsageTracker.trackActionResult('applicationAuthorization', 'save-authorization', 'FAILURE');
      showBrickStatus(resolveApplicationErrorMessage(error, i18n), 'error');
    } finally {
      authorizationSaving.value = false;
    }
  }

  async function deleteCurrentApplication() {
    if (!selectedApplicationId.value || editorMode.value !== 'edit') {
      return false;
    }
    deleting.value = true;
    const deletedName = currentDetail.value?.applicationName || selectedApplication.value?.applicationName || selectedApplicationId.value;
    try {
      await removeApplication(selectedApplicationId.value);
      await reloadApplications();
      if (applications.value.length > 0) {
        await selectApplication(applications.value[0].applicationId);
      } else {
        startCreateApplication();
      }
      void applicationCenterUsageTracker.trackActionResult('applicationProfile', 'delete', 'SUCCESS');
      showBrickStatus(t('module.application-center.status.deleted', { name: deletedName }), 'success');
      return true;
    } catch (error) {
      void applicationCenterUsageTracker.trackActionResult('applicationProfile', 'delete', 'FAILURE');
      showBrickStatus(resolveApplicationErrorMessage(error, i18n), 'error');
      return false;
    } finally {
      deleting.value = false;
    }
  }

  async function ensureCallRecordsLoaded() {
    if (!selectedApplicationId.value || editorMode.value !== 'edit') {
      return;
    }
    if (callRecordLoadedForApplicationId.value === selectedApplicationId.value && callRecords.value.length > 0) {
      return;
    }
    await refreshCallRecords();
  }

  async function refreshCallRecords() {
    if (!selectedApplicationId.value || editorMode.value !== 'edit') {
      return;
    }
    callRecordLoading.value = true;
    try {
      const page = await loadApplicationCallRecords(selectedApplicationId.value, {
        page: 1,
        size: 20,
        result: emptyToUndefined(callRecordFilters.result),
        traceId: emptyToUndefined(callRecordFilters.traceId),
        requestPathKeyword: emptyToUndefined(callRecordFilters.requestPathKeyword),
      });
      callRecords.value = page.records || [];
      callRecordTotal.value = page.total || 0;
      callRecordLoadedForApplicationId.value = selectedApplicationId.value;
      if (callRecords.value.length === 0) {
        selectedCallRecordId.value = '';
        currentCallRecord.value = null;
        void applicationCenterUsageTracker.trackActionResult('applicationCallRecord', 'search', 'SUCCESS');
        return;
      }
      const preferredRecordId = callRecords.value.some((item) => item.callRecordId === selectedCallRecordId.value)
        ? selectedCallRecordId.value
        : callRecords.value[0].callRecordId;
      await selectCallRecord(preferredRecordId);
      void applicationCenterUsageTracker.trackActionResult('applicationCallRecord', 'search', 'SUCCESS');
    } catch (error) {
      void applicationCenterUsageTracker.trackActionResult('applicationCallRecord', 'search', 'FAILURE');
      showBrickStatus(resolveApplicationErrorMessage(error, i18n), 'error');
    } finally {
      callRecordLoading.value = false;
    }
  }

  async function selectCallRecord(callRecordId: string) {
    if (!selectedApplicationId.value || !callRecordId || editorMode.value !== 'edit') {
      return;
    }
    selectedCallRecordId.value = callRecordId;
    callRecordDetailLoading.value = true;
    try {
      currentCallRecord.value = await loadApplicationCallRecordDetail(selectedApplicationId.value, callRecordId);
      void applicationCenterUsageTracker.trackOpen('applicationCallRecord', 'open-detail');
    } catch (error) {
      void applicationCenterUsageTracker.trackOpen('applicationCallRecord', 'open-detail', 'FAILURE');
      showBrickStatus(resolveApplicationErrorMessage(error, i18n), 'error');
    } finally {
      callRecordDetailLoading.value = false;
    }
  }

  function exportAccessProfile() {
    if (!canExportAuthorization.value || !authorizationDetail.value || !currentDetail.value) {
      return;
    }
    const scopesValue = currentDetail.value.scopes.join(', ') || t('module.application-center.export.scopesNone');
    const exportedAt = new Date().toLocaleString(undefined, { hour12: false });
    const markdown = buildAccessProfileMarkdown(currentDetail.value, {
      typeLabel: selectedApplicationTypeLabel.value,
      grantedRows: authorizationRows.value,
      ungroupedLabel: t('module.application-center.authorization.ungrouped'),
      exportedAt,
      labels: {
        title: t('module.application-center.export.title', { name: currentDetail.value.applicationName }),
        appName: t('module.application-center.export.appName', { value: currentDetail.value.applicationName }),
        appCode: t('module.application-center.export.appCode', { value: currentDetail.value.applicationCode }),
        appType: t('module.application-center.export.appType', { value: selectedApplicationTypeLabel.value }),
        exportedAt: t('module.application-center.export.exportedAt', { value: exportedAt }),
        scopes: t('module.application-center.export.scopes', { value: scopesValue }),
        section: t('module.application-center.export.section'),
        tableHeader: t('module.application-center.export.tableHeader'),
        scopesNone: t('module.application-center.export.scopesNone'),
      },
    });
    const ok = downloadTextFile(markdown, buildAccessProfileFileName(currentDetail.value));
    void applicationCenterUsageTracker.trackActionResult(
      'applicationAuthorization',
      'export-authorization',
      ok ? 'SUCCESS' : 'FAILURE',
    );
    if (!ok) {
      showBrickStatus(t('module.application-center.export.failed'), 'error');
    }
  }

  const activeFilterChips = computed(() => {
    const typeLabel = applicationTypeOptions.value.find((item) => item.value === applicationTypeFilter.value)?.label
      || applicationTypeFilter.value;
    return listApplicationFilterChips(
      {
        keyword: keyword.value,
        applicationType: applicationTypeFilter.value,
        enabled: enabledFilter.value,
      },
      {
        keyword: t('module.application-center.filter.keywordLabel'),
        applicationType: t('module.application-center.filter.typeLabel'),
        enabled: t('module.application-center.filter.statusLabel'),
      },
    ).map((chip) => {
      if (chip.key === 'applicationType') {
        return { ...chip, value: typeLabel || chip.value };
      }
      if (chip.key === 'enabled') {
        return { ...chip, value: resolveEnabledFilterLabel(enabledFilter.value, t) };
      }
      return chip;
    });
  });

  async function clearFilterChip(key: string) {
    if (key === 'keyword') {
      keyword.value = '';
    } else if (key === 'applicationType') {
      applicationTypeFilter.value = '';
    } else if (key === 'enabled') {
      enabledFilter.value = 'all';
    }
    page.value = 1;
    await submitSearch();
  }

  function fillForm(detail: ApplicationDetail) {
    form.applicationName = detail.applicationName;
    form.applicationCode = detail.applicationCode;
    form.applicationType = detail.applicationType;
    form.logoResourceId = detail.logoResourceId;
    form.description = detail.description || '';
    form.enabled = detail.enabled;
    form.redirectUris = [...detail.redirectUris];
    form.scopes = [...detail.scopes];
    void syncLogoPreview(detail.logoResourceId);
    redirectUrisText.value = detail.redirectUris.join('\n');
    scopesText.value = detail.scopes.join('\n');
  }

  function normalizeForm(): ApplicationUpsertRequest {
    return normalizeApplicationFormInput({
      applicationName: form.applicationName,
      applicationCode: form.applicationCode,
      applicationType: form.applicationType,
      logoResourceId: form.logoResourceId,
      description: form.description,
      enabled: form.enabled,
      redirectUrisText: redirectUrisText.value,
      scopesText: scopesText.value,
    });
  }

  function resolveSubmitActionCode() {
    if (editorMode.value === 'create') {
      return 'create';
    }
    if (currentDetail.value && currentDetail.value.enabled !== Boolean(form.enabled)) {
      return form.enabled ? 'enable' : 'disable';
    }
    return 'update';
  }

  function resetCallRecordState() {
    callRecords.value = [];
    callRecordTotal.value = 0;
    callRecordLoading.value = false;
    callRecordDetailLoading.value = false;
    currentCallRecord.value = null;
    selectedCallRecordId.value = '';
    callRecordLoadedForApplicationId.value = '';
    callRecordFilters.result = '';
    callRecordFilters.traceId = '';
    callRecordFilters.requestPathKeyword = '';
  }

  async function createLogoObjectUrl(resourceId: string): Promise<string> {
    const blob = await loadImageResourceBlob(resourceId);
    return window.URL.createObjectURL(blob);
  }

  async function syncLogoPreview(logoResourceId?: string) {
    if (!logoResourceId) {
      releaseLocalLogoPreview();
      logoPreviewUrl.value = '';
      return;
    }
    try {
      releaseLocalLogoPreview();
      logoPreviewUrl.value = await ensureApplicationLogoUrl(logoResourceId);
    } catch {
      logoPreviewUrl.value = '';
    }
  }

  async function syncVisibleApplicationLogoUrls() {
    const resourceIds = [...new Set(
      applications.value
        .map((item) => item.logoResourceId)
        .filter((resourceId): resourceId is string => Boolean(resourceId)),
    )];
    await Promise.allSettled(resourceIds.map((resourceId) => ensureApplicationLogoUrl(resourceId)));
  }

  async function ensureApplicationLogoUrl(resourceId: string): Promise<string> {
    const cached = applicationLogoUrls.value[resourceId];
    if (cached) {
      return cached;
    }
    const pending = logoObjectUrlLoads.get(resourceId);
    if (pending) {
      return pending;
    }
    const loading = createLogoObjectUrl(resourceId)
      .then((url) => {
        applicationLogoUrls.value = {
          ...applicationLogoUrls.value,
          [resourceId]: url,
        };
        logoObjectUrlLoads.delete(resourceId);
        return url;
      })
      .catch((error) => {
        logoObjectUrlLoads.delete(resourceId);
        throw error;
      });
    logoObjectUrlLoads.set(resourceId, loading);
    return loading;
  }

  function replaceLocalLogoPreview(url: string) {
    releaseLocalLogoPreview();
    localLogoPreviewUrl = url;
    logoPreviewUrl.value = url;
  }

  function releaseLocalLogoPreview() {
    if (!localLogoPreviewUrl) {
      return;
    }
    window.URL.revokeObjectURL(localLogoPreviewUrl);
    if (logoPreviewUrl.value === localLogoPreviewUrl) {
      logoPreviewUrl.value = '';
    }
    localLogoPreviewUrl = '';
  }

  onScopeDispose(() => {
    releaseLocalLogoPreview();
    for (const url of Object.values(applicationLogoUrls.value)) {
      window.URL.revokeObjectURL(url);
    }
    applicationLogoUrls.value = {};
  });

  return {
    activeFilterChips,
    applicationTypeFilter,
    applicationTypeOptions,
    applications,
    authorizationRows,
    authorizationDetail,
    authorizationSaving,
    callRecordDetailLoading,
    callRecordFilters,
    callRecordLoading,
    callRecordResultOptions,
    callRecordTotal,
    callRecords,
    canDeleteApplication,
    canExportAuthorization,
    canRotateSecret,
    canSaveAuthorization,
    changePage,
    changePageSize,
    clearFilterChip,
    copyCredential,
    currentCallRecord,
    currentDetail,
    detailLoading,
    deleteCurrentApplication,
    deleting,
    editorMode,
    enabledFilter,
    ensureCallRecordsLoaded,
    exportAccessProfile,
    focusedScope,
    form,
    initialize,
    keyword,
    latestSecret,
    applicationLogoUrls,
    listError,
    listLoading,
    logoPreviewUrl,
    logoUploading,
    page,
    pageSize,
    pageSizeOptions: APPLICATION_PAGE_SIZE_OPTIONS,
    pageSummary,
    redirectUrisText,
    reloadApplications,
    resetFilters,
    rotateApplicationSecret,
    rotateReason,
    rotating,
    saving,
    scopesText,
    selectCallRecord,
    selectApplication,
    selectedCallRecordId,
    selectedApplication,
    selectedApplicationId,
    selectedApplicationTypeLabel,
    selectedScopes,
    startCreateApplication,
    submitAuthorizations,
    submitForm,
    submitSearch,
    total,
    refreshCallRecords,
    clearApplicationLogo,
    uploadApplicationLogo,
  };
}

function trackApplicationListActionResult(actionCode: 'search' | 'reset-filters' | undefined, success: boolean) {
  if (!actionCode) {
    return;
  }
  void applicationCenterUsageTracker.trackActionResult('applicationList', actionCode, success ? 'SUCCESS' : 'FAILURE');
}

function emptyToUndefined(value?: string): string | undefined {
  return value && value.trim() ? value.trim() : undefined;
}

function consumeManagementRouteIntent(expectedRouteId: string): Record<string, string> | null {
  if (typeof window === 'undefined') {
    return null;
  }
  const raw = window.sessionStorage.getItem('brick.management.intent');
  if (!raw) {
    return null;
  }
  try {
    const parsed = JSON.parse(raw);
    if (parsed?.routeId !== expectedRouteId || !parsed.selection || typeof parsed.selection !== 'object') {
      return null;
    }
    return parsed.selection;
  } catch {
    return null;
  } finally {
    window.sessionStorage.removeItem('brick.management.intent');
  }
}
