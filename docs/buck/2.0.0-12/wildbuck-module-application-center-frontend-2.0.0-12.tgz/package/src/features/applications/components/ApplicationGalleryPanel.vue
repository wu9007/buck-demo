<script setup lang="ts">
import { BrickPaginationBar } from '@wildbuck/core-ui-frontend/patterns';
import type { ApplicationSummary } from '../../../generated/types';
import { useApplicationCenterI18n } from '../../../i18n.js';
import {
  resolveApplicationLogoText,
  resolveApplicationTypeLabel,
} from '../lib/application-identity.js';

const props = defineProps<{
  applications: ApplicationSummary[];
  applicationLogoUrls: Record<string, string>;
  applicationTypeOptions: Array<{ label: string; value: string }>;
  listError: string;
  listLoading: boolean;
  page: number;
  pageSize: number;
  pageSizeOptions: number[];
  pageSummary: string;
  selectedApplicationId: string;
  total: number;
}>();

defineEmits<{
  select: [applicationId: string];
  'update:page': [value: number];
  'update:pageSize': [value: number];
}>();

const { t } = useApplicationCenterI18n();

function resolveTypeLabel(applicationType: string) {
  return resolveApplicationTypeLabel(applicationType, props.applicationTypeOptions);
}

function resolveLogoText(applicationName: string, applicationCode: string) {
  return resolveApplicationLogoText(applicationName, applicationCode);
}

function resolveLogoUrl(logoResourceId?: string) {
  return logoResourceId ? props.applicationLogoUrls[logoResourceId] || '' : '';
}
</script>

<template>
  <el-card shadow="never" class="card" data-guide-anchor="list">
    <template #header>
      <div class="card-header">
        <div>
          <h2>{{ t('module.application-center.list.title') }}</h2>
          <p>{{ t('module.application-center.list.description', { summary: pageSummary }) }}</p>
        </div>
        <span class="summary-chip">{{ t('module.application-center.list.recordCount', { count: applications.length }) }}</span>
      </div>
    </template>

    <p v-if="listError" class="state-text state-error">{{ listError }}</p>
    <p v-else-if="listLoading" class="state-text">{{ t('module.application-center.loading.list') }}</p>

    <div v-else class="list-stack">
      <button
        v-for="application in applications"
        :key="application.applicationId"
        type="button"
        class="application-card"
        :class="{
          'is-active': selectedApplicationId === application.applicationId,
          'is-disabled-app': !application.enabled,
        }"
        @click="$emit('select', application.applicationId)"
      >
        <div class="application-card__top">
          <div class="application-card__identity">
            <div class="application-card__logo" aria-hidden="true">
              <img
                v-if="resolveLogoUrl(application.logoResourceId)"
                :src="resolveLogoUrl(application.logoResourceId)"
                :alt="`${application.applicationName} logo`"
                class="application-card__logo-image"
              />
              <span v-else>{{ resolveLogoText(application.applicationName, application.applicationCode) }}</span>
            </div>
            <div>
              <strong>{{ application.applicationName }}</strong>
              <p>{{ application.applicationCode }}</p>
            </div>
          </div>
          <el-tag :type="application.enabled ? 'success' : 'warning'" effect="plain" round>
            {{ application.enabled ? t('module.application-center.list.enabled') : t('module.application-center.list.disabled') }}
          </el-tag>
        </div>

        <div class="application-card__body">
          <div class="application-card__caption">
            <span>{{ t('module.application-center.list.typeLabel') }}</span>
            <strong>{{ resolveTypeLabel(application.applicationType) }}</strong>
          </div>
        </div>

        <div class="application-card__footer">
          <span>{{ t('module.application-center.list.openDetail') }}</span>
        </div>
      </button>

      <el-empty
        v-if="applications.length === 0"
        :description="t('module.application-center.list.empty')"
      />
    </div>

    <BrickPaginationBar
      :page="page"
      :page-size="pageSize"
      :page-sizes="pageSizeOptions"
      :summary="pageSummary"
      :total="total"
      @update:page="$emit('update:page', $event)"
      @update:page-size="$emit('update:pageSize', $event)"
    />
  </el-card>
</template>

<style scoped>
.card {
  border: 1px solid var(--console-card-border, #e6ebf2);
  background: var(--console-card-bg, #ffffff);
}

.card-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
}

.card-header h2,
.card-header p {
  margin: 0;
}

.card-header h2 {
  color: var(--console-title, #172033);
  font-size: 18px;
}

.card-header p {
  margin-top: 6px;
  color: var(--console-text, #4a5a70);
  font-size: 13px;
}

.summary-chip {
  display: inline-flex;
  align-items: center;
  padding: 8px 12px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 700;
}

.summary-chip {
  border: 1px solid var(--console-card-border, #e6ebf2);
  color: var(--console-text, #4a5a70);
  background: var(--console-card-bg, #ffffff);
}

.list-stack {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: var(--console-card-header-y, 14px);
  padding: var(--console-card-body-y, 18px) var(--console-card-body-x, 18px);
}

.application-card {
  display: grid;
  gap: 10px;
  min-height: 132px;
  padding: var(--console-card-header-y, 14px);
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: var(--console-card-radius, 8px);
  background: var(--console-card-bg, #ffffff);
  text-align: left;
  cursor: pointer;
  transition: border-color 0.16s ease, background 0.16s ease;
}

.application-card:hover,
.application-card.is-active {
  border-color: var(--console-field-hover-border, var(--console-primary, #188168));
  background: var(--console-block-bg, var(--console-card-bg, #ffffff));
}

.application-card.is-disabled-app {
  opacity: 0.78;
  background: var(--console-page-bg, #f6f8f8);
}

.application-card__top,
.application-card__footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.application-card__identity {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}

.application-card__logo {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  flex: 0 0 44px;
  width: 44px;
  height: 44px;
  border: 1px solid rgba(24, 129, 104, 0.14);
  border-radius: var(--console-field-radius, 6px);
  color: var(--console-primary, #188168);
  background: var(--console-accent-soft, rgba(24, 129, 104, 0.08));
  font-size: 12px;
  font-weight: 800;
  letter-spacing: 0.04em;
}

.application-card__logo-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.application-card__identity strong,
.application-card__identity p {
  margin: 0;
}

.application-card__identity strong {
  color: var(--console-title, #172033);
  font-size: 14px;
}

.application-card__identity p {
  margin-top: 4px;
  color: var(--console-text, #4a5a70);
  font-size: 12px;
  line-height: 1.4;
  word-break: break-all;
}

.application-card__body {
  display: grid;
  align-content: start;
  gap: 6px;
}

.application-card__caption {
  display: grid;
  gap: 4px;
}

.application-card__caption span {
  color: var(--console-muted, #7e8ba0);
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.application-card__caption strong {
  color: var(--console-title, #172033);
  font-size: 13px;
}

.application-card__footer {
  margin-top: auto;
  padding-top: 2px;
  color: var(--console-muted, #7e8ba0);
  font-size: 12px;
  font-weight: 700;
}

.card :deep(.el-card__header) {
  padding: var(--console-card-header-y, 14px) var(--console-card-header-x, 18px);
  border-bottom: 1px solid var(--console-card-border, #e6ebf2);
}

.card :deep(.el-card__body) {
  padding: 0;
}

.card :deep(.el-tag) {
  font-weight: 700;
}

.state-text {
  margin: 0;
  padding: var(--console-card-body-y, 18px) var(--console-card-body-x, 18px);
  color: var(--console-text, #4a5a70);
}

.state-error {
  color: var(--console-danger, #b4232f);
}

.state-empty {
  grid-column: 1 / -1;
  padding: 6px 0;
}

@media (max-width: 760px) {
  .card-header {
    display: grid;
  }

  .list-stack {
    grid-template-columns: 1fr;
  }

  .application-card {
    min-height: 0;
  }

  .application-card__top,
  .application-card__footer {
    align-items: flex-start;
    flex-direction: column;
  }
}
</style>
