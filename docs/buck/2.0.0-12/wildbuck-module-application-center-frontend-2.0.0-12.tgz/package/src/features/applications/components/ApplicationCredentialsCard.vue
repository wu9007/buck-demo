<script setup lang="ts">
import type { ApplicationDetail, RotateApplicationSecretResult } from '../../../generated/types';
import { useApplicationCenterI18n } from '../../../i18n.js';

defineProps<{
  canRotateSecret: boolean;
  currentDetail: ApplicationDetail | null;
  latestSecret: RotateApplicationSecretResult | null;
  rotateReason: string;
  rotating: boolean;
}>();

defineEmits<{
  'copy-client-id': [];
  'copy-secret': [];
  rotate: [];
  'update:rotateReason': [value: string];
}>();

const { t } = useApplicationCenterI18n();
</script>

<template>
  <el-card shadow="never" class="card" data-guide-anchor="credentials">
    <template #header>
      <div class="card-header">
        <div>
          <h2>{{ t('module.application-center.credentials.title') }}</h2>
          <p>{{ t('module.application-center.credentials.description') }}</p>
        </div>
        <el-button type="warning" plain :disabled="!canRotateSecret" :loading="rotating" @click="$emit('rotate')">
          {{ t('module.application-center.credentials.rotate') }}
        </el-button>
      </div>
    </template>

    <div class="credential-grid">
      <div class="credential-item">
        <span class="credential-label">Client ID</span>
        <div class="credential-value-row">
          <strong>{{ currentDetail?.clientId || t('module.application-center.credentials.clientIdPending') }}</strong>
          <el-button
            v-if="currentDetail?.clientId"
            link
            type="primary"
            @click="$emit('copy-client-id')"
          >
            {{ t('module.application-center.common.copy') }}
          </el-button>
        </div>
      </div>

      <div class="field-block">
        <span>{{ t('module.application-center.credentials.rotateReason') }}</span>
        <el-input
          :model-value="rotateReason"
          :aria-label="t('module.application-center.credentials.rotateReason')"
          maxlength="200"
          :placeholder="t('module.application-center.credentials.rotateReasonPlaceholder')"
          @update:model-value="$emit('update:rotateReason', $event || '')"
        />
      </div>
    </div>

    <div v-if="latestSecret" class="secret-result" role="status">
      <p class="secret-warning">{{ t('module.application-center.credentials.secretWarning') }}</p>
      <el-descriptions :column="1" border>
        <el-descriptions-item label="Client ID">
          <div class="credential-value-row">
            <span>{{ latestSecret.clientId }}</span>
            <el-button link type="primary" @click="$emit('copy-client-id')">{{ t('module.application-center.common.copy') }}</el-button>
          </div>
        </el-descriptions-item>
        <el-descriptions-item label="Client Secret">
          <div class="credential-value-row">
            <span class="secret-value">{{ latestSecret.clientSecret }}</span>
            <el-button link type="primary" @click="$emit('copy-secret')">{{ t('module.application-center.common.copy') }}</el-button>
          </div>
        </el-descriptions-item>
        <el-descriptions-item :label="t('module.application-center.credentials.rotatedAt')">
          {{ latestSecret.rotatedAt }}
        </el-descriptions-item>
      </el-descriptions>
    </div>
  </el-card>
</template>

<style scoped>
.card {
  border: 1px solid var(--console-card-border, #e6ebf2);
  background: var(--console-card-bg, #ffffff);
}

.card-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
}

.card-header h2,
.card-header p {
  margin: 0;
}

.card-header p {
  margin-top: 6px;
  color: var(--console-text, #4a5a70);
}

.card :deep(.el-card__header) {
  padding: var(--console-card-header-y, 14px) var(--console-card-header-x, 18px);
  border-bottom: 1px solid var(--console-card-border, #e6ebf2);
}

.card :deep(.el-card__body) {
  padding: var(--console-card-body-y, 18px) var(--console-card-body-x, 18px);
}

.credential-grid {
  display: grid;
  grid-template-columns: 1fr 1.3fr;
  gap: 18px;
  align-items: end;
}

.credential-item,
.field-block {
  display: grid;
  gap: 8px;
}

.credential-label,
.field-block span {
  color: var(--console-text, #4a5a70);
  font-size: 13px;
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.credential-item strong {
  color: var(--console-title, #172033);
  font-size: 18px;
  line-height: 1.4;
  word-break: break-all;
}

.credential-value-row {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  flex-wrap: wrap;
}

.card-header :deep(.el-button) {
  min-height: 42px;
  padding: 0 18px;
  border-radius: 999px;
  font-weight: 700;
}

.secret-result {
  margin-top: 24px;
  padding: var(--console-card-body-y, 18px) var(--console-card-body-x, 18px);
  border: 1px solid rgba(183, 108, 0, 0.18);
  border-radius: var(--console-card-radius, 8px);
  background: var(--console-warning-soft, rgba(183, 108, 0, 0.10));
}

.secret-warning {
  margin: 0 0 14px;
  color: var(--console-warning, #b76c00);
  font-weight: 700;
}

.secret-value {
  word-break: break-all;
  font-family: 'SFMono-Regular', 'Roboto Mono', monospace;
}

@media (max-width: 760px) {
  .card-header,
  .credential-grid {
    display: grid;
  }
}
</style>
