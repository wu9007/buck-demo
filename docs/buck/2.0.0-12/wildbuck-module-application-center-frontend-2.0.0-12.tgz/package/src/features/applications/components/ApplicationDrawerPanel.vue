<script setup lang="ts">
import { BrickConsoleDrawer } from '@wildbuck/core-ui-frontend/shell';
import type {
  ApplicationCallRecordDetail,
  ApplicationCallRecordSummary,
  ApplicationAuthorizationDetail,
  ApplicationDetail,
  ApplicationSummary,
  ApplicationUpsertRequest,
  RotateApplicationSecretResult,
} from '../../../generated/types';
import ApplicationCallRecordCard from './ApplicationCallRecordCard.vue';
import ApplicationAuthorizationCard from './ApplicationAuthorizationCard.vue';
import ApplicationCredentialsCard from './ApplicationCredentialsCard.vue';
import ApplicationProfileCard from './ApplicationProfileCard.vue';
import { useApplicationCenterI18n } from '../../../i18n.js';

type OptionItem = { label: string; value: string };

defineProps<{
  activeTab: string;
  applicationTypeOptions: OptionItem[];
  callRecordDetail: ApplicationCallRecordDetail | null;
  callRecordDetailLoading: boolean;
  callRecordLoading: boolean;
  callRecordResultOptions: OptionItem[];
  callRecordTotal: number;
  callRecords: ApplicationCallRecordSummary[];
  authorizationDetail: ApplicationAuthorizationDetail | null;
  authorizationSaving: boolean;
  canDeleteApplication: boolean;
  canExportAuthorization: boolean;
  canRotateSecret: boolean;
  canSaveAuthorization: boolean;
  currentDetail: ApplicationDetail | null;
  deleting: boolean;
  editorMode: 'edit' | 'create';
  form: ApplicationUpsertRequest;
  logoPreviewUrl: string;
  logoUploading: boolean;
  latestSecret: RotateApplicationSecretResult | null;
  panelLoading: boolean;
  redirectUrisText: string;
  rotateReason: string;
  rotating: boolean;
  requestPathKeyword: string;
  resultFilter: string;
  saving: boolean;
  scopesText: string;
  selectedCallRecordId: string;
  selectedScopes: string[];
  selectedApplication: ApplicationSummary | null;
  selectedApplicationTypeLabel: string;
  traceIdFilter: string;
  focusedScope: string;
  visible: boolean;
}>();

const { t } = useApplicationCenterI18n();

defineEmits<{
  close: [];
  'clear-logo': [];
  'copy-client-id': [];
  'copy-secret': [];
  delete: [];
  export: [];
  rotate: [];
  refreshCallRecords: [];
  save: [];
  saveAuthorization: [];
  selectCallRecord: [callRecordId: string];
  'upload-logo': [file: File];
  'update:activeTab': [value: string];
  'update:requestPathKeyword': [value: string];
  'update:redirectUrisText': [value: string];
  'update:resultFilter': [value: string];
  'update:rotateReason': [value: string];
  'update:scopesText': [value: string];
  'update:selectedScopes': [value: string[]];
  'update:traceIdFilter': [value: string];
}>();
</script>

<template>
  <BrickConsoleDrawer
    :model-value="visible"
    size="min(960px, calc(100vw - 24px))"
    :destroy-on-close="false"
    class="application-drawer"
    :eyebrow="t('module.application-center.drawer.eyebrow')"
    :title="form.applicationName || selectedApplication?.applicationName || t('module.application-center.drawer.createTitle')"
    :description="
      `${currentDetail?.applicationCode || form.applicationCode || t('module.application-center.drawer.codePending')} · ${
        form.enabled ? t('module.application-center.drawer.enabled') : t('module.application-center.drawer.disabled')
      }`
    "
    @close="$emit('close')"
  >
    <p v-if="panelLoading" class="drawer-state-text">{{ t('module.application-center.loading.detailShort') }}</p>

    <el-tabs
      v-else
      :model-value="activeTab"
      class="application-drawer__tabs"
      @update:model-value="$emit('update:activeTab', $event)"
    >
      <el-tab-pane :label="t('module.application-center.drawer.tab.profile')" name="detail">
        <ApplicationProfileCard
          :application-type-options="applicationTypeOptions"
          :can-delete-application="canDeleteApplication"
          :deleting="deleting"
          :editor-mode="editorMode"
          :form="form"
          :logo-preview-url="logoPreviewUrl"
          :logo-uploading="logoUploading"
          :redirect-uris-text="redirectUrisText"
          :saving="saving"
          :scopes-text="scopesText"
          :selected-application-type-label="selectedApplicationTypeLabel"
          @clear-logo="$emit('clear-logo')"
          @delete="$emit('delete')"
          @save="$emit('save')"
          @upload-logo="$emit('upload-logo', $event)"
          @update:redirect-uris-text="$emit('update:redirectUrisText', $event)"
          @update:scopes-text="$emit('update:scopesText', $event)"
        />
      </el-tab-pane>

      <el-tab-pane :label="t('module.application-center.drawer.tab.authorization')" name="authorization" :disabled="editorMode === 'create'">
        <ApplicationAuthorizationCard
          :authorization-detail="authorizationDetail"
          :authorization-saving="authorizationSaving"
          :can-export-authorization="canExportAuthorization"
          :can-save-authorization="canSaveAuthorization"
          :editor-mode="editorMode"
          :focused-scope="focusedScope"
          :selected-scopes="selectedScopes"
          @export="$emit('export')"
          @save="$emit('saveAuthorization')"
          @update:selected-scopes="$emit('update:selectedScopes', $event)"
        />
      </el-tab-pane>

      <el-tab-pane :label="t('module.application-center.drawer.tab.credentials')" name="credentials" :disabled="editorMode === 'create'">
        <ApplicationCredentialsCard
          :can-rotate-secret="canRotateSecret"
          :current-detail="currentDetail"
          :latest-secret="latestSecret"
          :rotate-reason="rotateReason"
          :rotating="rotating"
          @copy-client-id="$emit('copy-client-id')"
          @copy-secret="$emit('copy-secret')"
          @rotate="$emit('rotate')"
          @update:rotate-reason="$emit('update:rotateReason', $event)"
        />
      </el-tab-pane>

      <el-tab-pane :label="t('module.application-center.drawer.tab.callRecords')" name="call-records" :disabled="editorMode === 'create'">
        <ApplicationCallRecordCard
          :call-record-detail="callRecordDetail"
          :call-record-detail-loading="callRecordDetailLoading"
          :call-record-loading="callRecordLoading"
          :call-record-result-options="callRecordResultOptions"
          :call-record-total="callRecordTotal"
          :call-records="callRecords"
          :editor-mode="editorMode"
          :request-path-keyword="requestPathKeyword"
          :result-filter="resultFilter"
          :selected-call-record-id="selectedCallRecordId"
          :trace-id-filter="traceIdFilter"
          @refresh="$emit('refreshCallRecords')"
          @select="$emit('selectCallRecord', $event)"
          @update:request-path-keyword="$emit('update:requestPathKeyword', $event)"
          @update:result-filter="$emit('update:resultFilter', $event)"
          @update:trace-id-filter="$emit('update:traceIdFilter', $event)"
        />
      </el-tab-pane>
    </el-tabs>
  </BrickConsoleDrawer>
</template>

<style scoped>
.application-drawer__tabs :deep(.el-tabs__header) {
  margin-bottom: 20px;
}

.application-drawer__tabs :deep(.el-tab-pane) {
  display: grid;
  gap: 16px;
}

.drawer-state-text {
  margin: 0;
  padding: var(--console-drawer-padding, 18px) 4px;
  color: var(--console-text, #4a5a70);
}
</style>
