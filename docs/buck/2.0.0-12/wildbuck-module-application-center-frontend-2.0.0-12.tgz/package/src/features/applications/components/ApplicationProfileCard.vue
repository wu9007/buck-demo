<script setup lang="ts">
import { computed, ref } from 'vue';
import { validateBrickRequiredFields } from '@wildbuck/core-ui-frontend';
import { BrickImageUploadField } from '@wildbuck/core-ui-frontend/fields';
import type { ApplicationUpsertRequest } from '../../../generated/types';
import { useApplicationCenterI18n } from '../../../i18n.js';

type OptionItem = { label: string; value: string };

const props = defineProps<{
  applicationTypeOptions: OptionItem[];
  canDeleteApplication: boolean;
  deleting: boolean;
  editorMode: 'edit' | 'create';
  form: ApplicationUpsertRequest;
  logoPreviewUrl: string;
  logoUploading: boolean;
  redirectUrisText: string;
  saving: boolean;
  scopesText: string;
  selectedApplicationTypeLabel: string;
}>();

const applicationNameInputRef = ref();
const applicationCodeInputRef = ref();
const applicationTypeSelectRef = ref();
const redirectUrisInputRef = ref();
const scopesInputRef = ref();

const emit = defineEmits<{
  'clear-logo': [];
  delete: [];
  save: [];
  'upload-logo': [file: File];
  'update:redirectUrisText': [value: string];
  'update:scopesText': [value: string];
}>();

const { t } = useApplicationCenterI18n();

const applicationTypeHint = computed(() => {
  if (props.form.applicationType === 'oidc_web') {
    return t('module.application-center.profile.typeHint.oidcWeb');
  }
  if (props.form.applicationType === 'oidc_spa') {
    return t('module.application-center.profile.typeHint.oidcSpa');
  }
  return t('module.application-center.profile.typeHint.machineClient');
});
const redirectUrisRequired = computed(() => props.form.applicationType === 'oidc_web' || props.form.applicationType === 'oidc_spa');
const redirectUrisLabel = computed(() => (
  redirectUrisRequired.value
    ? t('module.application-center.profile.redirectUrisRequired')
    : t('module.application-center.profile.redirectUrisOptional')
));
const redirectUrisHint = computed(() => (
  redirectUrisRequired.value
    ? t('module.application-center.profile.redirectUrisHint.required')
    : t('module.application-center.profile.redirectUrisHint.optional')
));

const logoPreview = computed(() => props.logoPreviewUrl || '');
const logoResourceHint = computed(() => (
  props.form.logoResourceId
    ? t('module.application-center.profile.logoResourceHint', { resourceId: props.form.logoResourceId })
    : t('module.application-center.profile.logoFormatHint')
));

function clearLogo() {
  emit('clear-logo');
}

function uploadLogo(file: File) {
  emit('upload-logo', file);
}

function resolveLogoFallback() {
  const source = props.form.applicationName?.trim()
    || props.form.applicationCode?.trim()
    || t('module.application-center.profile.logoFallback');
  const compact = source.replace(/\s+/g, '');
  return compact.length <= 2 ? compact.toUpperCase() : compact.slice(0, 2).toUpperCase();
}

function handleSubmit() {
  const result = validateBrickRequiredFields([
    {
      label: t('module.application-center.profile.name'),
      value: props.form.applicationName,
      focusTarget: applicationNameInputRef.value,
    },
    {
      label: t('module.application-center.profile.code'),
      value: props.form.applicationCode,
      focusTarget: applicationCodeInputRef.value,
    },
    {
      label: t('module.application-center.profile.type'),
      value: props.form.applicationType,
      focusTarget: applicationTypeSelectRef.value,
    },
    ...(redirectUrisRequired.value
      ? [{
        label: t('module.application-center.profile.redirectUris'),
        value: props.redirectUrisText,
        focusTarget: redirectUrisInputRef.value,
      }]
      : []),
    {
      label: t('module.application-center.profile.scopes'),
      value: props.scopesText,
      focusTarget: scopesInputRef.value,
    },
  ]);
  if (!result.ok) {
    return;
  }
  emit('save');
}
</script>

<template>
  <el-card shadow="never" class="card">
    <template #header>
      <div class="card-header">
        <div>
          <h2>{{ editorMode === 'create' ? t('module.application-center.profile.createTitle') : t('module.application-center.profile.editTitle') }}</h2>
          <p>{{ editorMode === 'create' ? t('module.application-center.profile.createDescription') : t('module.application-center.profile.editDescription') }}</p>
        </div>
        <span class="summary-chip">{{ selectedApplicationTypeLabel }}</span>
      </div>
    </template>

    <div>
      <el-form label-position="top" class="detail-form brick-required-form" @submit.prevent="handleSubmit">
        <el-form-item :label="t('module.application-center.profile.nameRequired')" required>
          <el-input ref="applicationNameInputRef" v-model.trim="form.applicationName" :aria-label="t('module.application-center.profile.name')" maxlength="100" required />
        </el-form-item>

        <el-form-item :label="t('module.application-center.profile.codeRequired')" required>
          <el-input ref="applicationCodeInputRef" v-model.trim="form.applicationCode" :aria-label="t('module.application-center.profile.code')" maxlength="100" required />
          <small class="field-hint">{{ t('module.application-center.profile.codeHint') }}</small>
        </el-form-item>

        <el-form-item :label="t('module.application-center.profile.typeRequired')" required>
          <el-select ref="applicationTypeSelectRef" v-model="form.applicationType" :aria-label="t('module.application-center.profile.type')">
            <el-option
              v-for="option in applicationTypeOptions"
              :key="option.value"
              :label="option.label"
              :value="option.value"
            />
          </el-select>
          <small class="field-hint">{{ applicationTypeHint }}</small>
        </el-form-item>

        <div class="status-field detail-form__full">
          <div class="status-field__copy">
            <span class="console-required-label">{{ t('module.application-center.profile.enabledRequired') }}</span>
            <small>{{ t('module.application-center.profile.enabledHint') }}</small>
          </div>
          <div class="status-actions" role="group" :aria-label="t('module.application-center.profile.enableApp')">
            <el-button :type="form.enabled ? 'primary' : 'default'" @click="form.enabled = true">{{ t('module.application-center.profile.enableApp') }}</el-button>
            <el-button :type="!form.enabled ? 'warning' : 'default'" plain @click="form.enabled = false">{{ t('module.application-center.profile.disableApp') }}</el-button>
          </div>
        </div>

        <BrickImageUploadField
          class="detail-form__full"
          :label="t('module.application-center.profile.logoOptional')"
          :description="t('module.application-center.profile.logoDescription')"
          :preview-url="logoPreview"
          :preview-alt="t('module.application-center.profile.logoPreviewAlt')"
          :fallback-text="resolveLogoFallback()"
          :uploading="logoUploading"
          :clear-disabled="!logoPreview || logoUploading"
          :upload-text="t('module.application-center.profile.logoUpload')"
          :clear-text="t('module.application-center.profile.logoClear')"
          :preview-size="88"
          :resource-hint="logoResourceHint"
          @upload="uploadLogo"
          @clear="clearLogo"
        />

        <el-form-item :label="t('module.application-center.profile.descriptionOptional')">
          <el-input v-model.trim="form.description" :aria-label="t('module.application-center.profile.description')" type="textarea" :rows="3" maxlength="500" />
        </el-form-item>

        <el-form-item :label="redirectUrisLabel" class="detail-form__full" :required="redirectUrisRequired">
          <el-input
            ref="redirectUrisInputRef"
            :model-value="redirectUrisText"
            :aria-label="t('module.application-center.profile.redirectUris')"
            type="textarea"
            :rows="4"
            placeholder="https://console.example.com/login/oauth2/code/brick"
            @update:model-value="$emit('update:redirectUrisText', $event || '')"
          />
          <small class="field-hint">{{ redirectUrisHint }}</small>
        </el-form-item>

        <el-form-item :label="t('module.application-center.profile.scopesRequired')" class="detail-form__full" required>
          <el-input
            ref="scopesInputRef"
            :model-value="scopesText"
            :aria-label="t('module.application-center.profile.scopes')"
            type="textarea"
            :rows="4"
            placeholder="openid&#10;profile&#10;openapi.read"
            @update:model-value="$emit('update:scopesText', $event || '')"
          />
        </el-form-item>

        <div class="form-actions detail-form__full">
          <el-button type="primary" native-type="button" :loading="saving" @click="handleSubmit">
            {{ editorMode === 'create' ? t('module.application-center.profile.createAction') : t('module.application-center.profile.saveAction') }}
          </el-button>
          <el-button
            v-if="editorMode === 'edit'"
            type="danger"
            plain
            :disabled="!canDeleteApplication"
            :loading="deleting"
            @click="$emit('delete')"
          >
            {{ t('module.application-center.profile.deleteAction') }}
          </el-button>
        </div>
      </el-form>
    </div>
  </el-card>
</template>

<style scoped>
.card {
  border: 1px solid var(--console-card-border, #e6ebf2);
  background: var(--console-card-bg, #ffffff);
}

.card-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
}

.card-header h2,
.card-header p {
  margin: 0;
}

.card-header p {
  margin-top: 6px;
  color: var(--console-text, #4a5a70);
}

.summary-chip {
  flex: 0 0 auto;
  padding: 10px 14px;
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: 999px;
  color: var(--console-text, #4a5a70);
  background: var(--console-card-bg, #ffffff);
  font-size: 13px;
  font-weight: 700;
}

.card :deep(.el-card__header) {
  padding: var(--console-card-header-y, 14px) var(--console-card-header-x, 18px);
  border-bottom: 1px solid var(--console-card-border, #e6ebf2);
}

.card :deep(.el-card__body) {
  padding: var(--console-card-body-y, 18px) var(--console-card-body-x, 18px);
}

.detail-form {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 18px;
}

.detail-form :deep(.el-form-item) {
  margin-bottom: 0;
}

.detail-form__full {
  grid-column: 1 / -1;
}

.detail-form :deep(.el-form-item__label),
.status-field__copy span {
  color: var(--console-text, #4a5a70);
  font-size: 13px;
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.detail-form :deep(.el-input__wrapper),
.detail-form :deep(.el-select__wrapper) {
  min-height: var(--console-control-height, 42px);
}

.field-hint {
  display: block;
  margin-top: 8px;
  color: var(--console-muted, #7e8ba0);
  font-size: 12px;
  line-height: 1.5;
}

.status-field {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 18px;
  min-width: 0;
  min-height: 46px;
  padding: 16px 18px;
  border: 1px solid var(--console-block-border, var(--console-card-border, #e6ebf2));
  border-radius: var(--console-block-radius, 8px);
  background: var(--console-block-bg, var(--console-card-bg, #ffffff));
}

.status-field__copy {
  display: grid;
  gap: 6px;
}

.status-field__copy small {
  color: var(--console-muted, #7e8ba0);
  font-size: 12px;
  line-height: 1.5;
}

.status-actions {
  display: inline-flex;
  flex: 0 0 auto;
  gap: 10px;
}

.status-actions :deep(.el-button) {
  min-width: 96px;
  min-height: var(--console-control-height, 42px);
  border-radius: var(--console-field-radius, 6px);
  font-weight: 700;
}

.form-actions {
  display: flex;
  align-items: center;
  gap: 12px;
}

.form-actions :deep(.el-button) {
  min-height: 40px;
  padding: 0 16px;
  border-radius: 999px;
  font-weight: 700;
}

@media (max-width: 760px) {
  .card-header,
  .form-actions,
  .status-field,
  .detail-form {
    grid-template-columns: 1fr;
  }

  .detail-form__full {
    grid-column: auto;
  }
}
</style>
