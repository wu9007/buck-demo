import {
  applicationCallRecordDetail,
  applicationAuthorizationDetail,
  applicationDetail,
  assignApplicationAuthorizations,
  createApplication,
  deleteApplication,
  rotateApplicationSecret,
  searchApplicationCallRecords,
  searchApplications,
  updateApplication,
} from '../../../generated/sdk';
import { request as brickRequest, requestBlob as brickRequestBlob } from '@wildbuck/core-api-frontend';
import type {
  ApplicationCallRecordDetail,
  ApplicationCallRecordSearchRequest,
  ApplicationCallRecordSummary,
  ApplicationAuthorizationAssignment,
  ApplicationAuthorizationDetail,
  ApplicationDetail,
  ApplicationSearchRequest,
  ApplicationSummary,
  ApplicationUpsertRequest,
  AssignApplicationAuthorizationsRequest,
  Page,
  RotateApplicationSecretRequest,
  RotateApplicationSecretResult,
} from '../../../generated/types';

export interface ImageUploadResponse {
  resourceId: string;
  contentUrl: string;
}

export async function loadApplications(input: ApplicationSearchRequest): Promise<Page<ApplicationSummary>> {
  return searchApplications(input);
}

export async function loadApplicationDetail(applicationId: string): Promise<ApplicationDetail> {
  return applicationDetail(applicationId, undefined);
}

export async function saveNewApplication(input: ApplicationUpsertRequest): Promise<ApplicationDetail> {
  return createApplication(input);
}

export async function saveExistingApplication(
  applicationId: string,
  input: ApplicationUpsertRequest,
): Promise<ApplicationDetail> {
  return updateApplication(applicationId, input);
}

export async function removeApplication(applicationId: string): Promise<void> {
  return deleteApplication(applicationId, undefined);
}

export async function rotateSecret(
  applicationId: string,
  input: RotateApplicationSecretRequest,
): Promise<RotateApplicationSecretResult> {
  return rotateApplicationSecret(applicationId, input);
}

export async function loadApplicationAuthorizationDetail(applicationId: string): Promise<ApplicationAuthorizationDetail> {
  return applicationAuthorizationDetail(applicationId, undefined);
}

export async function saveApplicationAuthorizations(
  applicationId: string,
  input: AssignApplicationAuthorizationsRequest,
): Promise<ApplicationAuthorizationAssignment> {
  return assignApplicationAuthorizations(applicationId, input);
}

export async function loadApplicationCallRecords(
  applicationId: string,
  input: ApplicationCallRecordSearchRequest,
): Promise<Page<ApplicationCallRecordSummary>> {
  return searchApplicationCallRecords(applicationId, input);
}

export async function loadApplicationCallRecordDetail(
  applicationId: string,
  callRecordId: string,
): Promise<ApplicationCallRecordDetail> {
  return applicationCallRecordDetail(applicationId, callRecordId, undefined);
}

export async function uploadImageResource(file: File): Promise<ImageUploadResponse> {
  const body = new FormData();
  body.append('file', file);
  return brickRequest<ImageUploadResponse>('/file-resources/images?category=APPLICATION_LOGO', {
    method: 'POST',
    body,
  });
}

export async function loadImageResourceBlob(resourceId: string): Promise<Blob> {
  return brickRequestBlob(`/file-resources/${encodeURIComponent(resourceId)}/content`);
}
