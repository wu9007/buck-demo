<script setup lang="ts">
import { computed } from 'vue';
import { BrickFilterToolbar } from '@wildbuck/core-ui-frontend/patterns';
import {
  buildApplicationEnabledFilterOptions,
  type ApplicationEnabledFilterValue,
} from '../lib/application-filter-options';
import { useApplicationCenterI18n } from '../../../i18n.js';

defineProps<{
  applicationTypeFilter: string;
  applicationTypeOptions: Array<{ label: string; value: string }>;
  enabledFilter: ApplicationEnabledFilterValue;
  keyword: string;
}>();

const emit = defineEmits<{
  reset: [];
  search: [];
  'update:applicationTypeFilter': [value: string];
  'update:enabledFilter': [value: ApplicationEnabledFilterValue];
  'update:keyword': [value: string];
}>();

const { t } = useApplicationCenterI18n();
const applicationEnabledFilterOptions = computed(() => buildApplicationEnabledFilterOptions(t));

function emitEnabledFilter(value: string) {
  emit('update:enabledFilter', value as ApplicationEnabledFilterValue);
}
</script>

<template>
  <form class="application-filter-form" @submit.prevent="$emit('search')">
    <BrickFilterToolbar class="application-filter-toolbar" field-min-width="220px" data-guide-anchor="filters">
      <el-input
        :model-value="keyword"
        :aria-label="t('module.application-center.filter.searchAria')"
        clearable
        :placeholder="t('module.application-center.filter.keywordPlaceholder')"
        @update:model-value="$emit('update:keyword', $event || '')"
      />

      <el-select
        :model-value="applicationTypeFilter"
        :aria-label="t('module.application-center.filter.typeAria')"
        clearable
        :placeholder="t('module.application-center.filter.typeAll')"
        @update:model-value="$emit('update:applicationTypeFilter', $event || '')"
      >
        <el-option
          v-for="option in applicationTypeOptions"
          :key="option.value"
          :label="option.label"
          :value="option.value"
        />
      </el-select>

      <el-select
        :model-value="enabledFilter"
        :aria-label="t('module.application-center.filter.statusAria')"
        :placeholder="t('module.application-center.filter.statusAll')"
        @update:model-value="emitEnabledFilter"
      >
        <el-option
          v-for="option in applicationEnabledFilterOptions"
          :key="option.value"
          :label="option.label"
          :value="option.value"
        />
      </el-select>

      <template #actions>
        <el-button native-type="button" @click.prevent="$emit('reset')">{{ t('module.application-center.filter.reset') }}</el-button>
        <el-button type="primary" native-type="submit">{{ t('module.application-center.filter.search') }}</el-button>
      </template>
    </BrickFilterToolbar>
  </form>
</template>

<style scoped>
.application-filter-form {
  margin: 0;
}
</style>
