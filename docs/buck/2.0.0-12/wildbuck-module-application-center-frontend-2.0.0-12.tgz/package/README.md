# @wildbuck/module-application-center-frontend

EIAM 应用中心路由与功能页面的前端模块包。

## i18n

- 词条键：`module.application-center.*`
- 公开入口：`@wildbuck/module-application-center-frontend/i18n`（`resolveApplicationCenterMessages` / `useApplicationCenterI18n`）
- 上层壳：`registerMessages('module-application-center', resolveApplicationCenterMessages(locale))`
