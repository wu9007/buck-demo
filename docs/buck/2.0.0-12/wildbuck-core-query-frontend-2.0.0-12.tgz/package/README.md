# @wildbuck/core-query-frontend

`@wildbuck/core-query-frontend` 提供前端构造 `core:query` `QueryCriteria` 的轻量工具。

它只负责 DSL 形状，不负责页面筛选布局、字段白名单或执行逻辑：

- 前端页面决定筛选控件、文案、布局和交互。
- 后端通过 `BrickQueryDefinition` 声明 `queryCode`、字段白名单、操作符白名单、分页上限和排序规则。
- 后端 service 接收 `QueryCriteria` 后仍必须交给 `BrickQueryExecutor` 执行。

```js
import { createQueryCriteria, queryFilter, querySorter } from '@wildbuck/core-query-frontend';

const criteria = createQueryCriteria({
  queryCode: 'face.archive.list',
  pageNo: 1,
  pageSize: 20,
  filterGroups: [
    [queryFilter.like('name', keyword)]
  ],
  sorters: [querySorter.desc('createdAt')]
});
```

业务页面不要再自定义分页、排序和筛选协议；如果这个包的 DSL 不够用，向 `buck` 提中文 Issue。
