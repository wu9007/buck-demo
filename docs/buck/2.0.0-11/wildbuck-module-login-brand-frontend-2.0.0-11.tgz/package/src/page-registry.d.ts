export declare const brickRouteComponentLoaders: Record<string, () => Promise<unknown>>;
