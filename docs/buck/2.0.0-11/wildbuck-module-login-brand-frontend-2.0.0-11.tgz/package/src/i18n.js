import { createBrickI18nRuntime, normalizeBrickLocale } from '@wildbuck/core-i18n-frontend';
import {
  LOGIN_BRAND_MESSAGES_EN_US,
  LOGIN_BRAND_MESSAGES_ZH_CN,
} from './features/login-brand-i18n-messages.js';

export function resolveLoginBrandMessages(locale) {
  const normalized = normalizeBrickLocale(locale);
  return normalized === 'en-US' ? LOGIN_BRAND_MESSAGES_EN_US : LOGIN_BRAND_MESSAGES_ZH_CN;
}

export function useLoginBrandI18n() {
  // Host shell usually injects i18n; page can also create a local runtime for standalone tests.
  const runtime = createBrickI18nRuntime({ locale: 'zh-CN' });
  runtime.registerMessages('module-login-brand', resolveLoginBrandMessages('zh-CN'));
  return {
    t: (key, params) => runtime.t(key, params),
    setLocale(locale) {
      const next = normalizeBrickLocale(locale);
      runtime.setLocale(next);
      runtime.registerMessages('module-login-brand', resolveLoginBrandMessages(next));
    },
  };
}
