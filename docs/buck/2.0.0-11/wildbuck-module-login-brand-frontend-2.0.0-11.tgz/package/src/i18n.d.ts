export declare function resolveLoginBrandMessages(locale?: string): Record<string, string>;
export declare function useLoginBrandI18n(): {
  t: (key: string, params?: Record<string, string | number>) => string;
  setLocale: (locale: string) => void;
};
