declare const loginBrandModule: {
  name: string;
  register(): {
    routes: Array<{
      path: string;
      name: string;
      component: () => Promise<unknown>;
    }>;
  };
};

export default loginBrandModule;
export declare const brickModuleKey: "login-brand";
export declare const brickModuleMeta: {
  displayName: string;
};
export declare const brickRoutes: Array<Record<string, unknown>>;
export declare const brickFeatureRegistry: Record<string, unknown>;
export declare const brickPermissionMap: Record<string, Record<string, string>>;
