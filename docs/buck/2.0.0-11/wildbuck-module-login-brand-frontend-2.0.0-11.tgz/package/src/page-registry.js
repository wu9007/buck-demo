export const brickRouteComponentLoaders = {
  "login-brand.appearance": () => import('./features/appearance/pages/LoginBrandAppearancePage.vue'),
};
