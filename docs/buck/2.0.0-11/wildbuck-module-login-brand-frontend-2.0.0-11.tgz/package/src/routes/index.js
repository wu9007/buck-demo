export const loginBrandRoutes = [
  {
    id: "login-brand.appearance",
    featureKey: "appearance",
    path: "/login-brand/appearance",
    title: "登录外观",
    abbr: "登",
    eyebrow: "登录品牌 / 登录外观",
    summary: "登录页系统名称、描述、logo、背景与表单/品牌布局配置。",
    permission: "login-brand:appearance:view",
    component: () => import('../features/appearance/pages/LoginBrandAppearancePage.vue'),
  },
];

export default function registerLoginBrandRoutes() {
  return loginBrandRoutes.map((route) => ({
    path: route.path,
    name: route.id,
    component: route.component,
  }));
}
