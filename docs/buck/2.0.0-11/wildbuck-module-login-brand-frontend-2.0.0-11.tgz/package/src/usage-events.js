import { createModuleUsageTracker } from '@wildbuck/core-usage-event-frontend';

export const LOGIN_BRAND_USAGE_EVENT_MODULE_CODE = 'login-brand';

export const loginBrandUsageEventMatrix = deepFreeze({
  pages: {
    appearance: {
      featureCode: 'login-appearance',
      pageCode: 'login-appearance-page',
      routeName: 'login-brand.appearance',
    },
  },
  features: {
    appearanceConfig: {
      featureCode: 'login-appearance-config',
      pageCode: 'login-appearance-page',
      routeName: 'login-brand.appearance',
      viewActionCode: 'open-config',
    },
    appearanceTemplate: {
      featureCode: 'login-appearance-template',
      pageCode: 'login-appearance-page',
      routeName: 'login-brand.appearance',
      viewActionCode: 'apply-template',
    },
    appearanceReset: {
      featureCode: 'login-appearance-reset',
      pageCode: 'login-appearance-page',
      routeName: 'login-brand.appearance',
      viewActionCode: 'factory-reset',
    },
  },
});

export const loginBrandUsageTracker = createModuleUsageTracker(
  LOGIN_BRAND_USAGE_EVENT_MODULE_CODE,
  loginBrandUsageEventMatrix,
);

function deepFreeze(value) {
  if (value == null || typeof value !== 'object') {
    return value;
  }
  for (const child of Object.values(value)) {
    deepFreeze(child);
  }
  return Object.freeze(value);
}
