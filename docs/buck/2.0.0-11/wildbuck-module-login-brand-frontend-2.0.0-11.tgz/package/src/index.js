import { appearanceFeature } from './features/appearance/index.js';
import registerLoginBrandRoutes, { loginBrandRoutes } from './routes/index.js';

export const loginBrandFeatureRegistry = {
  appearance: appearanceFeature,
};

export const loginBrandPermissionMap = {
  appearance: appearanceFeature.permissions,
};

export default {
  name: "login-brand",
  register() {
    return {
      routes: registerLoginBrandRoutes(),
    };
  },
};

export const brickModuleKey = "login-brand";
export const brickModuleMeta = {
  displayName: "登录品牌",
};
export const brickFeatureRegistry = loginBrandFeatureRegistry;
export const brickPermissionMap = loginBrandPermissionMap;
export const brickRoutes = loginBrandRoutes;

export { loginBrandRoutes };
