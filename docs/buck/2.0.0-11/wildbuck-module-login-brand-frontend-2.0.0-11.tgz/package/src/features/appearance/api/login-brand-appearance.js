import { request as brickRequest } from '@wildbuck/core-api-frontend';
import { updateLoginBrandSetting } from '../../../generated/sdk';

export async function loadLoginBrandSetting() {
  return brickRequest('/login-brand/appearance/detail', { method: 'POST' });
}

export async function saveLoginBrandSetting(input) {
  return updateLoginBrandSetting(input);
}

export async function resetLoginBrandSetting() {
  return brickRequest('/login-brand/appearance/reset', { method: 'POST' });
}
