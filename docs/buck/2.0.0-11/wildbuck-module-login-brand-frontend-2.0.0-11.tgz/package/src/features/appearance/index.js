import { loginBrandRoutes } from '../../routes/index.js';

export const appearancePermissions = {
  view: "login-brand:appearance:view",
  manage: "login-brand:appearance:manage",
};

export const appearanceFeature = {
  featureKey: "appearance",
  routes: loginBrandRoutes,
  permissions: appearancePermissions,
};
