# 登录品牌 Frontend

该包由 `brick module scaffold` 创建，提供 登录品牌 的最小 route、feature registry 和 page-registry 骨架。
