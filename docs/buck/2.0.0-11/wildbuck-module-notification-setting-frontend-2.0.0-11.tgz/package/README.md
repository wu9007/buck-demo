# notification-setting frontend

EMAIL/SMTP 配置治理前端模块。

## i18n

- 词条键：`module.notification-setting.*`
- 公开入口：`@wildbuck/module-notification-setting-frontend/i18n`（`resolveNotificationSettingMessages` / `useNotificationSettingI18n`）
- 上层壳：`registerMessages('module-notification-setting', resolveNotificationSettingMessages(locale))`
