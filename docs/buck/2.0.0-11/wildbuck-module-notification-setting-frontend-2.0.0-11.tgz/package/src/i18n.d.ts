import type { ComputedRef, Ref } from 'vue';

export declare const NOTIFICATION_SETTING_MESSAGES_ZH_CN: Readonly<Record<string, string>>;
export declare const NOTIFICATION_SETTING_MESSAGES_EN_US: Readonly<Record<string, string>>;
export declare const NOTIFICATION_SETTING_MESSAGES: Readonly<Record<string, Readonly<Record<string, string>>>>;

export declare function resolveNotificationSettingMessages(locale?: string): Readonly<Record<string, string>>;
export declare function translateNotificationSetting(
  runtime: unknown,
  key: string,
  params?: Record<string, unknown>,
  fallbackLocale?: string,
): string;

export declare function useNotificationSettingI18n(): {
  t: (key: string, params?: Record<string, unknown>) => string;
  i18n: unknown;
  locale: ComputedRef<string>;
  revision: Ref<number>;
};
