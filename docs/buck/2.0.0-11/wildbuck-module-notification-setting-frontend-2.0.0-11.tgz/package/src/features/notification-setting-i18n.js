import { formatBrickI18nMessage, normalizeBrickLocale } from '@wildbuck/core-i18n-frontend';
import {
  useBrickConsoleI18n,
} from '@wildbuck/core-ui-frontend/i18n';
import {
  NOTIFICATION_SETTING_MESSAGES,
  NOTIFICATION_SETTING_MESSAGES_EN_US,
  NOTIFICATION_SETTING_MESSAGES_ZH_CN,
} from './notification-setting-i18n-messages.js';

/**
 * @param {unknown} locale
 * @returns {Readonly<Record<string, string>>}
 */
export function resolveNotificationSettingMessages(locale) {
  const normalized = normalizeBrickLocale(locale);
  return NOTIFICATION_SETTING_MESSAGES[normalized] ?? NOTIFICATION_SETTING_MESSAGES_ZH_CN;
}

/**
 * @param {unknown} runtime
 * @param {string} key
 * @param {Record<string, unknown>} [params]
 * @param {string} [fallbackLocale]
 */
export function translateNotificationSetting(runtime, key, params = {}, fallbackLocale = 'zh-CN') {
  const messageKey = String(key ?? '');
  if (!messageKey) {
    return '';
  }
  if (runtime && typeof runtime.t === 'function') {
    const resolved = runtime.t(messageKey, params);
    if (resolved != null && resolved !== '' && resolved !== messageKey) {
      return String(resolved);
    }
  }
  const locale = normalizeBrickLocale(
    typeof runtime?.getLocale === 'function' ? runtime.getLocale() : fallbackLocale,
    fallbackLocale,
  );
  const pack = resolveNotificationSettingMessages(locale);
  const template = pack[messageKey] ?? NOTIFICATION_SETTING_MESSAGES_ZH_CN[messageKey];
  if (typeof template === 'string') {
    return formatBrickI18nMessage(template, params);
  }
  return messageKey;
}

/**
 * Vue inject helper for notification-setting SFCs.
 * Tracks runtime revision so setLocale / registerMessages re-render templates that call t().
 */
export function useNotificationSettingI18n() {
  const { i18n, revision, locale, t: consoleT } = useBrickConsoleI18n();

  function t(key, params) {
    void revision.value;
    const fromRuntime = consoleT(key, params);
    if (fromRuntime != null && fromRuntime !== '' && fromRuntime !== key) {
      return fromRuntime;
    }
    return translateNotificationSetting(i18n, key, params, locale.value);
  }

  return {
    i18n,
    revision,
    locale,
    t,
  };
}

export {
  NOTIFICATION_SETTING_MESSAGES,
  NOTIFICATION_SETTING_MESSAGES_EN_US,
  NOTIFICATION_SETTING_MESSAGES_ZH_CN,
};
