<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { resolveBrickErrorFromCatalog } from '@wildbuck/core-api-frontend';
import { showBrickStatus, validateBrickRequiredFields } from '@wildbuck/core-ui-frontend/status';
import { BrickActionBar, BrickPageBlock } from '@wildbuck/core-ui-frontend/patterns';
import {
  notificationSettingErrors,
  type NotificationSettingErrorCode,
} from '../../../generated/errors';
import type {
  EmailSmtpProviderSettingDetail,
  UpdateEmailSmtpProviderSettingRequest,
} from '../../../generated/types';
import {
  notificationSettingUsageTracker,
} from '../../../usage-events';
import { useNotificationSettingI18n } from '../../../i18n.js';
import {
  loadEmailSmtpProviderSetting,
  saveEmailSmtpProviderSetting,
  sendEmailSmtpTestMail,
} from '../api/email-smtp';
import { buildEmailSmtpPendingChanges } from '../lib/email-smtp-changes.js';

type EmailSmtpSettingForm = {
  settingId: string;
  enabled: boolean;
  host: string;
  port: number;
  username: string;
};

const DEFAULT_PORT = 465;

const { t } = useNotificationSettingI18n();

const loading = ref(true);
const saving = ref(false);
const testing = ref(false);
const loadFailed = ref(false);
const snapshot = ref('');
const passwordDraft = ref('');
const clearStoredPassword = ref(false);
const testToAddress = ref('');
const detail = ref<EmailSmtpProviderSettingDetail | null>(null);
const form = ref<EmailSmtpSettingForm>(defaultForm());
const hostInputRef = ref();
const portInputRef = ref();
const usernameInputRef = ref();
const testToAddressInputRef = ref();

const hasUnsavedChanges = computed(() => !loading.value && !loadFailed.value && serializeState() !== snapshot.value);
const passwordStatusLabel = computed(() => resolvePasswordSummary(detail.value));
const canClearStoredPassword = computed(() => !form.value.enabled && Boolean(detail.value?.passwordConfigured));
const canTestSend = computed(
  () =>
    !loading.value
    && !loadFailed.value
    && !hasUnsavedChanges.value
    && Boolean(detail.value?.enabled)
    && Boolean(detail.value?.passwordConfigured)
    && Boolean(detail.value?.host)
    && Boolean(detail.value?.username),
);
const pendingChangeRows = computed(() => {
  if (!hasUnsavedChanges.value || !detail.value) {
    return [];
  }
  return buildEmailSmtpPendingChanges(
    {
      enabled: detail.value.enabled,
      host: detail.value.host || '',
      port: detail.value.port,
      username: detail.value.username || '',
      passwordConfigured: Boolean(detail.value.passwordConfigured),
    },
    {
      enabled: form.value.enabled,
      host: normalizedText(form.value.host),
      port: normalizePort(form.value.port),
      username: normalizedText(form.value.username),
      passwordDraft: Boolean(normalizedText(passwordDraft.value)),
      clearPassword: canClearStoredPassword.value && clearStoredPassword.value,
    },
    {
      enabled: t('module.notification-setting.change.field.enabled'),
      host: t('module.notification-setting.change.field.host'),
      port: t('module.notification-setting.change.field.port'),
      username: t('module.notification-setting.change.field.username'),
      password: t('module.notification-setting.change.field.password'),
      empty: t('module.notification-setting.change.empty'),
      on: t('module.notification-setting.change.enabledOn'),
      off: t('module.notification-setting.change.enabledOff'),
      pending: t('module.notification-setting.password.pending'),
      clear: t('module.notification-setting.change.passwordClear'),
      configured: t('module.notification-setting.password.configured'),
      unconfigured: t('module.notification-setting.password.unconfigured'),
    },
  );
});

onMounted(async () => {
  void notificationSettingUsageTracker.trackPage('emailSmtp');
  await reload();
});

async function reload() {
  loading.value = true;
  loadFailed.value = false;
  try {
    applyDetail(await loadEmailSmtpProviderSetting());
    void notificationSettingUsageTracker.trackOpen('emailSmtpConfig');
  } catch (error) {
    loadFailed.value = true;
    showBrickStatus(resolveErrorMessage(error, 'NOTIFICATION_SETTING_EMAIL_SMTP_SAVE_FAILED'), 'error');
  } finally {
    loading.value = false;
  }
}

async function save() {
  saving.value = true;
  try {
    await notificationSettingUsageTracker.trackAction('emailSmtpConfig', 'save', async () => {
      const saved = await saveEmailSmtpProviderSetting(buildRequest());
      applyDetail(saved);
    });
    showBrickStatus(t('module.notification-setting.status.saved'), 'success');
  } catch (error) {
    showBrickStatus(resolveErrorMessage(error, 'NOTIFICATION_SETTING_EMAIL_SMTP_INVALID_CONFIGURATION'), 'error');
  } finally {
    saving.value = false;
  }
}

function handleSave() {
  const result = validateBrickRequiredFields([
    {
      label: t('module.notification-setting.field.host'),
      value: form.value.host,
      focusTarget: hostInputRef.value,
    },
    {
      label: t('module.notification-setting.field.port'),
      value: form.value.port,
      message: t('module.notification-setting.field.portInvalid'),
      focusTarget: portInputRef.value,
      validate: (value) => Number.isFinite(Number(value)) && Number(value) > 0,
    },
    {
      label: t('module.notification-setting.field.username'),
      value: form.value.username,
      focusTarget: usernameInputRef.value,
    },
  ]);
  if (!result.ok) {
    return;
  }
  void save();
}

async function testSend() {
  if (!canTestSend.value) {
    showBrickStatus(t('module.notification-setting.status.testBlocked'), 'warning');
    return;
  }
  const result = validateBrickRequiredFields([
    {
      label: t('module.notification-setting.field.testTo'),
      value: testToAddress.value,
      focusTarget: testToAddressInputRef.value,
      validate: (value) => String(value || '').includes('@'),
      message: t('module.notification-setting.field.testToInvalid'),
    },
  ]);
  if (!result.ok) {
    return;
  }
  testing.value = true;
  try {
    await notificationSettingUsageTracker.trackAction('emailSmtpTestSend', 'send', async () => {
      const response = await sendEmailSmtpTestMail({
        toAddress: normalizedText(testToAddress.value),
      });
      if (!response?.success) {
        throw new Error(response?.message || t('module.notification-setting.test.sendFailed'));
      }
    });
    showBrickStatus(t('module.notification-setting.status.testSubmitted'), 'success');
  } catch (error) {
    showBrickStatus(resolveErrorMessage(error, 'NOTIFICATION_SETTING_EMAIL_SMTP_TEST_SEND_FAILED'), 'error');
  } finally {
    testing.value = false;
  }
}

function buildRequest(): UpdateEmailSmtpProviderSettingRequest {
  return {
    settingId: form.value.settingId,
    enabled: form.value.enabled,
    host: normalizedText(form.value.host),
    port: normalizePort(form.value.port),
    username: normalizedText(form.value.username),
    password: normalizedText(passwordDraft.value),
    clearPassword: canClearStoredPassword.value && clearStoredPassword.value,
  };
}

function applyDetail(nextDetail: EmailSmtpProviderSettingDetail) {
  detail.value = nextDetail;
  form.value = toForm(nextDetail);
  passwordDraft.value = '';
  clearStoredPassword.value = false;
  snapshot.value = serializeState();
}

function toForm(currentDetail: EmailSmtpProviderSettingDetail): EmailSmtpSettingForm {
  return {
    settingId: currentDetail.settingId || 'email-smtp',
    enabled: Boolean(currentDetail.enabled),
    host: currentDetail.host || '',
    port: normalizePort(currentDetail.port),
    username: currentDetail.username || '',
  };
}

function defaultForm(): EmailSmtpSettingForm {
  return {
    settingId: 'email-smtp',
    enabled: false,
    host: '',
    port: DEFAULT_PORT,
    username: '',
  };
}

function serializeState() {
  return JSON.stringify({
    form: {
      ...form.value,
      host: normalizedText(form.value.host),
      username: normalizedText(form.value.username),
      port: normalizePort(form.value.port),
    },
    password: normalizedText(passwordDraft.value),
    clearStoredPassword: canClearStoredPassword.value && clearStoredPassword.value,
    passwordConfigured: Boolean(detail.value?.passwordConfigured),
  });
}

function resolvePasswordSummary(currentDetail: EmailSmtpProviderSettingDetail | null) {
  if (normalizedText(passwordDraft.value)) {
    return t('module.notification-setting.password.pending');
  }
  return currentDetail?.passwordConfigured
    ? t('module.notification-setting.password.configured')
    : t('module.notification-setting.password.unconfigured');
}

function resolveErrorMessage(error: unknown, fallbackCode: NotificationSettingErrorCode) {
  return resolveBrickErrorFromCatalog(error, notificationSettingErrors, {
    fallbackCode,
    localeHint: 'zh-CN',
  }).text;
}

function normalizedText(value: string | undefined | null) {
  return typeof value === 'string' && value.trim() ? value.trim() : '';
}

function normalizePort(value: number | string | undefined | null) {
  if (typeof value === 'number' && Number.isFinite(value) && value > 0) {
    return value;
  }
  if (typeof value === 'string') {
    const parsed = Number.parseInt(value, 10);
    if (Number.isFinite(parsed) && parsed > 0) {
      return parsed;
    }
  }
  return DEFAULT_PORT;
}
</script>

<template>
  <article class="console-settings-page notification-setting-page">
    <BrickPageBlock
      data-guide-anchor="summary"
      :eyebrow="t('module.notification-setting.page.eyebrow')"
      :title="t('module.notification-setting.page.title')"
      :description="t('module.notification-setting.page.description')"
      :loading="loading"
      :loading-text="t('module.notification-setting.page.loading')"
      :error="loadFailed ? t('module.notification-setting.page.loadError') : false"
    >
      <template #actions>
        <div class="page-chip-group">
          <span class="change-chip" :class="{ visible: hasUnsavedChanges }">
            {{ t('module.notification-setting.page.unsavedChanges') }}
          </span>
        </div>
      </template>

      <template #error>
        <section class="state-panel">
          <p class="state-text">{{ t('module.notification-setting.page.loadError') }}</p>
          <el-button type="primary" plain @click="reload">
            {{ t('module.notification-setting.page.reload') }}
          </el-button>
        </section>
      </template>

      <form class="page-form" @submit.prevent="handleSave">
        <!-- Human-readable before→after preview (same mental model as audit field changes) -->
        <section
          v-if="pendingChangeRows.length"
          class="change-preview"
          data-guide-anchor="change-preview"
        >
          <div class="change-preview__head">
            <h2>{{ t('module.notification-setting.change.title') }}</h2>
            <p>{{ t('module.notification-setting.change.intro') }}</p>
          </div>
          <ul class="change-preview__list">
            <li
              v-for="row in pendingChangeRows"
              :key="row.id"
              class="change-preview__item"
            >
              <div class="change-preview__field">{{ row.field }}</div>
              <div class="change-preview__values">
                <span class="value-chip value-chip--before">
                  <span class="value-chip__label">{{ t('module.notification-setting.change.before') }}</span>
                  <span class="value-chip__text">{{ row.before }}</span>
                </span>
                <span class="value-arrow" aria-hidden="true">→</span>
                <span class="value-chip value-chip--after">
                  <span class="value-chip__label">{{ t('module.notification-setting.change.after') }}</span>
                  <span class="value-chip__text">{{ row.after }}</span>
                </span>
              </div>
            </li>
          </ul>
        </section>

        <section class="setting-grid" data-guide-anchor="settings">
          <el-card shadow="never" class="setting-card">
            <template #header>
              <div class="setting-card__header">
                <div>
                  <h2>{{ t('module.notification-setting.card.status.title') }}</h2>
                  <p>{{ t('module.notification-setting.card.status.description') }}</p>
                </div>
              </div>
            </template>
            <el-form label-position="top" class="setting-form brick-required-form">
              <div class="setting-form__full toggle-brief">
                <div>
                  <p class="toggle-brief__label console-required-label">
                    {{ t('module.notification-setting.card.status.enabledLabel') }}
                  </p>
                  <p class="toggle-brief__description">
                    {{ t('module.notification-setting.card.status.enabledDescription') }}
                  </p>
                </div>
                <el-switch
                  v-model="form.enabled"
                  inline-prompt
                  :active-text="t('module.notification-setting.switch.on')"
                  :inactive-text="t('module.notification-setting.switch.off')"
                  @change="clearStoredPassword = false"
                />
              </div>
            </el-form>
          </el-card>

          <el-card shadow="never" class="setting-card">
            <template #header>
              <div class="setting-card__header">
                <div>
                  <h2>{{ t('module.notification-setting.card.smtp.title') }}</h2>
                  <p>{{ t('module.notification-setting.card.smtp.description') }}</p>
                </div>
              </div>
            </template>
            <el-form label-position="top" class="setting-form brick-required-form" :class="{ 'is-muted': !form.enabled }">
              <el-form-item :label="t('module.notification-setting.field.hostRequired')" required>
                <el-input
                  ref="hostInputRef"
                  v-model="form.host"
                  :placeholder="t('module.notification-setting.field.hostPlaceholder')"
                />
              </el-form-item>
              <el-form-item :label="t('module.notification-setting.field.portRequired')" required>
                <el-input
                  ref="portInputRef"
                  v-model.number="form.port"
                  type="number"
                  min="1"
                  :placeholder="t('module.notification-setting.field.portPlaceholder')"
                />
              </el-form-item>
              <el-form-item :label="t('module.notification-setting.field.usernameRequired')" required>
                <el-input
                  ref="usernameInputRef"
                  v-model="form.username"
                  :placeholder="t('module.notification-setting.field.usernamePlaceholder')"
                />
              </el-form-item>
              <el-form-item :label="t('module.notification-setting.field.passwordStatus')">
                <div class="readonly-field">{{ passwordStatusLabel }}</div>
              </el-form-item>
              <el-form-item :label="t('module.notification-setting.field.passwordOptional')">
                <el-input
                  v-model="passwordDraft"
                  type="password"
                  show-password
                  :placeholder="t('module.notification-setting.field.passwordPlaceholder')"
                  @input="clearStoredPassword = false"
                />
              </el-form-item>
              <div v-if="canClearStoredPassword" class="setting-form__full">
                <el-checkbox v-model="clearStoredPassword">
                  {{ t('module.notification-setting.field.clearPassword') }}
                </el-checkbox>
              </div>
            </el-form>
          </el-card>

          <el-card shadow="never" class="setting-card" data-guide-anchor="test-send">
            <template #header>
              <div class="setting-card__header">
                <div>
                  <h2>{{ t('module.notification-setting.card.test.title') }}</h2>
                  <p>{{ t('module.notification-setting.card.test.description') }}</p>
                </div>
              </div>
            </template>
            <el-form label-position="top" class="setting-form brick-required-form">
              <el-form-item :label="t('module.notification-setting.field.testToRequired')" required>
                <el-input
                  ref="testToAddressInputRef"
                  v-model="testToAddress"
                  :placeholder="t('module.notification-setting.field.testToPlaceholder')"
                  :disabled="!canTestSend || testing"
                />
              </el-form-item>
              <p v-if="hasUnsavedChanges" class="toggle-brief__description setting-form__full">
                {{ t('module.notification-setting.test.blockedUnsaved') }}
              </p>
              <p v-else-if="!canTestSend" class="toggle-brief__description setting-form__full">
                {{ t('module.notification-setting.test.blockedIncomplete') }}
              </p>
              <div class="setting-form__full">
                <!-- Use solid primary (same as save) so label stays readable on console card surface;
                     plain primary inherits low-contrast theme tokens and can look blank until hover. -->
                <el-button type="primary" :disabled="!canTestSend" :loading="testing" @click="testSend">
                  {{ t('module.notification-setting.test.sendButton') }}
                </el-button>
              </div>
            </el-form>
          </el-card>
        </section>

        <BrickActionBar class="page-footer" sticky :loading="saving || testing" data-guide-anchor="save-area">
          <template #primary>
            <div class="footer-actions">
              <el-button type="primary" native-type="submit" :loading="saving">
                {{ t('module.notification-setting.action.save') }}
              </el-button>
            </div>
          </template>
        </BrickActionBar>
      </form>
    </BrickPageBlock>
  </article>
</template>

<style>
@import "@wildbuck/core-ui-frontend/settings-page.css";

.change-preview {
  display: grid;
  gap: 12px;
  margin-bottom: 18px;
  padding: 16px 18px;
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: var(--console-card-radius, 8px);
  background: var(--console-card-bg, #ffffff);
}

.change-preview__head h2,
.change-preview__head p {
  margin: 0;
}

.change-preview__head h2 {
  color: var(--console-title, #172033);
  font-size: 16px;
}

.change-preview__head p {
  margin-top: 6px;
  color: var(--console-muted, #7e8ba0);
  font-size: 13px;
  line-height: 1.5;
}

.change-preview__list {
  display: grid;
  gap: 10px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.change-preview__item {
  display: grid;
  gap: 8px;
  padding: 12px 14px;
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: 8px;
  background: var(--console-page-bg, #f6f8f8);
}

.change-preview__field {
  color: var(--console-title, #172033);
  font-size: 13px;
  font-weight: 700;
}

.change-preview__values {
  display: flex;
  flex-wrap: wrap;
  align-items: stretch;
  gap: 10px;
}

.value-chip {
  flex: 1 1 140px;
  display: grid;
  gap: 4px;
  min-width: 0;
  padding: 8px 10px;
  border-radius: 8px;
}

.value-chip--before {
  background: rgba(180, 35, 47, 0.06);
  border: 1px solid rgba(180, 35, 47, 0.12);
}

.value-chip--after {
  background: rgba(24, 129, 104, 0.08);
  border: 1px solid rgba(24, 129, 104, 0.16);
}

.value-chip__label {
  color: var(--console-muted, #7e8ba0);
  font-size: 11px;
  font-weight: 700;
}

.value-chip__text {
  color: var(--console-title, #172033);
  font-size: 13px;
  word-break: break-word;
}

.value-chip--before .value-chip__text {
  text-decoration: line-through;
  text-decoration-color: rgba(180, 35, 47, 0.35);
}

.value-arrow {
  align-self: center;
  color: var(--console-muted, #7e8ba0);
  font-weight: 700;
}
</style>
