import {
  getEmailSmtpProviderSetting,
  testSendEmailSmtpProviderSetting,
  updateEmailSmtpProviderSetting,
} from '../../../generated/sdk';
import type {
  EmailSmtpProviderSettingDetail,
  EmailSmtpTestSendRequest,
  EmailSmtpTestSendResult,
  UpdateEmailSmtpProviderSettingRequest,
} from '../../../generated/types';

export async function loadEmailSmtpProviderSetting(settingId = 'email-smtp'): Promise<EmailSmtpProviderSettingDetail> {
  return getEmailSmtpProviderSetting({ settingId });
}

export async function saveEmailSmtpProviderSetting(
  input: UpdateEmailSmtpProviderSettingRequest,
): Promise<EmailSmtpProviderSettingDetail> {
  return updateEmailSmtpProviderSetting(input);
}

export async function sendEmailSmtpTestMail(
  input: EmailSmtpTestSendRequest,
): Promise<EmailSmtpTestSendResult> {
  return testSendEmailSmtpProviderSetting(input);
}
