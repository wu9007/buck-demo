import { emailSmtpPermissions } from './permission/index.js';
import { notificationSettingRoutes } from '../../routes/index.js';

export const emailSmtpFeature = {
  featureKey: 'email-smtp',
  routes: notificationSettingRoutes,
  permissions: emailSmtpPermissions,
};
