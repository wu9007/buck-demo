export const emailSmtpPermissions = {
  view: 'notification-setting:email-smtp:view',
  manage: 'notification-setting:email-smtp:manage',
};
