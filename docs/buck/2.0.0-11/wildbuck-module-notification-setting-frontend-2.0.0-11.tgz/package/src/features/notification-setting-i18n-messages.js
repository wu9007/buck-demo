/** Notification-setting frontend copy packs. Keys: module.notification-setting.* — register via createBrickI18nRuntime. */

export const NOTIFICATION_SETTING_MESSAGES_ZH_CN = Object.freeze({
  'module.notification-setting.meta.displayName': '通知配置',

  'module.notification-setting.page.eyebrow': '通知配置 / 邮件通道',
  'module.notification-setting.page.title': '邮件通道配置',
  'module.notification-setting.page.description':
    '管理 EMAIL 通道 SMTP 配置，供 MFA 与系统邮件复用。保存前可预览「变更前 → 变更后」；审计日志同样按字段记录人类可读变更。',
  'module.notification-setting.page.loading': '正在加载邮件通道配置...',
  'module.notification-setting.page.loadError': '邮件通道配置加载失败，请重新加载后重试。',
  'module.notification-setting.page.reload': '重新加载',
  'module.notification-setting.page.unsavedChanges': '有未保存更改',

  'module.notification-setting.change.title': '本次将保存的变更',
  'module.notification-setting.change.intro': '按字段查看从旧值到新值的变化，保存后审计日志也会按同样方式记录。',
  'module.notification-setting.change.before': '变更前',
  'module.notification-setting.change.after': '变更后',
  'module.notification-setting.change.empty': '（空）',
  'module.notification-setting.change.enabledOn': '已启用',
  'module.notification-setting.change.enabledOff': '已停用',
  'module.notification-setting.change.passwordClear': '将清空',
  'module.notification-setting.change.field.enabled': '启用状态',
  'module.notification-setting.change.field.host': 'SMTP 主机',
  'module.notification-setting.change.field.port': 'SMTP 端口',
  'module.notification-setting.change.field.username': '认证账号',
  'module.notification-setting.change.field.password': '认证密码',

  'module.notification-setting.card.status.title': '邮件通道状态',
  'module.notification-setting.card.status.description':
    '启用后，MFA 和其他 EMAIL 通知会复用这里的 SMTP 配置。',
  'module.notification-setting.card.status.enabledLabel': '启用邮件通道（必填）',
  'module.notification-setting.card.status.enabledDescription':
    '未启用时，EMAIL MFA 和其他邮件通知不可用。',
  'module.notification-setting.switch.on': '开',
  'module.notification-setting.switch.off': '关',

  'module.notification-setting.card.smtp.title': 'SMTP 连接与认证',
  'module.notification-setting.card.smtp.description':
    '只维护真实 SMTP 连接参数；认证密码留空表示沿用已存值。',
  'module.notification-setting.field.host': 'SMTP 主机',
  'module.notification-setting.field.hostRequired': 'SMTP 主机（必填）',
  'module.notification-setting.field.hostPlaceholder': '例如 smtp.163.com',
  'module.notification-setting.field.port': 'SMTP 端口',
  'module.notification-setting.field.portRequired': 'SMTP 端口（必填）',
  'module.notification-setting.field.portPlaceholder': '默认 465',
  'module.notification-setting.field.portInvalid': '请先填写有效的 SMTP 端口。',
  'module.notification-setting.field.username': '认证账号',
  'module.notification-setting.field.usernameRequired': '认证账号（必填）',
  'module.notification-setting.field.usernamePlaceholder': '例如 notifier@example.com',
  'module.notification-setting.field.passwordStatus': '已存密码状态',
  'module.notification-setting.field.passwordOptional': '认证密码（选填）',
  'module.notification-setting.field.passwordPlaceholder': '留空表示沿用已存密码',
  'module.notification-setting.field.clearPassword': '停用时同时清空已存密码',

  'module.notification-setting.password.pending': '待更新',
  'module.notification-setting.password.configured': '已配置',
  'module.notification-setting.password.unconfigured': '未配置',

  'module.notification-setting.card.test.title': '测试发送',
  'module.notification-setting.card.test.description':
    '使用已保存并启用的正式 SMTP 配置发送探测邮件；不会在页面回显密码。',
  'module.notification-setting.field.testTo': '测试收件地址',
  'module.notification-setting.field.testToRequired': '测试收件地址（必填）',
  'module.notification-setting.field.testToPlaceholder': '例如 you@example.com',
  'module.notification-setting.field.testToInvalid': '请先填写有效的测试收件邮箱。',
  'module.notification-setting.test.blockedUnsaved': '有未保存更改时不能测试发送，请先保存配置。',
  'module.notification-setting.test.blockedIncomplete':
    '请先保存并启用完整的 SMTP 配置后再测试发送。',
  'module.notification-setting.test.sendButton': '发送测试邮件',
  'module.notification-setting.test.sendFailed': '测试邮件发送失败',

  'module.notification-setting.action.save': '保存邮件通道配置',

  'module.notification-setting.status.saved': '邮件通道配置已保存。',
  'module.notification-setting.status.testSubmitted': '测试邮件已提交发送，请检查收件箱。',
  'module.notification-setting.status.testBlocked':
    '请先保存并启用完整的 SMTP 配置后再测试发送。',
});

export const NOTIFICATION_SETTING_MESSAGES_EN_US = Object.freeze({
  'module.notification-setting.meta.displayName': 'Notification settings',

  'module.notification-setting.page.eyebrow': 'Notification / Email channel',
  'module.notification-setting.page.title': 'Email channel',
  'module.notification-setting.page.description':
    'Manage SMTP for the EMAIL channel (MFA and system mail). Preview before→after changes before save; audit logs record the same human-readable field diffs.',
  'module.notification-setting.page.loading': 'Loading email channel settings…',
  'module.notification-setting.page.loadError':
    'Failed to load email channel settings. Reload and try again.',
  'module.notification-setting.page.reload': 'Reload',
  'module.notification-setting.page.unsavedChanges': 'Unsaved changes',

  'module.notification-setting.change.title': 'Changes that will be saved',
  'module.notification-setting.change.intro':
    'Review each field from the old value to the new value. Audit logs use the same human-readable format after save.',
  'module.notification-setting.change.before': 'Before',
  'module.notification-setting.change.after': 'After',
  'module.notification-setting.change.empty': '(empty)',
  'module.notification-setting.change.enabledOn': 'Enabled',
  'module.notification-setting.change.enabledOff': 'Disabled',
  'module.notification-setting.change.passwordClear': 'Will clear',
  'module.notification-setting.change.field.enabled': 'Enabled',
  'module.notification-setting.change.field.host': 'SMTP host',
  'module.notification-setting.change.field.port': 'SMTP port',
  'module.notification-setting.change.field.username': 'Auth username',
  'module.notification-setting.change.field.password': 'Auth password',

  'module.notification-setting.card.status.title': 'Channel status',
  'module.notification-setting.card.status.description':
    'When enabled, MFA and other EMAIL notifications reuse this SMTP configuration.',
  'module.notification-setting.card.status.enabledLabel': 'Enable email channel (required)',
  'module.notification-setting.card.status.enabledDescription':
    'When disabled, EMAIL MFA and other mail notifications are unavailable.',
  'module.notification-setting.switch.on': 'On',
  'module.notification-setting.switch.off': 'Off',

  'module.notification-setting.card.smtp.title': 'SMTP connection and auth',
  'module.notification-setting.card.smtp.description':
    'Maintain real SMTP connection parameters only; leave the password blank to keep the stored value.',
  'module.notification-setting.field.host': 'SMTP host',
  'module.notification-setting.field.hostRequired': 'SMTP host (required)',
  'module.notification-setting.field.hostPlaceholder': 'e.g. smtp.example.com',
  'module.notification-setting.field.port': 'SMTP port',
  'module.notification-setting.field.portRequired': 'SMTP port (required)',
  'module.notification-setting.field.portPlaceholder': 'Default 465',
  'module.notification-setting.field.portInvalid': 'Enter a valid SMTP port first.',
  'module.notification-setting.field.username': 'Auth username',
  'module.notification-setting.field.usernameRequired': 'Auth username (required)',
  'module.notification-setting.field.usernamePlaceholder': 'e.g. notifier@example.com',
  'module.notification-setting.field.passwordStatus': 'Stored password status',
  'module.notification-setting.field.passwordOptional': 'Auth password (optional)',
  'module.notification-setting.field.passwordPlaceholder': 'Leave blank to keep the stored password',
  'module.notification-setting.field.clearPassword': 'Also clear stored password when disabling',

  'module.notification-setting.password.pending': 'Pending update',
  'module.notification-setting.password.configured': 'Configured',
  'module.notification-setting.password.unconfigured': 'Not configured',

  'module.notification-setting.card.test.title': 'Test send',
  'module.notification-setting.card.test.description':
    'Send a probe message with the saved, enabled SMTP configuration. Passwords are never shown on the page.',
  'module.notification-setting.field.testTo': 'Test recipient',
  'module.notification-setting.field.testToRequired': 'Test recipient (required)',
  'module.notification-setting.field.testToPlaceholder': 'e.g. you@example.com',
  'module.notification-setting.field.testToInvalid': 'Enter a valid test recipient email first.',
  'module.notification-setting.test.blockedUnsaved':
    'Cannot test while there are unsaved changes. Save the configuration first.',
  'module.notification-setting.test.blockedIncomplete':
    'Save and enable a complete SMTP configuration before testing.',
  'module.notification-setting.test.sendButton': 'Send test email',
  'module.notification-setting.test.sendFailed': 'Failed to send test email',

  'module.notification-setting.action.save': 'Save email channel',

  'module.notification-setting.status.saved': 'Email channel settings saved.',
  'module.notification-setting.status.testSubmitted':
    'Test email submitted. Check the recipient inbox.',
  'module.notification-setting.status.testBlocked':
    'Save and enable a complete SMTP configuration before testing.',
});

export const NOTIFICATION_SETTING_MESSAGES = Object.freeze({
  'zh-CN': NOTIFICATION_SETTING_MESSAGES_ZH_CN,
  'en-US': NOTIFICATION_SETTING_MESSAGES_EN_US,
});
