export {
  NOTIFICATION_SETTING_MESSAGES,
  NOTIFICATION_SETTING_MESSAGES_EN_US,
  NOTIFICATION_SETTING_MESSAGES_ZH_CN,
  resolveNotificationSettingMessages,
  translateNotificationSetting,
  useNotificationSettingI18n,
} from './features/notification-setting-i18n.js';
