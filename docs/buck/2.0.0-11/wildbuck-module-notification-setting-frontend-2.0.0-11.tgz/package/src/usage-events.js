import { createModuleUsageTracker } from '@wildbuck/core-usage-event-frontend';

export const NOTIFICATION_SETTING_USAGE_EVENT_MODULE_CODE = 'notification-setting';

export const notificationSettingUsageEventMatrix = deepFreeze({
  pages: {
    emailSmtp: {
      featureCode: 'email-smtp',
      pageCode: 'email-smtp-page',
      routeName: 'notification-setting.email-smtp',
    },
  },
  features: {
    emailSmtpConfig: {
      featureCode: 'email-smtp-config',
      pageCode: 'email-smtp-page',
      routeName: 'notification-setting.email-smtp',
      viewActionCode: 'open-config',
    },
    emailSmtpTestSend: {
      featureCode: 'email-smtp-test-send',
      pageCode: 'email-smtp-page',
      routeName: 'notification-setting.email-smtp',
      viewActionCode: 'open-test-send',
    },
  },
});

export const notificationSettingUsageTracker = createModuleUsageTracker(
  NOTIFICATION_SETTING_USAGE_EVENT_MODULE_CODE,
  notificationSettingUsageEventMatrix,
);

function deepFreeze(value) {
  if (value == null || typeof value !== 'object') {
    return value;
  }
  for (const child of Object.values(value)) {
    deepFreeze(child);
  }
  return Object.freeze(value);
}
