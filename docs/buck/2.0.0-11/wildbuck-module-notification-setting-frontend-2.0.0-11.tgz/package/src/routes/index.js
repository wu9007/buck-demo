export const notificationSettingRoutes = [
  {
    id: 'notification-setting.email-smtp',
    featureKey: 'email-smtp',
    path: '/notification-setting/email-smtp',
    title: '邮件通道配置',
    abbr: '邮',
    eyebrow: '通知配置 / 邮件通道',
    summary: '管理 EMAIL 通道当前生效的 SMTP 提供方配置。',
    guide: {
      title: '邮件通道配置路径',
      steps: [
        {
          anchor: 'summary',
          title: '先确认是否启用',
          body: '进入页面后先确认邮件通道是否启用，未启用时先打开开关。',
        },
        {
          anchor: 'settings',
          title: '再维护 SMTP 配置',
          body: '只维护 SMTP 主机、端口、认证账号、认证密码和发件人信息。',
        },
        {
          anchor: 'save-area',
          title: '最后保存配置',
          body: '保存后即可供 EMAIL MFA 和其他邮件通知复用。',
        },
      ],
    },
    messages: {
      viewTitle: '邮件通道配置',
      guideTitle: '邮件通道配置路径',
    },
    permission: 'notification-setting:email-smtp:view',
    component: () => import('../features/email-smtp/pages/EmailSmtpProviderSettingPage.vue'),
  },
];

export const notificationSettingWorkbenchCards = [
  {
    cardId: 'notification-setting.email-smtp.summary',
    title: '邮件通道配置',
    summary: '查看当前 EMAIL 通道的 SMTP 提供方配置与启用状态。',
    routeId: 'notification-setting.email-smtp',
    priority: 80,
  },
];

export default function registerNotificationSettingRoutes() {
  return notificationSettingRoutes.map((route) => ({
    path: route.path,
    name: route.id,
    component: route.component,
  }));
}
