export type NotificationSettingUsageEventPageKey = 'emailSmtp';
export type NotificationSettingUsageEventFeatureKey = 'emailSmtpConfig';
export type NotificationSettingUsageEventActionCode = 'save';

export interface NotificationSettingUsageEventPageEntry {
  featureCode: string;
  pageCode: string;
  routeName: string;
}

export interface NotificationSettingUsageEventFeatureEntry extends NotificationSettingUsageEventPageEntry {
  viewActionCode: 'open-config';
}

export declare const NOTIFICATION_SETTING_USAGE_EVENT_MODULE_CODE: 'notification-setting';
export declare const notificationSettingUsageEventMatrix: Readonly<{
  pages: Record<NotificationSettingUsageEventPageKey, Readonly<NotificationSettingUsageEventPageEntry>>;
  features: Record<
    NotificationSettingUsageEventFeatureKey,
    Readonly<NotificationSettingUsageEventFeatureEntry>
  >;
}>;
export declare const notificationSettingUsageTracker: import('@wildbuck/core-usage-event-frontend').BrickModuleUsageTracker;
