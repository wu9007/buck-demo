export const brickRouteComponentLoaders = {
  'notification-setting.email-smtp': () => import('./features/email-smtp/pages/EmailSmtpProviderSettingPage.vue'),
};
