import { emailSmtpFeature } from './features/email-smtp/index.js';
import registerNotificationSettingRoutes, {
  notificationSettingRoutes,
  notificationSettingWorkbenchCards,
} from './routes/index.js';

export const notificationSettingFeatureRegistry = {
  emailSmtp: emailSmtpFeature,
};

export const notificationSettingPermissionMap = {
  emailSmtp: emailSmtpFeature.permissions,
};

export default {
  name: 'notification-setting',
  register() {
    return {
      routes: registerNotificationSettingRoutes(),
    };
  },
};

export const brickModuleKey = 'notification-setting';
export const brickModuleMeta = {
  displayName: '通知配置',
};
export const brickFeatureRegistry = notificationSettingFeatureRegistry;
export const brickPermissionMap = notificationSettingPermissionMap;
export const brickRoutes = notificationSettingRoutes;

export { notificationSettingRoutes, notificationSettingWorkbenchCards };
export {
  NOTIFICATION_SETTING_USAGE_EVENT_MODULE_CODE,
  notificationSettingUsageEventMatrix,
  notificationSettingUsageTracker,
} from './usage-events.js';
