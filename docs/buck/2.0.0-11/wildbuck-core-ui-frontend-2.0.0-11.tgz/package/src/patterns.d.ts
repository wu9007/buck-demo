import type { Component } from 'vue';

export { useBrickFilterDraft } from './list-filters';
export type { BrickFilterDraftApi } from './list-filters';

export declare const BrickFilterToolbar: Component;
export declare const BrickPageHeader: Component;
export declare const BrickListPageActions: Component;
export declare const BrickSelectionActionBar: Component;
export declare const BrickImportExportMenu: Component;
export declare const BrickPageBlock: Component;
export declare const BrickStatStrip: Component;
export declare const BrickEmptyState: Component;
export declare const BrickPaginationBar: Component;
export declare const BrickActionBar: Component;
export declare const BrickRiskConfirm: Component;
export declare const BrickStepUpConfirm: Component;
export declare const BrickSessionRecoveryOverlay: Component;
export declare const BrickTableMoreMenu: Component;
export declare const BrickTableActions: Component;
/** @deprecated Prefer `BrickTableActions`. */
export declare const IamTableActions: Component;
export declare const BrickSettingsGrid: Component;
export declare const BrickSettingsCard: Component;
export declare const BrickSettingsDrawer: Component;
export declare const BrickSettingsDrawerSection: Component;
export declare const BrickSettingsEnableSwitch: Component;
export declare const BrickSettingsScale: Component;
export declare const BrickSettingsSegmentChoice: Component;
export declare const BrickSettingsCheckGrid: Component;
export declare const BrickSettingsPreview: Component;
export declare const BrickSettingsStaticNote: Component;
/** @deprecated Use `BrickSettingsGrid`. */
export declare const BrickPolicyGrid: Component;
/** @deprecated Use `BrickSettingsCard`. */
export declare const BrickPolicyCard: Component;
/** @deprecated Use `BrickSettingsDrawer`. */
export declare const BrickPolicyDrawer: Component;
/** @deprecated Use `BrickSettingsDrawerSection`. */
export declare const BrickPolicyDrawerSection: Component;
/** @deprecated Use `BrickSettingsEnableSwitch`. */
export declare const BrickPolicyEnableSwitch: Component;
/** @deprecated Use `BrickSettingsScale`. */
export declare const BrickPolicyScale: Component;
/** @deprecated Use `BrickSettingsSegmentChoice`. */
export declare const BrickPolicySegmentChoice: Component;
/** @deprecated Use `BrickSettingsCheckGrid`. */
export declare const BrickPolicyCheckGrid: Component;
/** @deprecated Use `BrickSettingsPreview`. */
export declare const BrickPolicyPreview: Component;
/** @deprecated Use `BrickSettingsStaticNote`. */
export declare const BrickPolicyStaticNote: Component;
