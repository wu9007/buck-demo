const THEME_PRESETS = Object.freeze({
  blue: freezeTheme('浅蓝（默认）', 'light', '克制浅色侧栏与浅色内容区，作为正式日间默认主题。', {
    '--shell-bg': '#f1f5f9',
    '--panel-bg': '#ffffff',
    '--panel-border': '#e2e8f0',
    '--ink-strong': '#0f172a',
    '--ink-normal': '#334155',
    '--ink-muted': '#64748b',
    '--accent': '#2563eb',
    '--accent-strong': '#1d4ed8',
    '--accent-soft': '#dbeafe',
    '--sidebar-bg': '#f8fafc',
    '--sidebar-border': '#e2e8f0',
    '--sidebar-ink': '#0f172a',
    '--sidebar-muted': '#64748b',
    '--sidebar-active-bg': '#2563eb',
    '--sidebar-active-ink': '#ffffff',
    '--topbar-bg': '#ffffff',
    '--topbar-border': '#e2e8f0',
    '--content-tint': '#f1f5f9'
  }),
  orange: freezeTheme('活力橙（深侧栏）', 'brand-sidebar', '橙色品牌侧栏与浅色内容区，不是全暗主题。', {
    '--shell-bg': '#fff8ed',
    '--panel-bg': '#fffdf8',
    '--panel-border': '#f0d7b8',
    '--ink-strong': '#2f2418',
    '--ink-normal': '#60482f',
    '--ink-muted': '#8a6e50',
    '--accent': '#c65310',
    '--accent-strong': '#9a3f0c',
    '--accent-soft': '#fde7cf',
    '--sidebar-bg': '#422412',
    '--sidebar-border': '#6d3a18',
    '--sidebar-ink': '#ffe8d1',
    '--sidebar-muted': '#dab991',
    '--sidebar-active-bg': '#8d4316',
    '--sidebar-active-ink': '#fff7ed',
    '--topbar-bg': '#fffdf8',
    '--topbar-border': '#f0d7b8',
    '--content-tint': '#fff1df'
  }),
  guard: freezeTheme('守卫蓝（深侧栏）', 'brand-sidebar', '深蓝品牌侧栏与浅色内容区，不是全暗主题。', {
    '--shell-bg': '#f4f7fb',
    '--panel-bg': '#ffffff',
    '--panel-border': '#cfd8e5',
    '--ink-strong': '#172238',
    '--ink-normal': '#3b4d67',
    '--ink-muted': '#64748b',
    '--accent': '#143f8f',
    '--accent-strong': '#0f2e68',
    '--accent-soft': '#e0e7ff',
    '--sidebar-bg': '#10244b',
    '--sidebar-border': '#1d3a68',
    '--sidebar-ink': '#dbe7ff',
    '--sidebar-muted': '#9fb0cf',
    '--sidebar-active-bg': '#143f8f',
    '--sidebar-active-ink': '#ffffff',
    '--topbar-bg': '#ffffff',
    '--topbar-border': '#cfd8e5',
    '--content-tint': '#edf2ff'
  }),
  green: freezeTheme('奉献绿（深侧栏）', 'brand-sidebar', '绿色品牌侧栏与浅色内容区，不是全暗主题。', {
    '--shell-bg': '#f2fbf6',
    '--panel-bg': '#ffffff',
    '--panel-border': '#c7e5d1',
    '--ink-strong': '#153326',
    '--ink-normal': '#315844',
    '--ink-muted': '#5d7d6c',
    '--accent': '#12805c',
    '--accent-strong': '#0d6b4e',
    '--accent-soft': '#d8f5e6',
    '--sidebar-bg': '#0f2d22',
    '--sidebar-border': '#174333',
    '--sidebar-ink': '#d7f3e5',
    '--sidebar-muted': '#98b8aa',
    '--sidebar-active-bg': '#176f52',
    '--sidebar-active-ink': '#effff7',
    '--topbar-bg': '#ffffff',
    '--topbar-border': '#c7e5d1',
    '--content-tint': '#e1f7ec'
  }),
  night: freezeTheme('夜间暗色（全暗）', 'dark', '侧栏、顶部栏和内容区都进入暗色模式。', {
    '--shell-bg': '#0f172a',
    '--panel-bg': '#111827',
    '--panel-border': '#334155',
    '--ink-strong': '#f8fafc',
    '--ink-normal': '#dbeafe',
    '--ink-muted': '#94a3b8',
    '--accent': '#60a5fa',
    '--accent-strong': '#3b82f6',
    '--accent-soft': '#1e3a8a',
    '--sidebar-bg': '#020617',
    '--sidebar-border': '#1e293b',
    '--sidebar-ink': '#e2e8f0',
    '--sidebar-muted': '#94a3b8',
    '--sidebar-active-bg': '#1d4ed8',
    '--sidebar-active-ink': '#eff6ff',
    '--topbar-bg': '#111827',
    '--topbar-border': '#334155',
    '--content-tint': '#162033'
  })
});

export function createBrickConsoleThemePresets() {
  return THEME_PRESETS;
}

/**
 * Resolve the browser/PWA chrome color for a console theme.
 * Uses topbar surface (not accent) so installed window chrome matches the shell band.
 *
 * @param {string} [themeName]
 * @returns {string}
 */
export function resolveBrickConsoleBrowserThemeColor(themeName = 'blue') {
  const presets = createBrickConsoleThemePresets();
  const preset = presets[themeName] || presets.blue;
  return String(preset.tokens['--topbar-bg'] || '#ffffff');
}

/**
 * Project palette + console surface tokens onto documentElement.
 *
 * Why: Element Plus dialogs/message-boxes often teleport under `body`, outside
 * `.console-root` / `.brick-console-shell`. If `--console-*` only live on those
 * hosts, teleported UI falls back to light `#fff` and looks broken in night theme.
 * Document-root projection is the durable SoT so overlays inherit the active theme.
 *
 * @param {string} [themeName]
 * @param {Document | null} [documentRef]
 * @returns {string} resolved render theme name
 */
export function applyBrickConsoleDocumentThemeTokens(themeName = 'blue', documentRef = typeof document !== 'undefined' ? document : null) {
  if (!documentRef?.documentElement) {
    return String(themeName || 'blue');
  }
  const presets = createBrickConsoleThemePresets();
  const resolvedName = presets[themeName] ? themeName : 'blue';
  const preset = presets[resolvedName];
  const root = documentRef.documentElement;
  const tokens = preset.tokens || {};

  root.setAttribute('data-theme', resolvedName);
  root.style.colorScheme = preset.mode === 'dark' ? 'dark' : 'light';

  for (const [key, value] of Object.entries(tokens)) {
    if (typeof key === 'string' && key.startsWith('--') && value != null && value !== '') {
      root.style.setProperty(key, String(value));
    }
  }

  const shellBg = String(tokens['--shell-bg'] || '');
  const panelBg = String(tokens['--panel-bg'] || '');
  const panelBorder = String(tokens['--panel-border'] || '');
  const inkStrong = String(tokens['--ink-strong'] || '');
  const inkNormal = String(tokens['--ink-normal'] || '');
  const inkMuted = String(tokens['--ink-muted'] || '');
  const accent = String(tokens['--accent'] || '');
  const accentStrong = String(tokens['--accent-strong'] || '');
  const contentTint = String(tokens['--content-tint'] || shellBg);

  // Console aliases used by module CSS (must match theme.css host cascade intent).
  root.style.setProperty('--console-page-bg', shellBg);
  root.style.setProperty('--console-card-bg', panelBg);
  root.style.setProperty('--console-card-border', panelBorder);
  root.style.setProperty('--console-title', inkStrong);
  root.style.setProperty('--console-text', inkNormal);
  root.style.setProperty('--console-muted', inkMuted);
  root.style.setProperty('--console-primary', accent);
  root.style.setProperty('--console-block-bg', contentTint);
  root.style.setProperty('--console-block-border', panelBorder);
  root.style.setProperty('--console-field-bg', panelBg);
  root.style.setProperty('--console-field-border', panelBorder);
  // Soft inset surface: same role as block, preferred name in some modules.
  root.style.setProperty('--console-soft-bg', contentTint);

  if (preset.mode === 'dark') {
    root.style.setProperty('--console-success', '#4ade80');
    root.style.setProperty('--console-warning', '#fbbf24');
    root.style.setProperty('--console-danger', '#fb7185');
  } else {
    root.style.setProperty('--console-success', '#16a34a');
    root.style.setProperty('--console-warning', '#d97706');
    root.style.setProperty('--console-danger', '#dc2626');
  }

  // Element Plus overlay surfaces (dialog/drawer/message) read these on ancestors of body.
  root.style.setProperty('--el-color-primary', accent);
  root.style.setProperty('--el-color-primary-dark-2', accentStrong || accent);
  root.style.setProperty('--el-bg-color', panelBg);
  root.style.setProperty('--el-bg-color-overlay', panelBg);
  root.style.setProperty('--el-bg-color-page', shellBg);
  root.style.setProperty('--el-fill-color-blank', panelBg);
  root.style.setProperty('--el-fill-color-light', contentTint);
  root.style.setProperty('--el-fill-color-lighter', contentTint);
  root.style.setProperty('--el-fill-color-extra-light', panelBg);
  root.style.setProperty('--el-dialog-bg-color', panelBg);
  root.style.setProperty('--el-mask-color', preset.mode === 'dark' ? 'rgba(2, 6, 23, 0.72)' : 'rgba(15, 23, 42, 0.48)');
  root.style.setProperty('--el-border-color', panelBorder);
  root.style.setProperty('--el-border-color-light', panelBorder);
  root.style.setProperty('--el-text-color-primary', inkStrong);
  root.style.setProperty('--el-text-color-regular', inkNormal);
  root.style.setProperty('--el-text-color-secondary', inkMuted);
  const success = root.style.getPropertyValue('--console-success') || (preset.mode === 'dark' ? '#4ade80' : '#16a34a');
  const warning = root.style.getPropertyValue('--console-warning') || (preset.mode === 'dark' ? '#fbbf24' : '#d97706');
  const danger = root.style.getPropertyValue('--console-danger') || (preset.mode === 'dark' ? '#fb7185' : '#dc2626');
  const info = inkMuted || accent;
  root.style.setProperty('--el-color-success', success);
  root.style.setProperty('--el-color-warning', warning);
  root.style.setProperty('--el-color-danger', danger);
  root.style.setProperty('--el-color-info', info);
  // Soft fills for el-tag / el-alert: mix onto card surface (works for light + night).
  const softMix = (color, amount) => `color-mix(in srgb, ${color} ${amount}%, ${panelBg || 'transparent'})`;
  for (const [name, color] of [
    ['primary', accent],
    ['success', success],
    ['warning', warning],
    ['danger', danger],
    ['info', info],
  ]) {
    root.style.setProperty(`--el-color-${name}-light-9`, softMix(color, 16));
    root.style.setProperty(`--el-color-${name}-light-8`, softMix(color, 22));
    root.style.setProperty(`--el-color-${name}-light-7`, softMix(color, 30));
    root.style.setProperty(`--el-color-${name}-light-5`, softMix(color, 45));
    root.style.setProperty(`--el-color-${name}-light-3`, softMix(color, 65));
  }

  return resolvedName;
}

/**
 * Apply theme-color meta for browser UI / installed PWA title bars,
 * and project console tokens onto documentElement for teleported overlays.
 *
 * @param {string} [themeName]
 * @param {Document | null} [documentRef]
 * @returns {string}
 */
export function applyBrickConsoleBrowserChromeTheme(themeName = 'blue', documentRef = typeof document !== 'undefined' ? document : null) {
  const color = resolveBrickConsoleBrowserThemeColor(themeName);
  if (!documentRef || !documentRef.head) {
    return color;
  }
  let meta = documentRef.querySelector('meta[name="theme-color"]');
  if (!meta) {
    meta = documentRef.createElement('meta');
    meta.setAttribute('name', 'theme-color');
    documentRef.head.appendChild(meta);
  }
  meta.setAttribute('content', color);
  applyBrickConsoleDocumentThemeTokens(themeName, documentRef);
  return color;
}

function freezeTheme(label, mode, description, tokens) {
  return Object.freeze({
    label,
    mode,
    description,
    tokens: Object.freeze(withShellAliasTokens(tokens))
  });
}

function withShellAliasTokens(tokens) {
  return {
    ...tokens,
    '--shell-sidebar-bg': tokens['--sidebar-bg'],
    '--shell-sidebar-border': tokens['--sidebar-border'],
    '--shell-sidebar-ink': tokens['--sidebar-ink'],
    '--shell-sidebar-muted': tokens['--sidebar-muted'],
    '--shell-sidebar-active-bg': tokens['--sidebar-active-bg'],
    '--shell-sidebar-active-ink': tokens['--sidebar-active-ink'],
    '--shell-topbar-bg': tokens['--topbar-bg'],
    '--shell-topbar-border': tokens['--topbar-border']
  };
}
