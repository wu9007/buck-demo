import type { BrickConsoleRoute, BrickConsoleRouteGroup } from './shell-navigation';

export interface BrickWorkspaceProfile {
  id: string;
  title?: string;
  label?: string;
  defaultPath?: string;
  routeIds?: string[];
  menuIds?: string[];
  pathPrefixes?: string[];
  /** Principal must have every code. */
  requiredPermissions?: string[];
  /** When non-empty, principal must have at least one code. */
  anyPermissions?: string[];
}

export declare const BRICK_CONSOLE_WORKSPACE_PROFILE_STORAGE_KEY: string;

export declare function normalizeBrickWorkspaceProfile(
  profile: unknown,
): BrickWorkspaceProfile | null;

export declare function normalizeBrickWorkspaceProfiles(
  profiles?: unknown[],
): BrickWorkspaceProfile[];

export declare function isBrickWorkspaceProfileAvailable(
  profile: unknown,
  permissions?: Iterable<string>,
): boolean;

export declare function listAvailableBrickWorkspaceProfiles(
  profiles?: unknown[],
  permissions?: Iterable<string>,
): BrickWorkspaceProfile[];

export declare function resolveBrickWorkspaceProfileId(
  profiles?: unknown[],
  permissions?: Iterable<string>,
  preferredId?: string,
): string;

export declare function findBrickWorkspaceProfile(
  profiles?: unknown[],
  profileId?: string,
): BrickWorkspaceProfile | null;

export declare function routeMatchesBrickWorkspaceProfile(
  route: unknown,
  profile: unknown,
): boolean;

export declare function filterBrickConsoleRoutesByWorkspaceProfile(
  routes?: unknown[],
  profile?: unknown,
  permissions?: Iterable<string>,
): BrickConsoleRoute[];

export declare function filterBrickConsoleNavigationGroupsByWorkspaceProfile(
  groups?: unknown[],
  profile?: unknown,
  permissions?: Iterable<string>,
): BrickConsoleRouteGroup[];

export declare function readBrickWorkspaceProfilePreference(
  storage?: Storage | null,
): string;

export declare function writeBrickWorkspaceProfilePreference(
  profileId: string,
  storage?: Storage | null,
): string;
