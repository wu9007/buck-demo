export const BRICK_CONSOLE_WORKBENCH_ROUTE = Object.freeze({
  id: 'workbench',
  title: '工作台',
  path: '/',
  group: 'workspace',
  order: 0,
  permissions: []
});

export const BRICK_CONSOLE_DEFAULT_ROUTE_GROUPS = Object.freeze([
  Object.freeze({ key: 'workspace', label: '工作台', order: 0 }),
  Object.freeze({ key: 'business', label: '业务功能', order: 100 }),
  Object.freeze({ key: 'governance', label: '治理中心', order: 200 }),
  Object.freeze({ key: 'security', label: '安全设置', order: 300 })
]);
const BRICK_CONSOLE_MANAGEMENT_INTENT_EVENT = 'brick:management-intent';
const BRICK_CONSOLE_COLLAPSED_GROUPS_STORAGE_KEY = 'brick-console:sidebar-collapsed-groups';
const BRICK_CONSOLE_LEGACY_COLLAPSED_GROUPS_STORAGE_KEY = 'brick-governance-foundation:collapsed-shell-groups';
/** sessionStorage: survive hard refresh, clear on tab close / explicit logout write. */
export const BRICK_CONSOLE_ACTIVE_ROUTE_STORAGE_KEY = 'brick-console:active-route-id';

export function collectBrickConsoleRoutes(catalogOrModules = []) {
  const modules = Array.isArray(catalogOrModules) ? catalogOrModules : catalogOrModules.modules ?? [];
  return modules
    .flatMap((module) => module?.routes ?? module?.brickRoutes ?? [])
    .filter((route) => route && route.id && route.path)
    .map((route) => ({
      id: route.id,
      title: route.title ?? route.name ?? route.id,
      path: route.path,
      group: route.group ?? route.category ?? 'business',
      order: Number.isFinite(route.order) ? route.order : Number.isFinite(route.sortNo) ? route.sortNo : 1000,
      icon: route.icon ?? route.menu?.icon,
      iconUrl: route.iconUrl ?? route.menu?.iconUrl,
      iconText: route.iconText ?? route.menu?.iconText,
      iconName: route.iconName ?? (typeof route.icon === 'string' ? route.icon : route.menu?.iconName),
      abbr: route.abbr ?? route.menu?.abbr,
      shortTitle: route.shortTitle ?? route.menu?.shortTitle,
      collapsedTitle: route.collapsedTitle ?? route.menu?.collapsedTitle,
      searchKeywords: route.searchKeywords ?? route.menu?.searchKeywords,
      keywords: route.keywords ?? route.menu?.keywords,
      permissions: Array.isArray(route.permissions) ? route.permissions : route.permission ? [route.permission] : []
    }));
}

export function canAccessBrickConsoleRoute(route, permissions = []) {
  const requiredPermissions = Array.isArray(route?.permissions) ? route.permissions : [];
  if (requiredPermissions.length === 0) {
    return true;
  }
  const granted = new Set(permissions ?? []);
  return requiredPermissions.every((permission) => granted.has(permission));
}

export function buildBrickConsoleNavigationGroups(
  routes = [],
  permissions = [],
  routeGroups = BRICK_CONSOLE_DEFAULT_ROUTE_GROUPS
) {
  const groupMap = new Map(routeGroups.map((group) => [group.key, { ...group, routes: [] }]));
  for (const route of routes) {
    if (!canAccessBrickConsoleRoute(route, permissions)) {
      continue;
    }
    const groupKey = route.group ?? 'business';
    if (!groupMap.has(groupKey)) {
      groupMap.set(groupKey, { key: groupKey, label: groupKey, order: 1000, routes: [] });
    }
    groupMap.get(groupKey).routes.push(route);
  }
  return [...groupMap.values()]
    .map((group) => ({
      ...group,
      routes: [...group.routes].sort(compareRouteOrder)
    }))
    .filter((group) => group.routes.length > 0)
    .sort((a, b) => (a.order ?? 1000) - (b.order ?? 1000));
}

export function mergeBrickConsoleRoutesWithMenus(routes = [], menus = []) {
  const menusByPath = collectMenusByPath(menus);
  return routes.map((route) => {
    const path = normalizePath(route?.path);
    const menuEntry = path ? menusByPath.get(path) : null;
    if (!menuEntry) {
      return route;
    }

    const searchKeywords = mergeKeywordArrays(route?.searchKeywords, menuEntry.searchKeywords);
    const keywords = mergeKeywordArrays(route?.keywords, menuEntry.keywords);
    const routeMenu = route?.menu ?? {};
    return {
      ...route,
      title: menuEntry.title || route.title,
      group: menuEntry.groupKey || route.group,
      order: Number.isFinite(menuEntry.order) ? menuEntry.order : route.order,
      icon: menuEntry.icon && typeof menuEntry.icon !== 'string' ? menuEntry.icon : route.icon,
      iconUrl: menuEntry.iconUrl || route.iconUrl,
      iconText: menuEntry.iconText || route.iconText,
      iconName: menuEntry.iconName || route.iconName,
      abbr: menuEntry.abbr || route.abbr,
      shortTitle: menuEntry.shortTitle || route.shortTitle,
      collapsedTitle: menuEntry.collapsedTitle || route.collapsedTitle,
      searchKeywords: searchKeywords.length > 0 ? searchKeywords : route.searchKeywords,
      keywords: keywords.length > 0 ? keywords : route.keywords,
      menu: {
        ...routeMenu,
        title: menuEntry.title || routeMenu.title,
        label: menuEntry.groupLabel || routeMenu.label,
        searchText: menuEntry.searchText || routeMenu.searchText,
        searchKeywords: searchKeywords.length > 0 ? searchKeywords : routeMenu.searchKeywords,
        keywords: keywords.length > 0 ? keywords : routeMenu.keywords,
        trail: menuEntry.trail.length > 0 ? menuEntry.trail : routeMenu.trail
      }
    };
  });
}

export function buildBrickConsoleNavigationGroupsFromMenus(routes = [], menus = [], options = {}) {
  const mergedRoutes = options.useMergedRoutes ? routes : mergeBrickConsoleRoutesWithMenus(routes, menus);
  const permissions = Array.isArray(options.permissions) ? options.permissions : [];
  const routesByPath = new Map(
    mergedRoutes
      .filter((route) => route?.path)
      .map((route) => [normalizePath(route.path), route])
  );

  return (menus || [])
    .map((menu) => {
      const collectedRoutes = [];
      walkMenuNodes([menu], (node) => {
        const path = normalizePath(node?.path);
        if (!path) {
          return;
        }
        const route = routesByPath.get(path);
        if (!route || !canAccessBrickConsoleRoute(route, permissions)) {
          return;
        }
        collectedRoutes.push(route);
      });
      const routesForGroup = dedupeRoutes(collectedRoutes).sort(compareRouteOrder);
      if (routesForGroup.length === 0) {
        return null;
      }

      const groupKeywords = mergeKeywordArrays(menu?.searchKeywords, menu?.keywords, collectMenuTrailKeywords(menu));
      return {
        key: menuKey(menu),
        label: menuTitle(menu) || menuKey(menu),
        order: menuOrder(menu),
        routes: routesForGroup,
        searchText: buildSearchText(groupKeywords),
        searchKeywords: groupKeywords,
        keywords: groupKeywords
      };
    })
    .filter(Boolean)
    .sort((left, right) => compareGroupOrder(left, right));
}

export function dispatchBrickConsoleManagementIntent(routeId, detail = {}, target = globalThis.window) {
  const normalizedRouteId = normalizeText(routeId);
  const dispatchTarget = target && typeof target.dispatchEvent === 'function' ? target : null;
  const CustomEventCtor = globalThis.CustomEvent;
  if (!normalizedRouteId || !dispatchTarget || typeof CustomEventCtor !== 'function') {
    return false;
  }
  dispatchTarget.dispatchEvent(new CustomEventCtor(BRICK_CONSOLE_MANAGEMENT_INTENT_EVENT, {
    detail: {
      ...detail,
      routeId: normalizedRouteId,
    },
  }));
  return true;
}

export function subscribeBrickConsoleManagementIntent(listener, target = globalThis.window) {
  if (typeof listener !== 'function' || !target || typeof target.addEventListener !== 'function') {
    return () => {};
  }
  const handleIntent = (event) => {
    const routeId = normalizeText(event?.detail?.routeId);
    if (!routeId) {
      return;
    }
    listener(routeId, event?.detail ?? {}, event);
  };
  target.addEventListener(BRICK_CONSOLE_MANAGEMENT_INTENT_EVENT, handleIntent);
  return () => {
    if (typeof target.removeEventListener === 'function') {
      target.removeEventListener(BRICK_CONSOLE_MANAGEMENT_INTENT_EVENT, handleIntent);
    }
  };
}

export function readBrickConsoleCollapsedGroupKeys(storage = resolveStorage()) {
  if (!storage || typeof storage.getItem !== 'function') {
    return [];
  }
  const raw = storage.getItem(BRICK_CONSOLE_COLLAPSED_GROUPS_STORAGE_KEY)
    ?? storage.getItem(BRICK_CONSOLE_LEGACY_COLLAPSED_GROUPS_STORAGE_KEY);
  if (!raw) {
    return [];
  }
  try {
    return normalizeCollapsedGroupKeys(JSON.parse(raw));
  } catch {
    return [];
  }
}

export function writeBrickConsoleCollapsedGroupKeys(keys = [], storage = resolveStorage()) {
  const normalized = normalizeCollapsedGroupKeys(keys);
  if (storage && typeof storage.setItem === 'function') {
    storage.setItem(BRICK_CONSOLE_COLLAPSED_GROUPS_STORAGE_KEY, JSON.stringify(normalized));
  }
  return normalized;
}

/**
 * Last authenticated management route id for hard-refresh restore.
 * Prefer sessionStorage so a full page reload keeps the workspace; logout should clear it.
 */
export function readBrickConsoleActiveRouteId(storage = resolveSessionStorage()) {
  if (!storage || typeof storage.getItem !== 'function') {
    return '';
  }
  const raw = storage.getItem(BRICK_CONSOLE_ACTIVE_ROUTE_STORAGE_KEY);
  return typeof raw === 'string' ? raw.trim() : '';
}

export function writeBrickConsoleActiveRouteId(routeId, storage = resolveSessionStorage()) {
  if (!storage) {
    return '';
  }
  const normalized = typeof routeId === 'string' ? routeId.trim() : '';
  if (!normalized || normalized === 'login') {
    if (typeof storage.removeItem === 'function') {
      storage.removeItem(BRICK_CONSOLE_ACTIVE_ROUTE_STORAGE_KEY);
    }
    return '';
  }
  if (typeof storage.setItem === 'function') {
    storage.setItem(BRICK_CONSOLE_ACTIVE_ROUTE_STORAGE_KEY, normalized);
  }
  return normalized;
}

/**
 * Current browser path for history-mode shell deep links.
 * Returns normalized pathname (no trailing slash except root).
 */
export function readBrickConsoleLocationPath(target = globalThis.window) {
  if (!target || !target.location) {
    return '';
  }
  return normalizePath(target.location.pathname || '');
}

/**
 * Sync the address bar with the active management route path.
 * @param {string} path route path
 * @param {{ replace?: boolean }} [options] use replaceState when restoring/hydrating
 * @param {Window|null} [target]
 */
export function syncBrickConsoleLocationPath(path, options = {}, target = globalThis.window) {
  const normalized = normalizePath(path);
  if (!normalized || !target || !target.history) {
    return normalized;
  }
  const current = normalizePath(target.location?.pathname || '');
  if (current === normalized) {
    return normalized;
  }
  const state = target.history.state ?? {};
  const nextUrl = normalized;
  if (options && options.replace && typeof target.history.replaceState === 'function') {
    target.history.replaceState(state, '', nextUrl);
  } else if (typeof target.history.pushState === 'function') {
    target.history.pushState(state, '', nextUrl);
  }
  return normalized;
}

/**
 * Resolve a management route id from an address-bar path (exact path match).
 * Root path `/` only matches an explicit route with path `/` (workbench), and
 * callers typically ignore workbench when restoring management routes.
 */
export function findBrickConsoleRouteIdByPath(routes = [], path = '') {
  const normalized = normalizePath(path);
  if (!normalized) {
    return '';
  }
  const matched = (Array.isArray(routes) ? routes : []).find(
    (route) => route && route.id && normalizePath(route.path) === normalized,
  );
  return matched?.id ? String(matched.id) : '';
}

function compareRouteOrder(a, b) {
  const order = (a.order ?? 1000) - (b.order ?? 1000);
  if (order !== 0) {
    return order;
  }
  return String(a.title ?? a.id).localeCompare(String(b.title ?? b.id), 'zh-Hans-CN');
}

function compareGroupOrder(a, b) {
  const order = (a.order ?? 1000) - (b.order ?? 1000);
  if (order !== 0) {
    return order;
  }
  return String(a.label ?? a.key).localeCompare(String(b.label ?? b.key), 'zh-Hans-CN');
}

function collectMenusByPath(menus = []) {
  const menusByPath = new Map();
  let sequence = 0;
  for (const rootMenu of menus || []) {
    walkMenuNodes([rootMenu], (menu, trail) => {
      const path = normalizePath(menu?.path);
      if (!path || menusByPath.has(path)) {
        return;
      }
      const root = trail[0] ?? menu;
      const menuKeywords = mergeKeywordArrays(
        menu?.searchKeywords,
        menu?.keywords,
        trail.map((item) => menuTitle(item)),
        [
          menu?.code,
          menu?.id,
          path,
          menuTitle(root),
        ],
      );
      sequence += 1;
      menusByPath.set(path, {
        title: menuTitle(menu),
        groupKey: menuKey(root),
        groupLabel: menuTitle(root) || menuKey(root),
        order: sequence,
        icon: menu?.icon,
        iconUrl: normalizeText(menu?.iconUrl),
        iconText: normalizeText(menu?.iconText),
        iconName: normalizeText(menu?.iconName) || (typeof menu?.icon === 'string' ? normalizeText(menu.icon) : ''),
        abbr: normalizeText(menu?.abbr),
        shortTitle: normalizeText(menu?.shortTitle),
        collapsedTitle: normalizeText(menu?.collapsedTitle),
        keywords: menuKeywords,
        searchKeywords: menuKeywords,
        searchText: buildSearchText(menuKeywords),
        trail: trail.map((item) => menuTitle(item)).filter(Boolean),
      });
    });
  }
  return menusByPath;
}

function collectMenuTrailKeywords(menu = null) {
  const keywords = [];
  walkMenuNodes([menu], (node, trail) => {
    keywords.push(
      menuTitle(node),
      node?.code,
      node?.id,
      node?.path,
      ...trail.map((item) => menuTitle(item)),
    );
  });
  return compactKeywords(keywords);
}

function walkMenuNodes(menus = [], visit, trail = []) {
  for (const menu of menus || []) {
    if (!menu) {
      continue;
    }
    const nextTrail = [...trail, menu];
    visit(menu, nextTrail);
    walkMenuNodes(menu.children || [], visit, nextTrail);
  }
}

function dedupeRoutes(routes = []) {
  const seenRouteIds = new Set();
  const dedupedRoutes = [];
  for (const route of routes || []) {
    const routeId = normalizeText(route?.id);
    if (!routeId || seenRouteIds.has(routeId)) {
      continue;
    }
    seenRouteIds.add(routeId);
    dedupedRoutes.push(route);
  }
  return dedupedRoutes;
}

function menuKey(menu) {
  return normalizeText(menu?.code)
    || normalizeText(menu?.id)
    || normalizePath(menu?.path)
    || menuTitle(menu)
    || 'group';
}

function menuTitle(menu) {
  return normalizeText(menu?.title)
    || normalizeText(menu?.label)
    || normalizeText(menu?.name)
    || '';
}

function menuOrder(menu) {
  return Number.isFinite(menu?.order) ? menu.order : Number.isFinite(menu?.sortNo) ? menu.sortNo : 1000;
}

function mergeKeywordArrays(...values) {
  return compactKeywords(values.flatMap((value) => Array.isArray(value) ? value : [value]));
}

function compactKeywords(values = []) {
  return [...new Set(
    values
      .map((value) => normalizeText(value))
      .filter(Boolean)
  )];
}

function buildSearchText(values = []) {
  return compactKeywords(values).join(' ');
}

function normalizePath(value) {
  const normalized = normalizeText(value);
  if (!normalized) {
    return '';
  }
  if (normalized === '/') {
    return normalized;
  }
  return normalized.replace(/\/+$/, '');
}

function normalizeText(value) {
  return typeof value === 'string' && value.trim() ? value.trim() : '';
}

function normalizeCollapsedGroupKeys(keys) {
  return Array.isArray(keys) ? keys.filter((key) => typeof key === 'string' && key) : [];
}

function resolveStorage() {
  return typeof localStorage === 'undefined' ? null : localStorage;
}

function resolveSessionStorage() {
  try {
    return typeof sessionStorage === 'undefined' ? null : sessionStorage;
  } catch {
    return null;
  }
}
