<script setup>
import { computed, ref } from 'vue';
import { resolveBrickManagedSecretField } from '../managed-secret.js';

const props = defineProps({
  modelValue: { type: String, default: '' },
  configured: { type: Boolean, default: false },
  description: { type: String, default: '' },
  placeholder: { type: String, default: '' },
  unconfiguredPlaceholder: { type: String, default: '' },
  configuredPlaceholder: { type: String, default: '' },
  unconfiguredHint: { type: String, default: '' },
  configuredHint: { type: String, default: '' },
  configuredTagText: { type: String, default: '已托管' },
  disabled: { type: Boolean, default: false },
  autocomplete: { type: String, default: 'new-password' },
  ariaLabel: { type: String, default: '敏感凭据录入字段' },
  showVisibilityToggle: { type: Boolean, default: true },
  showConfiguredTag: { type: Boolean, default: true },
  revealText: { type: String, default: '显示' },
  concealText: { type: String, default: '隐藏' },
});

const emit = defineEmits(['update:modelValue']);
const inputRef = ref(null);
const visible = ref(false);

const fieldState = computed(() => resolveBrickManagedSecretField({
  configured: props.configured,
  configuredTagText: props.configuredTagText,
  value: props.modelValue,
  placeholder: props.placeholder,
  unconfiguredPlaceholder: props.unconfiguredPlaceholder,
  configuredPlaceholder: props.configuredPlaceholder,
  unconfiguredHint: props.unconfiguredHint,
  configuredHint: props.configuredHint,
}));
const inputType = computed(() => (visible.value ? 'text' : 'password'));
const canToggleVisibility = computed(() => props.showVisibilityToggle && !props.disabled);

function handleInput(event) {
  emit('update:modelValue', event.target.value);
}

function toggleVisibility() {
  if (!canToggleVisibility.value) {
    return;
  }
  visible.value = !visible.value;
}

function focus(options) {
  if (!inputRef.value || typeof inputRef.value.focus !== 'function') {
    return;
  }
  try {
    inputRef.value.focus(options);
  } catch {
    inputRef.value.focus();
  }
}

defineExpose({ focus });
</script>

<template>
  <div
    :class="[
      'brick-managed-secret-input',
      'brick-readonly-copy-input',
      { 'is-disabled': disabled, 'is-configured': configured }
    ]"
  >
    <div
      v-if="configured && showConfiguredTag"
      class="brick-managed-secret-input__status"
      style="display: flex; justify-content: flex-end;"
    >
      <span class="brick-managed-secret-input__tag">{{ fieldState.configuredTagText }}</span>
    </div>
    <p
      v-if="description"
      class="brick-managed-secret-input__description brick-readonly-copy-input__description"
      style="line-height: 1.5;"
    >
      {{ description }}
    </p>
    <div class="brick-managed-secret-input__control brick-readonly-copy-input__control">
      <input
        ref="inputRef"
        class="brick-managed-secret-input__field brick-readonly-copy-input__field"
        :type="inputType"
        :value="modelValue"
        :disabled="disabled"
        :placeholder="fieldState.placeholder"
        :aria-label="ariaLabel"
        :autocomplete="autocomplete"
        autocapitalize="off"
        spellcheck="false"
        @input="handleInput"
      />
      <button
        v-if="showVisibilityToggle"
        class="brick-managed-secret-input__toggle brick-readonly-copy-input__copy"
        type="button"
        :disabled="!canToggleVisibility"
        @click="toggleVisibility"
      >
        {{ visible ? concealText : revealText }}
      </button>
    </div>
    <p
      class="brick-managed-secret-input__hint brick-readonly-copy-input__description"
      style="line-height: 1.5;"
      aria-live="polite"
    >
      {{ fieldState.hint }}
    </p>
  </div>
</template>
