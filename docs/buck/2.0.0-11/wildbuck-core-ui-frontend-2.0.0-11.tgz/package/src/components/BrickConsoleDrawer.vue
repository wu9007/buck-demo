<script setup>
import { computed, useSlots } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';

const props = defineProps({
  modelValue: { type: Boolean, default: false },
  title: { type: String, default: '' },
  eyebrow: { type: String, default: '' },
  description: { type: String, default: '' },
  size: { type: [String, Number], default: '52%' },
  direction: { type: String, default: 'rtl' },
  loading: { type: Boolean, default: false },
  destroyOnClose: { type: Boolean, default: false },
  appendToBody: { type: Boolean, default: false },
  modal: { type: Boolean, default: true },
  showClose: { type: Boolean, default: true },
  closeOnClickModal: { type: Boolean, default: true },
  closeOnPressEscape: { type: Boolean, default: true },
  lockScroll: { type: Boolean, default: true }
});

const emit = defineEmits(['update:modelValue', 'close', 'closed', 'open', 'opened']);
const slots = useSlots();
const { t } = useBrickConsoleI18n();
const hasFooter = computed(() => Boolean(slots.footer));
const resolvedTitle = computed(() => props.title || t('core.ui.drawer.defaultTitle'));

function updateVisible(value) {
  emit('update:modelValue', value);
}

function closeDrawer() {
  emit('update:modelValue', false);
  emit('close');
}
</script>

<template>
  <el-drawer
    :model-value="modelValue"
    class="brick-console-drawer"
    :size="size"
    :direction="direction"
    :destroy-on-close="destroyOnClose"
    :append-to-body="appendToBody"
    :modal="modal"
    :show-close="showClose"
    :close-on-click-modal="closeOnClickModal"
    :close-on-press-escape="closeOnPressEscape"
    :lock-scroll="lockScroll"
    @update:model-value="updateVisible"
    @close="closeDrawer"
    @closed="emit('closed')"
    @open="emit('open')"
    @opened="emit('opened')"
  >
    <template #header>
      <slot name="header">
        <div class="brick-console-drawer__header">
          <p v-if="eyebrow" class="brick-console-drawer__eyebrow">{{ eyebrow }}</p>
          <div class="brick-console-drawer__title-row">
            <h2 class="brick-console-drawer__title">{{ resolvedTitle }}</h2>
            <div v-if="$slots.actions" class="brick-console-drawer__actions">
              <slot name="actions" />
            </div>
          </div>
          <p v-if="description" class="brick-console-drawer__description">{{ description }}</p>
        </div>
      </slot>
    </template>

    <section class="brick-console-drawer__body" :aria-busy="loading ? 'true' : 'false'">
      <slot v-if="loading" name="loading">
        <p class="brick-console-drawer__state">{{ t('core.ui.drawer.loading') }}</p>
      </slot>
      <slot v-else />
    </section>

    <template v-if="hasFooter" #footer>
      <footer class="brick-console-drawer__footer">
        <slot name="footer" />
      </footer>
    </template>
  </el-drawer>
</template>
