<script setup>
import { computed } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';

const props = defineProps({
  title: { type: String, required: true },
  description: { type: String, required: true },
  statusLabel: { type: String, required: true },
  statusTone: { type: String, default: 'default' },
  summaryItems: { type: Array, default: () => [] },
  riskLabel: { type: String, default: '' },
  riskTone: { type: String, default: 'default' },
  actionText: { type: String, default: '' },
  disabled: { type: Boolean, default: false },
});

const emit = defineEmits(['open']);
const { t } = useBrickConsoleI18n();
const resolvedActionText = computed(() => props.actionText || t('core.ui.policy.configure'));
</script>

<template>
  <article
    class="brick-policy-card"
    :class="{ 'is-disabled': disabled }"
    :aria-disabled="disabled ? 'true' : undefined"
  >
    <span class="brick-policy-card__topline">
      <span class="brick-policy-card__status brick-policy-status" :data-tone="statusTone">
        <span>{{ statusLabel }}</span>
      </span>
      <span v-if="riskLabel" class="brick-policy-card__risk" :data-tone="riskTone">
        {{ riskLabel }}
      </span>
    </span>
    <span class="brick-policy-card__title">{{ title }}</span>
    <span class="brick-policy-card__description">{{ description }}</span>
    <span v-if="summaryItems.length" class="brick-policy-card__summary">
      <span
        v-for="item in summaryItems"
        :key="item.label"
        class="brick-policy-card__summary-item"
        :data-tone="item.tone || 'default'"
      >
        <span>{{ item.label }}</span>
        <strong>{{ item.value }}</strong>
      </span>
    </span>
    <el-button
      class="brick-policy-card__action"
      :disabled="disabled"
      @click="emit('open')"
    >
      {{ resolvedActionText }}
    </el-button>
  </article>
</template>

<style scoped>
.brick-policy-card {
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-height: 196px;
  padding: 16px;
  border: 1px solid var(--console-card-border, #dbe3ef);
  border-radius: var(--console-card-radius, 8px);
  background: var(--console-card-bg, #ffffff);
  box-shadow: 0 1px 2px rgba(15, 23, 42, 0.05);
  color: var(--console-title, #0f172a);
  text-align: left;
}

.brick-policy-card__topline,
.brick-policy-card__summary {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 10px;
}

.brick-policy-card__risk {
  color: var(--console-title, #0f172a);
  font-size: 12px;
  font-weight: 700;
}

.brick-policy-card__risk::before {
  margin-right: 8px;
  color: var(--console-muted, #64748b);
  content: "/";
}

.brick-policy-card__summary-item[data-tone='success'] strong {
  color: var(--console-success, #16a34a);
}

.brick-policy-card__risk[data-tone='warning'],
.brick-policy-card__summary-item[data-tone='warning'] strong {
  color: var(--console-warning, #b45309);
}

.brick-policy-card__risk[data-tone='danger'],
.brick-policy-card__summary-item[data-tone='danger'] strong {
  color: var(--console-danger, #dc2626);
}

.brick-policy-card__title {
  font-size: 18px;
  font-weight: 760;
  letter-spacing: 0;
  line-height: 1.3;
}

.brick-policy-card__description {
  color: var(--console-text, #334155);
  font-size: 13px;
  line-height: 1.6;
}

.brick-policy-card__summary {
  margin-top: auto;
  padding-top: 12px;
  border-top: 1px solid var(--console-block-border, var(--console-card-border, #dbe3ef));
}

.brick-policy-card__summary-item {
  display: grid;
  flex: 1 1 96px;
  gap: 4px;
  min-width: 92px;
}

.brick-policy-card__summary-item span {
  color: var(--console-muted, #64748b);
  font-size: 11px;
  font-weight: 700;
}

.brick-policy-card__summary-item strong {
  color: var(--console-title, #0f172a);
  font-size: 14px;
  line-height: 1.3;
  overflow-wrap: anywhere;
}

.brick-policy-card__action {
  align-self: flex-start;
  min-height: 32px;
  margin-top: 4px;
  padding: 0 14px;
  border-color: color-mix(in srgb, var(--console-primary, #2563eb) 42%, var(--console-card-border, #dbe3ef));
  background: transparent;
  color: var(--console-primary, #2563eb);
  font-size: 13px;
  font-weight: 700;
}
</style>
