<template>
  <p class="brick-policy-static-note">
    <slot />
  </p>
</template>

<style scoped>
.brick-policy-static-note {
  margin: 0;
  color: var(--console-text, #334155);
  font-size: 13px;
  line-height: 1.6;
}
</style>
