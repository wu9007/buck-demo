<script setup>
/**
 * Optional plain dropdown combining import + export under one control (#443 / #446).
 * Prefer separate #import / #export slots on BrickListPageActions when both are frequent.
 */
import { useBrickConsoleI18n } from '../i18n.js';

defineProps({
  /** Button label; default from i18n. */
  label: { type: String, default: '' },
  disabled: { type: Boolean, default: false },
  importDisabled: { type: Boolean, default: false },
  exportDisabled: { type: Boolean, default: false },
  importLabel: { type: String, default: '' },
  exportLabel: { type: String, default: '' },
  guideAnchor: { type: String, default: 'import-export' },
});

const emit = defineEmits(['import', 'export']);

const { t } = useBrickConsoleI18n();
</script>

<template>
  <el-dropdown
    class="brick-import-export-menu"
    trigger="click"
    :disabled="disabled"
    @command="(cmd) => cmd === 'import' ? emit('import') : emit('export')"
  >
    <el-button type="primary" plain :disabled="disabled" :data-guide-anchor="guideAnchor">
      {{ label || t('core.ui.importExport.menu') }}
      <span class="brick-import-export-menu__caret" aria-hidden="true">▾</span>
    </el-button>
    <template #dropdown>
      <el-dropdown-menu>
        <el-dropdown-item command="import" :disabled="importDisabled" data-guide-anchor="import">
          {{ importLabel || t('core.ui.importExport.import') }}
        </el-dropdown-item>
        <el-dropdown-item command="export" :disabled="exportDisabled" data-guide-anchor="export">
          {{ exportLabel || t('core.ui.importExport.export') }}
        </el-dropdown-item>
      </el-dropdown-menu>
    </template>
  </el-dropdown>
</template>

<style scoped>
.brick-import-export-menu__caret {
  margin-inline-start: 6px;
  font-size: 11px;
  opacity: 0.75;
}
</style>
