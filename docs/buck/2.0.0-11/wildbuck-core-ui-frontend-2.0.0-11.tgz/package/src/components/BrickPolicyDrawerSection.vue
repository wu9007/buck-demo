<script setup>
defineProps({
  title: { type: String, required: true },
  description: { type: String, default: '' },
});
</script>

<template>
  <section class="brick-policy-drawer-section">
    <h3 class="brick-policy-drawer-section__title">{{ title }}</h3>
    <p v-if="description" class="brick-policy-drawer-section__description">{{ description }}</p>
    <slot />
  </section>
</template>

<style scoped>
.brick-policy-drawer-section {
  display: grid;
  gap: var(--console-space-3, 14px);
}

.brick-policy-drawer-section__title {
  margin: 0;
  color: var(--console-title, #0f172a);
  font-size: 16px;
  font-weight: 850;
  line-height: 1.4;
}

.brick-policy-drawer-section__description {
  margin: 0;
  color: var(--console-text, #334155);
  font-size: 12px;
  line-height: 1.6;
}
</style>
