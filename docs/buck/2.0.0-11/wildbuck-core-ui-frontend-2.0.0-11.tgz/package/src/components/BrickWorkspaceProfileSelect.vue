<script setup>
/**
 * Workspace Profile selector: UI-only station/workbench focus.
 * Does not change token or IAM authorization. Parent supplies profiles and
 * principal permissions; selection is filtered to available profiles only.
 */
import { computed } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';
import {
  listAvailableBrickWorkspaceProfiles,
  resolveBrickWorkspaceProfileId,
} from '../workspace-profile.js';

const props = defineProps({
  /** Business-defined profiles (id/title/routeIds/…). */
  profiles: { type: Array, default: () => [] },
  /** Current principal permission codes (union). */
  permissions: { type: Array, default: () => [] },
  /** Selected profile id (v-model). */
  modelValue: { type: String, default: '' },
  /** Hide control when fewer than 2 available profiles. */
  hideWhenSingle: { type: Boolean, default: true },
  /** Disabled / read-only display. */
  disabled: { type: Boolean, default: false },
  /** Optional explicit aria / field label override. */
  label: { type: String, default: '' },
});

const emit = defineEmits(['update:modelValue', 'change']);
const { t } = useBrickConsoleI18n();

const availableProfiles = computed(() =>
  listAvailableBrickWorkspaceProfiles(props.profiles, props.permissions),
);

const resolvedValue = computed(() =>
  resolveBrickWorkspaceProfileId(props.profiles, props.permissions, props.modelValue),
);

const visible = computed(() => {
  if (availableProfiles.value.length === 0) {
    return false;
  }
  if (props.hideWhenSingle && availableProfiles.value.length < 2) {
    return false;
  }
  return true;
});

const fieldLabel = computed(() =>
  props.label || t('core.ui.workspaceProfile.label'),
);

function profileTitle(profile) {
  return profile.title || profile.label || profile.id;
}

function onChange(event) {
  const next = String(event?.target?.value ?? '').trim();
  emit('update:modelValue', next);
  emit('change', next);
}
</script>

<template>
  <label
    v-if="visible"
    class="brick-appearance-switcher__field brick-workspace-profile-select"
    :aria-label="fieldLabel"
  >
    <span class="brick-workspace-profile-select__label">{{ fieldLabel }}</span>
    <select
      class="brick-workspace-profile-select__control"
      :value="resolvedValue"
      :disabled="disabled"
      @change="onChange"
    >
      <option
        v-for="profile in availableProfiles"
        :key="profile.id"
        :value="profile.id"
      >
        {{ profileTitle(profile) }}
      </option>
    </select>
  </label>
</template>
