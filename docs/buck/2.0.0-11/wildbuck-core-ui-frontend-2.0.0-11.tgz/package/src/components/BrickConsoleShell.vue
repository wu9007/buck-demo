<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { resolveBrickConsoleAppearanceTheme } from '../appearance.js';
import { useBrickConsoleI18n } from '../i18n.js';
import { resolveBrickConsoleNavIconName } from '../shell-icons.js';
import BrickConsoleNavIcon from './BrickConsoleNavIcon.vue';
import BrickConsoleSidebar from './BrickConsoleSidebar.vue';
import BrickConsoleSidebarCollapseToggle from './BrickConsoleSidebarCollapseToggle.vue';
import BrickConsoleTopbar from './BrickConsoleTopbar.vue';

const props = defineProps({
  theme: { type: String, default: 'blue' },
  themePreference: { type: String, default: '' },
  density: { type: String, default: 'comfortable' },
  fontSize: { type: String, default: 'normal' },
  brandTitle: { type: String, default: 'Brick' },
  brandSubtitle: { type: String, default: '' },
  brandMark: { type: String, default: 'B' },
  brandLogoUrl: { type: String, default: '' },
  topbarTitle: { type: String, default: '' },
  topbarSubtitle: { type: String, default: '' },
  topbarBreadcrumbs: { type: Array, default: () => [] },
  navigationGroups: { type: Array, default: () => [] },
  activeRouteId: { type: String, default: '' },
  currentPrincipal: { type: Object, default: () => ({}) },
  showAppearanceSettings: { type: Boolean, default: true },
  showChangePassword: { type: Boolean, default: true },
  changePasswordSubmit: { type: Function, default: null },
  appearanceEntry: { type: String, default: 'user-menu' },
  canInstallApp: { type: Boolean, default: false },
  refreshEnabled: { type: Boolean, default: false },
  fullscreenEnabled: { type: Boolean, default: false },
  fullscreenAutoEnter: { type: Boolean, default: false },
  locale: { type: String, default: 'zh-CN' },
  sidebarCollapsed: { type: Boolean, default: false },
  sidebarCollapsible: { type: Boolean, default: true },
  sidebarGroupCollapsible: { type: Boolean, default: true },
  sidebarCollapsedGroupKeys: { type: Array, default: undefined },
  sidebarDefaultCollapsedGroupKeys: { type: Array, default: () => [] },
  sidebarSearchable: { type: Boolean, default: false },
  sidebarSearchKeyword: { type: String, default: '' },
  sidebarSearchPlaceholder: { type: String, default: '' },
  contextPanelOpen: { type: Boolean, default: false },
  contextPanelWidth: { type: String, default: '560px' },
});

const emit = defineEmits([
  'navigate',
  'logout',
  'install-app',
  'change-password-success',
  'refresh',
  'update:theme',
  'update:density',
  'update:fontSize',
  'update:fullscreenAutoEnter',
  'update:locale',
  'update:sidebarCollapsed',
  'update:sidebarCollapsedGroupKeys',
  'update:sidebarSearchKeyword',
  'update:contextPanelOpen',
]);

const { t } = useBrickConsoleI18n();
const principalName = computed(() => props.currentPrincipal.displayName || props.currentPrincipal.username || '');
const principalUsername = computed(() => String(props.currentPrincipal.username || '').trim());
const principalSubtitle = computed(() => {
  const displayName = String(props.currentPrincipal.displayName || '').trim();
  const username = principalUsername.value;
  if (username && username !== displayName) {
    return username;
  }
  return String(props.currentPrincipal.subtitle || props.currentPrincipal.email || '').trim();
});
const principalAvatarUrl = computed(() => props.currentPrincipal.avatarUrl || '');
const contextPanelAriaLabel = computed(() => t('core.ui.shell.contextPanelAria'));
const localSidebarCollapsed = ref(props.sidebarCollapsed);
const shellStyle = computed(() => ({
  '--shell-context-panel-width': props.contextPanelWidth,
}));
/**
 * theme prop must be a render token (never data-theme="system").
 * If a shell mistakenly passes preference "system", resolve it so CSS tokens still switch.
 */
let warnedSystemThemeProp = false;
const resolvedTheme = computed(() => {
  const raw = String(props.theme || 'blue');
  if (raw === 'system' && !warnedSystemThemeProp && typeof console !== 'undefined' && typeof console.warn === 'function') {
    warnedSystemThemeProp = true;
    console.warn(
      '[BrickConsoleShell] theme="system" is a preference, not a CSS token. '
      + 'Pass resolvedTheme from createBrickConsoleAppearanceRuntime to :theme / data-theme, '
      + 'and keep "system" only on :theme-preference.',
    );
  }
  return resolveBrickConsoleAppearanceTheme(raw);
});
const resolvedThemePreference = computed(() => props.themePreference || props.theme || resolvedTheme.value);
const fullscreenSupported = ref(false);
const fullscreenActive = ref(false);
const fullscreenAutoEntered = ref(false);
const fullscreenMounted = ref(false);

watch(
  () => props.sidebarCollapsed,
  (value) => {
    localSidebarCollapsed.value = value;
  },
);

function updateSidebarCollapsed(value) {
  localSidebarCollapsed.value = value;
  emit('update:sidebarCollapsed', value);
}

function closeContextPanel() {
  emit('update:contextPanelOpen', false);
}

function routeTitle(route) {
  return String(route?.title ?? route?.id ?? '');
}

function routeMark(route) {
  return String(route?.abbr ?? route?.iconText ?? route?.shortTitle ?? route?.collapsedTitle ?? routeTitle(route).slice(0, 1)).slice(0, 2);
}

function routeIconComponent(route) {
  if (!route?.icon || typeof route.icon === 'string') {
    return null;
  }
  return route.icon;
}

function routeIconUrl(route) {
  return String(route && route.iconUrl ? route.iconUrl : '').trim();
}

function routeIconName(route) {
  return resolveBrickConsoleNavIconName(route);
}

function getFullscreenDocument() {
  return typeof document === 'undefined' ? null : document;
}

function getFullscreenElement() {
  const fullscreenDocument = getFullscreenDocument();
  if (!fullscreenDocument) {
    return null;
  }
  return fullscreenDocument.fullscreenElement
    ?? fullscreenDocument.webkitFullscreenElement
    ?? null;
}

function syncFullscreenSupport() {
  const fullscreenDocument = getFullscreenDocument();
  const rootElement = fullscreenDocument?.documentElement;
  fullscreenSupported.value = Boolean(
    fullscreenDocument
    && (
      fullscreenDocument.fullscreenEnabled
      || fullscreenDocument.webkitFullscreenEnabled
      || typeof rootElement?.requestFullscreen === 'function'
      || typeof rootElement?.webkitRequestFullscreen === 'function'
    ),
  );
}

function syncFullscreenState() {
  fullscreenActive.value = Boolean(getFullscreenElement());
}

async function enterFullscreen() {
  if (!props.fullscreenEnabled || fullscreenActive.value) {
    return false;
  }
  const fullscreenDocument = getFullscreenDocument();
  const rootElement = fullscreenDocument?.documentElement;
  if (!fullscreenDocument || !rootElement) {
    return false;
  }
  try {
    if (typeof rootElement.requestFullscreen === 'function') {
      await rootElement.requestFullscreen();
    } else if (typeof rootElement.webkitRequestFullscreen === 'function') {
      rootElement.webkitRequestFullscreen();
    } else {
      return false;
    }
    syncFullscreenState();
    return true;
  } catch {
    syncFullscreenState();
    return false;
  }
}

async function exitFullscreen() {
  if (!fullscreenActive.value) {
    return false;
  }
  const fullscreenDocument = getFullscreenDocument();
  if (!fullscreenDocument) {
    return false;
  }
  try {
    if (typeof fullscreenDocument.exitFullscreen === 'function') {
      await fullscreenDocument.exitFullscreen();
    } else if (typeof fullscreenDocument.webkitExitFullscreen === 'function') {
      fullscreenDocument.webkitExitFullscreen();
    } else {
      return false;
    }
    syncFullscreenState();
    return true;
  } catch {
    syncFullscreenState();
    return false;
  }
}

async function autoEnterFullscreenOnce() {
  if (!props.fullscreenEnabled || !props.fullscreenAutoEnter || fullscreenAutoEntered.value) {
    return;
  }
  fullscreenAutoEntered.value = true;
  await enterFullscreen();
}

function handleFullscreenChange() {
  syncFullscreenState();
}

watch(
  () => [props.fullscreenEnabled, props.fullscreenAutoEnter],
  ([enabled, autoEnter]) => {
    if (fullscreenMounted.value && enabled && autoEnter) {
      void autoEnterFullscreenOnce();
    }
  },
  { immediate: true },
);

onMounted(() => {
  fullscreenMounted.value = true;
  syncFullscreenSupport();
  syncFullscreenState();
  const fullscreenDocument = getFullscreenDocument();
  fullscreenDocument?.addEventListener('fullscreenchange', handleFullscreenChange);
  fullscreenDocument?.addEventListener('webkitfullscreenchange', handleFullscreenChange);
  void autoEnterFullscreenOnce();
});

onBeforeUnmount(() => {
  fullscreenMounted.value = false;
  const fullscreenDocument = getFullscreenDocument();
  fullscreenDocument?.removeEventListener('fullscreenchange', handleFullscreenChange);
  fullscreenDocument?.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
});
</script>

<template>
  <main
    class="brick-console-shell shell-app"
    :data-theme="resolvedTheme"
    :data-density="density"
    :data-font-size="fontSize"
    :data-sidebar-collapsed="localSidebarCollapsed ? 'true' : 'false'"
    :data-context-panel-open="contextPanelOpen && $slots['context-panel'] ? 'true' : 'false'"
    :style="shellStyle"
  >
    <BrickConsoleSidebar
      :brand-title="brandTitle"
      :brand-subtitle="brandSubtitle"
      :brand-mark="brandMark"
      :brand-logo-url="brandLogoUrl"
      :navigation-groups="navigationGroups"
      :active-route-id="activeRouteId"
      :collapsed="localSidebarCollapsed"
      :collapsible="sidebarCollapsible"
      :group-collapsible="sidebarGroupCollapsible"
      :collapsed-group-keys="sidebarCollapsedGroupKeys"
      :default-collapsed-group-keys="sidebarDefaultCollapsedGroupKeys"
      :searchable="sidebarSearchable"
      :search-keyword="sidebarSearchKeyword"
      :search-placeholder="sidebarSearchPlaceholder"
      @navigate="(route) => emit('navigate', route)"
      @update:collapsed="updateSidebarCollapsed"
      @update:collapsed-group-keys="(value) => emit('update:sidebarCollapsedGroupKeys', value)"
      @update:search-keyword="(value) => emit('update:sidebarSearchKeyword', value)"
    >
      <template #brand-mark="{ collapsed, brandTitle: slotBrandTitle, brandLogoUrl: slotBrandLogoUrl }">
        <slot
          name="sidebar-brand-mark"
          :collapsed="collapsed"
          :brand-title="slotBrandTitle"
          :brand-logo-url="slotBrandLogoUrl || brandLogoUrl"
        >
          <img
            v-if="slotBrandLogoUrl || brandLogoUrl"
            class="shell-brand-mark__logo"
            :src="slotBrandLogoUrl || brandLogoUrl"
            alt=""
          />
          <template v-else>{{ brandMark || slotBrandTitle.slice(0, 1) || 'B' }}</template>
        </slot>
      </template>
      <template #collapse-toggle="{ collapsed, label, toggle }">
        <slot name="sidebar-collapse-toggle" :collapsed="collapsed" :label="label" :toggle="toggle">
          <BrickConsoleSidebarCollapseToggle :collapsed="collapsed" :label="label" :toggle="toggle" />
        </slot>
      </template>
      <template #route-icon="{ route, collapsed }">
        <!-- Same priority as BrickConsoleSidebar: uploaded iconUrl > component > line fallback. -->
        <slot name="sidebar-route-icon" :route="route" :collapsed="collapsed">
          <img
            v-if="routeIconUrl(route)"
            class="shell-nav-item__icon-image"
            :src="routeIconUrl(route)"
            :alt="routeTitle(route)"
          />
          <component
            :is="routeIconComponent(route)"
            v-else-if="routeIconComponent(route)"
            class="shell-nav-item__icon"
          />
          <BrickConsoleNavIcon v-else :name="routeIconName(route)" />
        </slot>
      </template>
      <template v-if="$slots['sidebar-nav-before']" #nav-before="{ collapsed }">
        <slot name="sidebar-nav-before" :collapsed="collapsed" />
      </template>
      <template #extra>
        <slot name="sidebar-extra" />
      </template>
    </BrickConsoleSidebar>

    <section class="brick-console-shell__main shell-main">
      <BrickConsoleTopbar
        :principal-name="principalName"
        :principal-subtitle="principalSubtitle"
        :principal-username="principalUsername"
        :principal-avatar-url="principalAvatarUrl"
        :theme="resolvedTheme"
        :theme-preference="resolvedThemePreference"
        :density="density"
        :font-size="fontSize"
        :fullscreen-auto-enter="fullscreenAutoEnter"
        :locale="locale"
        :show-appearance-settings="showAppearanceSettings"
        :show-change-password="showChangePassword"
        :change-password-submit="changePasswordSubmit"
        :appearance-entry="appearanceEntry"
        :can-install-app="canInstallApp"
        :title="topbarTitle"
        :subtitle="topbarSubtitle"
        :breadcrumbs="topbarBreadcrumbs"
        :refresh-enabled="refreshEnabled"
        :fullscreen-enabled="fullscreenEnabled"
        :fullscreen-supported="fullscreenSupported"
        :fullscreen-active="fullscreenActive"
        @logout="emit('logout')"
        @install-app="emit('install-app')"
        @change-password-success="emit('change-password-success')"
        @refresh="emit('refresh')"
        @update:theme="(value) => emit('update:theme', value)"
        @update:density="(value) => emit('update:density', value)"
        @update:font-size="(value) => emit('update:fontSize', value)"
        @update:fullscreen-auto-enter="(value) => emit('update:fullscreenAutoEnter', value)"
        @update:locale="(value) => emit('update:locale', value)"
        @enter-fullscreen="enterFullscreen"
        @exit-fullscreen="exitFullscreen"
      >
        <template v-if="$slots['topbar-primary']" #primary="slotProps">
          <slot name="topbar-primary" v-bind="slotProps" />
        </template>
        <template v-if="$slots['topbar-title']" #title="slotProps">
          <slot name="topbar-title" v-bind="slotProps" />
        </template>
        <template #actions>
          <slot name="topbar-actions" />
        </template>
        <template v-if="$slots['topbar-trailing-actions']" #trailing-actions>
          <slot name="topbar-trailing-actions" />
        </template>
      </BrickConsoleTopbar>

      <section class="brick-console-shell__content shell-content">
        <slot />
      </section>
    </section>

    <aside
      v-if="contextPanelOpen && $slots['context-panel']"
      class="brick-console-shell__context-panel shell-context-panel"
      :aria-label="contextPanelAriaLabel"
    >
      <slot name="context-panel" :open="contextPanelOpen" :close="closeContextPanel" />
    </aside>
  </main>
</template>
