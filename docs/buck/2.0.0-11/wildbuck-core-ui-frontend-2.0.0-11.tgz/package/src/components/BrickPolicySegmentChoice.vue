<script setup>
import { computed } from 'vue';

const props = defineProps({
  modelValue: { type: String, required: true },
  label: { type: String, required: true },
  description: { type: String, default: '' },
  options: { type: Array, required: true },
  disabled: { type: Boolean, default: false },
});

const emit = defineEmits(['update:modelValue']);

const isRequired = computed(() => props.label.includes('必填'));
</script>

<template>
  <el-form-item
    class="brick-policy-form-item"
    :class="{ 'is-disabled': disabled }"
    :label="label"
    :required="isRequired"
  >
    <div class="brick-policy-form-control">
      <p v-if="description" class="brick-policy-field-description">{{ description }}</p>
      <el-radio-group
        class="brick-policy-radio-list"
        :model-value="modelValue"
        :disabled="disabled"
        @update:model-value="emit('update:modelValue', String($event))"
      >
        <el-radio
          v-for="option in options"
          :key="option.value"
          class="brick-policy-radio-option"
          :value="option.value"
          :disabled="option.disabled"
        >
          <span class="brick-policy-option-title">{{ option.label }}</span>
          <span v-if="option.description" class="brick-policy-option-description">{{ option.description }}</span>
        </el-radio>
      </el-radio-group>
    </div>
  </el-form-item>
</template>
