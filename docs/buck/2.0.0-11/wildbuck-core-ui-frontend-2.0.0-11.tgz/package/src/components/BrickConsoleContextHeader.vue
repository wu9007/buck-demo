<script setup>
import { computed } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';

/**
 * Shell-aligned chrome bar for right-hand context panels.
 * Height, padding and divider match BrickConsoleTopbar so the two bars read as one band.
 */
const props = defineProps({
  ariaLabel: { type: String, default: '' },
});
const { t } = useBrickConsoleI18n();
const resolvedAriaLabel = computed(() => props.ariaLabel || t('core.ui.contextHeader.aria'));
</script>

<template>
  <header class="brick-console-context-header shell-context-header" :aria-label="resolvedAriaLabel">
    <div v-if="$slots.leading" class="shell-context-header__leading">
      <slot name="leading" />
    </div>
    <div class="shell-context-header__body">
      <slot />
    </div>
    <div v-if="$slots.trailing" class="shell-context-header__trailing">
      <slot name="trailing" />
    </div>
  </header>
</template>
