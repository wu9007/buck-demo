<script setup>
import { computed, ref, watch } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';

/**
 * Soft-suspend recovery after silent refresh fails (SCREEN_LOCK).
 * Full-screen mask keeps workspace underneath (URL / drafts).
 * Unlock uses shell-provided re-auth (login path), never step-up verify-password.
 */
const props = defineProps({
  modelValue: { type: Boolean, default: false },
  title: { type: String, default: '' },
  description: { type: String, default: '' },
  username: { type: String, default: '' },
  confirmText: { type: String, default: '' },
  logoutText: { type: String, default: '' },
  passwordLabel: { type: String, default: '' },
  passwordPlaceholder: { type: String, default: '' },
  /** async (password: string) => void — must not leak password after resolve */
  unlock: { type: Function, required: true },
  /** optional exit: end session entirely */
  onLogout: { type: Function, default: null },
});

const emit = defineEmits(['update:modelValue', 'success', 'logout', 'fail']);
const { t } = useBrickConsoleI18n();

const password = ref('');
const submitting = ref(false);
const localError = ref('');

const visible = computed({
  get() {
    return Boolean(props.modelValue);
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

const resolvedTitle = computed(
  () => props.title || t('core.ui.sessionRecovery.lockTitle'),
);

const resolvedDescription = computed(
  () => props.description || t('core.ui.sessionRecovery.lockDescription'),
);

const resolvedConfirmText = computed(
  () => props.confirmText || t('core.ui.sessionRecovery.unlock'),
);
const resolvedLogoutText = computed(
  () => props.logoutText || t('core.ui.sessionRecovery.logout'),
);
const resolvedPasswordLabel = computed(
  () => props.passwordLabel || t('core.ui.sessionRecovery.passwordLabel'),
);
const resolvedPasswordPlaceholder = computed(
  () => props.passwordPlaceholder || t('core.ui.sessionRecovery.passwordPlaceholder'),
);

watch(visible, (open) => {
  if (open) {
    password.value = '';
    localError.value = '';
    submitting.value = false;
  } else {
    password.value = '';
  }
});

async function handleUnlock() {
  if (submitting.value) {
    return;
  }
  const value = password.value;
  if (!value || !String(value).trim()) {
    localError.value = t('core.ui.sessionRecovery.passwordRequired');
    return;
  }
  if (typeof props.unlock !== 'function') {
    localError.value = t('core.ui.sessionRecovery.unlockMissing');
    return;
  }
  submitting.value = true;
  localError.value = '';
  try {
    const result = await props.unlock(String(value));
    password.value = '';
    emit('success', result);
    visible.value = false;
  } catch (error) {
    localError.value = error?.message || t('core.ui.sessionRecovery.unlockFailed');
    emit('fail', error);
  } finally {
    submitting.value = false;
    password.value = '';
  }
}

async function handleLogout() {
  if (submitting.value) {
    return;
  }
  submitting.value = true;
  try {
    if (typeof props.onLogout === 'function') {
      await props.onLogout();
    }
    emit('logout');
    visible.value = false;
  } finally {
    submitting.value = false;
  }
}
</script>

<template>
  <Teleport to="body">
    <div
      v-if="visible"
      class="brick-session-recovery brick-session-recovery--lock"
      role="dialog"
      aria-modal="true"
      :aria-label="resolvedTitle"
    >
      <div class="brick-session-recovery__mask" />
      <div class="brick-session-recovery__panel">
        <header class="brick-session-recovery__header">
          <p class="brick-session-recovery__eyebrow">
            {{ t('core.ui.sessionRecovery.lockEyebrow') }}
          </p>
          <h2 class="brick-session-recovery__title">{{ resolvedTitle }}</h2>
          <p class="brick-session-recovery__description">{{ resolvedDescription }}</p>
          <p v-if="username" class="brick-session-recovery__user">
            {{ t('core.ui.sessionRecovery.signedInAs', { name: username }) }}
          </p>
        </header>

        <label class="brick-session-recovery__field">
          <span class="brick-session-recovery__label">{{ resolvedPasswordLabel }}</span>
          <el-input
            v-model="password"
            type="password"
            show-password
            autocomplete="current-password"
            :disabled="submitting"
            :placeholder="resolvedPasswordPlaceholder"
            @keyup.enter="handleUnlock"
          />
        </label>

        <p v-if="localError" class="brick-session-recovery__error" role="alert">{{ localError }}</p>

        <footer class="brick-session-recovery__footer">
          <el-button :disabled="submitting" @click="handleLogout">
            {{ resolvedLogoutText }}
          </el-button>
          <el-button type="primary" :loading="submitting" @click="handleUnlock">
            {{ resolvedConfirmText }}
          </el-button>
        </footer>
      </div>
    </div>
  </Teleport>
</template>

<style scoped>
.brick-session-recovery {
  position: fixed;
  inset: 0;
  z-index: 5000;
  display: grid;
  place-items: center;
  padding: 24px;
}

.brick-session-recovery__mask {
  position: absolute;
  inset: 0;
  background: color-mix(in srgb, #0f172a 78%, transparent);
  backdrop-filter: blur(6px);
}

.brick-session-recovery__panel {
  position: relative;
  z-index: 1;
  width: min(420px, calc(100vw - 32px));
  display: grid;
  gap: 16px;
  padding: 24px;
  border-radius: var(--console-card-radius, 12px);
  border: 1px solid var(--console-card-border, #e6ebf2);
  background: var(--console-card-bg, #ffffff);
  color: var(--console-text, #334155);
  box-shadow: 0 24px 64px color-mix(in srgb, #0f172a 28%, transparent);
}

.brick-session-recovery__eyebrow {
  margin: 0 0 6px;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--console-muted, #64748b);
}

.brick-session-recovery__title {
  margin: 0;
  font-size: 20px;
  font-weight: 800;
  color: var(--console-title, #0f172a);
}

.brick-session-recovery__description {
  margin: 8px 0 0;
  line-height: 1.7;
  color: var(--console-text, #334155);
}

.brick-session-recovery__user {
  margin: 8px 0 0;
  font-size: 13px;
  color: var(--console-muted, #64748b);
}

.brick-session-recovery__field {
  display: grid;
  gap: 8px;
}

.brick-session-recovery__label {
  font-size: var(--console-label-size, 12px);
  font-weight: 700;
  color: var(--console-muted, #64748b);
}

.brick-session-recovery__field :deep(.el-input__wrapper) {
  background-color: var(--console-field-bg, var(--console-card-bg, #ffffff));
  box-shadow: 0 0 0 1px var(--console-field-border, var(--console-card-border, #e6ebf2)) inset;
}

.brick-session-recovery__error {
  margin: 0;
  color: var(--console-danger, #dc2626);
  font-size: 13px;
}

.brick-session-recovery__footer {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: 12px;
}
</style>
