<script setup>
import { computed, ref, watch } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';

const props = defineProps({
  modelValue: { type: Boolean, default: undefined },
  title: { type: String, default: '' },
  description: { type: String, default: '' },
  impact: { type: [String, Array], default: '' },
  confirmText: { type: String, default: '' },
  cancelText: { type: String, default: '' },
  passwordLabel: { type: String, default: '' },
  passwordPlaceholder: { type: String, default: '' },
  /** async (password: string) => void | result — must not leak password after resolve */
  verify: { type: Function, required: true },
  disabled: { type: Boolean, default: false },
  dialogWidth: { type: String, default: 'min(420px, calc(100vw - 32px))' },
});

const emit = defineEmits(['update:modelValue', 'success', 'cancel', 'fail']);
const { t } = useBrickConsoleI18n();

const resolvedTitle = computed(() => props.title || t('core.ui.stepUpConfirm.defaultTitle'));
const resolvedConfirmText = computed(() => props.confirmText || t('core.ui.stepUpConfirm.confirm'));
const resolvedCancelText = computed(() => props.cancelText || t('core.ui.stepUpConfirm.cancel'));
const resolvedPasswordLabel = computed(() => props.passwordLabel || t('core.ui.stepUpConfirm.passwordLabel'));
const resolvedPasswordPlaceholder = computed(
  () => props.passwordPlaceholder || t('core.ui.stepUpConfirm.passwordPlaceholder'),
);

const internalVisible = ref(false);
const password = ref('');
const submitting = ref(false);
const localError = ref('');

const isControlled = computed(() => props.modelValue !== undefined);
const visible = computed({
  get() {
    return isControlled.value ? props.modelValue : internalVisible.value;
  },
  set(value) {
    if (!isControlled.value) {
      internalVisible.value = value;
    }
    emit('update:modelValue', value);
  },
});

const impactItems = computed(() => {
  if (Array.isArray(props.impact)) {
    return props.impact.filter(Boolean);
  }
  return props.impact ? [props.impact] : [];
});

watch(visible, (open) => {
  if (open) {
    password.value = '';
    localError.value = '';
    submitting.value = false;
  } else {
    password.value = '';
  }
});

function openConfirm() {
  if (props.disabled || submitting.value) {
    return;
  }
  visible.value = true;
}

function closeConfirm() {
  if (submitting.value) {
    return;
  }
  visible.value = false;
  emit('cancel');
}

async function handleConfirm() {
  if (props.disabled || submitting.value) {
    return;
  }
  const value = password.value;
  if (!value || !String(value).trim()) {
    localError.value = t('core.ui.stepUpConfirm.passwordRequired');
    return;
  }
  if (typeof props.verify !== 'function') {
    localError.value = t('core.ui.stepUpConfirm.verifyMissing');
    return;
  }
  submitting.value = true;
  localError.value = '';
  try {
    const result = await props.verify(value);
    password.value = '';
    visible.value = false;
    emit('success', result);
  } catch (error) {
    localError.value = error?.message || t('core.ui.stepUpConfirm.verifyFailed');
    emit('fail', error);
  } finally {
    submitting.value = false;
    password.value = '';
  }
}
</script>

<template>
  <span class="brick-step-up-confirm__trigger" @click="openConfirm">
    <slot name="trigger" :open="openConfirm" :disabled="disabled" :loading="submitting" />
  </span>

  <el-dialog
    v-model="visible"
    class="brick-step-up-confirm"
    :title="resolvedTitle"
    :width="dialogWidth"
    :close-on-click-modal="!submitting"
    :close-on-press-escape="!submitting"
    :show-close="!submitting"
    append-to-body
  >
    <section class="brick-step-up-confirm__body" aria-live="polite">
      <slot name="body">
        <p v-if="description" class="brick-step-up-confirm__description">{{ description }}</p>
      </slot>

      <div v-if="$slots.impact || impactItems.length > 0" class="brick-step-up-confirm__impact">
        <slot name="impact">
          <p class="brick-step-up-confirm__impact-title">{{ t('core.ui.stepUpConfirm.impactTitle') }}</p>
          <ul>
            <li v-for="item in impactItems" :key="item">{{ item }}</li>
          </ul>
        </slot>
      </div>

      <label class="brick-step-up-confirm__field">
        <span class="brick-step-up-confirm__label">{{ resolvedPasswordLabel }}</span>
        <el-input
          v-model="password"
          type="password"
          show-password
          autocomplete="current-password"
          :disabled="submitting || disabled"
          :placeholder="resolvedPasswordPlaceholder"
          @keyup.enter="handleConfirm"
        />
      </label>

      <p v-if="localError" class="brick-step-up-confirm__error" role="alert">{{ localError }}</p>
    </section>

    <template #footer>
      <div class="brick-step-up-confirm__footer">
        <el-button :disabled="submitting" @click="closeConfirm">
          {{ resolvedCancelText }}
        </el-button>
        <el-button
          type="primary"
          :loading="submitting"
          :disabled="disabled"
          @click="handleConfirm"
        >
          {{ resolvedConfirmText }}
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<style scoped>
.brick-step-up-confirm__trigger {
  display: inline-flex;
}

.brick-step-up-confirm__body {
  display: grid;
  gap: var(--console-space-4, 16px);
  color: var(--console-text, #334155);
}

.brick-step-up-confirm__description {
  margin: 0;
  line-height: 1.7;
}

.brick-step-up-confirm__impact {
  padding: var(--console-space-4, 16px);
  border: 1px solid color-mix(in srgb, var(--console-warning, #d97706) 34%, var(--console-card-border, #dbe3ef));
  border-radius: var(--console-block-radius, 8px);
  /* 警示底：与弹层主面区分，避免 append-to-body 时看起来像“底色消失” */
  background: color-mix(in srgb, var(--console-warning, #d97706) 12%, var(--console-card-bg, #ffffff));
}

.brick-step-up-confirm__impact-title {
  margin: 0 0 var(--console-space-2, 8px);
  color: var(--console-warning, #d97706);
  font-size: 13px;
  font-weight: 800;
}

.brick-step-up-confirm__impact ul {
  margin: 0;
  padding-inline-start: 18px;
}

.brick-step-up-confirm__impact li {
  line-height: 1.7;
  color: var(--console-text, #334155);
}

.brick-step-up-confirm__field {
  display: grid;
  gap: 8px;
}

.brick-step-up-confirm__label {
  font-size: var(--console-label-size, 12px);
  font-weight: 700;
  color: var(--console-muted, #64748b);
}

.brick-step-up-confirm__field :deep(.el-input) {
  --el-input-bg-color: var(--console-field-bg, var(--console-card-bg, #ffffff));
  --el-fill-color-blank: var(--console-field-bg, var(--console-card-bg, #ffffff));
  --el-input-text-color: var(--console-text, #334155);
  --el-input-border-color: var(--console-field-border, var(--console-card-border, #e6ebf2));
  --el-input-hover-border-color: var(--console-primary, #2563eb);
  --el-input-focus-border-color: var(--console-primary, #2563eb);
}

.brick-step-up-confirm__field :deep(.el-input__wrapper) {
  background-color: var(--console-field-bg, var(--console-card-bg, #ffffff));
  box-shadow: 0 0 0 1px var(--console-field-border, var(--console-card-border, #e6ebf2)) inset;
}

.brick-step-up-confirm__field :deep(.el-input__wrapper:hover),
.brick-step-up-confirm__field :deep(.el-input__wrapper.is-focus) {
  background-color: var(--console-field-bg, var(--console-card-bg, #ffffff));
  box-shadow: 0 0 0 1px var(--console-primary, #2563eb) inset;
}

.brick-step-up-confirm__field :deep(.el-input__inner) {
  color: var(--console-text, #334155);
  background-color: transparent;
  -webkit-text-fill-color: var(--console-text, #334155);
  caret-color: var(--console-text, #334155);
}

/*
 * 浏览器 autofill / 密码填充会给 input 刷一层白底，与 wrapper 主题色错位，
 * 表现为录入后输入区左侧出现一小段白色。用 inset 铺满覆盖。
 */
.brick-step-up-confirm__field :deep(.el-input__inner:-webkit-autofill),
.brick-step-up-confirm__field :deep(.el-input__inner:-webkit-autofill:hover),
.brick-step-up-confirm__field :deep(.el-input__inner:-webkit-autofill:focus),
.brick-step-up-confirm__field :deep(.el-input__inner:-webkit-autofill:active) {
  -webkit-box-shadow: 0 0 0 1000px var(--console-field-bg, var(--console-card-bg, #ffffff)) inset !important;
  box-shadow: 0 0 0 1000px var(--console-field-bg, var(--console-card-bg, #ffffff)) inset !important;
  -webkit-text-fill-color: var(--console-text, #334155) !important;
  caret-color: var(--console-text, #334155);
  transition: background-color 99999s ease-out 0s;
}

.brick-step-up-confirm__field :deep(.el-input__password),
.brick-step-up-confirm__field :deep(.el-input__suffix),
.brick-step-up-confirm__field :deep(.el-input__prefix) {
  color: var(--console-muted, #64748b);
  background: transparent;
}

.brick-step-up-confirm__error {
  margin: 0;
  color: var(--console-danger, #dc2626);
  font-size: 13px;
}

.brick-step-up-confirm__footer {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: var(--console-space-3, 12px);
}
</style>

<style>
/* Dialog surface follows console tokens when step-up is teleported to body. */
.brick-step-up-confirm.el-dialog {
  --el-dialog-bg-color: var(--console-card-bg, #ffffff);
  --el-text-color-primary: var(--console-title, #0f172a);
  --el-text-color-regular: var(--console-text, #334155);
  background: var(--console-card-bg, #ffffff);
  color: var(--console-text, #334155);
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: var(--console-card-radius, 8px);
}

.brick-step-up-confirm.el-dialog .el-dialog__header,
.brick-step-up-confirm.el-dialog .el-dialog__body,
.brick-step-up-confirm.el-dialog .el-dialog__footer {
  background: transparent;
  color: inherit;
}

.brick-step-up-confirm.el-dialog .el-dialog__title {
  color: var(--console-title, #0f172a);
  font-weight: 700;
}
</style>
