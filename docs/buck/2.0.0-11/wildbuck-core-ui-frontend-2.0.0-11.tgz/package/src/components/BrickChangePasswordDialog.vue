<script setup>
/**
 * Self-service change-password dialog for console avatar menu.
 * Stays on the shell (append-to-body modal); does not own HTTP — parent supplies submit().
 */
import { computed, reactive, ref, watch } from 'vue';
import { ElButton } from 'element-plus/es/components/button/index.mjs';
import { ElDialog } from 'element-plus/es/components/dialog/index.mjs';
import { ElInput } from 'element-plus/es/components/input/index.mjs';
import 'element-plus/es/components/button/style/css';
import 'element-plus/es/components/dialog/style/css';
import 'element-plus/es/components/input/style/css';
import { useBrickConsoleI18n } from '../i18n.js';

const props = defineProps({
  visible: { type: Boolean, default: false },
  /**
   * Login username for browser password managers. Without a username target, Chrome
   * often autofills the saved username into the sidebar menu search instead.
   */
  username: { type: String, default: '' },
  /**
   * async ({ currentPassword, newPassword }) => void
   * Reject with Error(message) to show inline error; resolve to close dialog.
   */
  submit: { type: Function, default: null },
  dialogWidth: { type: String, default: 'min(440px, calc(100vw - 32px))' },
});

const emit = defineEmits(['close', 'success', 'fail']);
const { t } = useBrickConsoleI18n();

const submitting = ref(false);
const localError = ref('');
const form = reactive({
  currentPassword: '',
  newPassword: '',
  confirmNewPassword: '',
});

const dialogVisible = computed({
  get: () => props.visible,
  set: (value) => {
    if (!value) {
      emit('close');
    }
  },
});

function resetForm() {
  form.currentPassword = '';
  form.newPassword = '';
  form.confirmNewPassword = '';
  localError.value = '';
  submitting.value = false;
}

watch(
  () => props.visible,
  (open) => {
    if (open) {
      resetForm();
    } else {
      resetForm();
    }
  },
);

function closeDialog() {
  if (submitting.value) {
    return;
  }
  emit('close');
}

async function handleSubmit() {
  if (submitting.value) {
    return;
  }
  const currentPassword = String(form.currentPassword || '');
  const newPassword = String(form.newPassword || '');
  const confirmNewPassword = String(form.confirmNewPassword || '');

  if (!currentPassword.trim()) {
    localError.value = t('core.ui.changePassword.currentRequired');
    return;
  }
  if (!newPassword.trim()) {
    localError.value = t('core.ui.changePassword.newRequired');
    return;
  }
  if (newPassword !== confirmNewPassword) {
    localError.value = t('core.ui.changePassword.confirmMismatch');
    return;
  }
  if (typeof props.submit !== 'function') {
    localError.value = t('core.ui.changePassword.submitMissing');
    return;
  }

  submitting.value = true;
  localError.value = '';
  try {
    await props.submit({ currentPassword, newPassword });
    resetForm();
    emit('success');
    emit('close');
  } catch (error) {
    localError.value = error?.message || t('core.ui.changePassword.submitFailed');
    emit('fail', error);
  } finally {
    submitting.value = false;
  }
}
</script>

<template>
  <ElDialog
    v-model="dialogVisible"
    class="brick-change-password-dialog"
    :title="t('core.ui.changePassword.title')"
    :width="dialogWidth"
    :close-on-click-modal="!submitting"
    :close-on-press-escape="!submitting"
    :show-close="!submitting"
    append-to-body
    destroy-on-close
    data-testid="brick-change-password-dialog"
    @closed="resetForm"
  >
    <section class="brick-change-password-dialog__body" aria-live="polite">
      <p class="brick-change-password-dialog__description">
        {{ t('core.ui.changePassword.description') }}
      </p>

      <!--
        Hidden username sink for password managers only — self-service change must NOT ask
        the user to re-enter account. Without any username target, browsers may dump the
        saved login into the sidebar menu search instead.
      -->
      <input
        type="text"
        name="username"
        autocomplete="username"
        :value="username"
        class="brick-change-password-dialog__username-trap"
        tabindex="-1"
        aria-hidden="true"
        readonly
      />

      <label class="brick-change-password-dialog__field">
        <span class="brick-change-password-dialog__label">{{ t('core.ui.changePassword.currentLabel') }}</span>
        <ElInput
          v-model="form.currentPassword"
          type="password"
          name="current-password"
          show-password
          autocomplete="current-password"
          :disabled="submitting"
          :placeholder="t('core.ui.changePassword.currentPlaceholder')"
        />
      </label>

      <label class="brick-change-password-dialog__field">
        <span class="brick-change-password-dialog__label">{{ t('core.ui.changePassword.newLabel') }}</span>
        <ElInput
          v-model="form.newPassword"
          type="password"
          name="new-password"
          show-password
          autocomplete="new-password"
          :disabled="submitting"
          :placeholder="t('core.ui.changePassword.newPlaceholder')"
        />
      </label>

      <label class="brick-change-password-dialog__field">
        <span class="brick-change-password-dialog__label">{{ t('core.ui.changePassword.confirmLabel') }}</span>
        <ElInput
          v-model="form.confirmNewPassword"
          type="password"
          name="confirm-new-password"
          show-password
          autocomplete="new-password"
          :disabled="submitting"
          :placeholder="t('core.ui.changePassword.confirmPlaceholder')"
          @keyup.enter="handleSubmit"
        />
      </label>

      <p v-if="localError" class="brick-change-password-dialog__error" role="alert">{{ localError }}</p>
    </section>

    <template #footer>
      <div class="brick-change-password-dialog__footer">
        <ElButton :disabled="submitting" @click="closeDialog">
          {{ t('core.ui.changePassword.cancel') }}
        </ElButton>
        <ElButton type="primary" :loading="submitting" @click="handleSubmit">
          {{ t('core.ui.changePassword.confirm') }}
        </ElButton>
      </div>
    </template>
  </ElDialog>
</template>

<style scoped>
.brick-change-password-dialog__body {
  display: grid;
  gap: var(--console-space-3, 12px);
  color: var(--console-text, #334155);
}

.brick-change-password-dialog__description {
  margin: 0;
  font-size: var(--console-body-size, 14px);
  line-height: 1.5;
  color: var(--console-muted, #64748b);
}

.brick-change-password-dialog__field {
  display: grid;
  gap: 6px;
}

.brick-change-password-dialog__label {
  font-size: var(--console-label-size, 12px);
  font-weight: 600;
  color: var(--console-title, #0f172a);
}

.brick-change-password-dialog__error {
  margin: 0;
  font-size: var(--console-caption-size, 12px);
  color: var(--console-danger, #dc2626);
}

.brick-change-password-dialog__footer {
  display: flex;
  justify-content: flex-end;
  gap: var(--console-space-2, 10px);
}

/* Invisible username sink when caller did not pass a display username. */
.brick-change-password-dialog__username-trap {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
}
</style>

<style>
/* Teleported dialog shell tokens (documentElement projection). */
.brick-change-password-dialog.el-dialog {
  --el-dialog-bg-color: var(--console-card-bg, #ffffff);
  background: var(--console-card-bg, #ffffff);
  color: var(--console-text, #334155);
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: var(--console-card-radius, 8px);
}

.brick-change-password-dialog.el-dialog .el-dialog__title {
  color: var(--console-title, #0f172a);
}
</style>
