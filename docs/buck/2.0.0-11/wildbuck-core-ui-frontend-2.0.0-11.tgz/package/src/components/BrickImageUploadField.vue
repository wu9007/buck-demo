<script setup>
/**
 * Shared image upload field.
 * Preview contract: never use authenticated /file-resources/{id}/content as img src.
 * After local file pick, component keeps a blob: preview until parent supplies a safe URL
 * (public path or another blob) or clears.
 */
import { computed, onBeforeUnmount, ref, watch } from 'vue';
import {
  createBrickLocalImagePreview,
  resolveBrickImagePreviewUrl,
  revokeBrickImagePreview,
} from '../image-resource.js';

const props = defineProps({
  label: { type: String, default: '图片' },
  description: { type: String, default: '' },
  previewUrl: { type: String, default: '' },
  previewAlt: { type: String, default: '图片预览' },
  fallbackText: { type: String, default: '图' },
  uploadText: { type: String, default: '上传图片' },
  uploadingText: { type: String, default: '上传中...' },
  clearText: { type: String, default: '清除图片' },
  resourceHint: { type: String, default: '' },
  accept: { type: String, default: 'image/png,image/jpeg,image/gif,image/webp,image/svg+xml' },
  allowedMimeTypes: {
    type: Array,
    default: () => ['image/png', 'image/jpeg', 'image/gif', 'image/webp', 'image/svg+xml'],
  },
  maxSizeBytes: { type: Number, default: 2 * 1024 * 1024 },
  previewSize: { type: Number, default: 72 },
  disabled: { type: Boolean, default: false },
  uploading: { type: Boolean, default: false },
  clearDisabled: { type: Boolean, default: false },
});

const emit = defineEmits(['upload', 'clear', 'invalid-file']);
const fileInput = ref(null);
const validationMessage = ref('');
const localPreviewUrl = ref('');

const previewStyle = computed(() => ({
  '--brick-image-upload-preview-size': `${Math.max(48, Number(props.previewSize) || 72)}px`,
}));
const effectiveFallback = computed(() => {
  const text = String(props.fallbackText || '图').replace(/\s+/g, '');
  return text.length <= 2 ? text.toUpperCase() : text.slice(0, 2).toUpperCase();
});
const formattedMaxSize = computed(() => {
  if (!props.maxSizeBytes || props.maxSizeBytes <= 0) {
    return '';
  }
  const megabytes = props.maxSizeBytes / 1024 / 1024;
  return Number.isInteger(megabytes) ? `${megabytes}MB` : `${megabytes.toFixed(1)}MB`;
});
const canOpenPicker = computed(() => !props.disabled && !props.uploading);
const canClear = computed(() => !props.disabled && !props.uploading && !props.clearDisabled);

/** Safe display URL: public/blob prop wins; authenticated contentUrl falls back to local blob. */
const displayPreviewUrl = computed(() => resolveBrickImagePreviewUrl(props.previewUrl, localPreviewUrl.value));

watch(
  () => props.previewUrl,
  (next) => {
    const safe = resolveBrickImagePreviewUrl(next, '');
    // Parent provided a safe non-local URL (public asset) — drop local blob.
    if (safe && !String(safe).startsWith('blob:') && localPreviewUrl.value) {
      revokeBrickImagePreview(localPreviewUrl.value);
      localPreviewUrl.value = '';
    }
    // Parent cleared preview.
    if (!next && localPreviewUrl.value) {
      revokeBrickImagePreview(localPreviewUrl.value);
      localPreviewUrl.value = '';
    }
  },
);

function replaceLocalPreview(file) {
  revokeBrickImagePreview(localPreviewUrl.value);
  localPreviewUrl.value = createBrickLocalImagePreview(file) || '';
}

function openPicker() {
  if (!canOpenPicker.value) {
    return;
  }
  validationMessage.value = '';
  fileInput.value?.click();
}

function handleFileChange(event) {
  const input = event.target;
  const file = input.files?.[0];
  if (!file) {
    return;
  }
  if (validateFile(file)) {
    // Local blob first so preview works even if parent sets authenticated contentUrl.
    replaceLocalPreview(file);
    emit('upload', file);
  }
  input.value = '';
}

function handleClear() {
  if (!canClear.value) {
    return;
  }
  validationMessage.value = '';
  revokeBrickImagePreview(localPreviewUrl.value);
  localPreviewUrl.value = '';
  emit('clear');
}

function validateFile(file) {
  const allowedTypes = props.allowedMimeTypes.map((type) => String(type).toLowerCase());
  const fileType = String(file.type || '').toLowerCase();
  if (allowedTypes.length > 0 && !matchesAllowedType(fileType, allowedTypes)) {
    reportInvalid('请上传 png、jpg、gif、webp 或 svg 图片。', 'type', file);
    return false;
  }
  if (props.maxSizeBytes > 0 && file.size > props.maxSizeBytes) {
    reportInvalid(`图片文件请控制在 ${formattedMaxSize.value} 以内。`, 'size', file);
    return false;
  }
  validationMessage.value = '';
  return true;
}

function matchesAllowedType(fileType, allowedTypes) {
  if (!fileType) {
    return false;
  }
  return allowedTypes.some((allowedType) => {
    if (allowedType.endsWith('/*')) {
      return fileType.startsWith(allowedType.slice(0, -1));
    }
    return fileType === allowedType;
  });
}

function reportInvalid(message, reason, file) {
  validationMessage.value = message;
  emit('invalid-file', { reason, message, file });
}

onBeforeUnmount(() => {
  revokeBrickImagePreview(localPreviewUrl.value);
  localPreviewUrl.value = '';
});
</script>

<template>
  <section
    class="brick-image-upload-field"
    :class="{ 'is-disabled': disabled, 'is-uploading': uploading }"
    :style="previewStyle"
  >
    <div v-if="label || description" class="brick-image-upload-field__copy">
      <span v-if="label" class="brick-image-upload-field__label">{{ label }}</span>
      <small v-if="description" class="brick-image-upload-field__description">{{ description }}</small>
    </div>

    <div class="brick-image-upload-field__body">
      <div class="brick-image-upload-field__preview">
        <img
          v-if="displayPreviewUrl"
          class="brick-image-upload-field__image"
          :src="displayPreviewUrl"
          :alt="previewAlt"
        />
        <span v-else class="brick-image-upload-field__fallback">{{ effectiveFallback }}</span>
      </div>

      <div class="brick-image-upload-field__actions">
        <input
          ref="fileInput"
          class="brick-image-upload-field__input"
          type="file"
          :accept="accept"
          :disabled="disabled || uploading"
          @change="handleFileChange"
        />
        <button
          class="brick-image-upload-field__button brick-image-upload-field__button--primary"
          type="button"
          :disabled="!canOpenPicker"
          @click="openPicker"
        >
          <span>{{ uploading ? uploadingText : uploadText }}</span>
        </button>
        <button
          class="brick-image-upload-field__button brick-image-upload-field__button--secondary"
          type="button"
          :disabled="!canClear"
          @click="handleClear"
        >
          <span>{{ clearText }}</span>
        </button>
        <p v-if="resourceHint" class="brick-image-upload-field__hint">
          {{ resourceHint }}
        </p>
        <p v-if="validationMessage" class="brick-image-upload-field__hint brick-image-upload-field__hint--error" aria-live="polite">
          {{ validationMessage }}
        </p>
      </div>
    </div>
  </section>
</template>
