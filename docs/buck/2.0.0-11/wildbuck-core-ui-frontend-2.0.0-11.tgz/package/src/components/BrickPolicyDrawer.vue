<script setup>
import { computed } from 'vue';
import BrickActionBar from './BrickActionBar.vue';
import { useBrickConsoleI18n } from '../i18n.js';

const props = defineProps({
  modelValue: { type: Boolean, required: true },
  title: { type: String, required: true },
  description: { type: String, default: '' },
  statusLabel: { type: String, default: '' },
  statusTone: { type: String, default: 'default' },
  changed: { type: Boolean, default: false },
  saving: { type: Boolean, default: false },
  saveable: { type: Boolean, default: true },
  saveText: { type: String, default: '' },
  cancelText: { type: String, default: '' },
  width: { type: String, default: 'min(640px, 92vw)' },
});

const emit = defineEmits(['update:modelValue', 'save']);
const { t } = useBrickConsoleI18n();

const hasStatus = computed(() => Boolean(props.statusLabel || props.changed));
const resolvedSaveText = computed(() => props.saveText || t('core.ui.policy.save'));
const resolvedCancelText = computed(() => props.cancelText || t('core.ui.policy.cancel'));
const unsavedLabel = computed(() => t('core.ui.policy.unsavedChanges'));

function close() {
  if (!props.saving) {
    emit('update:modelValue', false);
  }
}
</script>

<template>
  <el-drawer
    class="brick-policy-drawer"
    :model-value="modelValue"
    :size="width"
    destroy-on-close
    @update:model-value="emit('update:modelValue', $event)"
  >
    <template #header>
      <div class="brick-policy-drawer__header">
        <div>
          <h2>{{ title }}</h2>
          <p v-if="description">{{ description }}</p>
        </div>
        <div v-if="hasStatus" class="brick-policy-drawer__status">
          <span v-if="statusLabel" class="brick-policy-drawer__status-item brick-policy-status" :data-tone="statusTone">{{ statusLabel }}</span>
          <span v-if="changed" class="brick-policy-drawer__status-item brick-policy-status" data-tone="warning">{{ unsavedLabel }}</span>
        </div>
      </div>
    </template>

    <section class="brick-policy-drawer__form" data-guide-anchor="settings">
      <slot />
    </section>

    <template #footer>
      <BrickActionBar align="between" data-guide-anchor="save-area">
        <template #secondary>
          <slot name="secondary" />
        </template>
        <template #primary>
          <el-button @click="close">{{ resolvedCancelText }}</el-button>
          <el-button
            v-if="saveable"
            type="primary"
            :loading="saving"
            @click="emit('save')"
          >
            {{ resolvedSaveText }}
          </el-button>
        </template>
      </BrickActionBar>
    </template>
  </el-drawer>
</template>

<style scoped>
.brick-policy-drawer__header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--console-space-4, 18px);
}

.brick-policy-drawer__header h2,
.brick-policy-drawer__header p {
  margin: 0;
}

.brick-policy-drawer__header h2 {
  color: var(--console-title, #0f172a);
  font-size: 20px;
  line-height: 1.25;
}

.brick-policy-drawer__header p {
  max-width: 460px;
  margin-top: 6px;
  color: var(--console-text, #334155);
  font-size: 13px;
  line-height: 1.7;
}

.brick-policy-drawer__status {
  display: inline-flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: var(--console-space-2, 10px);
}

.brick-policy-drawer__form {
  display: grid;
  gap: var(--console-space-4, 18px);
}

.brick-policy-drawer__form :deep(.setting-form) {
  grid-template-columns: 1fr;
  gap: var(--console-space-5, 24px);
}

.brick-policy-drawer__form :deep(.setting-form .el-form-item__label) {
  margin-bottom: 8px;
  color: var(--console-title, #0f172a);
  font-size: 13px;
  font-weight: 850;
  letter-spacing: 0;
  line-height: 1.35;
  text-transform: none;
}

@media (max-width: 760px) {
  .brick-policy-drawer__header {
    display: grid;
  }

  .brick-policy-drawer__status {
    justify-content: flex-start;
  }
}
</style>
