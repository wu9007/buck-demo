<script setup>
import { computed } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';

const props = defineProps({
  title: { type: String, default: '' },
  description: { type: String, default: '' },
  variant: { type: String, default: 'empty' },
  compact: { type: Boolean, default: false },
  actionText: { type: String, default: '' },
  iconText: { type: String, default: 'i' },
});

const emit = defineEmits(['action']);
const { t } = useBrickConsoleI18n();
const resolvedTitle = computed(() => props.title || t('core.ui.empty.defaultTitle'));
</script>

<template>
  <section
    class="brick-empty-state"
    :class="[`brick-empty-state--${variant}`, { 'is-compact': compact }]"
    role="status"
    aria-live="polite"
  >
    <div class="brick-empty-state__icon" aria-hidden="true">
      <slot name="icon">
        <span class="brick-empty-state__icon-mark">{{ props.iconText }}</span>
      </slot>
    </div>

    <h3 v-if="$slots.title || resolvedTitle" class="brick-empty-state__title">
      <slot name="title">{{ resolvedTitle }}</slot>
    </h3>

    <p v-if="$slots.description || description" class="brick-empty-state__description">
      <slot name="description">{{ description }}</slot>
    </p>

    <div v-if="$slots.actions || actionText" class="brick-empty-state__actions">
      <slot name="actions">
        <el-button v-if="actionText" type="primary" plain @click="emit('action')">
          {{ actionText }}
        </el-button>
      </slot>
    </div>

    <slot />
  </section>
</template>

<style scoped>
.brick-empty-state {
  display: flex;
  min-height: 168px;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--console-space-3, 12px);
  padding: var(--console-space-8, 32px);
  border: 1px dashed var(--console-block-border, var(--console-card-border, #dbe3ef));
  border-radius: var(--console-block-radius, 8px);
  background: var(--console-block-bg, #f8fafc);
  color: var(--console-text, #334155);
  text-align: center;
}

.brick-empty-state.is-compact {
  min-height: 104px;
  padding: var(--console-space-5, 20px);
}

.brick-empty-state__icon {
  display: inline-flex;
  width: 40px;
  height: 40px;
  align-items: center;
  justify-content: center;
  border-radius: 999px;
  background: color-mix(in srgb, var(--console-primary, #2563eb) 12%, transparent);
  color: var(--console-primary, #2563eb);
  font-weight: 800;
}

.brick-empty-state--error .brick-empty-state__icon {
  background: color-mix(in srgb, var(--console-danger, #dc2626) 12%, transparent);
  color: var(--console-danger, #dc2626);
}

.brick-empty-state--permission .brick-empty-state__icon {
  background: color-mix(in srgb, var(--console-warning, #d97706) 14%, transparent);
  color: var(--console-warning, #d97706);
}

.brick-empty-state__title {
  margin: 0;
  color: var(--console-title, #0f172a);
  font-size: 16px;
  font-weight: 800;
}

.brick-empty-state__description {
  max-width: 520px;
  margin: 0;
  color: var(--console-muted, #64748b);
  font-size: 14px;
  line-height: 1.7;
}

.brick-empty-state__actions {
  display: inline-flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: var(--console-space-3, 12px);
}
</style>
