<script setup>
/**
 * Compact admin page header for list/governance pages.
 * Primary actions belong in #actions; metrics belong in #stats (or BrickStatStrip),
 * never competing with the primary action row as marketing-size chrome.
 */
defineProps({
  title: { type: String, default: '' },
  description: { type: String, default: '' },
  eyebrow: { type: String, default: '' },
});
</script>

<template>
  <header class="brick-page-header">
    <div class="brick-page-header__main">
      <p v-if="$slots.eyebrow || eyebrow" class="brick-page-header__eyebrow">
        <slot name="eyebrow">{{ eyebrow }}</slot>
      </p>
      <div class="brick-page-header__title-row">
        <h1 v-if="$slots.title || title" class="brick-page-header__title">
          <slot name="title">{{ title }}</slot>
        </h1>
        <div v-if="$slots.actions" class="brick-page-header__actions">
          <slot name="actions" />
        </div>
      </div>
      <p v-if="$slots.description || description" class="brick-page-header__description">
        <slot name="description">{{ description }}</slot>
      </p>
    </div>
    <div v-if="$slots.stats" class="brick-page-header__stats">
      <slot name="stats" />
    </div>
  </header>
</template>

<style scoped>
.brick-page-header {
  display: grid;
  gap: var(--console-space-3, 12px);
}
.brick-page-header__main {
  display: grid;
  gap: var(--console-space-2, 8px);
}
.brick-page-header__eyebrow,
.brick-page-header__title,
.brick-page-header__description {
  margin: 0;
}
.brick-page-header__eyebrow {
  color: var(--console-muted, #6b7a90);
  font-size: var(--console-caption-size, 12px);
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}
.brick-page-header__title-row {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--console-space-4, 16px);
}
.brick-page-header__title {
  color: var(--console-title, #172033);
  font-size: 20px;
  font-weight: 750;
  line-height: 1.3;
  letter-spacing: -0.01em;
}
.brick-page-header__description {
  max-width: 52rem;
  color: var(--console-text, #41516a);
  font-size: var(--console-body-size, 14px);
  line-height: 1.6;
}
.brick-page-header__actions,
.brick-page-header__stats {
  display: flex;
  flex-wrap: wrap;
  gap: var(--console-space-2, 8px);
}
.brick-page-header__actions {
  align-items: center;
  justify-content: flex-end;
  flex-shrink: 0;
}
.brick-page-header__stats {
  gap: var(--console-space-3, 12px);
}
@media (max-width: 760px) {
  .brick-page-header__title-row {
    flex-direction: column;
  }
  .brick-page-header__actions {
    width: 100%;
    justify-content: flex-start;
  }
}
</style>
