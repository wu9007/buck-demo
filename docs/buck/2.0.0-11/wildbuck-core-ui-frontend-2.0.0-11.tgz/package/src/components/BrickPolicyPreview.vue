<script setup>
import { useBrickConsoleI18n } from '../i18n.js';

defineProps({
  title: { type: String, required: true },
  message: { type: String, required: true },
  tone: { type: String, default: 'default' },
  items: { type: Array, default: () => [] },
});

const { t } = useBrickConsoleI18n();
</script>

<template>
  <aside class="brick-policy-preview" :data-tone="tone">
    <div>
      <p class="brick-policy-preview__eyebrow">{{ t('core.ui.policy.previewEyebrow') }}</p>
      <h4 class="brick-policy-preview__title">{{ title }}</h4>
      <p class="brick-policy-preview__message">{{ message }}</p>
    </div>
    <dl v-if="items.length" class="brick-policy-preview__items">
      <div v-for="item in items" :key="item.label" class="brick-policy-preview__item" :data-tone="item.tone || 'default'">
        <dt>{{ item.label }}</dt>
        <dd>{{ item.value }}</dd>
      </div>
    </dl>
  </aside>
</template>

<style scoped>
.brick-policy-preview {
  display: grid;
  gap: var(--console-space-2, 10px);
}

.brick-policy-preview[data-tone='warning'] {
  color: var(--console-warning, #b45309);
}

.brick-policy-preview[data-tone='danger'] {
  color: var(--console-danger, #dc2626);
}

.brick-policy-preview__eyebrow,
.brick-policy-preview__title,
.brick-policy-preview__message,
.brick-policy-preview__item dt,
.brick-policy-preview__item dd {
  margin: 0;
}

.brick-policy-preview__eyebrow {
  color: var(--console-muted, #64748b);
  font-size: 11px;
  font-weight: 850;
  letter-spacing: 0;
  text-transform: uppercase;
}

.brick-policy-preview__title {
  margin-top: 4px;
  color: var(--console-title, #0f172a);
  font-size: 15px;
  font-weight: 850;
}

.brick-policy-preview__message {
  margin-top: 6px;
  color: var(--console-text, #334155);
  font-size: 13px;
  line-height: 1.65;
}

.brick-policy-preview__items {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 6px var(--console-space-4, 18px);
  margin: 0;
}

.brick-policy-preview__item {
  display: flex;
  align-items: baseline;
  gap: var(--console-space-2, 10px);
  min-width: 0;
}

.brick-policy-preview__item dt {
  color: var(--console-muted, #64748b);
  font-size: 11px;
  font-weight: 800;
}

.brick-policy-preview__item dd {
  color: var(--console-title, #0f172a);
  font-size: 14px;
  font-weight: 850;
}
</style>
