<template>
  <section class="brick-policy-grid">
    <slot />
  </section>
</template>

<style scoped>
.brick-policy-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: var(--console-space-4, 18px);
}

@media (max-width: 760px) {
  .brick-policy-grid {
    grid-template-columns: 1fr;
  }
}
</style>
