<script setup>
/**
 * Appears when table rows are multi-selected (#442 / #443).
 * Host owns selection state; this bar only presents count + batch/clear actions.
 */
import { computed } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';

const props = defineProps({
  /** Number of selected rows. Bar is hidden when <= 0. */
  selectedCount: { type: Number, default: 0 },
  /** Override label; supports {count} placeholder. Empty → i18n default. */
  selectedLabel: { type: String, default: '' },
  ariaLabel: { type: String, default: '' },
});

const { t } = useBrickConsoleI18n();

const visible = computed(() => Number(props.selectedCount) > 0);

const countText = computed(() => {
  const count = Math.max(0, Number(props.selectedCount) || 0);
  if (props.selectedLabel && props.selectedLabel.trim()) {
    return props.selectedLabel.replaceAll('{count}', String(count));
  }
  return t('core.ui.selection.selectedCount', { count });
});
</script>

<template>
  <div
    v-if="visible"
    class="brick-selection-action-bar"
    role="region"
    :aria-label="ariaLabel || countText"
    data-brick-selection-action-bar="true"
  >
    <span class="brick-selection-action-bar__count">{{ countText }}</span>
    <div v-if="$slots.batch" class="brick-selection-action-bar__batch">
      <slot name="batch" />
    </div>
    <div v-if="$slots.clear" class="brick-selection-action-bar__clear">
      <slot name="clear" />
    </div>
    <div v-if="$slots.default" class="brick-selection-action-bar__default">
      <slot />
    </div>
  </div>
</template>

<style scoped>
.brick-selection-action-bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--console-space-3, 12px);
  padding: var(--console-space-2, 8px) var(--console-space-3, 12px);
  border: 1px solid rgba(24, 129, 104, 0.22);
  border-radius: var(--console-card-radius, 8px);
  background: rgba(24, 129, 104, 0.06);
}

.brick-selection-action-bar__count {
  color: var(--console-title, #172033);
  font-size: var(--console-body-size, 14px);
  font-weight: 700;
}

.brick-selection-action-bar__batch,
.brick-selection-action-bar__clear,
.brick-selection-action-bar__default {
  display: inline-flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--console-space-2, 8px);
}

.brick-selection-action-bar__clear,
.brick-selection-action-bar__default {
  margin-inline-start: auto;
}

.brick-selection-action-bar :deep(.el-button) {
  min-height: var(--console-control-height, 36px);
  border-radius: var(--console-field-radius, 6px);
  font-weight: 700;
}

@media (max-width: 760px) {
  .brick-selection-action-bar__clear,
  .brick-selection-action-bar__default {
    margin-inline-start: 0;
    width: 100%;
  }
}
</style>
