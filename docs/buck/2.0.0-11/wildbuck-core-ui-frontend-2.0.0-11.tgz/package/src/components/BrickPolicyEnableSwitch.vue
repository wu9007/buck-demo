<script setup>
import { computed } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';

const props = defineProps({
  modelValue: { type: Boolean, required: true },
  label: { type: String, required: true },
  description: { type: String, default: '' },
  disabled: { type: Boolean, default: false },
});

const emit = defineEmits(['update:modelValue']);
const { t } = useBrickConsoleI18n();

// Labels may mark required with Chinese or English parenthetical form.
const isRequired = computed(() => /必填|\(required\)/i.test(props.label));
</script>

<template>
  <el-form-item
    class="brick-policy-form-item brick-policy-enable-switch"
    :class="{ 'is-disabled': disabled, 'is-enabled': modelValue }"
    :label="label"
    :required="isRequired"
  >
    <div class="brick-policy-switch-row">
      <p v-if="description" class="brick-policy-field-description">{{ description }}</p>
      <div class="brick-policy-switch-row__control">
        <el-switch
          :model-value="modelValue"
          :disabled="disabled"
          :active-text="t('core.ui.common.enabled')"
          :inactive-text="t('core.ui.common.disabled')"
          inline-prompt
          @update:model-value="emit('update:modelValue', Boolean($event))"
        />
      </div>
    </div>
  </el-form-item>
</template>
