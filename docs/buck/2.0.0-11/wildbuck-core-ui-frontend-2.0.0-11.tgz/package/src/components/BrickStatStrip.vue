<script setup>
/**
 * Compact stat strip for admin list pages.
 * Place under BrickPageHeader #stats, never inside primary #actions.
 * Does not fetch data, compute metrics, or encode business meaning.
 */
defineProps({
  items: {
    type: Array,
    default: () => [],
  },
});
</script>

<template>
  <div class="brick-stat-strip" role="group">
    <slot>
      <section
        v-for="(item, index) in items"
        :key="item.key || `${item.label}-${index}`"
        class="brick-stat-strip__item"
        :data-tone="item.tone || 'default'"
      >
        <p class="brick-stat-strip__label">{{ item.label }}</p>
        <strong class="brick-stat-strip__value">{{ item.value }}</strong>
      </section>
    </slot>
  </div>
</template>

<style scoped>
.brick-stat-strip {
  display: flex;
  flex-wrap: wrap;
  gap: var(--console-space-3, 12px);
}
.brick-stat-strip__item {
  min-width: 112px;
  display: grid;
  gap: 4px;
  padding: 10px 12px;
  border: 1px solid var(--console-card-border, #dbe3ef);
  border-radius: var(--console-block-radius, 8px);
  background: var(--console-card-bg, #ffffff);
}
.brick-stat-strip__label,
.brick-stat-strip__value {
  margin: 0;
}
.brick-stat-strip__label {
  color: var(--console-muted, #6b7a90);
  font-size: var(--console-caption-size, 12px);
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}
.brick-stat-strip__value {
  color: var(--console-title, #172033);
  font-size: 16px;
  font-weight: 700;
  line-height: 1.2;
}
.brick-stat-strip__item[data-tone='success'] .brick-stat-strip__value {
  color: var(--console-success, #16a34a);
}
.brick-stat-strip__item[data-tone='warning'] .brick-stat-strip__value {
  color: var(--console-warning, #d97706);
}
.brick-stat-strip__item[data-tone='danger'] .brick-stat-strip__value {
  color: var(--console-danger, #dc2626);
}
</style>
