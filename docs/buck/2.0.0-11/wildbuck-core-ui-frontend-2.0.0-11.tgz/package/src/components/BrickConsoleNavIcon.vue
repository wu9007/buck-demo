<script setup>
/**
 * Formal stroke icons for console navigation marks.
 * Keep glyphs simple and monochrome so expanded/collapsed rails stay product-grade.
 */
import { computed } from 'vue';
import { normalizeBrickConsoleNavIconName } from '../shell-icons.js';

const props = defineProps({
  name: { type: String, default: 'menu' },
});

const iconName = computed(() => normalizeBrickConsoleNavIconName(props.name) || 'menu');
</script>

<template>
  <svg
    class="shell-nav-item__icon shell-nav-icon"
    :data-icon-name="iconName"
    viewBox="0 0 16 16"
    aria-hidden="true"
    focusable="false"
  >
    <!-- menu / list -->
    <template v-if="iconName === 'menu'">
      <path d="M3 4.5h10" />
      <path d="M3 8h10" />
      <path d="M3 11.5h10" />
    </template>
    <!-- home / principal -->
    <template v-else-if="iconName === 'home'">
      <path d="M2.75 7.25 8 2.75l5.25 4.5" />
      <path d="M4.25 6.75V13h7.5V6.75" />
      <path d="M6.5 13V9.5h3V13" />
    </template>
    <!-- users / employees -->
    <template v-else-if="iconName === 'users'">
      <circle cx="6" cy="5.5" r="2" />
      <path d="M2.5 12.5c.4-2 1.8-3 3.5-3s3.1 1 3.5 3" />
      <circle cx="11" cy="6" r="1.6" />
      <path d="M10 9.4c1.2.2 2.2 1 2.7 2.6" />
    </template>
    <!-- org -->
    <template v-else-if="iconName === 'org'">
      <path d="M3 13.25V4.5h4.25v8.75" />
      <path d="M7.25 7.25H13v6" />
      <path d="M5 6.5h.01M5 8.75h.01M5 11h.01" />
      <path d="M9.5 9.5h.01M11.5 9.5h.01M9.5 11.5h.01M11.5 11.5h.01" />
    </template>
    <!-- role / shield -->
    <template v-else-if="iconName === 'role'">
      <path d="M8 2.75 12.5 4.5v3.4c0 2.8-1.8 4.7-4.5 5.6-2.7-.9-4.5-2.8-4.5-5.6V4.5L8 2.75Z" />
      <path d="M6.25 8.1 7.5 9.35 9.9 6.85" />
    </template>
    <!-- session / monitor -->
    <template v-else-if="iconName === 'session'">
      <rect x="2.5" y="3.25" width="11" height="7.5" rx="1.2" />
      <path d="M6 13.25h4" />
      <path d="M8 10.75v2.5" />
    </template>
    <!-- audit / document -->
    <template v-else-if="iconName === 'audit'">
      <path d="M4.25 2.75h5.2L12.5 5.8V13.25H4.25V2.75Z" />
      <path d="M9.25 2.75V6h2.9" />
      <path d="M6 8.5h4" />
      <path d="M6 10.75h3" />
    </template>
    <!-- lock / security -->
    <template v-else-if="iconName === 'lock'">
      <rect x="3.5" y="7" width="9" height="6.5" rx="1.2" />
      <path d="M5.5 7V5.4a2.5 2.5 0 0 1 5 0V7" />
    </template>
    <!-- key / password -->
    <template v-else-if="iconName === 'key'">
      <circle cx="5.5" cy="8" r="2.5" />
      <path d="M7.7 8h5.8" />
      <path d="M11.2 8v2" />
      <path d="M13 8v1.4" />
    </template>
    <!-- network / transport -->
    <template v-else-if="iconName === 'network'">
      <circle cx="4" cy="4.5" r="1.5" />
      <circle cx="12" cy="4.5" r="1.5" />
      <circle cx="8" cy="11.5" r="1.5" />
      <path d="M5.3 5.3 6.8 10" />
      <path d="M10.7 5.3 9.2 10" />
    </template>
    <!-- mail -->
    <template v-else-if="iconName === 'mail'">
      <rect x="2.5" y="4" width="11" height="8" rx="1.2" />
      <path d="M3.2 5.1 8 8.4l4.8-3.3" />
    </template>
    <!-- app -->
    <template v-else-if="iconName === 'app'">
      <rect x="2.75" y="2.75" width="4.2" height="4.2" rx="0.9" />
      <rect x="9.05" y="2.75" width="4.2" height="4.2" rx="0.9" />
      <rect x="2.75" y="9.05" width="4.2" height="4.2" rx="0.9" />
      <rect x="9.05" y="9.05" width="4.2" height="4.2" rx="0.9" />
    </template>
    <!-- ai -->
    <template v-else-if="iconName === 'ai'">
      <path d="M8 2.5 9.2 5.8 12.5 7 9.2 8.2 8 11.5 6.8 8.2 3.5 7l3.3-1.2L8 2.5Z" />
      <path d="M12.2 10.2 12.8 11.6 14.2 12.2 12.8 12.8 12.2 14.2 11.6 12.8 10.2 12.2l1.4-.6.6-1.4Z" />
    </template>
    <!-- settings -->
    <template v-else-if="iconName === 'settings'">
      <circle cx="8" cy="8" r="2.2" />
      <path d="M8 2.6v1.5M8 11.9v1.5M2.6 8h1.5M11.9 8h1.5M4.1 4.1l1.1 1.1M10.8 10.8l1.1 1.1M11.9 4.1l-1.1 1.1M5.2 10.8l-1.1 1.1" />
    </template>
    <!-- grid / generic -->
    <template v-else>
      <rect x="3" y="3" width="4" height="4" rx="0.8" />
      <rect x="9" y="3" width="4" height="4" rx="0.8" />
      <rect x="3" y="9" width="4" height="4" rx="0.8" />
      <rect x="9" y="9" width="4" height="4" rx="0.8" />
    </template>
  </svg>
</template>
