<script setup>
import { computed, reactive, watch } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';
import {
  BRICK_CONSOLE_DENSITY_NAMES,
  BRICK_CONSOLE_FONT_SIZE_NAMES,
  BRICK_CONSOLE_LOCALE_NAMES,
  BRICK_CONSOLE_THEME_PREFERENCE_NAMES,
  createBrickConsoleThemePresets,
  normalizeBrickConsoleAppearance,
  resolveBrickConsoleAppearanceTheme,
} from '../theme.js';

const props = defineProps({
  visible: { type: Boolean, default: false },
  theme: { type: String, default: 'blue' },
  density: { type: String, default: 'comfortable' },
  fontSize: { type: String, default: 'normal' },
  fullscreenAutoEnter: { type: Boolean, default: false },
  locale: { type: String, default: 'zh-CN' }
});

const emit = defineEmits([
  'close',
  'update:theme',
  'update:density',
  'update:fontSize',
  'update:fullscreenAutoEnter',
  'update:locale'
]);
const { t } = useBrickConsoleI18n();
const themePresets = createBrickConsoleThemePresets();

// Swatch tones stay aligned with theme-presets brand accents (not decorative demo colors).
const themeOptions = [
  { value: 'system', tone: 'linear-gradient(135deg, #2563eb 0 50%, #0f172a 50% 100%)' },
  { value: 'blue', tone: '#2563eb' },
  { value: 'orange', tone: '#c65310' },
  { value: 'guard', tone: '#143f8f' },
  { value: 'green', tone: '#12805c' },
  { value: 'night', tone: '#0f172a' }
].filter((theme) => BRICK_CONSOLE_THEME_PREFERENCE_NAMES.includes(theme.value));

const fontSizeOptions = computed(() => [
  { value: 'normal', label: t('core.ui.appearance.font.normal') },
  { value: 'large', label: t('core.ui.appearance.font.large') },
  { value: 'xlarge', label: t('core.ui.appearance.font.xlarge') }
].filter((fontSize) => BRICK_CONSOLE_FONT_SIZE_NAMES.includes(fontSize.value)));

const densityOptions = computed(() => [
  { value: 'comfortable', label: t('core.ui.appearance.density.comfortable') },
  { value: 'compact', label: t('core.ui.appearance.density.compact') }
].filter((density) => BRICK_CONSOLE_DENSITY_NAMES.includes(density.value)));

const fullscreenOptions = computed(() => [
  { value: false, label: t('core.ui.appearance.fullscreen.off') },
  { value: true, label: t('core.ui.appearance.fullscreen.on') }
]);

const localeOptions = computed(() => [
  { value: 'zh-CN', label: t('core.ui.appearance.locale.zh-CN') },
  { value: 'en-US', label: t('core.ui.appearance.locale.en-US') }
].filter((locale) => BRICK_CONSOLE_LOCALE_NAMES.includes(locale.value)));

const draft = reactive({
  theme: 'blue',
  density: 'comfortable',
  fontSize: 'normal',
  fullscreenAutoEnter: false,
  locale: 'zh-CN'
});
/** Snapshot at dialog open so Cancel can restore live-preview changes. */
const openSnapshot = reactive({
  theme: 'blue',
  density: 'comfortable',
  fontSize: 'normal',
  fullscreenAutoEnter: false,
  locale: 'zh-CN',
  captured: false,
});
const resolvedDraftTheme = computed(() => resolveBrickConsoleAppearanceTheme(draft));
const statusMessage = computed(() => {
  if (!props.visible) {
    return '';
  }
  return t('core.ui.appearance.livePreviewHint', {
    theme: themeDisplayLabel(draft.theme),
    density: t(`core.ui.appearance.density.${draft.density}`),
    font: t(`core.ui.appearance.font.${draft.fontSize}`),
  });
});

watch(
  () => [props.visible, props.theme, props.density, props.fontSize, props.fullscreenAutoEnter, props.locale],
  ([visible]) => {
    const normalized = normalizeBrickConsoleAppearance(props);
    Object.assign(draft, normalized);
    if (visible && !openSnapshot.captured) {
      Object.assign(openSnapshot, { ...normalized, captured: true });
    }
    if (!visible) {
      openSnapshot.captured = false;
    }
  },
  { immediate: true },
);

function emitLivePreview() {
  // Live preview while dialog is open (production UX: see density/font/theme immediately).
  emit('update:theme', draft.theme);
  emit('update:density', draft.density);
  emit('update:fontSize', draft.fontSize);
  emit('update:fullscreenAutoEnter', draft.fullscreenAutoEnter);
  emit('update:locale', draft.locale);
}

function selectTheme(theme) {
  draft.theme = theme;
  emitLivePreview();
}

function selectFontSize(fontSize) {
  draft.fontSize = fontSize;
  emitLivePreview();
}

function selectDensity(density) {
  draft.density = density;
  emitLivePreview();
}

function selectFullscreenAutoEnter(value) {
  draft.fullscreenAutoEnter = value;
  emitLivePreview();
}

function selectLocale(locale) {
  draft.locale = locale;
  emitLivePreview();
}

function resetDraft() {
  Object.assign(draft, normalizeBrickConsoleAppearance());
  emitLivePreview();
}

function restoreSnapshot() {
  if (!openSnapshot.captured) {
    return;
  }
  emit('update:theme', openSnapshot.theme);
  emit('update:density', openSnapshot.density);
  emit('update:fontSize', openSnapshot.fontSize);
  emit('update:fullscreenAutoEnter', openSnapshot.fullscreenAutoEnter);
  emit('update:locale', openSnapshot.locale);
}

function cancelDraft() {
  restoreSnapshot();
  emit('close');
}

function applyDraft() {
  emitLivePreview();
  openSnapshot.captured = false;
  emit('close');
}

function themePreset(theme) {
  return themePresets[resolveBrickConsoleAppearanceTheme({ theme })] ?? themePresets.blue;
}

function themeModeKey(theme) {
  const mode = themePreset(theme).mode;
  if (mode === 'brand-sidebar') {
    return 'brandSidebar';
  }
  return mode;
}

function themeModeLabel(theme) {
  if (theme === 'system') {
    return themePreset(theme).mode === 'dark'
      ? t('core.ui.appearance.theme.systemNight')
      : t('core.ui.appearance.theme.systemDay');
  }
  return t(`core.ui.appearance.theme.mode.${themeModeKey(theme)}`);
}

function themeCardModeLabel(theme) {
  if (theme === 'system') {
    return themePreset(theme).mode === 'dark'
      ? t('core.ui.appearance.theme.currentNight')
      : t('core.ui.appearance.theme.currentDay');
  }
  return themeModeLabel(theme);
}

function themeDisplayLabel(theme) {
  if (theme === 'system') {
    return t('core.ui.appearance.theme.system');
  }
  return t(`core.ui.theme.${theme}.label`);
}

function themeDescription(theme) {
  if (theme === 'system') {
    return t('core.ui.appearance.theme.systemDescription', {
      theme: themeDisplayLabel(resolvedDraftTheme.value),
    });
  }
  return t(`core.ui.theme.${theme}.description`);
}
</script>

<template>
  <div
    v-if="visible"
    :class="[
      'brick-appearance-settings-dialog',
      `theme-${resolvedDraftTheme}`,
      `font-${draft.fontSize}`,
      `density-${draft.density}`,
    ]"
    role="dialog"
    aria-modal="true"
    aria-labelledby="brick-appearance-settings-title"
    data-testid="brick-appearance-settings-dialog"
    @keydown.esc="cancelDraft"
  >
    <button
      class="brick-appearance-settings-dialog__backdrop"
      type="button"
      :aria-label="t('core.ui.appearance.closeAria')"
      @click="cancelDraft"
    />
    <section class="brick-appearance-settings-dialog__panel">
      <header class="brick-appearance-settings-dialog__header">
        <div class="brick-appearance-settings-dialog__header-copy">
          <h2 id="brick-appearance-settings-title">{{ t('core.ui.appearance.title') }}</h2>
          <p class="brick-appearance-settings-dialog__header-desc">
            {{ t('core.ui.appearance.description') }}
          </p>
          <p class="brick-appearance-settings-dialog__live-hint" aria-live="polite" data-testid="appearance-live-hint">
            {{ statusMessage }}
          </p>
        </div>
        <button
          class="brick-appearance-settings-dialog__close"
          type="button"
          :aria-label="t('core.ui.appearance.closeAria')"
          @click="cancelDraft"
        >
          ×
        </button>
      </header>

      <div class="brick-appearance-settings-dialog__body">
        <section class="brick-appearance-settings-dialog__section" :aria-label="t('core.ui.appearance.sectionTheme')">
          <div class="brick-appearance-settings-dialog__section-head">
            <h3 class="brick-appearance-settings-dialog__section-title">{{ t('core.ui.appearance.sectionTheme') }}</h3>
            <p class="brick-appearance-settings-dialog__section-hint">
              {{ themeModeLabel(draft.theme) }} · {{ themeDescription(draft.theme) }}
            </p>
          </div>
          <div class="brick-appearance-settings-dialog__theme-list" role="listbox" :aria-label="t('core.ui.appearance.sectionTheme')">
            <button
              v-for="themeOption in themeOptions"
              :key="themeOption.value"
              type="button"
              role="option"
              :data-theme-value="themeOption.value"
              :aria-selected="draft.theme === themeOption.value ? 'true' : 'false'"
              :class="[
                'brick-appearance-settings-dialog__theme-option',
                { active: draft.theme === themeOption.value },
              ]"
              @click="selectTheme(themeOption.value)"
            >
              <span
                class="brick-appearance-settings-dialog__theme-swatch"
                :style="{ background: themeOption.tone }"
                aria-hidden="true"
              />
              <span class="brick-appearance-settings-dialog__theme-meta">
                <strong>{{ themeDisplayLabel(themeOption.value) }}</strong>
                <span>{{ themeCardModeLabel(themeOption.value) }}</span>
              </span>
              <span
                class="brick-appearance-settings-dialog__theme-check"
                aria-hidden="true"
              />
            </button>
          </div>
        </section>

        <section class="brick-appearance-settings-dialog__section" :aria-label="t('core.ui.appearance.sectionDisplay')">
          <div class="brick-appearance-settings-dialog__section-head">
            <h3 class="brick-appearance-settings-dialog__section-title">{{ t('core.ui.appearance.sectionDisplay') }}</h3>
          </div>
          <div class="brick-appearance-settings-dialog__fields" :aria-label="t('core.ui.appearance.fieldsAria')">
            <div class="brick-appearance-settings-dialog__field">
              <span class="brick-appearance-settings-dialog__field-label" id="brick-appearance-font-size-label">
                {{ t('core.ui.appearance.fontSize') }}
              </span>
              <div
                class="brick-appearance-settings-dialog__segmented"
                role="group"
                aria-labelledby="brick-appearance-font-size-label"
              >
                <button
                  v-for="fontSizeOption in fontSizeOptions"
                  :key="fontSizeOption.value"
                  type="button"
                  :aria-pressed="draft.fontSize === fontSizeOption.value ? 'true' : 'false'"
                  :data-font-size-value="fontSizeOption.value"
                  :class="{ active: draft.fontSize === fontSizeOption.value }"
                  @click="selectFontSize(fontSizeOption.value)"
                >
                  {{ fontSizeOption.label }}
                </button>
              </div>
            </div>
            <div class="brick-appearance-settings-dialog__field">
              <span class="brick-appearance-settings-dialog__field-label" id="brick-appearance-density-label">
                {{ t('core.ui.appearance.density') }}
              </span>
              <div
                class="brick-appearance-settings-dialog__segmented"
                role="group"
                aria-labelledby="brick-appearance-density-label"
              >
                <button
                  v-for="densityOption in densityOptions"
                  :key="densityOption.value"
                  type="button"
                  :aria-pressed="draft.density === densityOption.value ? 'true' : 'false'"
                  :data-density-value="densityOption.value"
                  :class="{ active: draft.density === densityOption.value }"
                  @click="selectDensity(densityOption.value)"
                >
                  {{ densityOption.label }}
                </button>
              </div>
            </div>
            <div class="brick-appearance-settings-dialog__field">
              <span class="brick-appearance-settings-dialog__field-label" id="brick-appearance-fullscreen-label">
                {{ t('core.ui.appearance.fullscreen') }}
              </span>
              <div
                class="brick-appearance-settings-dialog__segmented"
                role="group"
                aria-labelledby="brick-appearance-fullscreen-label"
              >
                <button
                  v-for="fullscreenOption in fullscreenOptions"
                  :key="String(fullscreenOption.value)"
                  type="button"
                  :aria-pressed="draft.fullscreenAutoEnter === fullscreenOption.value ? 'true' : 'false'"
                  :data-fullscreen-value="String(fullscreenOption.value)"
                  :class="{ active: draft.fullscreenAutoEnter === fullscreenOption.value }"
                  @click="selectFullscreenAutoEnter(fullscreenOption.value)"
                >
                  {{ fullscreenOption.label }}
                </button>
              </div>
            </div>
            <div class="brick-appearance-settings-dialog__field">
              <span class="brick-appearance-settings-dialog__field-label" id="brick-appearance-locale-label">
                {{ t('core.ui.appearance.language') }}
              </span>
              <div
                class="brick-appearance-settings-dialog__segmented"
                role="group"
                aria-labelledby="brick-appearance-locale-label"
              >
                <button
                  v-for="localeOption in localeOptions"
                  :key="localeOption.value"
                  type="button"
                  :aria-pressed="draft.locale === localeOption.value ? 'true' : 'false'"
                  :data-locale-value="localeOption.value"
                  :class="{ active: draft.locale === localeOption.value }"
                  @click="selectLocale(localeOption.value)"
                >
                  {{ localeOption.label }}
                </button>
              </div>
            </div>
            <p class="brick-appearance-settings-dialog__field-note">
              {{ t('core.ui.appearance.fullscreenNote') }}
            </p>
          </div>
        </section>
      </div>

      <footer class="brick-appearance-settings-dialog__footer">
        <button type="button" class="brick-appearance-settings-dialog__footer-button ghost" @click="resetDraft">
          {{ t('core.ui.appearance.reset') }}
        </button>
        <div class="brick-appearance-settings-dialog__footer-actions">
          <button type="button" class="brick-appearance-settings-dialog__footer-button" data-testid="appearance-cancel" @click="cancelDraft">
            {{ t('core.ui.appearance.cancel') }}
          </button>
          <button type="button" class="brick-appearance-settings-dialog__footer-button primary" data-testid="appearance-apply" @click="applyDraft">
            {{ t('core.ui.appearance.confirm') }}
          </button>
        </div>
      </footer>
    </section>
  </div>
</template>
