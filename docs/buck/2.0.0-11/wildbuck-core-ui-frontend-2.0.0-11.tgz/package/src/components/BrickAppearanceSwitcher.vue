<script setup>
import { useBrickConsoleI18n } from '../i18n.js';
import {
  BRICK_CONSOLE_DENSITY_NAMES,
  BRICK_CONSOLE_FONT_SIZE_NAMES,
  BRICK_CONSOLE_LOCALE_NAMES,
  BRICK_CONSOLE_THEME_PREFERENCE_NAMES,
} from '../theme.js';

defineProps({
  theme: { type: String, default: 'blue' },
  density: { type: String, default: 'comfortable' },
  fontSize: { type: String, default: 'normal' },
  fullscreenAutoEnter: { type: Boolean, default: false },
  locale: { type: String, default: 'zh-CN' }
});

const emit = defineEmits([
  'update:theme',
  'update:density',
  'update:fontSize',
  'update:fullscreenAutoEnter',
  'update:locale'
]);
const { t } = useBrickConsoleI18n();

function themeOptionLabel(name) {
  if (name === 'system') {
    return t('core.ui.appearance.theme.system');
  }
  return t(`core.ui.theme.${name}.labelFull`);
}

function fontSizeLabel(name) {
  if (name === 'normal') {
    return t('core.ui.appearance.font.normal');
  }
  if (name === 'large') {
    return t('core.ui.appearance.font.largeFull');
  }
  if (name === 'xlarge') {
    return t('core.ui.appearance.font.xlargeFull');
  }
  return name;
}

function densityLabel(name) {
  return name === 'compact'
    ? t('core.ui.appearance.density.compact')
    : t('core.ui.appearance.density.comfortableFull');
}
</script>

<template>
  <form class="brick-appearance-switcher" :aria-label="t('core.ui.appearance.switcherAria')">
    <label class="brick-appearance-switcher__field">
      <span>{{ t('core.ui.appearance.sectionTheme') }}</span>
      <select :value="theme" @change="emit('update:theme', $event.target.value)">
        <option
          v-for="name in BRICK_CONSOLE_THEME_PREFERENCE_NAMES"
          :key="name"
          :value="name"
        >
          {{ themeOptionLabel(name) }}
        </option>
      </select>
    </label>

    <label class="brick-appearance-switcher__field">
      <span>{{ t('core.ui.appearance.density') }}</span>
      <select :value="density" @change="emit('update:density', $event.target.value)">
        <option
          v-for="name in BRICK_CONSOLE_DENSITY_NAMES"
          :key="name"
          :value="name"
        >
          {{ densityLabel(name) }}
        </option>
      </select>
    </label>

    <label class="brick-appearance-switcher__field">
      <span>{{ t('core.ui.appearance.fontSize') }}</span>
      <select :value="fontSize" @change="emit('update:fontSize', $event.target.value)">
        <option
          v-for="name in BRICK_CONSOLE_FONT_SIZE_NAMES"
          :key="name"
          :value="name"
        >
          {{ fontSizeLabel(name) }}
        </option>
      </select>
    </label>

    <label class="brick-appearance-switcher__field">
      <span>{{ t('core.ui.appearance.fullscreen') }}</span>
      <select
        :value="fullscreenAutoEnter ? 'true' : 'false'"
        @change="emit('update:fullscreenAutoEnter', $event.target.value === 'true')"
      >
        <option value="false">{{ t('core.ui.appearance.fullscreen.offFull') }}</option>
        <option value="true">{{ t('core.ui.appearance.fullscreen.onFull') }}</option>
      </select>
    </label>

    <label class="brick-appearance-switcher__field">
      <span>{{ t('core.ui.appearance.language') }}</span>
      <select :value="locale" @change="emit('update:locale', $event.target.value)">
        <option
          v-for="name in BRICK_CONSOLE_LOCALE_NAMES"
          :key="name"
          :value="name"
        >
          {{ t(`core.ui.appearance.locale.${name}`) }}
        </option>
      </select>
    </label>
  </form>
</template>
