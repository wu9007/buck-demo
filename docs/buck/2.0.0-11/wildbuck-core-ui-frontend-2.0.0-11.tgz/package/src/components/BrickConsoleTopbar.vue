<script setup>
import { computed } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';
import {
  normalizeBreadcrumbs,
  resolveFullscreenAction,
  shouldShowFullscreenButton,
  shouldShowRefreshButton,
  shouldUseUserMenuAppearanceEntry,
} from '../topbar.js';
import BrickUserMenu from './BrickUserMenu.vue';

const props = defineProps({
  principalName: { type: String, default: '' },
  principalSubtitle: { type: String, default: '' },
  principalUsername: { type: String, default: '' },
  principalAvatarUrl: { type: String, default: '' },
  theme: { type: String, default: 'blue' },
  themePreference: { type: String, default: '' },
  density: { type: String, default: 'comfortable' },
  fontSize: { type: String, default: 'normal' },
  fullscreenAutoEnter: { type: Boolean, default: false },
  locale: { type: String, default: 'zh-CN' },
  showAppearanceSettings: { type: Boolean, default: true },
  showChangePassword: { type: Boolean, default: true },
  changePasswordSubmit: { type: Function, default: null },
  appearanceEntry: { type: String, default: 'user-menu' },
  canInstallApp: { type: Boolean, default: false },
  title: { type: String, default: '' },
  subtitle: { type: String, default: '' },
  breadcrumbs: { type: Array, default: () => [] },
  refreshEnabled: { type: Boolean, default: false },
  fullscreenEnabled: { type: Boolean, default: false },
  fullscreenSupported: { type: Boolean, default: false },
  fullscreenActive: { type: Boolean, default: false }
});

const emit = defineEmits([
  'logout',
  'install-app',
  'change-password-success',
  'refresh',
  'update:theme',
  'update:density',
  'update:fontSize',
  'update:fullscreenAutoEnter',
  'update:locale',
  'enter-fullscreen',
  'exit-fullscreen'
]);

const { t } = useBrickConsoleI18n();

const normalizedBreadcrumbs = computed(() => normalizeBreadcrumbs(props.breadcrumbs));
const showRefresh = computed(() => shouldShowRefreshButton({ refreshEnabled: props.refreshEnabled }));
const showFullscreen = computed(() => shouldShowFullscreenButton({
  fullscreenEnabled: props.fullscreenEnabled,
  fullscreenSupported: props.fullscreenSupported,
}));
const fullscreenAction = computed(() => resolveFullscreenAction({
  fullscreenEnabled: props.fullscreenEnabled,
  fullscreenSupported: props.fullscreenSupported,
  fullscreenActive: props.fullscreenActive,
}));
const useUserMenu = computed(() => shouldUseUserMenuAppearanceEntry(props.appearanceEntry));

function onFullscreenClick() {
  if (fullscreenAction.value === 'exit') {
    emit('exit-fullscreen');
    return;
  }
  emit('enter-fullscreen');
}
</script>

<template>
  <header
    class="brick-console-topbar shell-topbar"
    :data-appearance-entry="appearanceEntry"
    :aria-label="t('core.ui.topbar.aria')"
  >
    <div class="shell-topbar__surface">
      <div class="shell-topbar__primary">
        <slot
          name="primary"
          :title="title"
          :subtitle="subtitle"
          :breadcrumbs="props.breadcrumbs"
        >
          <div v-if="normalizedBreadcrumbs.length > 0 || title || subtitle || $slots.title" class="shell-topbar__primary-copy">
            <nav
              v-if="normalizedBreadcrumbs.length > 0"
              class="shell-topbar__breadcrumbs"
              :aria-label="t('core.ui.topbar.breadcrumbsAria')"
            >
              <template v-for="(item, index) in normalizedBreadcrumbs" :key="`${item.label}-${index}`">
                <span v-if="index > 0" class="shell-topbar__breadcrumb-separator" aria-hidden="true">/</span>
                <span class="shell-topbar__breadcrumb" :title="item.title">{{ item.label }}</span>
              </template>
            </nav>
            <div v-if="title || $slots.title" class="shell-topbar__title-row">
              <slot name="title" :title="title" :subtitle="subtitle" :breadcrumbs="props.breadcrumbs">
                <span v-if="title" class="shell-topbar__title">{{ title }}</span>
              </slot>
            </div>
            <span v-if="subtitle" class="shell-topbar__subtitle">{{ subtitle }}</span>
          </div>
        </slot>
      </div>

      <div class="shell-topbar__actions">
        <slot name="actions" />
        <button
          v-if="showRefresh"
          class="shell-icon-button"
          type="button"
          :title="t('core.ui.topbar.refresh')"
          :aria-label="t('core.ui.topbar.refresh')"
          data-guide-anchor="topbar-refresh"
          @click="emit('refresh')"
        >
          <svg class="shell-icon-button__glyph" viewBox="0 0 16 16" aria-hidden="true">
            <path d="M13.5 8a5.5 5.5 0 1 1-1.4-3.6" />
            <path d="M13.5 2.5v3.2h-3.2" />
          </svg>
        </button>
        <button
          v-if="showFullscreen && fullscreenAction === 'enter'"
          class="shell-icon-button"
          type="button"
          :title="t('core.ui.topbar.enterFullscreen')"
          :aria-label="t('core.ui.topbar.enterFullscreen')"
          data-guide-anchor="topbar-fullscreen"
          @click="onFullscreenClick"
        >
          <svg class="shell-icon-button__glyph" viewBox="0 0 16 16" aria-hidden="true">
            <path d="M3 6.5V3h3.5" />
            <path d="M13 6.5V3H9.5" />
            <path d="M3 9.5V13h3.5" />
            <path d="M13 9.5V13H9.5" />
          </svg>
        </button>
        <button
          v-else-if="showFullscreen"
          class="shell-icon-button"
          type="button"
          :title="t('core.ui.topbar.exitFullscreen')"
          :aria-label="t('core.ui.topbar.exitFullscreen')"
          data-guide-anchor="topbar-fullscreen"
          @click="onFullscreenClick"
        >
          <svg class="shell-icon-button__glyph" viewBox="0 0 16 16" aria-hidden="true">
            <path d="M6.5 3v3.5H3" />
            <path d="M9.5 3v3.5H13" />
            <path d="M6.5 13V9.5H3" />
            <path d="M9.5 13V9.5H13" />
          </svg>
        </button>
        <BrickUserMenu
          v-if="useUserMenu"
          :principal-name="principalName"
          :principal-subtitle="principalSubtitle"
          :principal-username="principalUsername"
          :principal-avatar-url="principalAvatarUrl"
          :theme="theme"
          :theme-preference="themePreference || theme"
          :density="density"
          :font-size="fontSize"
          :fullscreen-auto-enter="fullscreenAutoEnter"
          :locale="locale"
          :show-appearance-settings="showAppearanceSettings"
          :show-change-password="showChangePassword"
          :change-password-submit="changePasswordSubmit"
          :can-install-app="canInstallApp"
          @logout="emit('logout')"
          @install-app="emit('install-app')"
          @change-password-success="emit('change-password-success')"
          @update:theme="(value) => emit('update:theme', value)"
          @update:density="(value) => emit('update:density', value)"
          @update:font-size="(value) => emit('update:fontSize', value)"
          @update:fullscreen-auto-enter="(value) => emit('update:fullscreenAutoEnter', value)"
          @update:locale="(value) => emit('update:locale', value)"
        />
        <button
          v-else
          class="shell-icon-button"
          type="button"
          :title="t('core.ui.userMenu.logout')"
          :aria-label="t('core.ui.userMenu.logout')"
          data-guide-anchor="topbar-logout"
          @click="emit('logout')"
        >
          <svg class="shell-icon-button__glyph" viewBox="0 0 16 16" aria-hidden="true">
            <path d="M7 3H4.5A1.5 1.5 0 0 0 3 4.5v7A1.5 1.5 0 0 0 4.5 13H7" />
            <path d="M10.5 10.5 13 8l-2.5-2.5" />
            <path d="M6.5 8H13" />
          </svg>
        </button>
        <slot name="trailing-actions" />
      </div>
    </div>
  </header>
</template>
