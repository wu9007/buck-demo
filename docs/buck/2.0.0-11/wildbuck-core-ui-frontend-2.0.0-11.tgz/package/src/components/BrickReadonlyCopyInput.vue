<script setup>
import { computed, ref } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';

const props = defineProps({
  modelValue: { type: [String, Number], default: undefined },
  value: { type: [String, Number], default: undefined },
  copyText: { type: [String, Number], default: undefined },
  copyable: { type: Boolean, default: true },
  masked: { type: Boolean, default: false },
  maskText: { type: String, default: '' },
  label: { type: String, default: '' },
  description: { type: String, default: '' },
  size: { type: String, default: 'default' },
  disabled: { type: Boolean, default: false },
  placeholder: { type: String, default: '' },
  copyButtonText: { type: String, default: '' },
  copiedText: { type: String, default: '' },
  copyFailedText: { type: String, default: '' }
});

const emit = defineEmits(['copied', 'copy-failed']);
const feedback = ref('');
const { t } = useBrickConsoleI18n();

const rawValue = computed(() => props.modelValue ?? props.value ?? '');
const resolvedMaskText = computed(() => props.maskText || t('core.ui.copy.maskedOnce'));
const resolvedCopyButtonText = computed(() => props.copyButtonText || t('core.ui.copy.button'));
const resolvedCopiedText = computed(() => props.copiedText || t('core.ui.copy.copied'));
const resolvedCopyFailedText = computed(() => props.copyFailedText || t('core.ui.copy.failed'));
const fieldAria = computed(() => props.label || t('core.ui.copy.fieldAria'));
const displayValue = computed(() => (props.masked ? resolvedMaskText.value : String(rawValue.value)));
const resolvedCopyText = computed(() => {
  if (props.copyText !== undefined && props.copyText !== null) {
    return String(props.copyText);
  }
  return props.masked ? '' : String(rawValue.value);
});
const canCopy = computed(() => props.copyable && !props.disabled && resolvedCopyText.value.length > 0);

async function handleCopy() {
  if (!canCopy.value) {
    return;
  }

  try {
    await navigator.clipboard.writeText(resolvedCopyText.value);
    feedback.value = resolvedCopiedText.value;
    emit('copied', resolvedCopyText.value);
  } catch (error) {
    feedback.value = resolvedCopyFailedText.value;
    emit('copy-failed', error);
  }
}
</script>

<template>
  <div
    :class="[
      'brick-readonly-copy-input',
      `brick-readonly-copy-input--${size}`,
      { 'is-disabled': disabled, 'is-masked': masked }
    ]"
  >
    <label v-if="label" class="brick-readonly-copy-input__label">
      {{ label }}
    </label>
    <p v-if="description" class="brick-readonly-copy-input__description">
      {{ description }}
    </p>
    <div class="brick-readonly-copy-input__control">
      <input
        class="brick-readonly-copy-input__field"
        :value="displayValue"
        :disabled="disabled"
        :placeholder="placeholder"
        :aria-label="fieldAria"
        readonly
        autocomplete="off"
      />
      <button
        v-if="copyable"
        class="brick-readonly-copy-input__copy"
        type="button"
        :disabled="!canCopy"
        @click="handleCopy"
      >
        {{ resolvedCopyButtonText }}
      </button>
    </div>
    <p v-if="feedback" class="brick-readonly-copy-input__feedback" aria-live="polite">
      {{ feedback }}
    </p>
  </div>
</template>
