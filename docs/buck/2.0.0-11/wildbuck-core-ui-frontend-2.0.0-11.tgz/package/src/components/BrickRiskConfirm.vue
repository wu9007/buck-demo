<script setup>
import { computed, ref } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';

const props = defineProps({
  modelValue: { type: Boolean, default: undefined },
  title: { type: String, default: '' },
  description: { type: String, default: '' },
  impact: { type: [String, Array], default: '' },
  confirmText: { type: String, default: '' },
  cancelText: { type: String, default: '' },
  loading: { type: Boolean, default: false },
  disabled: { type: Boolean, default: false },
  dialogWidth: { type: String, default: 'min(420px, calc(100vw - 32px))' },
});

const emit = defineEmits(['update:modelValue', 'confirm', 'cancel']);
const { t } = useBrickConsoleI18n();
const resolvedTitle = computed(() => props.title || t('core.ui.riskConfirm.defaultTitle'));
const resolvedConfirmText = computed(() => props.confirmText || t('core.ui.riskConfirm.confirm'));
const resolvedCancelText = computed(() => props.cancelText || t('core.ui.riskConfirm.cancel'));

const internalVisible = ref(false);
const isControlled = computed(() => props.modelValue !== undefined);
const visible = computed({
  get() {
    return isControlled.value ? props.modelValue : internalVisible.value;
  },
  set(value) {
    if (!isControlled.value) {
      internalVisible.value = value;
    }
    emit('update:modelValue', value);
  },
});

const impactItems = computed(() => {
  if (Array.isArray(props.impact)) {
    return props.impact.filter(Boolean);
  }
  return props.impact ? [props.impact] : [];
});

function openConfirm() {
  if (props.disabled || props.loading) {
    return;
  }
  visible.value = true;
}

function closeConfirm() {
  if (props.loading) {
    return;
  }
  visible.value = false;
  emit('cancel');
}

function handleConfirm() {
  if (props.disabled || props.loading) {
    return;
  }
  emit('confirm');
  visible.value = false;
}
</script>

<template>
  <span class="brick-risk-confirm__trigger" @click="openConfirm">
    <slot name="trigger" :open="openConfirm" :disabled="disabled" :loading="loading" />
  </span>

  <el-dialog
    v-model="visible"
    class="brick-risk-confirm"
    :title="resolvedTitle"
    :width="dialogWidth"
    :close-on-click-modal="!loading"
    :close-on-press-escape="!loading"
    :show-close="!loading"
    append-to-body
  >
    <section class="brick-risk-confirm__body" aria-live="polite">
      <slot name="body">
        <p v-if="description" class="brick-risk-confirm__description">{{ description }}</p>
      </slot>

      <div v-if="$slots.impact || impactItems.length > 0" class="brick-risk-confirm__impact">
        <slot name="impact">
          <p class="brick-risk-confirm__impact-title">{{ t('core.ui.riskConfirm.impactTitle') }}</p>
          <ul>
            <li v-for="item in impactItems" :key="item">{{ item }}</li>
          </ul>
        </slot>
      </div>
    </section>

    <template #footer>
      <div class="brick-risk-confirm__footer">
        <slot
          name="footer"
          :confirm="handleConfirm"
          :cancel="closeConfirm"
          :loading="loading"
          :disabled="disabled"
        >
          <el-button :disabled="loading" @click="closeConfirm">
            {{ resolvedCancelText }}
          </el-button>
          <el-button
            type="danger"
            :loading="loading"
            :disabled="disabled"
            @click="handleConfirm"
          >
            {{ resolvedConfirmText }}
          </el-button>
        </slot>
      </div>
    </template>
  </el-dialog>
</template>

<style scoped>
.brick-risk-confirm__trigger {
  display: inline-flex;
}

.brick-risk-confirm__body {
  display: grid;
  gap: var(--console-space-4, 16px);
  color: var(--console-text, #334155);
}

.brick-risk-confirm__description {
  margin: 0;
  line-height: 1.7;
}

.brick-risk-confirm__impact {
  padding: var(--console-space-4, 16px);
  border: 1px solid color-mix(in srgb, var(--console-danger, #dc2626) 36%, var(--console-card-border, #dbe3ef));
  border-radius: var(--console-block-radius, 8px);
  /* 危险底：相对弹层主面足够可辨，teleport 到 body 仍依赖 :root token */
  background: color-mix(in srgb, var(--console-danger, #dc2626) 12%, var(--console-card-bg, #ffffff));
}

.brick-risk-confirm__impact-title {
  margin: 0 0 var(--console-space-2, 8px);
  color: var(--console-danger, #dc2626);
  font-size: 13px;
  font-weight: 800;
}

.brick-risk-confirm__impact ul {
  margin: 0;
  padding-inline-start: 18px;
}

.brick-risk-confirm__impact li {
  line-height: 1.7;
  color: var(--console-text, #334155);
}

.brick-risk-confirm__footer {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: var(--console-space-3, 12px);
}
</style>

<style>
/* Dialog surface follows console tokens when risk confirm is teleported to body. */
.brick-risk-confirm.el-dialog {
  --el-dialog-bg-color: var(--console-card-bg, #ffffff);
  --el-text-color-primary: var(--console-title, #0f172a);
  --el-text-color-regular: var(--console-text, #334155);
  background: var(--console-card-bg, #ffffff);
  color: var(--console-text, #334155);
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: var(--console-card-radius, 8px);
}

.brick-risk-confirm.el-dialog .el-dialog__header,
.brick-risk-confirm.el-dialog .el-dialog__body,
.brick-risk-confirm.el-dialog .el-dialog__footer {
  background: transparent;
  color: inherit;
}

.brick-risk-confirm.el-dialog .el-dialog__title {
  color: var(--console-title, #0f172a);
  font-weight: 700;
}
</style>
