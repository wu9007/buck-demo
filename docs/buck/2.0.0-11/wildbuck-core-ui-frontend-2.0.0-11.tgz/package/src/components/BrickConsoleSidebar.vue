<script setup>
import { computed, ref, watch } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';
import { resolveBrickConsoleNavIconName } from '../shell-icons.js';
import BrickConsoleNavIcon from './BrickConsoleNavIcon.vue';
import BrickConsoleSidebarCollapseToggle from './BrickConsoleSidebarCollapseToggle.vue';

const props = defineProps({
  brandTitle: { type: String, default: 'Brick' },
  brandSubtitle: { type: String, default: '' },
  brandMark: { type: String, default: 'B' },
  /** Public logo URL (e.g. login-brand public asset); preferred over text mark. */
  brandLogoUrl: { type: String, default: '' },
  navigationGroups: { type: Array, default: () => [] },
  activeRouteId: { type: String, default: '' },
  collapsed: { type: Boolean, default: false },
  collapsible: { type: Boolean, default: true },
  groupCollapsible: { type: Boolean, default: true },
  collapsedGroupKeys: { type: Array, default: undefined },
  defaultCollapsedGroupKeys: { type: Array, default: () => [] },
  searchable: { type: Boolean, default: false },
  searchKeyword: { type: String, default: '' },
  searchPlaceholder: { type: String, default: '' }
});

const emit = defineEmits(['navigate', 'update:collapsed', 'update:collapsedGroupKeys', 'update:searchKeyword']);
const { t } = useBrickConsoleI18n();
const resolvedSearchPlaceholder = computed(() => props.searchPlaceholder || t('core.ui.sidebar.searchPlaceholder'));

const localCollapsedGroupKeys = ref(defaultCollapsedKeys());
const knownGroupKeys = ref(new Set());
const localSearchKeyword = ref(props.searchKeyword);
/** Chrome autofill often ignores autocomplete=off until the field is focused. */
const searchAutofillLocked = ref(true);
const effectiveSearchKeyword = computed(() => normalizeSearchText(localSearchKeyword.value));
const filteredNavigationGroups = computed(() => {
  const keyword = effectiveSearchKeyword.value;
  if (!keyword) {
    return props.navigationGroups;
  }

  return props.navigationGroups
    .map((group) => {
      const routes = Array.isArray(group?.routes) ? group.routes : [];
      if (matchesGroupSearch(group, keyword)) {
        return { ...group, routes };
      }
      return {
        ...group,
        routes: routes.filter((route) => matchesRouteSearch(route, group, keyword))
      };
    })
    .filter((group) => Array.isArray(group.routes) && group.routes.length > 0);
});

watch(
  () => props.searchKeyword,
  (value) => {
    localSearchKeyword.value = value ?? '';
  },
);

watch(
  () => props.collapsedGroupKeys,
  (value) => {
    if (Array.isArray(value)) {
      localCollapsedGroupKeys.value = normalizeGroupKeys(value);
    }
  },
  { immediate: true },
);

watch(
  () => props.navigationGroups,
  () => {
    syncNavigationGroupDefaults();
    expandActiveRouteGroup(Array.isArray(props.collapsedGroupKeys));
  },
  { deep: true, immediate: true },
);

watch(
  () => props.activeRouteId,
  () => {
    // active route group stays expanded so navigation never hides the current page.
    expandActiveRouteGroup(true);
  },
  { immediate: true },
);

function routeTitle(route) {
  return String(route?.title ?? route?.id ?? '');
}

function routeMark(route) {
  return String(route?.abbr ?? route?.iconText ?? route?.shortTitle ?? route?.collapsedTitle ?? routeTitle(route).slice(0, 1)).slice(0, 2);
}

function routeIconComponent(route) {
  if (!route?.icon || typeof route.icon === 'string') {
    return null;
  }
  return route.icon;
}

function routeIconUrl(route) {
  return String(route && route.iconUrl ? route.iconUrl : '').trim();
}

function routeIconName(route) {
  return resolveBrickConsoleNavIconName(route);
}

function routeHasVisibleMark(route) {
  // Always reserve a mark/icon slot so expanded and collapsed layouts share the same left rail.
  return true;
}

function brandMarkText() {
  return String(props.brandMark || props.brandTitle.slice(0, 1) || 'B');
}

function brandLogoSrc() {
  return String(props.brandLogoUrl || '').trim();
}

function collapseLabel() {
  return props.collapsed ? t('core.ui.sidebar.expand') : t('core.ui.sidebar.collapse');
}

function toggleCollapsed() {
  emit('update:collapsed', !props.collapsed);
}

function groupKey(group) {
  return String(group?.key ?? group?.label ?? '');
}

function groupRoutesId(group) {
  return `shell-nav-group-routes-${groupKey(group).replace(/[^a-zA-Z0-9_-]/g, '-')}`;
}

function groupCollapseLabel(group) {
  const label = group?.label ?? t('core.ui.sidebar.groupFallback');
  return isGroupCollapsed(group)
    ? t('core.ui.sidebar.expandGroup', { label })
    : t('core.ui.sidebar.collapseGroup', { label });
}

function isGroupCollapsible(group) {
  return props.groupCollapsible && group?.collapsible !== false && Array.isArray(group?.routes) && group.routes.length > 0;
}

function isGroupCollapsed(group) {
  if (Boolean(effectiveSearchKeyword.value)) {
    return false;
  }
  return !props.collapsed && isGroupCollapsible(group) && localCollapsedGroupKeys.value.has(groupKey(group));
}

function updateSearchKeyword(event) {
  const value = event?.target?.value ?? '';
  localSearchKeyword.value = value;
  emit('update:searchKeyword', value);
}

function clearSearchKeyword() {
  localSearchKeyword.value = '';
  emit('update:searchKeyword', '');
}

function matchesGroupSearch(group, keyword) {
  return [
    group?.label,
    group?.key,
    group?.title,
    group?.searchText,
    group?.searchKeywords,
    group?.keywords
  ].some((value) => matchesSearchValue(value, keyword));
}

function matchesRouteSearch(route, group, keyword) {
  return [
    route?.title,
    route?.name,
    route?.id,
    route?.path,
    route?.group,
    route?.abbr,
    route?.iconText,
    route?.shortTitle,
    route?.collapsedTitle,
    route?.searchText,
    route?.searchKeywords,
    route?.keywords,
    route?.menu?.title,
    route?.menu?.label,
    route?.menu?.searchText,
    route?.menu?.searchKeywords,
    route?.menu?.keywords,
    group?.label
  ].some((value) => matchesSearchValue(value, keyword));
}

function matchesSearchValue(value, keyword) {
  if (Array.isArray(value)) {
    return value.some((item) => matchesSearchValue(item, keyword));
  }
  return normalizeSearchText(value).includes(keyword);
}

function normalizeSearchText(value) {
  return String(value ?? '').trim().toLocaleLowerCase('zh-CN');
}

function toggleGroupCollapsed(group) {
  if (!isGroupCollapsible(group)) {
    return;
  }
  const key = groupKey(group);
  const next = new Set(localCollapsedGroupKeys.value);
  if (next.has(key)) {
    next.delete(key);
  } else {
    next.add(key);
  }
  setCollapsedGroupKeys(next, true);
}

function syncNavigationGroupDefaults() {
  const currentKeys = new Set(props.navigationGroups.map((group) => groupKey(group)));
  const next = new Set([...localCollapsedGroupKeys.value].filter((key) => currentKeys.has(key)));
  if (!Array.isArray(props.collapsedGroupKeys)) {
    const defaultKeys = normalizeGroupKeys(props.defaultCollapsedGroupKeys);
    for (const group of props.navigationGroups) {
      const key = groupKey(group);
      if (!knownGroupKeys.value.has(key) && (defaultKeys.has(key) || group?.defaultCollapsed === true || group?.collapsed === true)) {
        next.add(key);
      }
    }
  }
  knownGroupKeys.value = currentKeys;
  setCollapsedGroupKeys(next, false);
}

function expandActiveRouteGroup(shouldEmit) {
  const activeGroup = props.navigationGroups.find((group) =>
    Array.isArray(group?.routes) && group.routes.some((route) => route?.id === props.activeRouteId),
  );
  if (!activeGroup) {
    return;
  }
  const key = groupKey(activeGroup);
  if (!localCollapsedGroupKeys.value.has(key)) {
    return;
  }
  const next = new Set(localCollapsedGroupKeys.value);
  next.delete(key);
  setCollapsedGroupKeys(next, shouldEmit);
}

function defaultCollapsedKeys() {
  const keys = normalizeGroupKeys(props.defaultCollapsedGroupKeys);
  for (const group of props.navigationGroups) {
    if (group?.defaultCollapsed === true || group?.collapsed === true) {
      keys.add(groupKey(group));
    }
  }
  return keys;
}

function normalizeGroupKeys(keys) {
  return new Set((keys ?? []).filter((key) => key !== null && key !== undefined).map((key) => String(key)));
}

function setCollapsedGroupKeys(keys, shouldEmit) {
  localCollapsedGroupKeys.value = normalizeGroupKeys([...keys]);
  if (shouldEmit) {
    emit('update:collapsedGroupKeys', [...localCollapsedGroupKeys.value]);
  }
}
</script>

<template>
  <aside class="brick-console-sidebar shell-sidebar" :class="{ 'is-collapsed': collapsed }">
    <div class="shell-brand">
      <span class="shell-brand-mark" :class="{ 'is-logo': Boolean(brandLogoSrc()) }" aria-hidden="true">
        <slot name="brand-mark" :collapsed="collapsed" :brand-title="brandTitle" :brand-logo-url="brandLogoSrc()">
          <img
            v-if="brandLogoSrc()"
            class="shell-brand-mark__logo"
            :src="brandLogoSrc()"
            alt=""
          />
          <template v-else>{{ brandMarkText() }}</template>
        </slot>
      </span>
      <span class="shell-brand-text">
        <strong>{{ brandTitle }}</strong>
        <small v-if="brandSubtitle">{{ brandSubtitle }}</small>
      </span>
    </div>

    <nav class="shell-nav" aria-label="Brick console navigation">
      <div v-if="searchable" class="shell-nav__search" :aria-hidden="collapsed ? 'true' : 'false'">
        <!--
          Menu filter is not a login field. Browsers still treat nearby password dialogs as
          “username + password” and dump the saved username (e.g. operator) into the first
          text/search input — wiping the nav. Harden name/autocomplete and unlock readonly only on focus.
        -->
        <input
          class="shell-nav__search-input"
          type="search"
          name="brick-console-menu-filter"
          :value="localSearchKeyword"
          :placeholder="resolvedSearchPlaceholder"
          :aria-label="t('core.ui.sidebar.searchAria')"
          autocomplete="off"
          autocorrect="off"
          autocapitalize="off"
          spellcheck="false"
          inputmode="search"
          data-form-type="other"
          data-lpignore="true"
          data-1p-ignore="true"
          data-bwignore="true"
          :readonly="searchAutofillLocked"
          :tabindex="collapsed ? -1 : 0"
          @focus="searchAutofillLocked = false"
          @input="updateSearchKeyword"
        />
        <button
          v-if="localSearchKeyword"
          class="shell-nav__search-clear"
          type="button"
          :aria-label="t('core.ui.sidebar.clearSearch')"
          :title="t('core.ui.sidebar.clearSearch')"
          :tabindex="collapsed ? -1 : 0"
          @click="clearSearchKeyword"
        >
          ×
        </button>
      </div>
      <div v-if="$slots['nav-before']" class="shell-nav__before">
        <slot name="nav-before" :collapsed="collapsed" />
      </div>

      <section
        v-for="group in filteredNavigationGroups"
        :key="group.key"
        class="shell-nav-group"
        :class="{ 'is-collapsed': isGroupCollapsed(group) }"
      >
        <div class="shell-nav-group__header">
          <button
            v-if="isGroupCollapsible(group)"
            class="shell-nav-group__toggle"
            type="button"
            :aria-expanded="String(!isGroupCollapsed(group))"
            :aria-controls="groupRoutesId(group)"
            :title="groupCollapseLabel(group)"
            :tabindex="collapsed ? -1 : 0"
            @click="toggleGroupCollapsed(group)"
          >
            <span class="shell-nav-group__title">{{ group.label }}</span>
            <span class="shell-nav-group__chevron" aria-hidden="true">
              <svg class="shell-nav-group__chevron-glyph" viewBox="0 0 16 16" focusable="false">
                <path d="M4.25 6 8 9.75 11.75 6" />
              </svg>
            </span>
          </button>
          <div v-else class="shell-nav-group__title">{{ group.label }}</div>
        </div>
        <div
          :id="groupRoutesId(group)"
          class="shell-nav-group__routes"
          v-show="!isGroupCollapsed(group)"
        >
          <button
            v-for="route in group.routes"
            :key="route.id"
            class="shell-nav-item"
            :class="{ 'is-active': route.id === activeRouteId, 'has-mark': routeHasVisibleMark(route) }"
            type="button"
            :data-route-id="route.id"
            :title="routeTitle(route)"
            :aria-label="routeTitle(route)"
            @click="emit('navigate', route)"
          >
            <span class="shell-nav-item__mark" aria-hidden="true">
              <!--
                Icon priority (product contract):
                1) menu-uploaded iconUrl from 菜单管理
                2) business component icon
                3) formal line-icon fallback (never replaces an uploaded image)
              -->
              <slot name="route-icon" :route="route" :collapsed="collapsed">
                <img
                  v-if="routeIconUrl(route)"
                  class="shell-nav-item__icon-image"
                  :src="routeIconUrl(route)"
                  :alt="routeTitle(route)"
                />
                <component
                  :is="routeIconComponent(route)"
                  v-else-if="routeIconComponent(route)"
                  class="shell-nav-item__icon"
                />
                <BrickConsoleNavIcon v-else :name="routeIconName(route)" />
              </slot>
            </span>
            <span class="shell-nav-item__label">{{ routeTitle(route) }}</span>
          </button>
        </div>
      </section>
      <p
        v-if="searchable && filteredNavigationGroups.length === 0"
        class="shell-nav__empty"
        :aria-hidden="collapsed ? 'true' : 'false'"
      >
        {{ t('core.ui.sidebar.noMatch') }}
      </p>
    </nav>

    <div class="shell-sidebar__extra">
      <slot name="extra" />
    </div>

    <div v-if="collapsible" class="shell-sidebar__footer">
      <slot
        name="collapse-toggle"
        :collapsed="collapsed"
        :label="collapseLabel()"
        :toggle="toggleCollapsed"
      >
        <BrickConsoleSidebarCollapseToggle
          :collapsed="collapsed"
          :label="collapseLabel()"
          :toggle="toggleCollapsed"
        />
      </slot>
    </div>
  </aside>
</template>
