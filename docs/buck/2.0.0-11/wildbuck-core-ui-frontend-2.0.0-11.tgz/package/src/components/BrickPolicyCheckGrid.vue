<script setup>
import { computed } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';

const props = defineProps({
  modelValue: { type: Array, required: true },
  label: { type: String, required: true },
  description: { type: String, default: '' },
  options: { type: Array, required: true },
  disabled: { type: Boolean, default: false },
  required: { type: Boolean, default: undefined },
});

const emit = defineEmits(['update:modelValue']);
const { t } = useBrickConsoleI18n();

// Prefer explicit prop; fallback keeps legacy Chinese/English required markers in labels.
const isRequired = computed(() => {
  if (typeof props.required === 'boolean') {
    return props.required;
  }
  return /必填|required/i.test(props.label);
});
const selectedLabel = computed(() => t('core.ui.policy.selectedCount', { count: props.modelValue.length }));

function updateValue(value) {
  emit('update:modelValue', Array.isArray(value) ? value.map(String) : []);
}
</script>

<template>
  <el-form-item
    class="brick-policy-form-item"
    :class="{ 'is-disabled': disabled }"
    :label="label"
    :required="isRequired"
  >
    <div class="brick-policy-form-control">
      <div class="brick-policy-form-control__top">
        <p v-if="description" class="brick-policy-field-description">{{ description }}</p>
        <strong class="brick-policy-field-value">{{ selectedLabel }}</strong>
      </div>
      <el-checkbox-group
        class="brick-policy-check-list"
        :model-value="modelValue"
        :disabled="disabled"
        @update:model-value="updateValue"
      >
        <el-checkbox
          v-for="option in options"
          :key="option.value"
          class="brick-policy-check-option"
          :value="option.value"
        >
          <span class="brick-policy-option-title">{{ option.label }}</span>
          <span v-if="option.description" class="brick-policy-option-description">{{ option.description }}</span>
        </el-checkbox>
      </el-checkbox-group>
    </div>
  </el-form-item>
</template>
