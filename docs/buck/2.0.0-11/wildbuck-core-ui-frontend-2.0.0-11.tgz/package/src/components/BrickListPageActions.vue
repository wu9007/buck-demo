<script setup>
/**
 * Canonical list-page header action slot (#442 / #443).
 * Order (LTR): extra tools → import → export → primary (create) rightmost.
 * Put this inside BrickPageHeader #actions. Do not place create/import/export in filter bars.
 *
 * Visual hierarchy (console themes):
 * - #primary create: solid `type="primary"`
 * - #export / #import / secondary tools: `type="primary" plain` (outline; readable label)
 * - Do not use bare `plain` alone for export — default plain can lose label contrast under tokens.
 */
defineProps({
  /** Accessible name for the action group. */
  ariaLabel: { type: String, default: '' },
});
</script>

<template>
  <div
    class="brick-list-page-actions"
    role="group"
    :aria-label="ariaLabel || undefined"
    data-brick-list-page-actions="true"
  >
    <div v-if="$slots.extra" class="brick-list-page-actions__extra">
      <slot name="extra" />
    </div>
    <div v-if="$slots.import" class="brick-list-page-actions__import">
      <slot name="import" />
    </div>
    <div v-if="$slots.export" class="brick-list-page-actions__export">
      <slot name="export" />
    </div>
    <div v-if="$slots.primary" class="brick-list-page-actions__primary">
      <slot name="primary" />
    </div>
    <!-- Escape hatch for pages mid-migration; prefer named slots. -->
    <div v-if="$slots.default" class="brick-list-page-actions__default">
      <slot />
    </div>
  </div>
</template>

<style scoped>
.brick-list-page-actions {
  display: inline-flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-end;
  gap: var(--console-space-2, 8px);
}

.brick-list-page-actions__extra,
.brick-list-page-actions__import,
.brick-list-page-actions__export,
.brick-list-page-actions__primary,
.brick-list-page-actions__default {
  display: inline-flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--console-space-2, 8px);
}

/* Primary create stays visually rightmost among named slots. */
.brick-list-page-actions__primary {
  order: 40;
}

.brick-list-page-actions__export {
  order: 30;
}

.brick-list-page-actions__import {
  order: 20;
}

.brick-list-page-actions__extra {
  order: 10;
}

.brick-list-page-actions__default {
  order: 50;
}

.brick-list-page-actions :deep(.el-button) {
  min-height: var(--console-control-height, 36px);
  border-radius: var(--console-field-radius, 6px);
  font-weight: 700;
}

@media (max-width: 760px) {
  .brick-list-page-actions {
    width: 100%;
    justify-content: flex-start;
  }
}
</style>
