<template>
  <!-- Shared row-action cluster for module list tables (replaces per-module IamTableActions copies). -->
  <div class="brick-table-actions iam-table-actions">
    <slot />
  </div>
</template>

<style scoped>
.brick-table-actions,
.iam-table-actions {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--console-space-2, 10px);
}

.brick-table-actions :deep(.el-button + .el-button),
.iam-table-actions :deep(.el-button + .el-button) {
  margin-left: 0;
}
</style>
