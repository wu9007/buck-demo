<script setup>
import { computed, ref, watch } from 'vue';
// Self-register EP widgets: hosts often on-demand-register Element Plus and omit
// input-number (validation/security-console main.js historically had Slider but not InputNumber).
// Without local import, <el-input-number> renders as an empty unknown element — only the unit text shows.
import { ElInputNumber } from 'element-plus/es/components/input-number/index.mjs';
import { ElSlider } from 'element-plus/es/components/slider/index.mjs';
import 'element-plus/es/components/input-number/style/css';
import 'element-plus/es/components/slider/style/css';

/**
 * Policy drawer numeric scale — single layout + interaction owner for Element Plus.
 *
 * Root causes of past "broken / unusable" sliders in modules:
 * 1) Pages styled raw el-slider with first/last mark transform hacks.
 * 2) Long description + input in one flex row hid the control as empty space.
 * 3) Marks layer can sit above the runway without pointer-events:none and block drag.
 * 4) Parent recomputing marks/max every tick while dragging can fight controlled updates.
 * 5) Host forgot to register ElInputNumber → blank control that cannot be operated.
 *
 * Use this as BrickSettingsScale. Do not re-skin el-slider in feature pages.
 */
const props = defineProps({
  modelValue: { type: Number, required: true },
  label: { type: String, required: true },
  description: { type: String, default: '' },
  /** Formatted display when showInput is false. */
  valueLabel: { type: String, default: '' },
  min: { type: Number, default: 0 },
  /** Slider track max (may use scaleMax). */
  max: { type: Number, default: 100 },
  /** Numeric input max; defaults to max. */
  inputMax: { type: Number, default: undefined },
  step: { type: Number, default: 1 },
  unit: { type: String, default: '' },
  impact: { type: String, default: '' },
  disabled: { type: Boolean, default: false },
  required: { type: Boolean, default: undefined },
  /** Show el-input-number for precise values (e.g. 1–2 min self-test). */
  showInput: { type: Boolean, default: false },
  /**
   * Marks: Array<{ value, label }> or Record<number|string, string>.
   * Prefer sparse marks for long ranges.
   */
  marks: { type: [Array, Object], default: () => [] },
});

const emit = defineEmits(['update:modelValue']);

/** Local draft so drag/type stay smooth even if parent recomputes marks/max each render. */
const localValue = ref(Number(props.modelValue) || 0);

watch(
  () => props.modelValue,
  (next) => {
    const n = Number(next);
    if (Number.isFinite(n) && n !== localValue.value) {
      localValue.value = n;
    }
  },
);

const sliderMarks = computed(() => {
  const raw = props.marks;
  if (Array.isArray(raw)) {
    return Object.fromEntries(
      raw
        .filter((mark) => mark != null && Number.isFinite(Number(mark.value)))
        .map((mark) => [Number(mark.value), String(mark.label ?? '')]),
    );
  }
  if (raw && typeof raw === 'object') {
    /** @type {Record<string, string>} */
    const next = {};
    for (const [key, label] of Object.entries(raw)) {
      if (Number.isFinite(Number(key))) {
        next[key] = String(label ?? '');
      }
    }
    return next;
  }
  return {};
});

const resolvedRequired = computed(() => {
  if (typeof props.required === 'boolean') {
    return props.required;
  }
  return props.label.includes('必填');
});

const resolvedMin = computed(() => {
  const n = Number(props.min);
  return Number.isFinite(n) ? n : 0;
});

const resolvedMax = computed(() => {
  const n = Number(props.max);
  const min = resolvedMin.value;
  if (!Number.isFinite(n) || n < min) {
    return min;
  }
  return n;
});

const resolvedInputMax = computed(() => {
  const candidate = props.inputMax == null ? resolvedMax.value : Number(props.inputMax);
  if (!Number.isFinite(candidate)) {
    return resolvedMax.value;
  }
  return Math.max(resolvedMin.value, candidate);
});

const resolvedStep = computed(() => {
  const n = Number(props.step);
  return Number.isFinite(n) && n > 0 ? n : 1;
});

const displayValue = computed(() => {
  if (props.valueLabel) {
    return props.valueLabel;
  }
  return `${localValue.value}${props.unit || ''}`;
});

function clampToRange(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function commitValue(raw) {
  if (Array.isArray(raw)) {
    return;
  }
  // Allow empty while typing; only commit finite numbers.
  if (raw === undefined || raw === null || raw === '') {
    return;
  }
  const n = Number(raw);
  if (!Number.isFinite(n)) {
    return;
  }
  const next = clampToRange(n, resolvedMin.value, resolvedInputMax.value);
  localValue.value = next;
  if (next !== Number(props.modelValue)) {
    emit('update:modelValue', next);
  }
}

function onInput(raw) {
  commitValue(raw);
}

function onSlider(raw) {
  // Slider max may be lower than inputMax (scaleMax track); clamp to slider track.
  if (Array.isArray(raw) || raw === undefined || raw === null || raw === '') {
    return;
  }
  const n = Number(raw);
  if (!Number.isFinite(n)) {
    return;
  }
  const next = clampToRange(n, resolvedMin.value, resolvedMax.value);
  localValue.value = next;
  if (next !== Number(props.modelValue)) {
    emit('update:modelValue', next);
  }
}
</script>

<template>
  <el-form-item
    class="brick-policy-form-item brick-policy-scale-item setting-form__full"
    :class="{ 'is-disabled': disabled }"
    :label="label"
    :required="resolvedRequired"
  >
    <div class="brick-policy-form-control brick-policy-scale-control">
      <div class="brick-policy-scale-control__head">
        <p v-if="description" class="brick-policy-field-description">{{ description }}</p>
        <strong v-if="!showInput" class="brick-policy-field-value">{{ displayValue }}</strong>
      </div>

      <div v-if="showInput" class="brick-policy-scale__input-row">
        <ElInputNumber
          class="brick-policy-scale__input"
          :model-value="localValue"
          :min="resolvedMin"
          :max="resolvedInputMax"
          :step="resolvedStep"
          :disabled="disabled"
          :value-on-clear="resolvedMin"
          controls-position="right"
          @update:model-value="onInput"
        />
        <span v-if="unit" class="brick-policy-scale__unit">{{ unit }}</span>
      </div>

      <ElSlider
        class="brick-policy-scale"
        :model-value="localValue"
        :min="resolvedMin"
        :max="resolvedMax"
        :step="resolvedStep"
        :marks="sliderMarks"
        :disabled="disabled"
        :show-tooltip="true"
        @update:model-value="onSlider"
      />

      <p v-if="impact" class="brick-policy-field-impact">{{ impact }}</p>
    </div>
  </el-form-item>
</template>

<style scoped>
.brick-policy-scale-item {
  min-width: 0;
}

.brick-policy-scale-control {
  position: relative;
  z-index: 0;
  width: 100%;
  min-width: 0;
}

.brick-policy-scale-control__head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--console-space-3, 12px);
  width: 100%;
}

.brick-policy-scale__input-row {
  position: relative;
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  margin: 4px 0 8px;
  pointer-events: auto;
}

/*
 * Reusable number field for policy scales.
 *
 * Hosts (e.g. security-console) often restyle ALL .el-input__wrapper with a taller
 * min-height and a real border. Element Plus input-number controls-position=right
 * hardcodes half-height ~15px for a 32px field — that desync is the root cause of
 * the broken spinner stack. Always pin control halves to half of control height.
 */
.brick-policy-scale__input {
  --el-input-height: var(--console-control-height, 36px);
  --el-input-border-color: var(--console-field-border, #c5d0e0);
  --el-input-hover-border-color: color-mix(in srgb, var(--console-primary, #2563eb) 45%, var(--console-field-border, #c5d0e0));
  --el-input-focus-border-color: var(--console-primary, #2563eb);
  --el-input-bg-color: var(--console-field-bg, var(--console-card-bg, #ffffff));
  --el-input-text-color: var(--console-title, #0f172a);
  --el-fill-color-light: var(--console-block-bg, #f3f6fb);
  --el-text-color-regular: var(--console-text, #4a5a70);
  --el-border-radius-base: var(--console-field-radius, 4px);
  --el-border: 1px solid var(--el-input-border-color);
  --el-input-number-controls-height: calc((var(--console-control-height, 36px) - 2px) / 2);
  width: 148px;
  flex: 0 0 148px;
  height: var(--console-control-height, 36px);
  line-height: var(--console-control-height, 36px);
  pointer-events: auto;
}

.brick-policy-scale__input :deep(.el-input__wrapper) {
  min-height: var(--console-control-height, 36px);
  background-color: var(--el-input-bg-color);
}

.brick-policy-scale__input :deep(.el-input__inner) {
  font-weight: 700;
  color: var(--el-input-text-color);
  -webkit-text-fill-color: var(--el-input-text-color);
}

/* Beat EP's hardcoded 15px half-height when host grows the field (e.g. 42px). */
.brick-policy-scale__input.is-controls-right :deep(.el-input-number__increase),
.brick-policy-scale__input.is-controls-right :deep(.el-input-number__decrease) {
  --el-input-number-controls-height: calc((var(--console-control-height, 36px) - 2px) / 2);
  height: var(--el-input-number-controls-height);
  line-height: var(--el-input-number-controls-height);
}

.brick-policy-scale__unit {
  color: var(--console-muted, #7e8ba0);
  font-size: 13px;
  font-weight: 600;
  white-space: nowrap;
}

/*
 * Slider geometry + hit testing. Marks must not steal pointer events from the runway.
 */
.brick-policy-scale {
  position: relative;
  z-index: 1;
  width: 100%;
  max-width: 100%;
  box-sizing: border-box;
  margin: 6px 0 40px;
  padding-inline: 10px;
  pointer-events: auto;
  --el-slider-main-bg-color: var(--console-primary, #2563eb);
  --el-slider-runway-bg-color: color-mix(in srgb, var(--console-primary, #2563eb) 12%, var(--console-card-border, #dbe3ef));
  --el-slider-disabled-color: var(--console-muted, #94a3b8);
}

.brick-policy-scale :deep(.el-slider__runway) {
  width: 100%;
  cursor: pointer;
  pointer-events: auto;
}

.brick-policy-scale :deep(.el-slider__bar) {
  pointer-events: none;
}

.brick-policy-scale :deep(.el-slider__button-wrapper) {
  z-index: 3;
  cursor: grab;
  pointer-events: auto;
}

.brick-policy-scale :deep(.el-slider__button-wrapper:active) {
  cursor: grabbing;
}

/* Full-size marks layer sits over the track in EP; disable hit testing on the layer. */
.brick-policy-scale :deep(.el-slider__marks) {
  pointer-events: none;
}

.brick-policy-scale :deep(.el-slider__stop) {
  pointer-events: none;
}

.brick-policy-scale :deep(.el-slider__marks-text) {
  max-width: none;
  margin-top: 14px;
  white-space: nowrap;
  word-break: normal;
  text-align: center;
  line-height: 1.25;
  color: var(--console-muted, #7e8ba0);
  font-size: var(--console-caption-size, 12px);
  font-weight: 750;
  pointer-events: none;
  user-select: none;
}

.brick-policy-scale-item.is-disabled,
.brick-policy-scale-item.is-disabled :deep(*) {
  cursor: not-allowed;
}
</style>
