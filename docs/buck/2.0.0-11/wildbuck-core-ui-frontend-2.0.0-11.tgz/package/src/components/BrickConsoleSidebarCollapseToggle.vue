<script setup>
/**
 * Default sidebar fold control: plain double chevrons + label, no plate background.
 * Shared by BrickConsoleSidebar and BrickConsoleShell so the chrome does not diverge.
 */
defineProps({
  collapsed: { type: Boolean, default: false },
  label: { type: String, default: '' },
  toggle: { type: Function, required: true },
});
</script>

<template>
  <button
    class="shell-sidebar__collapse"
    type="button"
    :aria-label="label"
    :title="label"
    :aria-expanded="String(!collapsed)"
    @click="toggle"
  >
    <svg class="shell-sidebar__collapse-glyph" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
      <!-- Plain double chevrons: simple formal fold control, no fill plate. -->
      <template v-if="collapsed">
        <path d="M3.5 4.25 7.25 8 3.5 11.75" />
        <path d="M8.5 4.25 12.25 8 8.5 11.75" />
      </template>
      <template v-else>
        <path d="M7.5 4.25 3.75 8 7.5 11.75" />
        <path d="M12.5 4.25 8.75 8 12.5 11.75" />
      </template>
    </svg>
    <span class="shell-sidebar__collapse-label">{{ label }}</span>
  </button>
</template>
