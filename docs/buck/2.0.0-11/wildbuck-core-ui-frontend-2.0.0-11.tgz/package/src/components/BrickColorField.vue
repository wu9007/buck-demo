<script setup>
/**
 * Compact color field: swatch (ElColorPicker) + hex input, aligned heights.
 * Used by login-brand and other settings pages that need a brand/primary color.
 */
const props = defineProps({
  modelValue: { type: String, default: '' },
  placeholder: { type: String, default: '#000000' },
  disabled: { type: Boolean, default: false },
  maxlength: { type: Number, default: 9 },
});

const emit = defineEmits(['update:modelValue']);

function onPicker(value) {
  emit('update:modelValue', value || '');
}

function onInput(value) {
  emit('update:modelValue', value == null ? '' : String(value));
}
</script>

<template>
  <div class="brick-color-field" :class="{ 'is-disabled': disabled }">
    <el-color-picker
      :model-value="modelValue || undefined"
      color-format="hex"
      :disabled="disabled"
      @update:model-value="onPicker"
    />
    <el-input
      class="brick-color-field__hex"
      :model-value="modelValue"
      :placeholder="placeholder"
      :maxlength="maxlength"
      :disabled="disabled"
      @update:model-value="onInput"
    />
  </div>
</template>

<style scoped>
.brick-color-field {
  --brick-color-swatch-size: 32px;
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 10px;
  width: 100%;
  min-width: 0;
}

.brick-color-field :deep(.el-color-picker) {
  flex: 0 0 auto;
  height: var(--brick-color-swatch-size);
}

.brick-color-field :deep(.el-color-picker__trigger) {
  box-sizing: border-box;
  width: var(--brick-color-swatch-size);
  height: var(--brick-color-swatch-size);
  padding: 3px;
  border: 1px solid var(--el-border-color, #dcdfe6);
  border-radius: 6px;
}

.brick-color-field :deep(.el-color-picker__color) {
  display: block;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  border: none;
  border-radius: 3px;
}

.brick-color-field :deep(.el-color-picker__color-inner) {
  display: block;
  width: 100%;
  height: 100%;
  border-radius: 3px;
}

.brick-color-field :deep(.el-color-picker__empty),
.brick-color-field :deep(.el-color-picker__icon) {
  display: none;
}

.brick-color-field__hex {
  flex: 1 1 auto;
  min-width: 0;
}

.brick-color-field__hex :deep(.el-input__wrapper) {
  min-height: var(--brick-color-swatch-size);
  height: var(--brick-color-swatch-size);
  padding-top: 0;
  padding-bottom: 0;
}

.brick-color-field.is-disabled {
  opacity: 0.65;
}
</style>
