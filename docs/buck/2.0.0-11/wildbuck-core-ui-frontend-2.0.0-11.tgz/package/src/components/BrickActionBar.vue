<script setup>
const props = defineProps({
  align: { type: String, default: 'end' },
  surface: {
    type: String,
    default: 'plain',
    validator: (value) => ['plain', 'framed'].includes(value),
  },
  sticky: { type: Boolean, default: false },
  loading: { type: Boolean, default: false },
  disabled: { type: Boolean, default: false },
  dangerSeparated: { type: Boolean, default: true },
});
</script>

<template>
  <footer
    class="brick-action-bar"
    :class="[
      `brick-action-bar--${props.align}`,
      `brick-action-bar--surface-${props.surface}`,
      {
        'is-sticky': sticky,
        'is-disabled': disabled,
        'has-danger-separator': dangerSeparated,
      },
    ]"
    :aria-disabled="disabled ? 'true' : 'false'"
    :aria-busy="loading ? 'true' : 'false'"
  >
    <div v-if="$slots.secondary" class="brick-action-bar__secondary">
      <slot name="secondary" />
    </div>

    <div v-if="$slots.batch" class="brick-action-bar__batch">
      <slot name="batch" />
    </div>

    <div v-if="$slots.default" class="brick-action-bar__default">
      <slot />
    </div>

    <div v-if="$slots.primary" class="brick-action-bar__primary">
      <slot name="primary" />
    </div>

    <div v-if="$slots.danger" class="brick-action-bar__danger">
      <slot name="danger" />
    </div>
  </footer>
</template>

<style scoped>
.brick-action-bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--console-space-3, 12px);
  padding: var(--console-space-3, 12px) 0 0;
  border: 0;
  border-radius: 0;
  background: transparent;
}

.brick-action-bar--surface-framed {
  padding: var(--console-space-4, 16px);
  border: 1px solid var(--console-card-border, #dbe3ef);
  border-radius: var(--console-card-radius, 8px);
  background: var(--console-card-bg, #ffffff);
}

.brick-action-bar--surface-plain {
  box-shadow: none;
}

.brick-action-bar--start {
  justify-content: flex-start;
}

.brick-action-bar--center {
  justify-content: center;
}

.brick-action-bar--end {
  justify-content: flex-end;
}

.brick-action-bar--between {
  justify-content: space-between;
}

.brick-action-bar.is-sticky {
  position: sticky;
  bottom: 0;
  z-index: 10;
  background: var(--console-card-bg, #ffffff);
  box-shadow: 0 -10px 24px rgba(15, 23, 42, 0.08);
}

.brick-action-bar.is-disabled {
  opacity: 0.68;
}

.brick-action-bar__secondary,
.brick-action-bar__batch,
.brick-action-bar__default,
.brick-action-bar__primary,
.brick-action-bar__danger {
  display: inline-flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--console-space-3, 12px);
}

.brick-action-bar__batch {
  color: var(--console-muted, #64748b);
}

.brick-action-bar__primary {
  margin-inline-start: auto;
}

.brick-action-bar__danger {
  color: var(--console-danger, #dc2626);
}

.brick-action-bar.has-danger-separator .brick-action-bar__danger {
  padding-inline-start: var(--console-space-3, 12px);
  border-inline-start: 1px solid var(--console-card-border, #dbe3ef);
}

.brick-action-bar :deep(.el-button) {
  min-height: var(--console-control-height, 36px);
  border-radius: var(--console-field-radius, 6px);
  font-weight: 700;
}

@media (max-width: 760px) {
  .brick-action-bar,
  .brick-action-bar__secondary,
  .brick-action-bar__batch,
  .brick-action-bar__default,
  .brick-action-bar__primary,
  .brick-action-bar__danger {
    width: 100%;
    justify-content: flex-start;
  }

  .brick-action-bar__primary {
    margin-inline-start: 0;
  }

  .brick-action-bar.has-danger-separator .brick-action-bar__danger {
    padding-block-start: var(--console-space-3, 12px);
    padding-inline-start: 0;
    border-block-start: 1px solid var(--console-card-border, #dbe3ef);
    border-inline-start: 0;
  }
}
</style>
