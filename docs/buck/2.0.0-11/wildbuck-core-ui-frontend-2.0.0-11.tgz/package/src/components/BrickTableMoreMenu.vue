<script setup>
import { computed } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';

/**
 * 列表操作列「更多」下拉。默认三点图标触发器，放在操作列末位。
 * 业务动作放在 default slot 的 el-dropdown-item 内；敏感项外层接 step-up。
 */
const props = defineProps({
  label: { type: String, default: '' },
  trigger: { type: String, default: 'click' },
  disabled: { type: Boolean, default: false },
  /** When true (default), show ⋯ icon only; label is still used as aria-label. */
  iconOnly: { type: Boolean, default: true },
});

defineEmits(['command']);

const { t } = useBrickConsoleI18n();
const accessibleLabel = computed(() => props.label || t('core.ui.tableMore.more'));
</script>

<template>
  <el-dropdown
    class="brick-table-more-menu"
    :trigger="trigger"
    :disabled="disabled"
    @command="(command) => $emit('command', command)"
  >
    <el-button
      class="brick-table-more-menu__trigger"
      :class="{ 'is-icon-only': iconOnly }"
      link
      type="primary"
      :disabled="disabled"
      :title="accessibleLabel"
      :aria-label="accessibleLabel"
    >
      <template v-if="iconOnly">
        <span class="brick-table-more-menu__dots" aria-hidden="true">⋯</span>
      </template>
      <template v-else>
        {{ accessibleLabel }}
        <span class="brick-table-more-menu__caret" aria-hidden="true">▾</span>
      </template>
    </el-button>
    <template #dropdown>
      <el-dropdown-menu class="brick-table-more-menu__panel">
        <slot />
      </el-dropdown-menu>
    </template>
  </el-dropdown>
</template>

<style scoped>
.brick-table-more-menu__trigger {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 0;
  height: auto;
  min-width: 28px;
  font-weight: 600;
}

.brick-table-more-menu__trigger.is-icon-only {
  width: 28px;
  min-height: 28px;
  font-weight: 700;
  letter-spacing: 0.02em;
}

.brick-table-more-menu__dots {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  line-height: 1;
  transform: translateY(-1px);
}

.brick-table-more-menu__caret {
  font-size: 11px;
  line-height: 1;
  opacity: 0.72;
}
</style>
