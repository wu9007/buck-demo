<script setup>
import { computed } from 'vue';

const props = defineProps({
  dataGuideAnchor: { type: String, default: 'filters' },
  fieldMinWidth: { type: String, default: '180px' },
});

const toolbarStyle = computed(() => ({
  '--brick-filter-toolbar-field-min': props.fieldMinWidth,
}));
</script>

<template>
  <section
    class="brick-filter-toolbar"
    :data-guide-anchor="dataGuideAnchor || undefined"
    :style="toolbarStyle"
  >
    <div class="brick-filter-toolbar__fields">
      <slot />
    </div>
    <div class="brick-filter-toolbar__actions">
      <slot name="actions" />
    </div>
  </section>
</template>

<style scoped>
.brick-filter-toolbar {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--console-space-4, 16px);
  padding: var(--console-card-body-y, 16px) var(--console-card-body-x, 16px);
  border: 1px solid var(--console-card-border, #dbe3ef);
  border-radius: var(--console-card-radius, 8px);
  background: var(--console-card-bg, #ffffff);
  box-shadow: var(--console-card-shadow, 0 1px 2px rgba(15, 23, 42, 0.04));
}

.brick-filter-toolbar__fields {
  display: grid;
  flex: 1 1 auto;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, var(--brick-filter-toolbar-field-min)), 1fr));
  gap: var(--console-space-3, 12px);
}

.brick-filter-toolbar__fields > :deep(*) {
  width: 100%;
  min-width: 0;
}

.brick-filter-toolbar__actions {
  display: flex;
  align-self: flex-start;
  align-items: center;
  gap: var(--console-space-3, 12px);
}

.brick-filter-toolbar :deep(.el-input__wrapper),
.brick-filter-toolbar :deep(.el-select__wrapper) {
  min-height: var(--console-control-height, 36px);
  border-radius: var(--console-field-radius, 4px);
}

.brick-filter-toolbar__fields > :deep(.brick-filter-toolbar__field--range) {
  grid-column: span 2;
}

.brick-filter-toolbar__actions :deep(.brick-action-bar) {
  padding-block-start: 0;
}

.brick-filter-toolbar :deep(.el-button) {
  min-height: var(--console-control-height, 36px);
  padding-inline: var(--console-space-4, 16px);
  border-radius: var(--console-field-radius, 4px);
  font-weight: 600;
}

@media (max-width: 760px) {
  .brick-filter-toolbar {
    flex-direction: column;
  }

  .brick-filter-toolbar__fields,
  .brick-filter-toolbar__actions {
    width: 100%;
  }

  .brick-filter-toolbar__actions {
    flex-wrap: wrap;
  }

  .brick-filter-toolbar__fields > :deep(.brick-filter-toolbar__field--range) {
    grid-column: 1 / -1;
  }
}
</style>
