<script setup>
import { computed } from 'vue';
import BrickEmptyState from './BrickEmptyState.vue';
import { useBrickConsoleI18n } from '../i18n.js';

const props = defineProps({
  title: { type: String, default: '' },
  description: { type: String, default: '' },
  eyebrow: { type: String, default: '' },
  loading: { type: Boolean, default: false },
  loadingText: { type: String, default: '' },
  error: { type: [String, Object, Boolean], default: false },
  empty: { type: Boolean, default: false },
  emptyTitle: { type: String, default: '' },
  emptyDescription: { type: String, default: '' },
  bordered: { type: Boolean, default: true },
  compact: { type: Boolean, default: false },
});

const { t } = useBrickConsoleI18n();

const resolvedLoadingText = computed(() => props.loadingText || t('core.ui.pageBlock.loading'));
const resolvedEmptyTitle = computed(() => props.emptyTitle || t('core.ui.pageBlock.emptyTitle'));

const hasError = computed(() => {
  if (typeof props.error === 'string') {
    return props.error.trim().length > 0;
  }
  if (typeof props.error === 'boolean') {
    return props.error;
  }
  return props.error != null;
});
const errorDescription = computed(() => {
  if (typeof props.error === 'string') {
    return props.error;
  }
  if (props.error && typeof props.error === 'object' && props.error.message) {
    return props.error.message;
  }
  return t('core.ui.pageBlock.loadFailedDescription');
});
</script>

<template>
  <section
    class="brick-page-block"
    :class="{ 'is-plain': !bordered, 'is-compact': compact }"
    :aria-busy="loading ? 'true' : 'false'"
  >
    <header
      v-if="$slots.header || $slots.title || $slots.actions || $slots.meta || title || description || eyebrow"
      class="brick-page-block__header"
    >
      <slot name="header">
        <div class="brick-page-block__heading">
          <p v-if="$slots.eyebrow || eyebrow" class="brick-page-block__eyebrow">
            <slot name="eyebrow">{{ eyebrow }}</slot>
          </p>
          <div class="brick-page-block__title-row">
            <h2 v-if="$slots.title || title" class="brick-page-block__title">
              <slot name="title">{{ title }}</slot>
            </h2>
            <div v-if="$slots.actions" class="brick-page-block__actions">
              <slot name="actions" />
            </div>
          </div>
          <p v-if="$slots.description || description" class="brick-page-block__description">
            <slot name="description">{{ description }}</slot>
          </p>
          <div v-if="$slots.meta" class="brick-page-block__meta">
            <slot name="meta" />
          </div>
        </div>
      </slot>
    </header>

    <div class="brick-page-block__body">
      <slot v-if="loading" name="loading">
        <p class="brick-page-block__state">{{ resolvedLoadingText }}</p>
      </slot>

      <slot v-else-if="hasError" name="error" :error="error">
        <BrickEmptyState
          variant="error"
          :title="t('core.ui.pageBlock.loadFailed')"
          :description="errorDescription"
          compact
        />
      </slot>

      <slot v-else-if="empty" name="empty">
        <BrickEmptyState
          :title="resolvedEmptyTitle"
          :description="emptyDescription"
          compact
        />
      </slot>

      <slot v-else />
    </div>

    <footer v-if="$slots.footer" class="brick-page-block__footer">
      <slot name="footer" />
    </footer>
  </section>
</template>

<style scoped>
.brick-page-block {
  overflow: hidden;
  border: 1px solid var(--console-card-border, #dbe3ef);
  border-radius: var(--console-card-radius, 8px);
  background: var(--console-card-bg, #ffffff);
  box-shadow: var(--console-card-shadow, 0 12px 30px rgba(15, 23, 42, 0.08));
}

.brick-page-block.is-plain {
  border-color: transparent;
  box-shadow: none;
}

.brick-page-block__header {
  padding: var(--console-card-header-y, 16px) var(--console-card-header-x, 20px);
  border-bottom: 1px solid var(--console-card-border, #dbe3ef);
  background: var(--console-card-bg, #ffffff);
}

.brick-page-block.is-compact .brick-page-block__header {
  padding-block: var(--console-space-3, 12px);
}

.brick-page-block__heading {
  display: grid;
  gap: var(--console-space-2, 8px);
}

.brick-page-block__eyebrow {
  margin: 0;
  color: var(--console-primary, #2563eb);
  font-size: 12px;
  font-weight: 800;
}

.brick-page-block__title-row {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--console-space-4, 16px);
}

.brick-page-block__title {
  margin: 0;
  color: var(--console-title, #0f172a);
  font-size: 18px;
  font-weight: 850;
  line-height: 1.35;
}

.brick-page-block__description,
.brick-page-block__state {
  margin: 0;
  color: var(--console-muted, #64748b);
  font-size: 14px;
  line-height: 1.7;
}

.brick-page-block__actions,
.brick-page-block__meta,
.brick-page-block__footer {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--console-space-3, 12px);
}

.brick-page-block__body {
  padding: var(--console-card-body-y, 18px) var(--console-card-body-x, 20px);
  background: var(--console-card-bg, #ffffff);
}

.brick-page-block__state {
  padding: var(--console-space-6, 24px);
  border: 1px dashed var(--console-block-border, var(--console-card-border, #dbe3ef));
  border-radius: var(--console-block-radius, 8px);
  background: var(--console-block-bg, #f8fafc);
  text-align: center;
}

.brick-page-block__footer {
  justify-content: flex-end;
  padding: var(--console-space-4, 16px) var(--console-card-header-x, 20px);
  border-top: 1px solid var(--console-card-border, #dbe3ef);
  background: var(--console-card-bg, #ffffff);
}

@media (max-width: 760px) {
  .brick-page-block__title-row {
    flex-direction: column;
  }

  .brick-page-block__actions,
  .brick-page-block__footer {
    width: 100%;
    justify-content: flex-start;
  }
}
</style>
