<script setup>
import { computed } from 'vue';
import { ElConfigProvider } from 'element-plus/es/components/config-provider/index.mjs';
import en from 'element-plus/es/locale/lang/en';
import zhCn from 'element-plus/es/locale/lang/zh-cn';
import { pickBrickElementPlusLocale } from '@wildbuck/core-i18n-frontend';
import { useBrickConsoleI18n } from '../i18n.js';

const props = defineProps({
  page: { type: Number, required: true },
  pageSize: { type: Number, required: true },
  pageSizes: { type: Array, default: () => [10, 20, 50, 100] },
  total: { type: Number, required: true },
  summary: { type: String, default: '' },
  /** Optional Element Plus locale override; defaults to shell appearance locale. */
  locale: { type: Object, default: null },
  disabled: { type: Boolean, default: false },
});

const emit = defineEmits(['update:page', 'update:pageSize']);

const { t, locale: brickLocale } = useBrickConsoleI18n();

const elementLocale = computed(() => {
  if (props.locale) {
    return props.locale;
  }
  return pickBrickElementPlusLocale(brickLocale.value, { zhCn, en }) ?? zhCn;
});

const resolvedSummary = computed(
  () => props.summary || t('core.ui.pagination.total', { total: props.total }),
);

function handlePageChange(value) {
  if (value !== props.page) {
    emit('update:page', value);
  }
}

function handlePageSizeChange(value) {
  if (value !== props.pageSize) {
    emit('update:pageSize', value);
  }
}
</script>

<template>
  <nav class="brick-pagination-bar" :aria-label="t('core.ui.pagination.aria')">
    <span class="brick-pagination-bar__summary">{{ resolvedSummary }}</span>
    <ElConfigProvider :locale="elementLocale">
      <el-pagination
        background
        :current-page="page"
        :disabled="disabled"
        :page-size="pageSize"
        :page-sizes="pageSizes"
        :total="total"
        layout="sizes, prev, pager, next, jumper"
        @update:current-page="handlePageChange"
        @update:page-size="handlePageSizeChange"
      />
    </ElConfigProvider>
  </nav>
</template>

<style scoped>
.brick-pagination-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--console-space-4, 16px);
  padding: var(--console-card-header-y, 14px) var(--console-card-header-x, 18px);
  border-top: 1px solid var(--console-card-border, #dbe3ef);
  color: var(--console-text, #4a5a70);
  background: var(--console-card-bg, #ffffff);
  font-size: var(--console-caption-size, 13px);
}

.brick-pagination-bar__summary {
  color: var(--console-text, #4a5a70);
  font-weight: 700;
}

.brick-pagination-bar :deep(.el-pagination) {
  --el-pagination-button-height: var(--console-control-height, 36px);
  --el-pagination-button-width: var(--console-control-height, 36px);
  --el-pagination-font-size: var(--console-caption-size, 13px);
  justify-content: flex-end;
  gap: var(--console-space-2, 8px);
}

.brick-pagination-bar :deep(.el-input__wrapper),
.brick-pagination-bar :deep(.el-select__wrapper) {
  min-height: var(--console-control-height, 36px);
  border-radius: var(--console-field-radius, 6px);
}

.brick-pagination-bar :deep(.el-pager li),
.brick-pagination-bar :deep(.btn-prev),
.brick-pagination-bar :deep(.btn-next) {
  border-radius: var(--console-field-radius, 6px);
  font-weight: 700;
}

@media (max-width: 760px) {
  .brick-pagination-bar {
    display: grid;
  }

  .brick-pagination-bar :deep(.el-pagination) {
    justify-content: flex-start;
  }
}
</style>
