<script setup>
import { computed, nextTick, onMounted, onUnmounted, ref, watch } from 'vue';
import { useBrickConsoleI18n } from '../i18n.js';
import {
  buildUserMenuItems,
  isClickOutsideUserMenu,
  normalizePrincipalSubtitle,
  resolveUserMenuAvatarAlt,
  resolveUserMenuDisplayName,
  resolveUserMenuInitial,
  shouldCloseUserMenuOnKey,
} from '../user-menu.js';
import BrickAppearanceSettingsDialog from './BrickAppearanceSettingsDialog.vue';
import BrickChangePasswordDialog from './BrickChangePasswordDialog.vue';

const props = defineProps({
  principalName: { type: String, default: '' },
  principalSubtitle: { type: String, default: '' },
  /** Login username for password-manager autofill (prefer over display name). */
  principalUsername: { type: String, default: '' },
  principalAvatarUrl: { type: String, default: '' },
  theme: { type: String, default: 'blue' },
  themePreference: { type: String, default: '' },
  density: { type: String, default: 'comfortable' },
  fontSize: { type: String, default: 'normal' },
  fullscreenAutoEnter: { type: Boolean, default: false },
  locale: { type: String, default: 'zh-CN' },
  showAppearanceSettings: { type: Boolean, default: true },
  showChangePassword: { type: Boolean, default: true },
  /**
   * async ({ currentPassword, newPassword }) => void
   * Wired by shell → IAM POST /brick/password/change (dialog stays in-shell).
   */
  changePasswordSubmit: { type: Function, default: null },
  canInstallApp: { type: Boolean, default: false }
});

const emit = defineEmits([
  'logout',
  'install-app',
  'change-password-success',
  'update:theme',
  'update:density',
  'update:fontSize',
  'update:fullscreenAutoEnter',
  'update:locale'
]);
const { t } = useBrickConsoleI18n();
const rootRef = ref(null);
const triggerRef = ref(null);
const menuOpen = ref(false);
const settingsOpen = ref(false);
const passwordOpen = ref(false);
const menuId = `brick-user-menu-${Math.random().toString(36).slice(2, 9)}`;

const displayName = computed(() => resolveUserMenuDisplayName(
  props.principalName,
  t('core.ui.userMenu.anonymous'),
));
const subtitle = computed(() => normalizePrincipalSubtitle(props.principalSubtitle));
const principalInitial = computed(() => resolveUserMenuInitial(
  props.principalName,
  t('core.ui.userMenu.anonymousInitial'),
));
const avatarAlt = computed(() => resolveUserMenuAvatarAlt(
  displayName.value,
  t('core.ui.userMenu.avatarAlt', { name: displayName.value }),
));
const menuItems = computed(() => buildUserMenuItems({
  canInstallApp: props.canInstallApp,
  showAppearanceSettings: props.showAppearanceSettings,
  showChangePassword: props.showChangePassword,
}));
const passwordUsername = computed(() => String(
  props.principalUsername || props.principalSubtitle || props.principalName || '',
).trim());

function closeMenu() {
  menuOpen.value = false;
}

function toggleMenu() {
  menuOpen.value = !menuOpen.value;
}

function openSettings() {
  closeMenu();
  settingsOpen.value = true;
}

function installApp() {
  closeMenu();
  emit('install-app');
}

function logout() {
  closeMenu();
  emit('logout');
}

function openChangePassword() {
  closeMenu();
  // In-shell modal only — never navigate to the full auth password stage.
  passwordOpen.value = true;
}

async function submitChangePassword(payload) {
  if (typeof props.changePasswordSubmit !== 'function') {
    throw new Error(t('core.ui.changePassword.submitMissing'));
  }
  await props.changePasswordSubmit(payload);
}

function onDocumentPointerDown(event) {
  if (!menuOpen.value) {
    return;
  }
  if (isClickOutsideUserMenu(event.target, rootRef.value)) {
    closeMenu();
  }
}

function onDocumentKeydown(event) {
  if (!menuOpen.value) {
    return;
  }
  if (shouldCloseUserMenuOnKey(event.key)) {
    event.preventDefault();
    closeMenu();
    nextTick(() => triggerRef.value?.focus?.());
  }
}

function onItemActivate(id) {
  if (id === 'install-app') {
    installApp();
    return;
  }
  if (id === 'personalization') {
    openSettings();
    return;
  }
  if (id === 'change-password') {
    openChangePassword();
    return;
  }
  if (id === 'logout') {
    logout();
  }
}

function menuItemLabel(id) {
  if (id === 'install-app') {
    return t('core.ui.userMenu.installApp');
  }
  if (id === 'personalization') {
    return t('core.ui.userMenu.personalization');
  }
  if (id === 'change-password') {
    return t('core.ui.userMenu.changePassword');
  }
  return t('core.ui.userMenu.logout');
}

onMounted(() => {
  document.addEventListener('pointerdown', onDocumentPointerDown, true);
  document.addEventListener('keydown', onDocumentKeydown, true);
});

onUnmounted(() => {
  document.removeEventListener('pointerdown', onDocumentPointerDown, true);
  document.removeEventListener('keydown', onDocumentKeydown, true);
});

watch(menuOpen, (open) => {
  if (!open) {
    return;
  }
  // Production: ensure expanded menu is announced; focus stays on trigger for light menus.
});
</script>

<template>
  <div ref="rootRef" class="brick-user-menu">
    <button
      ref="triggerRef"
      class="brick-user-menu__trigger"
      type="button"
      aria-haspopup="menu"
      :aria-controls="menuId"
      :aria-expanded="menuOpen ? 'true' : 'false'"
      :aria-label="t('core.ui.userMenu.triggerAria', { name: displayName })"
      @click="toggleMenu"
    >
      <span class="brick-user-menu__avatar" aria-hidden="true">
        <img
          v-if="principalAvatarUrl"
          class="brick-user-menu__avatar-image"
          :src="principalAvatarUrl"
          alt=""
        />
        <span v-else>{{ principalInitial }}</span>
      </span>
      <span class="brick-user-menu__name">{{ displayName }}</span>
      <span class="brick-user-menu__chevron" aria-hidden="true">⌄</span>
    </button>

    <div
      v-if="menuOpen"
      :id="menuId"
      class="brick-user-menu__dropdown"
      role="menu"
      :aria-label="t('core.ui.userMenu.menuAria')"
    >
      <div class="brick-user-menu__identity" role="presentation">
        <span class="brick-user-menu__identity-name">{{ displayName }}</span>
        <span v-if="subtitle" class="brick-user-menu__identity-sub">{{ subtitle }}</span>
      </div>
      <div class="brick-user-menu__divider" role="separator" />

      <template v-for="item in menuItems" :key="item.id">
        <div
          v-if="item.kind === 'separator'"
          class="brick-user-menu__divider"
          role="separator"
        />
        <button
          v-else
          class="brick-user-menu__item"
          :class="{
            'brick-user-menu__item--danger': item.kind === 'danger',
          }"
          type="button"
          role="menuitem"
          @click="onItemActivate(item.id)"
        >
          {{ menuItemLabel(item.id) }}
        </button>
      </template>
    </div>

    <BrickAppearanceSettingsDialog
      :visible="settingsOpen"
      :theme="themePreference || theme"
      :density="density"
      :font-size="fontSize"
      :fullscreen-auto-enter="fullscreenAutoEnter"
      :locale="locale"
      @close="settingsOpen = false"
      @update:theme="(value) => emit('update:theme', value)"
      @update:density="(value) => emit('update:density', value)"
      @update:font-size="(value) => emit('update:fontSize', value)"
      @update:fullscreen-auto-enter="(value) => emit('update:fullscreenAutoEnter', value)"
      @update:locale="(value) => emit('update:locale', value)"
    />

    <BrickChangePasswordDialog
      :visible="passwordOpen"
      :username="passwordUsername"
      :submit="submitChangePassword"
      @close="passwordOpen = false"
      @success="emit('change-password-success')"
    />
  </div>
</template>
