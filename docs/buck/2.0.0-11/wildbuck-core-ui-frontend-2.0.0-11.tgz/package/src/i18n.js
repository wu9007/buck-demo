import { computed, inject, onScopeDispose, ref } from 'vue';
import { formatBrickI18nMessage, normalizeBrickLocale } from '@wildbuck/core-i18n-frontend';
import {
  BRICK_CONSOLE_UI_MESSAGES,
  BRICK_CONSOLE_UI_MESSAGES_EN_US,
  BRICK_CONSOLE_UI_MESSAGES_ZH_CN,
} from './i18n-messages.js';

/** Prefer Symbol inject; string key kept for plain-object provide convenience. */
export const BRICK_CONSOLE_I18N_INJECTION_KEY = Symbol.for('brick.console.i18n');
export const BRICK_CONSOLE_I18N_INJECTION_KEY_STRING = 'brickI18n';

export {
  BRICK_CONSOLE_UI_MESSAGES,
  BRICK_CONSOLE_UI_MESSAGES_EN_US,
  BRICK_CONSOLE_UI_MESSAGES_ZH_CN,
};

/**
 * @param {unknown} locale
 * @returns {Readonly<Record<string, string>>}
 */
export function resolveBrickConsoleUiMessages(locale) {
  const normalized = normalizeBrickLocale(locale);
  return BRICK_CONSOLE_UI_MESSAGES[normalized] ?? BRICK_CONSOLE_UI_MESSAGES_ZH_CN;
}

/**
 * Translate using injected runtime when present; otherwise zh-CN / en pack fallbacks.
 * Missing keys fall back to zh-CN pack, then the key itself.
 * @param {unknown} runtime
 * @param {string} key
 * @param {Record<string, unknown>} [params]
 * @param {string} [fallbackLocale]
 */
export function translateBrickConsoleUi(runtime, key, params = {}, fallbackLocale = 'zh-CN') {
  const messageKey = String(key ?? '');
  if (!messageKey) {
    return '';
  }
  if (runtime && typeof runtime.t === 'function') {
    const resolved = runtime.t(messageKey, params);
    if (resolved != null && resolved !== '' && resolved !== messageKey) {
      return String(resolved);
    }
  }
  const locale = normalizeBrickLocale(
    typeof runtime?.getLocale === 'function' ? runtime.getLocale() : fallbackLocale,
    fallbackLocale,
  );
  const pack = resolveBrickConsoleUiMessages(locale);
  const zhPack = BRICK_CONSOLE_UI_MESSAGES_ZH_CN;
  const template = pack[messageKey] ?? zhPack[messageKey];
  if (typeof template === 'string') {
    return formatBrickI18nMessage(template, params);
  }
  return messageKey;
}

/**
 * Vue inject helper for shell SFCs.
 * Tracks runtime revision so setLocale / registerMessages re-render templates that call t().
 * @returns {{
 *   t: (key: string, params?: Record<string, unknown>) => string,
 *   i18n: unknown,
 *   locale: import('vue').ComputedRef<string>,
 *   revision: import('vue').Ref<number>,
 * }}
 */
export function useBrickConsoleI18n() {
  const injected = inject(BRICK_CONSOLE_I18N_INJECTION_KEY, null)
    ?? inject(BRICK_CONSOLE_I18N_INJECTION_KEY_STRING, null);
  const revision = ref(
    typeof injected?.getRevision === 'function' ? injected.getRevision() : 0,
  );

  if (injected && typeof injected.subscribe === 'function') {
    const unsubscribe = injected.subscribe((snapshot) => {
      revision.value = Number(snapshot?.revision ?? revision.value + 1);
    });
    onScopeDispose(() => {
      if (typeof unsubscribe === 'function') {
        unsubscribe();
      }
    });
  }

  return {
    i18n: injected,
    revision,
    locale: computed(() => {
      // Depend on revision so locale switches invalidate computed/template paths.
      void revision.value;
      if (typeof injected?.getLocale === 'function') {
        return injected.getLocale();
      }
      return 'zh-CN';
    }),
    t(key, params) {
      // Establish a reactive dependency on locale/message table changes.
      void revision.value;
      return translateBrickConsoleUi(injected, key, params);
    },
  };
}
