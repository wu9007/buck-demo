export declare const BRICK_CONSOLE_I18N_INJECTION_KEY: symbol;
export declare const BRICK_CONSOLE_I18N_INJECTION_KEY_STRING: 'brickI18n';
export declare const BRICK_CONSOLE_UI_MESSAGES_ZH_CN: Readonly<Record<string, string>>;
export declare const BRICK_CONSOLE_UI_MESSAGES_EN_US: Readonly<Record<string, string>>;
export declare const BRICK_CONSOLE_UI_MESSAGES: Readonly<Record<'zh-CN' | 'en-US', Readonly<Record<string, string>>>>;

export declare function resolveBrickConsoleUiMessages(locale?: unknown): Readonly<Record<string, string>>;
export declare function translateBrickConsoleUi(
  runtime: { t?: (key: string, params?: Record<string, unknown>) => string; getLocale?: () => string } | null | undefined,
  key: string,
  params?: Record<string, unknown>,
  fallbackLocale?: string,
): string;
export declare function useBrickConsoleI18n(): {
  i18n: unknown;
  revision: { value: number };
  locale: { value: string };
  t(key: string, params?: Record<string, unknown>): string;
};
