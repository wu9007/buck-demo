import type { Component } from 'vue';

export interface BrickConsoleRoute {
  id: string;
  title: string;
  path: string;
  group?: string;
  order?: number;
  icon?: string | Component;
  iconUrl?: string;
  iconName?: string;
  iconText?: string;
  abbr?: string;
  shortTitle?: string;
  collapsedTitle?: string;
  searchKeywords?: string[];
  keywords?: string[];
  menu?: {
    title?: string;
    label?: string;
    searchText?: string;
    searchKeywords?: string[];
    keywords?: string[];
    trail?: string[];
  };
  permissions?: string[];
}

export interface BrickConsolePrincipal {
  displayName?: string;
  username?: string;
  avatarUrl?: string;
}

export interface BrickConsoleTopbarBreadcrumb {
  label: string;
  title?: string;
  path?: string;
  href?: string;
  routeName?: string;
}

export interface BrickConsoleRouteGroup {
  key: string;
  label: string;
  order?: number;
  collapsible?: boolean;
  defaultCollapsed?: boolean;
  searchText?: string;
  searchKeywords?: string[];
  keywords?: string[];
  routes?: BrickConsoleRoute[];
}

export interface BrickConsoleModuleCatalog {
  modules?: Array<{ routes?: BrickConsoleRoute[]; brickRoutes?: BrickConsoleRoute[] }>;
}

export interface BrickConsoleMenuNode {
  id?: string;
  code?: string;
  title?: string;
  label?: string;
  name?: string;
  path?: string;
  icon?: string | Component;
  iconUrl?: string;
  iconName?: string;
  iconText?: string;
  abbr?: string;
  shortTitle?: string;
  collapsedTitle?: string;
  searchKeywords?: string[];
  keywords?: string[];
  order?: number;
  sortNo?: number;
  children?: BrickConsoleMenuNode[];
}

export declare const BRICK_CONSOLE_WORKBENCH_ROUTE: Readonly<BrickConsoleRoute>;
export declare const BRICK_CONSOLE_DEFAULT_ROUTE_GROUPS: readonly Readonly<BrickConsoleRouteGroup>[];
export declare function collectBrickConsoleRoutes(catalogOrModules?: BrickConsoleModuleCatalog | Array<unknown>): BrickConsoleRoute[];
export declare function canAccessBrickConsoleRoute(route: BrickConsoleRoute, permissions?: string[]): boolean;
export declare function buildBrickConsoleNavigationGroups(
  routes?: BrickConsoleRoute[],
  permissions?: string[],
  routeGroups?: readonly BrickConsoleRouteGroup[]
): BrickConsoleRouteGroup[];
export declare function mergeBrickConsoleRoutesWithMenus(
  routes?: BrickConsoleRoute[],
  menus?: BrickConsoleMenuNode[]
): BrickConsoleRoute[];
export declare function buildBrickConsoleNavigationGroupsFromMenus(
  routes?: BrickConsoleRoute[],
  menus?: BrickConsoleMenuNode[],
  options?: { permissions?: string[]; useMergedRoutes?: boolean }
): BrickConsoleRouteGroup[];
export declare function dispatchBrickConsoleManagementIntent(
  routeId: string,
  detail?: Record<string, unknown>,
  target?: Window | null
): boolean;
export declare function subscribeBrickConsoleManagementIntent(
  listener: (routeId: string, detail: Record<string, unknown>, event: Event) => void,
  target?: Window | null
): () => void;
export declare function readBrickConsoleCollapsedGroupKeys(storage?: Storage | null): string[];
export declare function writeBrickConsoleCollapsedGroupKeys(keys?: string[], storage?: Storage | null): string[];
export declare const BRICK_CONSOLE_ACTIVE_ROUTE_STORAGE_KEY: string;
export declare function readBrickConsoleActiveRouteId(storage?: Storage | null): string;
export declare function writeBrickConsoleActiveRouteId(routeId?: string, storage?: Storage | null): string;
export declare function readBrickConsoleLocationPath(target?: Window | null): string;
export declare function syncBrickConsoleLocationPath(
  path?: string,
  options?: { replace?: boolean },
  target?: Window | null
): string;
export declare function findBrickConsoleRouteIdByPath(
  routes?: BrickConsoleRoute[],
  path?: string
): string;
