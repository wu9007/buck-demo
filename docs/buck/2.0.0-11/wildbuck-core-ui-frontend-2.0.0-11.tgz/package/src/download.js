/**
 * Trigger a browser file download from text content.
 * Shared by audit export, application-center access profile, etc.
 *
 * @param {string|BlobPart} content
 * @param {string} fileName
 * @param {string} [mimeType]
 * @returns {boolean} false when document/URL APIs are unavailable
 */
export function downloadTextFile(content, fileName, mimeType = 'text/plain;charset=utf-8') {
  if (typeof document === 'undefined' || typeof URL === 'undefined') {
    return false;
  }
  const blob = content instanceof Blob
    ? content
    : new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = fileName || 'download.txt';
  anchor.rel = 'noopener';
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
  return true;
}
