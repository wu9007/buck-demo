export const BRICK_CONSOLE_THEME_NAMES = Object.freeze(['blue', 'orange', 'guard', 'green', 'night']);
export const BRICK_CONSOLE_THEME_PREFERENCE_NAMES = Object.freeze(['system', ...BRICK_CONSOLE_THEME_NAMES]);
export const BRICK_CONSOLE_DENSITY_NAMES = Object.freeze(['comfortable', 'compact']);
export const BRICK_CONSOLE_FONT_SIZE_NAMES = Object.freeze(['normal', 'large', 'xlarge']);
export const BRICK_CONSOLE_LOCALE_NAMES = Object.freeze(['zh-CN', 'en-US']);
/** Canonical localStorage keys (also exported for product tests / diagnostics). */
export const BRICK_CONSOLE_APPEARANCE_STORAGE_KEYS = Object.freeze({
  theme: 'brick-console:appearance-theme',
  density: 'brick-console:appearance-density',
  fontSize: 'brick-console:appearance-font-size',
  fullscreenAutoEnter: 'brick-console:appearance-fullscreen-auto-enter',
  locale: 'brick-console:appearance-locale'
});
export const BRICK_CONSOLE_LEGACY_APPEARANCE_STORAGE_KEYS = Object.freeze({
  theme: 'brick-governance-foundation:appearance-theme',
  density: 'brick-governance-foundation:appearance-density',
  fontSize: 'brick-governance-foundation:appearance-font-size',
  fullscreenAutoEnter: 'brick-governance-foundation:appearance-fullscreen-auto-enter',
  locale: 'brick-governance-foundation:appearance-locale'
});
/** Default production appearance (browser-local preference only). */
export const BRICK_CONSOLE_APPEARANCE_DEFAULTS = Object.freeze({
  theme: 'blue',
  density: 'comfortable',
  fontSize: 'normal',
  fullscreenAutoEnter: false,
  locale: 'zh-CN',
});

export function normalizeBrickConsoleAppearance(appearance = {}) {
  const theme = normalizeBrickConsoleThemePreference(appearance.theme);
  const density = BRICK_CONSOLE_DENSITY_NAMES.includes(appearance.density) ? appearance.density : 'comfortable';
  const fontSize = BRICK_CONSOLE_FONT_SIZE_NAMES.includes(appearance.fontSize) ? appearance.fontSize : 'normal';
  const fullscreenAutoEnter = normalizeBooleanPreference(appearance.fullscreenAutoEnter, false);
  const locale = BRICK_CONSOLE_LOCALE_NAMES.includes(appearance.locale) ? appearance.locale : 'zh-CN';
  return Object.freeze({ theme, density, fontSize, fullscreenAutoEnter, locale });
}

export function readBrickConsoleAppearancePreference(storage = resolveStorage()) {
  return normalizeBrickConsoleAppearance({
    theme: readStoredValue(storage, BRICK_CONSOLE_APPEARANCE_STORAGE_KEYS.theme, BRICK_CONSOLE_LEGACY_APPEARANCE_STORAGE_KEYS.theme),
    density: readStoredValue(storage, BRICK_CONSOLE_APPEARANCE_STORAGE_KEYS.density, BRICK_CONSOLE_LEGACY_APPEARANCE_STORAGE_KEYS.density),
    fontSize: readStoredValue(storage, BRICK_CONSOLE_APPEARANCE_STORAGE_KEYS.fontSize, BRICK_CONSOLE_LEGACY_APPEARANCE_STORAGE_KEYS.fontSize),
    fullscreenAutoEnter: readStoredValue(
      storage,
      BRICK_CONSOLE_APPEARANCE_STORAGE_KEYS.fullscreenAutoEnter,
      BRICK_CONSOLE_LEGACY_APPEARANCE_STORAGE_KEYS.fullscreenAutoEnter
    ),
    locale: readStoredValue(storage, BRICK_CONSOLE_APPEARANCE_STORAGE_KEYS.locale, BRICK_CONSOLE_LEGACY_APPEARANCE_STORAGE_KEYS.locale)
  });
}

export function writeBrickConsoleAppearancePreference(appearance = {}, storage = resolveStorage()) {
  const normalized = normalizeBrickConsoleAppearance(appearance);
  writeStoredValue(storage, BRICK_CONSOLE_APPEARANCE_STORAGE_KEYS.theme, normalized.theme);
  writeStoredValue(storage, BRICK_CONSOLE_APPEARANCE_STORAGE_KEYS.density, normalized.density);
  writeStoredValue(storage, BRICK_CONSOLE_APPEARANCE_STORAGE_KEYS.fontSize, normalized.fontSize);
  writeStoredValue(storage, BRICK_CONSOLE_APPEARANCE_STORAGE_KEYS.fullscreenAutoEnter, normalized.fullscreenAutoEnter ? 'true' : 'false');
  writeStoredValue(storage, BRICK_CONSOLE_APPEARANCE_STORAGE_KEYS.locale, normalized.locale);
  return normalized;
}

export function resolveBrickConsoleAppearanceTheme(appearance = {}, media = resolveSystemColorSchemeMedia()) {
  const theme = typeof appearance === 'string'
    ? normalizeBrickConsoleThemePreference(appearance)
    : normalizeBrickConsoleAppearance(appearance).theme;
  if (theme !== 'system') {
    return normalizeBrickConsoleThemeName(theme);
  }
  return media?.matches ? 'night' : 'blue';
}

export function createBrickConsoleAppearanceRuntime({
  storage = resolveStorage(),
  media = resolveSystemColorSchemeMedia(),
  appearance = readBrickConsoleAppearancePreference(storage),
  onChange,
} = {}) {
  const emit = typeof onChange === 'function' ? onChange : null;
  let currentAppearance = normalizeBrickConsoleAppearance(appearance);
  const read = () => ({
    ...currentAppearance,
    resolvedTheme: resolveBrickConsoleAppearanceTheme(currentAppearance, media),
  });
  const notify = () => {
    if (emit) {
      emit(read());
    }
  };
  const unsubscribe = subscribeSystemColorSchemeChange(media, () => {
    if (currentAppearance.theme === 'system') {
      notify();
    }
  });

  function setAppearance(patch = {}, persist = true) {
    currentAppearance = normalizeBrickConsoleAppearance({
      ...currentAppearance,
      ...patch,
    });
    if (persist) {
      writeBrickConsoleAppearancePreference(currentAppearance, storage);
    }
    notify();
    return read();
  }

  function resetAppearance(persist = true) {
    return setAppearance({ ...BRICK_CONSOLE_APPEARANCE_DEFAULTS }, persist);
  }

  return Object.freeze({ read, setAppearance, resetAppearance, dispose: unsubscribe });
}

/**
 * Full personalization matrix for production depth tests and QA.
 * Themes × density × fontSize × locale (fullscreen toggled separately).
 * @returns {Array<{ theme: string, density: string, fontSize: string, locale: string, fullscreenAutoEnter: boolean, resolvedTheme: string }>}
 */
export function listBrickConsoleAppearanceMatrix(options = {}) {
  const media = options.media ?? { matches: false };
  const includeFullscreen = options.includeFullscreen === true;
  const matrix = [];
  for (const theme of BRICK_CONSOLE_THEME_PREFERENCE_NAMES) {
    for (const density of BRICK_CONSOLE_DENSITY_NAMES) {
      for (const fontSize of BRICK_CONSOLE_FONT_SIZE_NAMES) {
        for (const locale of BRICK_CONSOLE_LOCALE_NAMES) {
          const fullscreenValues = includeFullscreen ? [false, true] : [false];
          for (const fullscreenAutoEnter of fullscreenValues) {
            const appearance = normalizeBrickConsoleAppearance({
              theme,
              density,
              fontSize,
              locale,
              fullscreenAutoEnter,
            });
            matrix.push(Object.freeze({
              ...appearance,
              resolvedTheme: resolveBrickConsoleAppearanceTheme(appearance, media),
            }));
          }
        }
      }
    }
  }
  return Object.freeze(matrix);
}

/**
 * Compact human-readable summary for status/toast/a11y announcements.
 * @param {object} appearance
 * @returns {string}
 */
export function summarizeBrickConsoleAppearance(appearance = {}) {
  const normalized = normalizeBrickConsoleAppearance(appearance);
  const resolved = resolveBrickConsoleAppearanceTheme(normalized, appearance.media);
  return [
    `theme=${normalized.theme}`,
    `resolved=${resolved}`,
    `density=${normalized.density}`,
    `font=${normalized.fontSize}`,
    `locale=${normalized.locale}`,
    `fullscreenAutoEnter=${normalized.fullscreenAutoEnter ? 'on' : 'off'}`,
  ].join(' ');
}

/**
 * Structural equality for normalized appearance fields (ignores resolvedTheme).
 * Used by settings dialog dirty-state and product tests.
 */
export function isBrickConsoleAppearanceEqual(left = {}, right = {}) {
  const a = normalizeBrickConsoleAppearance(left);
  const b = normalizeBrickConsoleAppearance(right);
  return (
    a.theme === b.theme
    && a.density === b.density
    && a.fontSize === b.fontSize
    && a.fullscreenAutoEnter === b.fullscreenAutoEnter
    && a.locale === b.locale
  );
}

/**
 * Clear stored personalization keys (canonical + legacy).
 * @param {Storage|null} [storage]
 */
export function clearBrickConsoleAppearancePreference(storage = resolveStorage()) {
  if (!storage || typeof storage.removeItem !== 'function') {
    return;
  }
  for (const key of Object.values(BRICK_CONSOLE_APPEARANCE_STORAGE_KEYS)) {
    try {
      storage.removeItem(key);
    } catch {
      // ignore quota / private mode
    }
  }
  for (const key of Object.values(BRICK_CONSOLE_LEGACY_APPEARANCE_STORAGE_KEYS)) {
    try {
      storage.removeItem(key);
    } catch {
      // ignore
    }
  }
}

function normalizeBooleanPreference(value, defaultValue = false) {
  if (value === true || value === 'true' || value === 1 || value === '1') {
    return true;
  }
  if (value === false || value === 'false' || value === 0 || value === '0') {
    return false;
  }
  return defaultValue;
}

function normalizeBrickConsoleThemeName(theme) {
  if (theme === 'teal') {
    return 'green';
  }
  if (theme === 'indigo') {
    return 'guard';
  }
  return BRICK_CONSOLE_THEME_NAMES.includes(theme) ? theme : 'blue';
}

function normalizeBrickConsoleThemePreference(theme) {
  if (theme === 'system') {
    return 'system';
  }
  return normalizeBrickConsoleThemeName(theme);
}

function resolveStorage() {
  return typeof localStorage === 'undefined' ? null : localStorage;
}

function readStoredValue(storage, key, legacyKey) {
  if (!storage || typeof storage.getItem !== 'function') {
    return null;
  }
  try {
    return storage.getItem(key) ?? storage.getItem(legacyKey);
  } catch {
    return null;
  }
}

function writeStoredValue(storage, key, value) {
  if (!storage || typeof storage.setItem !== 'function') {
    return;
  }
  try {
    storage.setItem(key, value);
  } catch {
  }
}

function resolveSystemColorSchemeMedia() {
  if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') {
    return null;
  }
  try {
    return window.matchMedia('(prefers-color-scheme: dark)');
  } catch {
    return null;
  }
}

function subscribeSystemColorSchemeChange(media, listener) {
  if (!media || typeof listener !== 'function') {
    return () => {};
  }
  if (typeof media.addEventListener === 'function' && typeof media.removeEventListener === 'function') {
    media.addEventListener('change', listener);
    return () => media.removeEventListener('change', listener);
  }
  if (typeof media.addListener === 'function' && typeof media.removeListener === 'function') {
    media.addListener(listener);
    return () => media.removeListener(listener);
  }
  return () => {};
}
