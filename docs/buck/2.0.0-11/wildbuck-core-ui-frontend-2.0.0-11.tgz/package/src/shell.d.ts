import type { Component } from 'vue';

export * from './shell-navigation';
export * from './shell-icons';
export * from './i18n';
export * from './pwa-install';
export * from './workspace-profile';

export interface BrickConsoleShellProps {
  contextPanelOpen?: boolean;
  contextPanelWidth?: string;
}

export declare const BrickConsoleShell: Component;
export declare const BrickConsoleSidebar: Component;
export declare const BrickConsoleDrawer: Component;
export declare const BrickConsoleTopbar: Component;
export declare const BrickConsoleContextHeader: Component;
export declare const BrickConsoleSidebarCollapseToggle: Component;
export declare const BrickConsoleNavIcon: Component;
export declare const BrickAppearanceSettingsDialog: Component;
export declare const BrickChangePasswordDialog: Component;
export declare const BrickUserMenu: Component;
export declare const BrickAppearanceSwitcher: Component;
export declare const BrickWorkspaceProfileSelect: Component;
