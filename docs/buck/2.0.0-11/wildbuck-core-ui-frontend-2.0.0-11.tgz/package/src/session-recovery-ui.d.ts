/**
 * Soft-suspend (SCREEN_LOCK) sets true so domain error toasts
 * do not stack under the global recovery overlay.
 */
export declare function setBrickSessionRecoveryUiActive(active: boolean): void;

export declare function isBrickSessionRecoveryUiActive(): boolean;
