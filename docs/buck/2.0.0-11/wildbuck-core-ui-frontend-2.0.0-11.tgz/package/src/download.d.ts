export function downloadTextFile(
  content: string | BlobPart,
  fileName: string,
  mimeType?: string,
): boolean;
