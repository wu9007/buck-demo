export declare function isBrickFileResourceContentUrl(url: string | null | undefined): boolean;

export declare function createBrickLocalImagePreview(
  file: Blob | File,
  createObjectURL?: (blob: Blob) => string,
): string;

export declare function revokeBrickImagePreview(
  url: string | null | undefined,
  revokeObjectURL?: (url: string) => void,
): void;

export declare function resolveBrickImagePreviewUrl(
  candidate: string | null | undefined,
  localFallback?: string,
): string;

export interface BrickImageUploadResponse {
  resourceId: string;
  contentUrl: string;
}

export declare function uploadBrickImageResource(
  file: File | Blob,
  category?: string,
  options?: {
    request?: (path: string, init?: RequestInit) => Promise<BrickImageUploadResponse>;
  },
): Promise<BrickImageUploadResponse>;

export declare function loadBrickImageResourcePreviewUrl(
  resourceId: string,
  options?: {
    requestBlob?: (path: string, init?: RequestInit) => Promise<Blob>;
    createObjectURL?: (blob: Blob) => string;
  },
): Promise<string>;
