/**
 * Workspace Profile (工位视图): UI-only focus within principal.permissions.
 * Never changes token or IAM authorization. Filtered menus must stay a subset
 * of permission-allowed routes.
 */

import { canAccessBrickConsoleRoute } from './shell-navigation.js';

export const BRICK_CONSOLE_WORKSPACE_PROFILE_STORAGE_KEY = 'brick-console:workspace-profile';

/**
 * @typedef {{
 *   id: string,
 *   title?: string,
 *   label?: string,
 *   defaultPath?: string,
 *   routeIds?: string[],
 *   menuIds?: string[],
 *   pathPrefixes?: string[],
 *   requiredPermissions?: string[],
 *   anyPermissions?: string[],
 * }} BrickWorkspaceProfile
 */

/**
 * @param {unknown} profile
 * @returns {BrickWorkspaceProfile | null}
 */
export function normalizeBrickWorkspaceProfile(profile) {
  if (profile == null || typeof profile !== 'object' || Array.isArray(profile)) {
    return null;
  }
  const id = String(profile.id ?? '').trim();
  if (!id) {
    return null;
  }
  return {
    id,
    title: normalizeOptionalText(profile.title ?? profile.label),
    label: normalizeOptionalText(profile.label ?? profile.title),
    defaultPath: normalizeOptionalText(profile.defaultPath),
    routeIds: normalizeStringArray(profile.routeIds),
    menuIds: normalizeStringArray(profile.menuIds),
    pathPrefixes: normalizeStringArray(profile.pathPrefixes),
    requiredPermissions: normalizeStringArray(profile.requiredPermissions),
    anyPermissions: normalizeStringArray(profile.anyPermissions),
  };
}

/**
 * @param {unknown[]} profiles
 * @returns {BrickWorkspaceProfile[]}
 */
export function normalizeBrickWorkspaceProfiles(profiles = []) {
  if (!Array.isArray(profiles)) {
    return [];
  }
  const seen = new Set();
  const normalized = [];
  for (const entry of profiles) {
    const profile = normalizeBrickWorkspaceProfile(entry);
    if (!profile || seen.has(profile.id)) {
      continue;
    }
    seen.add(profile.id);
    normalized.push(profile);
  }
  return normalized;
}

/**
 * Profile is available when principal satisfies requiredPermissions (all)
 * and anyPermissions (at least one when non-empty). Empty gates mean open to all.
 *
 * @param {unknown} profile
 * @param {Iterable<string>} [permissions]
 * @returns {boolean}
 */
export function isBrickWorkspaceProfileAvailable(profile, permissions = []) {
  const normalized = normalizeBrickWorkspaceProfile(profile);
  if (!normalized) {
    return false;
  }
  const granted = new Set(
    Array.isArray(permissions) || permissions instanceof Set
      ? permissions
      : [],
  );
  for (const code of normalized.requiredPermissions) {
    if (!granted.has(code)) {
      return false;
    }
  }
  if (normalized.anyPermissions.length > 0) {
    const hit = normalized.anyPermissions.some((code) => granted.has(code));
    if (!hit) {
      return false;
    }
  }
  return true;
}

/**
 * @param {unknown[]} profiles
 * @param {Iterable<string>} [permissions]
 * @returns {BrickWorkspaceProfile[]}
 */
export function listAvailableBrickWorkspaceProfiles(profiles = [], permissions = []) {
  return normalizeBrickWorkspaceProfiles(profiles).filter((profile) =>
    isBrickWorkspaceProfileAvailable(profile, permissions),
  );
}

/**
 * Prefer preferredId when available; otherwise first available profile id; else ''.
 *
 * @param {unknown[]} profiles
 * @param {Iterable<string>} [permissions]
 * @param {string} [preferredId]
 * @returns {string}
 */
export function resolveBrickWorkspaceProfileId(profiles = [], permissions = [], preferredId = '') {
  const available = listAvailableBrickWorkspaceProfiles(profiles, permissions);
  if (available.length === 0) {
    return '';
  }
  const preferred = String(preferredId ?? '').trim();
  if (preferred && available.some((profile) => profile.id === preferred)) {
    return preferred;
  }
  return available[0].id;
}

/**
 * @param {unknown[]} profiles
 * @param {string} profileId
 * @returns {BrickWorkspaceProfile | null}
 */
export function findBrickWorkspaceProfile(profiles = [], profileId = '') {
  const id = String(profileId ?? '').trim();
  if (!id) {
    return null;
  }
  return normalizeBrickWorkspaceProfiles(profiles).find((profile) => profile.id === id) ?? null;
}

/**
 * When profile has no route/menu/path selectors, every permission-allowed route matches.
 *
 * @param {unknown} route
 * @param {unknown} profile
 * @returns {boolean}
 */
export function routeMatchesBrickWorkspaceProfile(route, profile) {
  const normalized = normalizeBrickWorkspaceProfile(profile);
  if (!normalized || !route || typeof route !== 'object') {
    return false;
  }
  const hasSelectors = normalized.routeIds.length > 0
    || normalized.menuIds.length > 0
    || normalized.pathPrefixes.length > 0;
  if (!hasSelectors) {
    return true;
  }

  const routeId = String(route.id ?? '').trim();
  const menuId = String(route.menuId ?? route.menu?.id ?? route.menu?.code ?? '').trim();
  const path = normalizePath(route.path);

  if (routeId && normalized.routeIds.includes(routeId)) {
    return true;
  }
  if (routeId && normalized.menuIds.includes(routeId)) {
    return true;
  }
  if (menuId && normalized.menuIds.includes(menuId)) {
    return true;
  }
  if (path) {
    for (const prefix of normalized.pathPrefixes) {
      const normalizedPrefix = normalizePath(prefix);
      if (!normalizedPrefix) {
        continue;
      }
      if (path === normalizedPrefix || path.startsWith(`${normalizedPrefix}/`)) {
        return true;
      }
    }
  }
  return false;
}

/**
 * Filter routes: permission gate first, then profile membership.
 *
 * @param {unknown[]} routes
 * @param {unknown} profile
 * @param {Iterable<string>} [permissions]
 * @returns {object[]}
 */
export function filterBrickConsoleRoutesByWorkspaceProfile(routes = [], profile = null, permissions = []) {
  const list = Array.isArray(routes) ? routes : [];
  const normalizedProfile = normalizeBrickWorkspaceProfile(profile);
  return list.filter((route) => {
    if (!canAccessBrickConsoleRoute(route, permissions)) {
      return false;
    }
    if (!normalizedProfile) {
      return true;
    }
    return routeMatchesBrickWorkspaceProfile(route, normalizedProfile);
  });
}

/**
 * Filter navigation groups in place structurally; drop empty groups.
 *
 * @param {unknown[]} groups
 * @param {unknown} profile
 * @param {Iterable<string>} [permissions]
 * @returns {object[]}
 */
export function filterBrickConsoleNavigationGroupsByWorkspaceProfile(
  groups = [],
  profile = null,
  permissions = [],
) {
  const list = Array.isArray(groups) ? groups : [];
  return list
    .map((group) => {
      if (!group || typeof group !== 'object') {
        return null;
      }
      const routes = filterBrickConsoleRoutesByWorkspaceProfile(
        group.routes ?? [],
        profile,
        permissions,
      );
      if (routes.length === 0) {
        return null;
      }
      return {
        ...group,
        routes,
      };
    })
    .filter(Boolean);
}

/**
 * @param {Storage | null} [storage]
 * @returns {string}
 */
export function readBrickWorkspaceProfilePreference(storage = resolveStorage()) {
  if (!storage || typeof storage.getItem !== 'function') {
    return '';
  }
  try {
    return String(storage.getItem(BRICK_CONSOLE_WORKSPACE_PROFILE_STORAGE_KEY) ?? '').trim();
  } catch {
    return '';
  }
}

/**
 * @param {string} profileId
 * @param {Storage | null} [storage]
 * @returns {string}
 */
export function writeBrickWorkspaceProfilePreference(profileId, storage = resolveStorage()) {
  const value = String(profileId ?? '').trim();
  if (!storage || typeof storage.setItem !== 'function') {
    return value;
  }
  try {
    if (!value) {
      if (typeof storage.removeItem === 'function') {
        storage.removeItem(BRICK_CONSOLE_WORKSPACE_PROFILE_STORAGE_KEY);
      }
      return '';
    }
    storage.setItem(BRICK_CONSOLE_WORKSPACE_PROFILE_STORAGE_KEY, value);
  } catch {
    // ignore quota / private mode
  }
  return value;
}

function normalizeOptionalText(value) {
  const text = String(value ?? '').trim();
  return text || undefined;
}

function normalizeStringArray(value) {
  if (!Array.isArray(value)) {
    return [];
  }
  const result = [];
  const seen = new Set();
  for (const entry of value) {
    const text = String(entry ?? '').trim();
    if (!text || seen.has(text)) {
      continue;
    }
    seen.add(text);
    result.push(text);
  }
  return result;
}

function normalizePath(path) {
  const text = String(path ?? '').trim();
  if (!text) {
    return '';
  }
  const withSlash = text.startsWith('/') ? text : `/${text}`;
  if (withSlash.length > 1 && withSlash.endsWith('/')) {
    return withSlash.slice(0, -1);
  }
  return withSlash;
}

function resolveStorage() {
  return typeof localStorage === 'undefined' ? null : localStorage;
}
