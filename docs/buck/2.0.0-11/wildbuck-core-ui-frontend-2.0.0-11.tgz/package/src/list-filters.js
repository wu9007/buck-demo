import { reactive } from 'vue';

/**
 * 列表筛选草稿模型（可复用约定）。
 *
 * ## 为何需要
 * 把 filters 当 prop 下传，再在子组件里 `v-model="filters.keyword"` 改 prop 字段时：
 * - 违反单向数据流
 * - 重置后父组件已改空，Element Plus 输入框/下拉常因内部状态不刷新而「看起来没清空」
 *
 * ## 约定
 * 1. 控件只绑定 **draft**（本地草稿）
 * 2. 「查询」：`snapshot()` 交给父组件发请求
 * 3. 「重置」：`resetDraft()` 再 `snapshot()` 交给父组件发请求
 * 4. 布局继续用 `BrickFilterToolbar`；字段仍由业务 slot 声明
 * 5. 不要用 `<form>` 包筛选栏；查询/重置按钮一律 `native-type="button"`
 *
 * @param {() => Record<string, unknown>} createDefaults 返回默认条件的工厂（每次 reset 重新调用）
 */
export function useBrickFilterDraft(createDefaults) {
  if (typeof createDefaults !== 'function') {
    throw new TypeError('useBrickFilterDraft(createDefaults) requires a factory function');
  }

  const draft = reactive({ ...createDefaults() });

  function resetDraft() {
    const fresh = { ...createDefaults() };
    for (const key of Object.keys(draft)) {
      if (!(key in fresh)) {
        delete draft[key];
      }
    }
    Object.assign(draft, fresh);
    return snapshot();
  }

  function replaceDraft(next) {
    const fresh = { ...(next || createDefaults()) };
    for (const key of Object.keys(draft)) {
      if (!(key in fresh)) {
        delete draft[key];
      }
    }
    Object.assign(draft, fresh);
    return snapshot();
  }

  function snapshot() {
    return { ...draft };
  }

  return {
    draft,
    resetDraft,
    replaceDraft,
    snapshot,
    defaultsOf: () => ({ ...createDefaults() }),
  };
}
