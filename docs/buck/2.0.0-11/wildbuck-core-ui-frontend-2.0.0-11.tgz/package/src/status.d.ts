export type BrickStatusType = 'success' | 'warning' | 'info' | 'error';

export type BrickStatusOptions = {
  duration?: number;
  grouping?: boolean;
  showClose?: boolean;
  center?: boolean;
  offset?: number;
};

export type BrickValidationFocusTarget = {
  focus: (options?: FocusOptions) => void;
} | null | undefined;

export type BrickRequiredFieldDefinition = {
  label: string;
  value: unknown;
  message?: string;
  focusTarget?: BrickValidationFocusTarget | BrickValidationFocusTarget[];
  validate?: (value: unknown) => boolean;
};

export type BrickRequiredFieldValidationOptions = {
  focus?: boolean;
  showStatus?: boolean;
  statusOptions?: BrickStatusOptions;
  type?: BrickStatusType;
};

export type BrickRequiredFieldValidationResult = {
  ok: boolean;
  invalidField: BrickRequiredFieldDefinition | null;
  message: string;
};

/**
 * Soft-suspend (SCREEN_LOCK) should set true so domain error toasts
 * do not stack under the global recovery overlay.
 */
export declare function setBrickSessionRecoveryUiActive(active: boolean): void;

export declare function isBrickSessionRecoveryUiActive(): boolean;

export declare function showBrickStatus(
  message: string,
  type?: BrickStatusType,
  options?: BrickStatusOptions & { force?: boolean },
): void;

export type BrickBusinessErrorStatusOptions = {
  type?: BrickStatusType;
  includeRecovery?: boolean;
  statusOptions?: BrickStatusOptions;
};

/**
 * Toast a business rejection. Prefer payload.message / recovery over bare "HTTP nnn".
 * Returns the text shown (or empty string when nothing is displayed).
 */
export declare function showBrickBusinessError(
  error: unknown,
  options?: BrickBusinessErrorStatusOptions,
): string;

export declare function validateBrickRequiredFields(
  fields: BrickRequiredFieldDefinition[],
  options?: BrickRequiredFieldValidationOptions,
): BrickRequiredFieldValidationResult;
