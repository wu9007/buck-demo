/**
 * Browser PWA install helpers for console shells.
 * Brand, manifest and service worker stay in the host app; core only owns the install prompt UX contract.
 */

/** Default toast when prompt is unavailable (Chrome/Edge + HTTPS/localhost). */
export const BRICK_PWA_INSTALL_UNAVAILABLE_MESSAGE =
  '当前浏览器暂不可安装。请使用 Chrome/Edge，并通过 HTTPS 或 localhost 访问。';

/**
 * @param {Window | null | undefined} [windowRef]
 * @returns {boolean}
 */
export function isBrickPwaStandalone(windowRef) {
  const win = windowRef || (typeof window !== 'undefined' ? window : null);
  if (!win) {
    return false;
  }
  const media = typeof win.matchMedia === 'function'
    ? win.matchMedia('(display-mode: standalone)').matches
    : false;
  const iosStandalone = Boolean(win.navigator && win.navigator.standalone);
  return media || iosStandalone;
}

/**
 * @param {{ serviceWorkerUrl?: string, scope?: string, windowRef?: Window }} [options]
 * @returns {Promise<ServiceWorkerRegistration | null>}
 */
export async function registerBrickPwaServiceWorker(options = {}) {
  const win = options.windowRef || (typeof window !== 'undefined' ? window : null);
  if (!win || !win.navigator || !('serviceWorker' in win.navigator)) {
    return null;
  }
  const url = options.serviceWorkerUrl || '/sw.js';
  const registration = await win.navigator.serviceWorker.register(url, {
    scope: options.scope || '/',
  });
  return registration;
}

/**
 * Menu/shell binding: show install only when browser offers prompt and not already standalone.
 * @param {{ canInstall?: boolean, isStandalone?: boolean }} snapshot
 * @returns {boolean}
 */
export function resolveBrickPwaCanInstallApp(snapshot = {}) {
  return Boolean(snapshot.canInstall) && !Boolean(snapshot.isStandalone);
}

/**
 * @param {{ windowRef?: Window, documentRef?: Document }} [options]
 * @returns {{
 *   canInstall: boolean,
 *   isStandalone: boolean,
 *   isSupported: boolean,
 *   subscribe: (listener: (snapshot: { canInstall: boolean, isStandalone: boolean }) => void) => () => void,
 *   promptInstall: () => Promise<'accepted' | 'dismissed' | 'unavailable'>,
 *   dispose: () => void,
 * }}
 */
export function createBrickPwaInstallController(options = {}) {
  const win = options.windowRef || (typeof window !== 'undefined' ? window : null);
  const doc = options.documentRef || (typeof document !== 'undefined' ? document : null);

  /** @type {BeforeInstallPromptEvent | null} */
  let deferredPrompt = null;
  const listeners = new Set();

  const state = {
    canInstall: false,
    isStandalone: isBrickPwaStandalone(win),
  };

  function notify() {
    for (const listener of listeners) {
      listener({ ...state });
    }
  }

  function setCanInstall(value) {
    state.canInstall = Boolean(value);
    notify();
  }

  function refreshStandalone() {
    state.isStandalone = isBrickPwaStandalone(win);
    if (state.isStandalone) {
      deferredPrompt = null;
      setCanInstall(false);
    } else {
      notify();
    }
  }

  /**
   * @param {Event} event
   */
  function onBeforeInstallPrompt(event) {
    event.preventDefault();
    deferredPrompt = /** @type {BeforeInstallPromptEvent} */ (event);
    setCanInstall(true);
  }

  function onAppInstalled() {
    deferredPrompt = null;
    setCanInstall(false);
    refreshStandalone();
  }

  const isSupported = Boolean(
    win
    && typeof win.addEventListener === 'function'
    && 'serviceWorker' in (win.navigator || {}),
  );

  if (isSupported && win) {
    win.addEventListener('beforeinstallprompt', onBeforeInstallPrompt);
    win.addEventListener('appinstalled', onAppInstalled);
    if (win.matchMedia) {
      const media = win.matchMedia('(display-mode: standalone)');
      if (typeof media.addEventListener === 'function') {
        media.addEventListener('change', refreshStandalone);
      } else if (typeof media.addListener === 'function') {
        media.addListener(refreshStandalone);
      }
    }
  }

  return {
    get canInstall() {
      return state.canInstall;
    },
    get isStandalone() {
      return state.isStandalone;
    },
    isSupported,
    /**
     * @param {(snapshot: { canInstall: boolean, isStandalone: boolean }) => void} listener
     */
    subscribe(listener) {
      listeners.add(listener);
      listener({ ...state });
      return () => listeners.delete(listener);
    },
    /**
     * @returns {Promise<'accepted' | 'dismissed' | 'unavailable'>}
     */
    async promptInstall() {
      if (!deferredPrompt || typeof deferredPrompt.prompt !== 'function') {
        return 'unavailable';
      }
      deferredPrompt.prompt();
      const choice = deferredPrompt.userChoice
        ? await deferredPrompt.userChoice
        : { outcome: 'dismissed' };
      deferredPrompt = null;
      setCanInstall(false);
      return choice?.outcome === 'accepted' ? 'accepted' : 'dismissed';
    },
    dispose() {
      if (win) {
        win.removeEventListener('beforeinstallprompt', onBeforeInstallPrompt);
        win.removeEventListener('appinstalled', onAppInstalled);
      }
      listeners.clear();
      deferredPrompt = null;
      void doc;
    },
  };
}

/**
 * Whether the composable should register a service worker from options.
 * @param {{ registerServiceWorker?: boolean, serviceWorkerUrl?: string }} options
 * @returns {boolean}
 */
function shouldRegisterServiceWorker(options) {
  if (options.registerServiceWorker === false) {
    return false;
  }
  if (options.registerServiceWorker === true) {
    return true;
  }
  return typeof options.serviceWorkerUrl === 'string' && options.serviceWorkerUrl.length > 0;
}

/**
 * Vue-friendly install wiring for console shells.
 * - `canInstallApp`: bind to BrickConsoleShell `can-install-app` (prompt available && not standalone)
 * - `installApp`: bind to `@install-app` (prompt + optional onUnavailable)
 * - pass `serviceWorkerUrl` (or `registerServiceWorker: true`) to register SW on mount
 * Host still owns manifest / icons / SW file content and anonymous auth for those assets.
 *
 * @param {{
 *   windowRef?: Window,
 *   documentRef?: Document,
 *   serviceWorkerUrl?: string,
 *   scope?: string,
 *   registerServiceWorker?: boolean,
 *   onUnavailable?: () => void,
 *   vue?: {
 *     ref: Function,
 *     onMounted?: Function,
 *     onScopeDispose?: Function,
 *   },
 * }} [options]
 */
export function useBrickPwaInstall(options = {}) {
  const controller = createBrickPwaInstallController(options);
  const vue = options.vue;
  let disposed = false;

  function registerSwIfNeeded() {
    if (disposed || !shouldRegisterServiceWorker(options)) {
      return;
    }
    registerBrickPwaServiceWorker({
      serviceWorkerUrl: options.serviceWorkerUrl || '/sw.js',
      scope: options.scope || '/',
      windowRef: options.windowRef,
    }).catch(() => {
      // Install UI still works when SW registration fails; browser may hide native prompt.
    });
  }

  /**
   * @returns {Promise<'accepted' | 'dismissed' | 'unavailable'>}
   */
  async function installApp() {
    const outcome = await controller.promptInstall();
    if (outcome === 'unavailable' && typeof options.onUnavailable === 'function') {
      options.onUnavailable();
    }
    return outcome;
  }

  function dispose() {
    if (disposed) {
      return;
    }
    disposed = true;
    controller.dispose();
  }

  if (!vue || typeof vue.ref !== 'function') {
    const canInstall = { value: controller.canInstall };
    const isStandalone = { value: controller.isStandalone };
    const canInstallApp = {
      value: resolveBrickPwaCanInstallApp({
        canInstall: controller.canInstall,
        isStandalone: controller.isStandalone,
      }),
    };
    const unsubscribe = controller.subscribe((snapshot) => {
      canInstall.value = snapshot.canInstall;
      isStandalone.value = snapshot.isStandalone;
      canInstallApp.value = resolveBrickPwaCanInstallApp(snapshot);
    });
    registerSwIfNeeded();
    return {
      controller,
      canInstall,
      canInstallApp,
      isStandalone,
      isSupported: controller.isSupported,
      promptInstall: () => controller.promptInstall(),
      installApp,
      dispose: () => {
        unsubscribe();
        dispose();
      },
    };
  }

  const canInstall = vue.ref(controller.canInstall);
  const isStandalone = vue.ref(controller.isStandalone);
  const canInstallApp = vue.ref(resolveBrickPwaCanInstallApp({
    canInstall: controller.canInstall,
    isStandalone: controller.isStandalone,
  }));
  const unsubscribe = controller.subscribe((snapshot) => {
    canInstall.value = snapshot.canInstall;
    isStandalone.value = snapshot.isStandalone;
    canInstallApp.value = resolveBrickPwaCanInstallApp(snapshot);
  });

  if (typeof vue.onMounted === 'function') {
    vue.onMounted(() => {
      registerSwIfNeeded();
    });
  } else {
    registerSwIfNeeded();
  }

  if (typeof vue.onScopeDispose === 'function') {
    vue.onScopeDispose(() => {
      unsubscribe();
      dispose();
    });
  }

  return {
    controller,
    canInstall,
    canInstallApp,
    isStandalone,
    isSupported: controller.isSupported,
    promptInstall: () => controller.promptInstall(),
    installApp,
    dispose: () => {
      unsubscribe();
      dispose();
    },
  };
}
