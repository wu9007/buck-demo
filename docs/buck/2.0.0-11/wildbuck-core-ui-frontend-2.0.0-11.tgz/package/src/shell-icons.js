/**
 * Formal console nav line-icon names and resolution helpers.
 * Prefer explicit route.iconName; otherwise infer from route id/path/title.
 */

export const BRICK_CONSOLE_NAV_ICON_NAMES = Object.freeze([
  'menu',
  'home',
  'users',
  'org',
  'role',
  'session',
  'audit',
  'lock',
  'key',
  'network',
  'mail',
  'app',
  'ai',
  'settings',
  'grid',
]);

const ICON_ALIASES = Object.freeze({
  user: 'users',
  employee: 'users',
  employees: 'users',
  people: 'users',
  organization: 'org',
  organizations: 'org',
  org: 'org',
  team: 'org',
  role: 'role',
  roles: 'role',
  shield: 'role',
  auth: 'role',
  permission: 'role',
  menu: 'menu',
  menus: 'menu',
  list: 'menu',
  session: 'session',
  sessions: 'session',
  monitor: 'session',
  home: 'home',
  me: 'home',
  profile: 'home',
  principal: 'home',
  audit: 'audit',
  log: 'audit',
  logs: 'audit',
  lock: 'lock',
  security: 'lock',
  login: 'lock',
  key: 'key',
  password: 'key',
  secret: 'key',
  network: 'network',
  transport: 'network',
  mail: 'mail',
  email: 'mail',
  smtp: 'mail',
  notification: 'mail',
  app: 'app',
  application: 'app',
  applications: 'app',
  center: 'app',
  ai: 'ai',
  assistant: 'ai',
  model: 'ai',
  settings: 'settings',
  setting: 'settings',
  config: 'settings',
  grid: 'grid',
  generic: 'grid',
  default: 'menu',
});

const INFERENCE_RULES = Object.freeze([
  { name: 'users', pattern: /employee|人员|员工|user(?!r)/i },
  { name: 'org', pattern: /organiz|org\.|组织|部门/i },
  { name: 'role', pattern: /role|角色|权限|authoriz/i },
  { name: 'menu', pattern: /menu|菜单/i },
  { name: 'session', pattern: /session|会话|token/i },
  { name: 'home', pattern: /current-principal|home|我的|个人/i },
  { name: 'audit', pattern: /audit|日志|log\b/i },
  { name: 'key', pattern: /password|密码|secret/i },
  { name: 'lock', pattern: /login-security|security|登录安全|安全设置/i },
  { name: 'network', pattern: /transport|传输|network|tls/i },
  { name: 'mail', pattern: /mail|smtp|email|通知|notification/i },
  { name: 'app', pattern: /application|应用中心|app\.|apps/i },
  { name: 'ai', pattern: /ai-|assistant|model-service|智能/i },
  { name: 'settings', pattern: /setting|配置|policy|策略/i },
]);

function normalizeIconToken(value) {
  return String(value ?? '')
    .trim()
    .toLowerCase()
    .replace(/^icon[-_:]/, '')
    .replace(/[\s_]+/g, '-');
}

export function isBrickConsoleNavIconName(name) {
  const normalized = normalizeIconToken(name);
  if (!normalized) {
    return false;
  }
  if (BRICK_CONSOLE_NAV_ICON_NAMES.includes(normalized)) {
    return true;
  }
  return Boolean(ICON_ALIASES[normalized]);
}

export function normalizeBrickConsoleNavIconName(name) {
  const normalized = normalizeIconToken(name);
  if (!normalized) {
    return '';
  }
  if (BRICK_CONSOLE_NAV_ICON_NAMES.includes(normalized)) {
    return normalized;
  }
  return ICON_ALIASES[normalized] || '';
}

/**
 * Resolve a formal line-icon name for console navigation fallback marks.
 *
 * This is only used when route.iconUrl (menu-uploaded image) and a component
 * icon are both absent. Uploaded menu icons always take precedence in the shell.
 *
 * Resolution: explicit iconName / string icon, else infer from id/path/title.
 */
export function resolveBrickConsoleNavIconName(route) {
  const explicit = normalizeBrickConsoleNavIconName(
    route?.iconName
    ?? (typeof route?.icon === 'string' ? route.icon : '')
    ?? route?.menu?.iconName
    ?? (typeof route?.menu?.icon === 'string' ? route.menu.icon : ''),
  );
  if (explicit) {
    return explicit;
  }

  const haystack = [
    route?.id,
    route?.path,
    route?.title,
    route?.name,
    route?.group,
    route?.featureKey,
  ]
    .filter(Boolean)
    .join(' ');

  for (const rule of INFERENCE_RULES) {
    if (rule.pattern.test(haystack)) {
      return rule.name;
    }
  }

  return 'menu';
}
