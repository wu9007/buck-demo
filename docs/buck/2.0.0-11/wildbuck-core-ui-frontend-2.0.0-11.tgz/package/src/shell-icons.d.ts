export declare const BRICK_CONSOLE_NAV_ICON_NAMES: readonly string[];

export declare function isBrickConsoleNavIconName(name?: string | null): boolean;
export declare function normalizeBrickConsoleNavIconName(name?: string | null): string;
export declare function resolveBrickConsoleNavIconName(route?: {
  id?: string;
  path?: string;
  title?: string;
  name?: string;
  group?: string;
  featureKey?: string;
  icon?: string | unknown;
  iconName?: string;
  menu?: {
    icon?: string | unknown;
    iconName?: string;
  };
} | null): string;
