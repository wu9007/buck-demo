import { ElMessage } from 'element-plus/es/components/message/index.mjs';
import 'element-plus/es/components/message/style/css';
import {
  formatBrickBusinessError,
  isBareHttpStatusMessage,
} from '@wildbuck/core-api-frontend';
import {
  isBrickSessionRecoveryUiActive,
  setBrickSessionRecoveryUiActive,
} from './session-recovery-ui.js';

export {
  isBrickSessionRecoveryUiActive,
  setBrickSessionRecoveryUiActive,
};

const BRICK_STATUS_TYPES = ['success', 'warning', 'info', 'error'];

const BRICK_STATUS_DURATION = {
  success: 2400,
  warning: 2800,
  info: 2400,
  error: 3600,
};

export function showBrickStatus(message, type = 'info', options = {}) {
  if (!message) {
    return;
  }
  const normalizedType = BRICK_STATUS_TYPES.includes(type) ? type : 'info';
  // Recovery overlay is the only session UI: suppress competing domain toasts.
  // Allow success after unlock (caller clears recovery flag first).
  if (isBrickSessionRecoveryUiActive() && normalizedType !== 'success' && options.force !== true) {
    return;
  }
  const text = String(message);
  // Errors with longer recovery copy need more reading time.
  const autoDuration = normalizedType === 'error' && text.length > 36
    ? Math.min(7200, 3600 + Math.floor((text.length - 36) * 40))
    : BRICK_STATUS_DURATION[normalizedType];
  const { force: _force, ...elOptions } = options;
  ElMessage({
    type: normalizedType,
    message: text,
    grouping: true,
    duration: elOptions.duration ?? autoDuration,
    showClose: elOptions.showClose ?? (normalizedType === 'error' && text.length > 48),
    ...elOptions,
  });
}

/**
 * Toast a business rejection. Prefer payload.message / recovery over bare "HTTP nnn".
 * Session errors should still use createBrickSessionErrorHandler; this is for domain 4xx.
 *
 * Unified with @wildbuck/core-api-frontend formatBrickBusinessError (message。recovery。).
 */
export function showBrickBusinessError(error, options = {}) {
  if (error == null) {
    return '';
  }
  let text = '';
  if (typeof error === 'string') {
    text = isBareHttpStatusMessage(error) ? '操作失败，请稍后重试。' : error.trim();
  } else {
    text = formatBrickBusinessError(error, {
      includeRecovery: options.includeRecovery !== false,
      localeHint: options.localeHint,
    });
  }
  if (!text) {
    return '';
  }
  showBrickStatus(text, options.type || 'error', options.statusOptions || {});
  return text;
}

export function validateBrickRequiredFields(fields, options = {}) {
  const invalidField = Array.isArray(fields)
    ? fields.find((field) => !isBrickRequiredFieldValid(field))
    : null;
  if (!invalidField) {
    return {
      ok: true,
      invalidField: null,
      message: '',
    };
  }

  const message = invalidField.message || `请先填写${invalidField.label}。`;
  if (options.showStatus !== false) {
    showBrickStatus(message, options.type || 'error', options.statusOptions || {});
  }
  if (options.focus !== false) {
    focusBrickValidationTarget(invalidField.focusTarget);
  }

  return {
    ok: false,
    invalidField,
    message,
  };
}

function isBrickRequiredFieldValid(field) {
  if (!field || typeof field !== 'object') {
    return false;
  }
  if (typeof field.validate === 'function') {
    return field.validate(field.value);
  }
  return hasBrickRequiredValue(field.value);
}

function hasBrickRequiredValue(value) {
  if (typeof value === 'string') {
    return value.trim().length > 0;
  }
  if (Array.isArray(value)) {
    return value.length > 0;
  }
  return value !== null && value !== undefined;
}

function focusBrickValidationTarget(target) {
  const candidates = Array.isArray(target) ? target : [target];
  for (const candidate of candidates) {
    if (!candidate || typeof candidate.focus !== 'function') {
      continue;
    }
    try {
      candidate.focus({ preventScroll: false });
    } catch {
      candidate.focus();
    }
    return;
  }
}
