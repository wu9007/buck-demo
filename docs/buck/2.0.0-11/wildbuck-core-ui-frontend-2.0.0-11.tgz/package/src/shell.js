import BrickConsoleShell from './components/BrickConsoleShell.vue';
import BrickConsoleSidebar from './components/BrickConsoleSidebar.vue';
import BrickConsoleDrawer from './components/BrickConsoleDrawer.vue';
import BrickConsoleTopbar from './components/BrickConsoleTopbar.vue';
import BrickConsoleContextHeader from './components/BrickConsoleContextHeader.vue';
import BrickConsoleSidebarCollapseToggle from './components/BrickConsoleSidebarCollapseToggle.vue';
import BrickConsoleNavIcon from './components/BrickConsoleNavIcon.vue';
import BrickAppearanceSwitcher from './components/BrickAppearanceSwitcher.vue';
import BrickAppearanceSettingsDialog from './components/BrickAppearanceSettingsDialog.vue';
import BrickChangePasswordDialog from './components/BrickChangePasswordDialog.vue';
import BrickUserMenu from './components/BrickUserMenu.vue';
import BrickWorkspaceProfileSelect from './components/BrickWorkspaceProfileSelect.vue';

export * from './shell-navigation.js';
export * from './shell-icons.js';
export * from './i18n.js';
export * from './pwa-install.js';
export * from './workspace-profile.js';
export * from './user-menu.js';
export * from './topbar.js';

export {
  BrickConsoleShell,
  BrickConsoleSidebar,
  BrickConsoleDrawer,
  BrickConsoleTopbar,
  BrickConsoleContextHeader,
  BrickConsoleSidebarCollapseToggle,
  BrickConsoleNavIcon,
  BrickAppearanceSettingsDialog,
  BrickChangePasswordDialog,
  BrickUserMenu,
  BrickAppearanceSwitcher,
  BrickWorkspaceProfileSelect,
};
