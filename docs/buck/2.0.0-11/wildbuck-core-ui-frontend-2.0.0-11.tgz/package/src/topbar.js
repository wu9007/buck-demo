/**
 * Pure helpers for BrickConsoleTopbar breadcrumbs and action visibility.
 */

export function breadcrumbLabel(item) {
  if (item == null) {
    return '';
  }
  if (typeof item === 'string' || typeof item === 'number' || typeof item === 'boolean') {
    return String(item);
  }
  return String(item?.label ?? item?.title ?? '');
}

export function breadcrumbTitle(item) {
  if (item == null) {
    return '';
  }
  if (typeof item === 'string' || typeof item === 'number' || typeof item === 'boolean') {
    return String(item);
  }
  return String(item?.title ?? item?.label ?? '');
}

export function normalizeBreadcrumbs(items) {
  if (!Array.isArray(items)) {
    return [];
  }
  return items
    .map((item) => {
      const label = breadcrumbLabel(item);
      if (!label) {
        return null;
      }
      return {
        label,
        title: breadcrumbTitle(item) || label,
      };
    })
    .filter(Boolean);
}

export function shouldShowFullscreenButton(options = {}) {
  return Boolean(options.fullscreenEnabled && options.fullscreenSupported);
}

export function resolveFullscreenAction(options = {}) {
  if (!shouldShowFullscreenButton(options)) {
    return null;
  }
  return options.fullscreenActive ? 'exit' : 'enter';
}

export function shouldShowRefreshButton(options = {}) {
  return Boolean(options.refreshEnabled);
}

export function shouldUseUserMenuAppearanceEntry(appearanceEntry = 'user-menu') {
  return appearanceEntry === 'user-menu';
}
