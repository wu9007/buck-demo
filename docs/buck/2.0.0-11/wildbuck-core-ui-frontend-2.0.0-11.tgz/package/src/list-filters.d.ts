import type { Reactive } from 'vue';

export interface BrickFilterDraftApi<T extends Record<string, unknown>> {
  /** 控件绑定的本地草稿（不要 v-model 到父 prop） */
  draft: Reactive<T>;
  /** 恢复默认条件，返回快照 */
  resetDraft: () => T;
  /** 用外部值整体替换草稿（可选） */
  replaceDraft: (next?: Partial<T> | T) => T;
  /** 当前草稿浅拷贝，供查询请求使用 */
  snapshot: () => T;
  /** 默认条件快照 */
  defaultsOf: () => T;
}

/**
 * 列表筛选草稿：查询/重置的可复用状态模型。
 * @see docs/architecture/capabilities/frontend-structure.md「列表筛选」
 */
export function useBrickFilterDraft<T extends Record<string, unknown>>(
  createDefaults: () => T,
): BrickFilterDraftApi<T>;
