/**
 * Pure helpers for console topbar avatar / account menu (production UX).
 */

export function resolveUserMenuDisplayName(principalName, anonymousLabel = '未登录') {
  const name = String(principalName || '').trim();
  return name || anonymousLabel;
}

export function resolveUserMenuInitial(principalName, anonymousInitial = '未') {
  const name = String(principalName || '').trim();
  if (!name) {
    return String(anonymousInitial || '未').slice(0, 1);
  }
  // Prefer first CJK/latin character; skip email domain noise.
  const local = name.includes('@') ? name.split('@')[0] : name;
  return local.slice(0, 1).toUpperCase();
}

export function resolveUserMenuAvatarAlt(displayName, template = '{name} 头像') {
  const name = String(displayName || '').trim() || 'user';
  return String(template || '{name} 头像').replaceAll('{name}', name);
}

/**
 * Build ordered menu items for the account dropdown.
 * @returns {Array<{ id: string, kind: 'action'|'danger'|'separator', enabled: boolean }>}
 */
export function buildUserMenuItems(options = {}) {
  const {
    canInstallApp = false,
    showAppearanceSettings = true,
    showChangePassword = true,
  } = options;
  const items = [];
  if (canInstallApp) {
    items.push({ id: 'install-app', kind: 'action', enabled: true });
  }
  if (showAppearanceSettings) {
    items.push({ id: 'personalization', kind: 'action', enabled: true });
  }
  // Self-service password change (account owner); shells wire emit → IAM password stage.
  if (showChangePassword) {
    items.push({ id: 'change-password', kind: 'action', enabled: true });
  }
  if (items.length > 0) {
    items.push({ id: 'separator-before-logout', kind: 'separator', enabled: true });
  }
  items.push({ id: 'logout', kind: 'danger', enabled: true });
  return items;
}

export function shouldCloseUserMenuOnKey(key) {
  return key === 'Escape' || key === 'Esc';
}

export function isClickOutsideUserMenu(target, rootElement) {
  if (!rootElement || !target) {
    return false;
  }
  if (typeof rootElement.contains !== 'function') {
    return false;
  }
  return !rootElement.contains(target);
}

export function normalizePrincipalSubtitle(value) {
  const text = String(value || '').trim();
  return text || '';
}
