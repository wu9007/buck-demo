export type BrickConsoleThemeName = 'blue' | 'orange' | 'guard' | 'green' | 'night';
export type BrickConsoleThemePreferenceName = 'system' | BrickConsoleThemeName;
export type BrickConsoleDensityName = 'comfortable' | 'compact';
export type BrickConsoleFontSizeName = 'normal' | 'large' | 'xlarge';
export type BrickConsoleLocaleName = 'zh-CN' | 'en-US';

export interface BrickConsoleAppearance {
  theme?: BrickConsoleThemePreferenceName | string;
  density?: BrickConsoleDensityName | string;
  fontSize?: BrickConsoleFontSizeName | string;
  fullscreenAutoEnter?: boolean | string | number;
  locale?: BrickConsoleLocaleName | string;
}

export interface BrickConsoleNormalizedAppearance {
  theme: BrickConsoleThemePreferenceName;
  density: BrickConsoleDensityName;
  fontSize: BrickConsoleFontSizeName;
  fullscreenAutoEnter: boolean;
  locale: BrickConsoleLocaleName;
}

export interface BrickConsoleResolvedAppearance extends BrickConsoleNormalizedAppearance {
  resolvedTheme: BrickConsoleThemeName;
}

export interface BrickConsoleAppearanceRuntime {
  read(): Readonly<BrickConsoleResolvedAppearance>;
  setAppearance(appearance?: BrickConsoleAppearance, persist?: boolean): Readonly<BrickConsoleResolvedAppearance>;
  resetAppearance(persist?: boolean): Readonly<BrickConsoleResolvedAppearance>;
  dispose(): void;
}

export interface BrickConsoleAppearanceRuntimeOptions {
  appearance?: BrickConsoleAppearance;
  storage?: Storage | null;
  media?: MediaQueryList | null;
  onChange?: (appearance: Readonly<BrickConsoleResolvedAppearance>) => void;
}

export interface BrickConsoleAppearanceMatrixItem extends BrickConsoleNormalizedAppearance {
  resolvedTheme: BrickConsoleThemeName;
}

export declare const BRICK_CONSOLE_THEME_NAMES: readonly BrickConsoleThemeName[];
export declare const BRICK_CONSOLE_THEME_PREFERENCE_NAMES: readonly BrickConsoleThemePreferenceName[];
export declare const BRICK_CONSOLE_DENSITY_NAMES: readonly BrickConsoleDensityName[];
export declare const BRICK_CONSOLE_FONT_SIZE_NAMES: readonly BrickConsoleFontSizeName[];
export declare const BRICK_CONSOLE_LOCALE_NAMES: readonly BrickConsoleLocaleName[];
export declare const BRICK_CONSOLE_APPEARANCE_DEFAULTS: Readonly<BrickConsoleNormalizedAppearance>;
export declare const BRICK_CONSOLE_APPEARANCE_STORAGE_KEYS: Readonly<Record<string, string>>;
export declare const BRICK_CONSOLE_LEGACY_APPEARANCE_STORAGE_KEYS: Readonly<Record<string, string>>;
export declare function normalizeBrickConsoleAppearance(appearance?: BrickConsoleAppearance): Readonly<BrickConsoleNormalizedAppearance>;
export declare function readBrickConsoleAppearancePreference(storage?: Storage | null): Readonly<BrickConsoleNormalizedAppearance>;
export declare function writeBrickConsoleAppearancePreference(
  appearance?: BrickConsoleAppearance,
  storage?: Storage | null
): Readonly<BrickConsoleNormalizedAppearance>;
export declare function clearBrickConsoleAppearancePreference(storage?: Storage | null): void;
export declare function resolveBrickConsoleAppearanceTheme(
  appearance?: BrickConsoleAppearance | BrickConsoleThemePreferenceName | string,
  media?: MediaQueryList | null
): BrickConsoleThemeName;
export declare function createBrickConsoleAppearanceRuntime(
  options?: BrickConsoleAppearanceRuntimeOptions
): BrickConsoleAppearanceRuntime;
export declare function listBrickConsoleAppearanceMatrix(options?: {
  media?: MediaQueryList | { matches?: boolean } | null;
  includeFullscreen?: boolean;
}): readonly BrickConsoleAppearanceMatrixItem[];
export declare function summarizeBrickConsoleAppearance(
  appearance?: BrickConsoleAppearance & { media?: MediaQueryList | { matches?: boolean } | null }
): string;
export declare function isBrickConsoleAppearanceEqual(
  left?: BrickConsoleAppearance,
  right?: BrickConsoleAppearance
): boolean;
