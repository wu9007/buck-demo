import type { Component } from 'vue';

export interface BrickManagedSecretFieldOptions {
  label?: string;
  configured?: boolean;
  value?: string | null;
  placeholder?: string;
  unconfiguredPlaceholder?: string;
  configuredPlaceholder?: string;
  unconfiguredHint?: string;
  configuredHint?: string;
  configuredTagText?: string;
  requiredText?: string;
  optionalText?: string;
}

export interface BrickManagedSecretFieldState {
  label: string;
  labelText: string;
  required: boolean;
  optional: boolean;
  configured: boolean;
  configuredTagText: string;
  placeholder: string;
  hint: string;
  changed: boolean;
  keepExisting: boolean;
  submitValue?: string;
  validationValue: string;
}

export declare const BrickColorField: Component;
export declare const BrickImageUploadField: Component;
export declare const BrickManagedSecretInput: Component;
export declare const BrickReadonlyCopyInput: Component;
export declare function resolveBrickManagedSecretField(options?: BrickManagedSecretFieldOptions): BrickManagedSecretFieldState;

export {
  createBrickLocalImagePreview,
  isBrickFileResourceContentUrl,
  loadBrickImageResourcePreviewUrl,
  resolveBrickImagePreviewUrl,
  revokeBrickImagePreview,
  uploadBrickImageResource,
} from './image-resource';
export type { BrickImageUploadResponse } from './image-resource';
