/**
 * Soft-suspend (SCREEN_LOCK) flag shared by shell lifecycle and status toasts.
 * Kept free of Element Plus so auth unit tests can import without browser UI deps.
 */

let brickSessionRecoveryUiActive = false;

/**
 * Soft-suspend sets true so page-level load-error toasts do not stack under the recovery overlay.
 */
export function setBrickSessionRecoveryUiActive(active) {
  brickSessionRecoveryUiActive = Boolean(active);
}

export function isBrickSessionRecoveryUiActive() {
  return brickSessionRecoveryUiActive;
}
