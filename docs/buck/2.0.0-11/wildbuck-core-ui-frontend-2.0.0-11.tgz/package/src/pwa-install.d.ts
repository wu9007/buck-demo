export const BRICK_PWA_INSTALL_UNAVAILABLE_MESSAGE: string;

export function isBrickPwaStandalone(windowRef?: Window | null): boolean;

export function registerBrickPwaServiceWorker(options?: {
  serviceWorkerUrl?: string;
  scope?: string;
  windowRef?: Window;
}): Promise<ServiceWorkerRegistration | null>;

export interface BrickPwaInstallSnapshot {
  canInstall: boolean;
  isStandalone: boolean;
}

export function resolveBrickPwaCanInstallApp(
  snapshot?: Partial<BrickPwaInstallSnapshot> | null,
): boolean;

export interface BrickPwaInstallController {
  readonly canInstall: boolean;
  readonly isStandalone: boolean;
  readonly isSupported: boolean;
  subscribe(listener: (snapshot: BrickPwaInstallSnapshot) => void): () => void;
  promptInstall(): Promise<'accepted' | 'dismissed' | 'unavailable'>;
  dispose(): void;
}

export function createBrickPwaInstallController(options?: {
  windowRef?: Window;
  documentRef?: Document;
}): BrickPwaInstallController;

export interface UseBrickPwaInstallOptions {
  windowRef?: Window;
  documentRef?: Document;
  /** When set (non-empty), registers SW on mount unless registerServiceWorker is false. */
  serviceWorkerUrl?: string;
  scope?: string;
  /**
   * true: register with serviceWorkerUrl or '/sw.js'.
   * false: never register.
   * omit: register only when serviceWorkerUrl is a non-empty string.
   */
  registerServiceWorker?: boolean;
  /** Called when installApp() cannot show a native prompt. */
  onUnavailable?: () => void;
  vue?: {
    ref: <T>(value: T) => { value: T };
    onMounted?: (fn: () => void) => void;
    onScopeDispose?: (fn: () => void) => void;
  };
}

export interface UseBrickPwaInstallResult {
  controller: BrickPwaInstallController;
  /** Raw browser prompt availability. */
  canInstall: { value: boolean };
  /** Shell binding: canInstall && !isStandalone. */
  canInstallApp: { value: boolean };
  isStandalone: { value: boolean };
  isSupported: boolean;
  promptInstall: () => Promise<'accepted' | 'dismissed' | 'unavailable'>;
  /** promptInstall + optional onUnavailable for shell @install-app. */
  installApp: () => Promise<'accepted' | 'dismissed' | 'unavailable'>;
  dispose: () => void;
}

export function useBrickPwaInstall(options?: UseBrickPwaInstallOptions): UseBrickPwaInstallResult;
