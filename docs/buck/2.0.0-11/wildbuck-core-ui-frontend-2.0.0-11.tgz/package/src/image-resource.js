/**
 * Shared image-resource preview helpers for Buck console modules.
 *
 * Contract:
 * - Business tables store `resourceId` only (not Base64 / bytes).
 * - `GET /file-resources/{id}/content` is authenticated; bare <img src> will 401.
 * - Unsaved local previews must use `blob:` object URLs from the File.
 * - Public anonymous assets (e.g. `/login-brand/public/logo`) may be used as img src.
 * - Do NOT use authenticated `contentUrl` as <img src>.
 */

import { request as brickRequest, requestBlob as brickRequestBlob } from '@wildbuck/core-api-frontend';

const CONTENT_URL_RE = /\/file-resources\/[^/?#]+\/content(?:\?|$)/i;

/**
 * True when URL points at authenticated file-resource content endpoint.
 * Such URLs must not be bound to bare <img src>.
 */
export function isBrickFileResourceContentUrl(url) {
  if (url == null || url === '') {
    return false;
  }
  return CONTENT_URL_RE.test(String(url));
}

/**
 * Create a local object URL for immediate preview after file pick / upload.
 * Caller owns lifecycle and should revoke when replaced or unmounted.
 */
export function createBrickLocalImagePreview(file, createObjectURL = globalThis.URL?.createObjectURL?.bind(globalThis.URL)) {
  if (!file || typeof createObjectURL !== 'function') {
    return '';
  }
  return createObjectURL(file);
}

/**
 * Revoke a blob: preview URL created by createBrickLocalImagePreview.
 * No-op for non-blob URLs.
 */
export function revokeBrickImagePreview(url, revokeObjectURL = globalThis.URL?.revokeObjectURL?.bind(globalThis.URL)) {
  if (!url || typeof url !== 'string' || !url.startsWith('blob:')) {
    return;
  }
  if (typeof revokeObjectURL === 'function') {
    try {
      revokeObjectURL(url);
    } catch {
      // ignore double-revoke
    }
  }
}

/**
 * Prefer a browser-safe preview URL:
 * - reject authenticated content URLs
 * - keep blob:/public/http(s) paths
 */
export function resolveBrickImagePreviewUrl(candidate, localFallback = '') {
  const url = candidate == null ? '' : String(candidate).trim();
  if (!url) {
    return localFallback || '';
  }
  if (isBrickFileResourceContentUrl(url)) {
    return localFallback || '';
  }
  return url;
}

/**
 * Upload an image to core:file-resource.
 * Returns { resourceId, contentUrl } — do not use contentUrl as img src.
 */
export async function uploadBrickImageResource(file, category, options = {}) {
  const requestFn = options.request || brickRequest;
  const body = new FormData();
  body.append('file', file);
  const path = category
    ? `/file-resources/images?category=${encodeURIComponent(category)}`
    : '/file-resources/images';
  return requestFn(path, {
    method: 'POST',
    body,
  });
}

/**
 * Load authenticated resource bytes and return a blob: object URL for preview.
 * Caller must revoke the returned URL when done.
 */
export async function loadBrickImageResourcePreviewUrl(resourceId, options = {}) {
  const id = resourceId == null ? '' : String(resourceId).trim();
  if (!id) {
    return '';
  }
  const requestBlobFn = options.requestBlob || brickRequestBlob;
  const createObjectURL = options.createObjectURL || globalThis.URL?.createObjectURL?.bind(globalThis.URL);
  const blob = await requestBlobFn(`/file-resources/${encodeURIComponent(id)}/content`);
  if (!blob || typeof createObjectURL !== 'function') {
    return '';
  }
  return createObjectURL(blob);
}
