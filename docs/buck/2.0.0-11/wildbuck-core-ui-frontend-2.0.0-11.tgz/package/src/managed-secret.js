const DEFAULT_LABEL = '敏感值';
const DEFAULT_REQUIRED_TEXT = '必填';
const DEFAULT_OPTIONAL_TEXT = '选填';
const DEFAULT_CONFIGURED_TAG_TEXT = '已托管';
const DEFAULT_CONFIGURED_PLACEHOLDER = '留空表示不修改';
const DEFAULT_UNCONFIGURED_HINT = '保存后加密存储，不回显明文。';
const DEFAULT_CONFIGURED_HINT = '已加密保存；如需更新请直接输入新值，留空表示不修改。';
const VALIDATION_SENTINEL = '__brick_managed_secret__';

export function resolveBrickManagedSecretField(options = {}) {
  const label = normalizeText(options.label) || DEFAULT_LABEL;
  const requiredText = normalizeText(options.requiredText) || DEFAULT_REQUIRED_TEXT;
  const optionalText = normalizeText(options.optionalText) || DEFAULT_OPTIONAL_TEXT;
  const configuredTagText = normalizeText(options.configuredTagText) || DEFAULT_CONFIGURED_TAG_TEXT;
  const configured = Boolean(options.configured);
  const normalizedValue = normalizeText(options.value);
  const explicitPlaceholder = normalizeText(options.placeholder);
  const placeholder = explicitPlaceholder
    || normalizeText(configured ? options.configuredPlaceholder : options.unconfiguredPlaceholder)
    || (configured ? DEFAULT_CONFIGURED_PLACEHOLDER : `请输入${label}`);
  const hint = normalizeText(configured ? options.configuredHint : options.unconfiguredHint)
    || (configured ? DEFAULT_CONFIGURED_HINT : DEFAULT_UNCONFIGURED_HINT);

  return {
    label,
    labelText: `${label}（${configured ? optionalText : requiredText}）`,
    required: !configured,
    optional: configured,
    configured,
    configuredTagText,
    placeholder,
    hint,
    changed: normalizedValue.length > 0,
    keepExisting: configured && normalizedValue.length === 0,
    submitValue: normalizedValue || undefined,
    validationValue: configured ? (normalizedValue || VALIDATION_SENTINEL) : normalizedValue,
  };
}

function normalizeText(value) {
  return typeof value === 'string' ? value.trim() : '';
}
