# @wildbuck/core-api-frontend

Buck 生成前端 SDK 使用的 HTTP 客户端运行时。

职责边界：

- 统一 `baseUrl`、JSON 请求和错误响应读取。
- 给生成 SDK 提供稳定的 `request<T>()` 入口。
- 可选接入 `core/transport/frontend` 的请求摘要、传输 envelope 封装和响应解封。
- 可选接入 `tokenRefresh`：会话类 401 先单飞静默续期并重放原请求；续期失败后再走 `responseErrorHandler`。
- 可选接入全局 `responseErrorHandler`，统一处理续期失败后的终态（`LOGIN_OUT` 退出并回登录 / `SCREEN_LOCK` 锁定当前页验证后继续；历史 `VERIFY_PASS` 归一 soft）与强制改密等会话级错误。
- 提供 `createBrickSessionErrorHandler()`、`isBrickSessionError()`，用于把并发 401 / 会话级错误收口为一次全局处理，并让页面级 `catch` 抑制局部失败提示。
- 提供 `readBrickBusinessError()` / `formatBrickBusinessError()`，把业务 4xx 信封（`code` + `message` + 可选 `recovery`）读成稳定形状；**禁止**把 `error.message === "HTTP 400"` 直接 toast 给用户。
- 不承载登录、权限判断、业务页面状态或具体 UI 框架逻辑。

```ts
import { configureHttp } from '@wildbuck/core-api-frontend';

configureHttp({
  baseUrl: '/api',
  transportEnvelope: {
    enabled: true,
    algorithm: 'SHA256',
    encrypt: async (plaintext) => encryptByProductCipher(plaintext),
    decrypt: async (data) => decryptByProductCipher(data),
  },
  requestDigest: {
    enabled: true,
    algorithm: 'SHA256',
    protectedHeaders: ['authorization', 'client-id'],
  },
});
```

会话过期推荐接入方式（先静默续期，失败再按策略分流）：

```ts
import {
  configureHttp,
  createBrickSessionErrorHandler,
  formatBrickBusinessError,
  isBrickSessionError,
} from '@wildbuck/core-api-frontend';
import { showBrickStatus } from '@wildbuck/core-ui-frontend';

const handleSessionError = createBrickSessionErrorHandler({
  onSessionError(error) {
    // 仅在 tokenRefresh 失败后到达。按 expirationStrategy 分流：
    // LOGIN_OUT → clearSession；SCREEN_LOCK → softSuspend + 恢复 UI（历史 VERIFY_PASS 归一为 SCREEN_LOCK）。
    handleSessionTerminal(error);
  },
});

configureHttp({
  baseUrl: '/api',
  tokenRefresh: {
    refresh: () => trySilentRefresh(), // 持久化 RT，成功则写回 AT/RT
  },
  responseErrorHandler: handleSessionError,
});

try {
  await loadPageData();
} catch (error) {
  if (isBrickSessionError(error)) {
    return;
  }
  // Domain 4xx: read payload, never toast bare "HTTP 400"
  showBrickStatus(formatBrickBusinessError(error), 'error');
  // or: showBrickBusinessError(error) from @wildbuck/core-ui-frontend
}
```

业务拒绝信封约定：

| 字段 | 含义 |
| --- | --- |
| `code` | 稳定机器码，供分支 / 埋点 / 日志 |
| `message` | **发生了什么 / 为什么不行**（用户主句） |
| `recovery` | **下一步怎么做**（用户第二句，errors.yaml 必填） |

`request()` 失败时 `BrickHttpError.message` 仍可能是 `HTTP 400`，真实文案在 `error.payload`。页面 catch 必须用 `readBrickBusinessError` / `formatBrickBusinessError` / `resolveBrickErrorFromCatalog` / `showBrickBusinessError`，不要 `showBrickStatus(error.message)`，也不要丢弃 `error` 永远弹固定文案。
