import type {
  BrickRequestDigestInitOptions,
  BrickTransportEnvelopeOptions,
} from '@wildbuck/core-transport-frontend';

export interface BrickHttpRequestDigestConfig extends BrickRequestDigestInitOptions {
  enabled: boolean;
  signer?: (
    init: RequestInit,
    options: BrickHttpRequestDigestConfig,
  ) => RequestInit | Promise<RequestInit>;
}

export interface BrickTokenRefreshConfig {
  /**
   * Silent single-flight refresh. Return a truthy value when new access/refresh
   * tokens were applied so the failed request can be retried once.
   * Must not call configureHttp request() against protected APIs that would re-enter refresh.
   */
  refresh: () => boolean | Promise<boolean | null | undefined | void | object>;
}

export interface HttpConfig {
  baseUrl: string;
  prepareRequest?: (
    path: string,
    init: RequestInit,
  ) => RequestInit | Promise<RequestInit>;
  /**
   * Active Brick locale for this client (e.g. zh-CN / en-US).
   * Injected as Accept-Language and X-Brick-Locale after prepareRequest.
   */
  localeProvider?: () => string | null | undefined;
  /**
   * Optional silent access-token refresh. On session-class 401, core runs this
   * once (single-flight) then retries the original request. Terminal session UI
   * (responseErrorHandler / createBrickSessionErrorHandler) only runs after refresh fails.
   */
  tokenRefresh?: BrickTokenRefreshConfig;
  responseErrorHandler?: (
    error: BrickHttpError,
    context: {
      path: string;
      init: RequestInit;
      response: Response;
    },
  ) => void | Promise<void>;
  requestDigest?: BrickHttpRequestDigestConfig;
  transportEnvelope?: BrickTransportEnvelopeOptions & {
    enabled: boolean;
  };
}

export interface BrickSessionErrorDetails {
  handled?: boolean;
  status?: number;
  code?: string;
  path?: string;
  [key: string]: unknown;
}

export interface BrickSessionErrorHandlerOptions {
  dedupeWindowMs?: number;
  now?: () => number;
  onSessionError?: (
    error: BrickHttpError,
    context: {
      path: string;
      init: RequestInit;
      response: Response;
    },
  ) => void | Promise<void>;
  shouldHandle?: (
    error: BrickHttpError,
    context: {
      path: string;
      init: RequestInit;
      response: Response;
    },
  ) => boolean | Promise<boolean>;
}

export declare class BrickHttpError extends Error {
  readonly status: number;
  readonly payload: unknown;

  constructor(message: string, status: number, payload: unknown);
}

export declare const BRICK_SESSION_ERROR_STATUSES: readonly number[];

export declare const BRICK_SESSION_ERROR_CODES: readonly string[];

export declare function markBrickSessionError(error: unknown, details?: BrickSessionErrorDetails): unknown;

export declare function isBrickSessionError(error: unknown): boolean;

export declare function isBrickSessionErrorCandidate(error: unknown, options?: {
  statuses?: Iterable<number>;
  codes?: Iterable<string>;
}): boolean;

export declare function createBrickSessionErrorHandler(options?: BrickSessionErrorHandlerOptions): NonNullable<HttpConfig['responseErrorHandler']>;

/**
 * Normalized business / HTTP rejection for UI and logs.
 * Prefer payload.message over transport text such as "HTTP 400".
 */
export interface BrickBusinessError {
  code: string;
  message: string;
  recovery: string;
  status?: number;
  payload: unknown;
}

export declare function readBrickBusinessError(error: unknown): BrickBusinessError;

export declare function formatBrickBusinessError(
  error: unknown,
  options?: { includeRecovery?: boolean; localeHint?: string },
): string;

export declare const BRICK_GENERIC_OPERATION_FAILED: string;
export declare const BRICK_GENERIC_OPERATION_FAILED_EN: string;

export declare function isBareHttpStatusMessage(message: unknown): boolean;
export declare function containsCjk(text: string): boolean;
export declare function composeBrickUserFacingErrorText(
  message: string,
  recovery?: string,
  options?: { includeRecovery?: boolean; localeHint?: string },
): string;

export declare function resolveBrickErrorFromCatalog(
  error: unknown,
  catalog?: Record<string, { message?: string; recovery?: string; httpStatus?: number }>,
  options?: {
    fallbackCode?: string;
    fallbackMessage?: string;
    includeRecovery?: boolean;
    localeHint?: string;
  },
): {
  code: string;
  message: string;
  recovery: string;
  text: string;
  fromCatalog: boolean;
  status?: number;
};

export declare function formatBrickCatalogError(
  definition: { message?: string; recovery?: string } | null | undefined,
  options?: { includeRecovery?: boolean; localeHint?: string },
): string;

export declare function isVagueErrorMessage(message: unknown): boolean;
export declare function isActionableRecovery(recovery: unknown): boolean;
export declare function validateBrickErrorDefinition(
  definition: { message?: string; recovery?: string } | null | undefined,
  options?: { requireRecovery?: boolean; strictLength?: boolean },
): { ok: boolean; issues: string[] };

export interface BrickApiResponse<T> {
  code: string;
  category: 'SUCCESS' | 'INFO' | 'WARNING' | 'ERROR' | 'success' | 'info' | 'warning' | 'error';
  data: T;
  message?: string | null;
  recovery?: string | null;
}

export declare function configureHttp(nextConfig: HttpConfig): void;

export declare function request<T>(path: string, init?: RequestInit): Promise<T>;

export declare function requestBlob(path: string, init?: RequestInit): Promise<Blob>;
