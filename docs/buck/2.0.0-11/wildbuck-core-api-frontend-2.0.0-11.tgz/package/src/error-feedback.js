/**
 * Production user-facing error feedback helpers.
 *
 * Contract:
 * - message = what went wrong (problem)
 * - recovery = what the user should do next (action)
 * - never show bare "HTTP nnn" as the primary toast text
 */

export const BRICK_GENERIC_OPERATION_FAILED = '操作失败，请稍后重试。';
export const BRICK_GENERIC_OPERATION_FAILED_EN = 'The operation failed. Please try again later.';

/**
 * @param {unknown} message
 * @returns {boolean}
 */
export function isBareHttpStatusMessage(message) {
  return typeof message === 'string' && /^HTTP\s+\d{3}$/i.test(message.trim());
}

/**
 * @param {string} text
 * @returns {boolean}
 */
export function containsCjk(text) {
  return typeof text === 'string' && /[\u3400-\u9FFF]/.test(text);
}

/**
 * Compose problem + recovery into one clear user-facing sentence block.
 * Chinese: 「原因。建议。」 English: "Reason. Recovery."
 *
 * @param {string} message
 * @param {string} [recovery]
 * @param {{ includeRecovery?: boolean, localeHint?: string }} [options]
 * @returns {string}
 */
export function composeBrickUserFacingErrorText(message, recovery = '', options = {}) {
  const includeRecovery = options.includeRecovery !== false;
  const msg = typeof message === 'string' ? message.trim() : '';
  const rec = typeof recovery === 'string' ? recovery.trim() : '';
  if (!msg && !rec) {
    return '';
  }
  if (!msg) {
    return ensureTerminalPunctuation(rec, containsCjk(rec));
  }
  if (!includeRecovery || !rec) {
    return msg;
  }
  // Avoid duplicating recovery already embedded in message.
  if (msg.includes(rec)) {
    return msg;
  }
  const cjk = containsCjk(msg) || containsCjk(rec) || options.localeHint === 'zh-CN';
  const left = stripTrailingSentencePunctuation(msg);
  const right = ensureTerminalPunctuation(rec, cjk);
  if (cjk) {
    return `${left}。${right}`;
  }
  return `${left}. ${right}`;
}

/**
 * Normalize a thrown HTTP / business rejection into a stable shape for UI and logs.
 * Prefer payload.message over transport text such as "HTTP 400".
 *
 * @param {unknown} error
 * @returns {{ code: string, message: string, recovery: string, status?: number, payload: unknown }}
 */
export function readBrickBusinessError(error) {
  const status = Number(error?.status);
  const payload = error?.payload ?? error?.body;
  let code = '';
  let payloadMessage = '';
  let recovery = '';
  if (payload != null && typeof payload === 'object' && !Array.isArray(payload)) {
    if (typeof payload.code === 'string') {
      code = payload.code.trim();
    }
    if (typeof payload.message === 'string') {
      payloadMessage = payload.message.trim();
    }
    if (typeof payload.recovery === 'string') {
      recovery = payload.recovery.trim();
    }
  }
  if (!code && typeof error?.code === 'string') {
    code = error.code.trim();
  }
  const transportMessage = typeof error?.message === 'string' ? error.message.trim() : '';
  const bareHttpStatus = isBareHttpStatusMessage(transportMessage);
  const message = payloadMessage
    || (!bareHttpStatus && transportMessage)
    || BRICK_GENERIC_OPERATION_FAILED;
  return Object.freeze({
    code,
    message,
    recovery,
    status: Number.isFinite(status) ? status : undefined,
    payload,
  });
}

/**
 * Build a user-facing reason string: message, optionally with recovery advice.
 * Never returns a bare "HTTP nnn" when payload carries a business message.
 *
 * @param {unknown} error
 * @param {{ includeRecovery?: boolean, localeHint?: string }} [options]
 * @returns {string}
 */
export function formatBrickBusinessError(error, options = {}) {
  if (typeof error === 'string') {
    const trimmed = error.trim();
    if (!trimmed) {
      return '';
    }
    if (isBareHttpStatusMessage(trimmed)) {
      return BRICK_GENERIC_OPERATION_FAILED;
    }
    return trimmed;
  }
  const read = readBrickBusinessError(error);
  return composeBrickUserFacingErrorText(read.message, read.recovery, options);
}

/**
 * Resolve display text from a thrown error plus optional module error catalog
 * (generated from contract/errors.yaml).
 *
 * Priority for message:
 * 1) payload.message (server/domain)
 * 2) catalog[code].message
 * 3) catalog[fallbackCode].message
 * 4) transport non-HTTP message
 * 5) options.fallbackMessage / generic
 *
 * Priority for recovery:
 * 1) payload.recovery
 * 2) catalog recovery for resolved code
 * 3) empty
 *
 * @param {unknown} error
 * @param {Record<string, { message?: string, recovery?: string, httpStatus?: number }>} [catalog]
 * @param {{ fallbackCode?: string, fallbackMessage?: string, includeRecovery?: boolean, localeHint?: string }} [options]
 * @returns {{ code: string, message: string, recovery: string, text: string, fromCatalog: boolean, status?: number }}
 */
export function resolveBrickErrorFromCatalog(error, catalog = {}, options = {}) {
  const read = readBrickBusinessError(error);
  const fallbackCode = typeof options.fallbackCode === 'string' ? options.fallbackCode.trim() : '';
  const code = read.code || fallbackCode;
  const def = lookupCatalog(catalog, code);
  const fallbackDef = !def && fallbackCode && fallbackCode !== code
    ? lookupCatalog(catalog, fallbackCode)
    : null;
  const catalogDef = def || fallbackDef;

  const payloadHasMessage = Boolean(
    read.payload
    && typeof read.payload === 'object'
    && !Array.isArray(read.payload)
    && typeof read.payload.message === 'string'
    && read.payload.message.trim(),
  );

  let message = '';
  let fromCatalog = false;
  if (payloadHasMessage) {
    message = String(read.payload.message).trim();
  } else if (catalogDef?.message) {
    message = String(catalogDef.message).trim();
    fromCatalog = true;
  } else if (read.message && read.message !== BRICK_GENERIC_OPERATION_FAILED) {
    message = read.message;
  } else if (typeof options.fallbackMessage === 'string' && options.fallbackMessage.trim()) {
    message = options.fallbackMessage.trim();
  } else {
    message = BRICK_GENERIC_OPERATION_FAILED;
  }

  let recovery = '';
  if (read.recovery) {
    recovery = read.recovery;
  } else if (catalogDef?.recovery) {
    recovery = String(catalogDef.recovery).trim();
  }

  const text = composeBrickUserFacingErrorText(message, recovery, options);
  return Object.freeze({
    code: code || (catalogDef ? fallbackCode || read.code : read.code),
    message,
    recovery,
    text,
    fromCatalog,
    status: read.status,
  });
}

/**
 * Format a catalog definition alone (no thrown error).
 * @param {{ message?: string, recovery?: string }} definition
 * @param {{ includeRecovery?: boolean, localeHint?: string }} [options]
 */
export function formatBrickCatalogError(definition, options = {}) {
  if (!definition || typeof definition !== 'object') {
    return BRICK_GENERIC_OPERATION_FAILED;
  }
  return composeBrickUserFacingErrorText(
    String(definition.message || '').trim() || BRICK_GENERIC_OPERATION_FAILED,
    String(definition.recovery || '').trim(),
    options,
  );
}

/**
 * Heuristic: message should describe the problem, not only "failed".
 * Used by coverage / governance checks — not a hard runtime gate.
 */
export function isVagueErrorMessage(message) {
  if (typeof message !== 'string' || !message.trim()) {
    return true;
  }
  const text = message.trim();
  if (isBareHttpStatusMessage(text)) {
    return true;
  }
  const vague = [
    /^error$/i,
    /^failed$/i,
    /^失败$/,
    /^操作失败$/,
    /^系统错误$/,
    /^unknown error$/i,
    /^request failed$/i,
    /^HTTP\s+\d{3}/i,
  ];
  return vague.some((re) => re.test(text));
}

/**
 * Heuristic: recovery should tell the user a next step.
 */
export function isActionableRecovery(recovery) {
  if (typeof recovery !== 'string' || !recovery.trim()) {
    return false;
  }
  const text = recovery.trim();
  // Chinese action verbs / English action cues
  return /请|先|再|检查|选择|填写|刷新|重试|确认|打开|关闭|启用|保存|联系|try|check|select|enter|refresh|retry|confirm|enable|save|contact|wait/i
    .test(text);
}

/**
 * Validate a contract-style error definition for production copy quality.
 * @returns {{ ok: boolean, issues: string[] }}
 */
export function validateBrickErrorDefinition(definition, options = {}) {
  const issues = [];
  if (!definition || typeof definition !== 'object') {
    return { ok: false, issues: ['missing-definition'] };
  }
  const message = String(definition.message || '').trim();
  const recovery = String(definition.recovery || '').trim();
  if (!message) {
    issues.push('message-empty');
  } else if (isVagueErrorMessage(message)) {
    issues.push('message-vague');
  }
  if (options.requireRecovery !== false) {
    if (!recovery) {
      issues.push('recovery-empty');
    } else if (!isActionableRecovery(recovery)) {
      issues.push('recovery-not-actionable');
    }
  }
  if (message && recovery && message === recovery) {
    issues.push('message-equals-recovery');
  }
  if (message.length > 80 && options.strictLength !== false) {
    issues.push('message-too-long');
  }
  if (recovery.length > 120 && options.strictLength !== false) {
    issues.push('recovery-too-long');
  }
  return { ok: issues.length === 0, issues };
}

function lookupCatalog(catalog, code) {
  if (!catalog || !code || typeof catalog !== 'object') {
    return null;
  }
  const def = catalog[code];
  if (!def || typeof def !== 'object') {
    return null;
  }
  return def;
}

function stripTrailingSentencePunctuation(text) {
  return String(text || '').replace(/[。.!！?？；;]+$/u, '').trim();
}

function ensureTerminalPunctuation(text, cjk) {
  const t = String(text || '').trim();
  if (!t) {
    return '';
  }
  if (/[。.!！?？]$/u.test(t)) {
    return t;
  }
  return cjk ? `${t}。` : `${t}.`;
}
