import {
  BRICK_GENERIC_OPERATION_FAILED,
  BRICK_GENERIC_OPERATION_FAILED_EN,
  composeBrickUserFacingErrorText,
  containsCjk,
  formatBrickBusinessError,
  formatBrickCatalogError,
  isActionableRecovery,
  isBareHttpStatusMessage,
  isVagueErrorMessage,
  readBrickBusinessError,
  resolveBrickErrorFromCatalog,
  validateBrickErrorDefinition,
} from './error-feedback.js';

export {
  BRICK_GENERIC_OPERATION_FAILED,
  BRICK_GENERIC_OPERATION_FAILED_EN,
  composeBrickUserFacingErrorText,
  containsCjk,
  formatBrickBusinessError,
  formatBrickCatalogError,
  isActionableRecovery,
  isBareHttpStatusMessage,
  isVagueErrorMessage,
  readBrickBusinessError,
  resolveBrickErrorFromCatalog,
  validateBrickErrorDefinition,
};

export class BrickHttpError extends Error {
  constructor(message, status, payload) {
    super(message);
    this.name = 'BrickHttpError';
    this.status = status;
    this.payload = payload;
  }
}

const BRICK_SESSION_ERROR_MARKER = Symbol.for('brick.core-api.session-error');

export const BRICK_SESSION_ERROR_STATUSES = Object.freeze([401]);

/**
 * Codes that mean the access session is dead and needs terminal recovery
 * (LOGIN_OUT / SCREEN_LOCK). Step-up states such as password change / MFA
 * are NOT listed here — they keep the token and must not trigger logout.
 */
export const BRICK_SESSION_ERROR_CODES = Object.freeze([
  'BRICK_UNAUTHORIZED',
  'BRICK_ACCESS_TOKEN_EXPIRED',
  'BRICK_TOKEN_EXPIRED',
  'BRICK_SESSION_EXPIRED',
]);

let config = {
  baseUrl: '',
};

/** Single-flight silent refresh; shared across concurrent 401s. */
let tokenRefreshInFlight = null;

export function configureHttp(nextConfig) {
  if (nextConfig == null || typeof nextConfig !== 'object') {
    throw new TypeError('Buck HTTP config must be an object');
  }
  config = {
    ...nextConfig,
    baseUrl: String(nextConfig.baseUrl ?? ''),
  };
  tokenRefreshInFlight = null;
}

/**
 * Optional localeProvider on HttpConfig injects Accept-Language and X-Brick-Locale
 * unless the caller already set those headers. Prefer providing a normalized Buck
 * locale such as zh-CN / en-US (see @wildbuck/core-i18n-frontend).
 */

export function markBrickSessionError(error, details = {}) {
  if (error == null || (typeof error !== 'object' && typeof error !== 'function')) {
    return error;
  }
  Object.defineProperty(error, BRICK_SESSION_ERROR_MARKER, {
    configurable: true,
    enumerable: false,
    value: Object.freeze({
      handled: true,
      ...details,
    }),
  });
  return error;
}

export function isBrickSessionError(error) {
  return Boolean(error?.[BRICK_SESSION_ERROR_MARKER]?.handled);
}

export function isBrickSessionErrorCandidate(error, options = {}) {
  const statuses = new Set(options.statuses ?? BRICK_SESSION_ERROR_STATUSES);
  const codes = new Set(options.codes ?? BRICK_SESSION_ERROR_CODES);
  const status = Number(error?.status);
  if (Number.isFinite(status) && statuses.has(status)) {
    return true;
  }
  const code = readBrickErrorCode(error);
  return Boolean(code && codes.has(code));
}

export function createBrickSessionErrorHandler(options = {}) {
  const {
    dedupeWindowMs = 1500,
    now = () => Date.now(),
    onSessionError,
    shouldHandle = isBrickSessionErrorCandidate,
  } = options ?? {};
  let lastHandledAt = Number.NEGATIVE_INFINITY;
  let inFlight = null;

  return async function handleBrickSessionError(error, context = {}) {
    const sessionCandidate = typeof shouldHandle === 'function'
      ? await shouldHandle(error, context)
      : isBrickSessionErrorCandidate(error);
    if (!sessionCandidate) {
      return false;
    }
    markBrickSessionError(error, {
      code: readBrickErrorCode(error),
      path: context.path,
      status: error?.status,
    });
    const currentTime = Number(now());
    if (inFlight || currentTime - lastHandledAt < dedupeWindowMs) {
      return true;
    }
    lastHandledAt = currentTime;
    if (typeof onSessionError !== 'function') {
      return true;
    }
    const handling = Promise.resolve(onSessionError(error, context));
    inFlight = handling;
    try {
      await handling;
    } finally {
      if (inFlight === handling) {
        inFlight = null;
      }
    }
    return true;
  };
}

export async function request(path, init = {}) {
  return runRequestWithOptionalRefresh(path, init, false, async (nextPath, nextInit) => {
    const response = await requestResponse(nextPath, nextInit);
    const payload = await readPayload(response);
    if (!response.ok) {
      return { ok: false, response, payload };
    }
    return { ok: true, value: unwrapBrickApiResponse(payload) };
  });
}

export async function requestBlob(path, init = {}) {
  return runRequestWithOptionalRefresh(path, init, false, async (nextPath, nextInit) => {
    const response = await requestResponse(nextPath, nextInit);
    if (!response.ok) {
      const payload = await readPayload(response);
      return { ok: false, response, payload };
    }
    return { ok: true, value: await response.blob() };
  });
}

/**
 * On session-class failures, single-flight silent refresh then one retry.
 * Terminal session UI only runs after refresh fails (or no RT).
 */
async function runRequestWithOptionalRefresh(path, init, isRetry, executor) {
  const result = await executor(path, init);
  if (result.ok) {
    return result.value;
  }
  const provisional = new BrickHttpError(
    `HTTP ${result.response.status}`,
    result.response.status,
    result.payload,
  );
  if (
    !isRetry
    && isBrickSessionErrorCandidate(provisional)
    && !shouldSkipTokenRefresh(path, provisional)
    && await tryConfiguredTokenRefresh()
  ) {
    return runRequestWithOptionalRefresh(path, init, true, executor);
  }
  throw await buildRequestError(path, init, result.response, result.payload);
}

async function tryConfiguredTokenRefresh() {
  const tokenRefresh = config.tokenRefresh;
  if (tokenRefresh == null || typeof tokenRefresh.refresh !== 'function') {
    return false;
  }
  if (tokenRefreshInFlight) {
    return tokenRefreshInFlight;
  }
  tokenRefreshInFlight = Promise.resolve()
    .then(() => tokenRefresh.refresh())
    .then((outcome) => Boolean(outcome))
    .catch(() => false)
    .finally(() => {
      tokenRefreshInFlight = null;
    });
  return tokenRefreshInFlight;
}

function shouldSkipTokenRefresh(path, error) {
  const normalizedPath = String(path || '');
  if (normalizedPath.includes('/brick/token/refresh')) {
    return true;
  }
  const code = readBrickErrorCode(error);
  // Force password change is a different session state — not silent refresh.
  return code === 'BRICK_PASSWORD_CHANGE_REQUIRED';
}

async function requestResponse(path, init = {}) {
  const normalizedHeaders = normalizeHeaders(init.headers);
  const requestInit = {
    ...init,
    headers: {
      ...defaultHeaders(init.body, normalizedHeaders),
      ...normalizedHeaders,
    },
  };
  const preparedInit = await applyPrepareRequest(path, requestInit);
  const localeBoundInit = applyLocaleHeaders(preparedInit);
  const sealedInit = await applyTransportEnvelope(localeBoundInit);
  const finalInit = await applyRequestDigest(sealedInit);
  return fetch(`${config.baseUrl}${path}`, finalInit);
}

function applyLocaleHeaders(init = {}) {
  if (typeof config.localeProvider !== 'function') {
    return init;
  }
  let locale;
  try {
    locale = config.localeProvider();
  } catch {
    return init;
  }
  const tag = String(locale ?? '').trim();
  if (!tag) {
    return init;
  }
  const headers = normalizeHeaders(init.headers);
  if (!hasHeader(headers, 'Accept-Language')) {
    headers['Accept-Language'] = tag;
  }
  if (!hasHeader(headers, 'X-Brick-Locale')) {
    headers['X-Brick-Locale'] = tag;
  }
  return {
    ...init,
    headers,
  };
}

function hasHeader(headers, name) {
  const target = String(name).toLowerCase();
  return Object.keys(headers).some((key) => key.toLowerCase() === target);
}

async function applyPrepareRequest(path, init) {
  if (typeof config.prepareRequest !== 'function') {
    return init;
  }
  return config.prepareRequest(path, init);
}

function normalizeHeaders(headers) {
  if (headers == null) {
    return {};
  }
  if (headers instanceof Headers) {
    return Object.fromEntries([...headers.entries()]);
  }
  if (Array.isArray(headers)) {
    return Object.fromEntries(headers);
  }
  return { ...headers };
}

function defaultHeaders(body, normalizedHeaders) {
  if (normalizedHeaders['Content-Type'] || normalizedHeaders['content-type']) {
    return {};
  }
  if (body == null || body === '' || isMultipartBody(body)) {
    return {};
  }
  return {
    'Content-Type': 'application/json',
  };
}

function isMultipartBody(body) {
  return typeof FormData !== 'undefined' && body instanceof FormData;
}

async function applyTransportEnvelope(init) {
  const transportEnvelope = config.transportEnvelope;
  if (!transportEnvelope?.enabled || init.body == null || init.body === '' || isMultipartBody(init.body)) {
    return init;
  }
  const { createBrickTransportEnvelope } = await loadTransportFrontend();
  return {
    ...init,
    body: JSON.stringify(await createBrickTransportEnvelope(String(init.body), transportEnvelope)),
  };
}

async function applyRequestDigest(init) {
  const requestDigest = config.requestDigest;
  if (!requestDigest?.enabled) {
    return init;
  }
  if (typeof requestDigest.signer === 'function') {
    return requestDigest.signer(init, requestDigest);
  }
  const { withBrickRequestDigest } = await loadTransportFrontend();
  return withBrickRequestDigest(init, requestDigest);
}

async function readPayload(response) {
  const text = await response.text();
  if (!text) return undefined;
  const payload = parseJsonIfPossible(text);
  if (config.transportEnvelope?.enabled && isTransportEnvelope(payload)) {
    const { openBrickTransportEnvelope } = await loadTransportFrontend();
    return parseJsonIfPossible(await openBrickTransportEnvelope(payload, config.transportEnvelope));
  }
  return payload;
}

async function buildRequestError(path, init, response, payload) {
  const error = new BrickHttpError(`HTTP ${response.status}`, response.status, payload);
  if (typeof config.responseErrorHandler === 'function') {
    await config.responseErrorHandler(error, {
      path,
      init,
      response,
    });
  }
  return error;
}

function readBrickErrorCode(error) {
  return readBrickBusinessError(error).code;
}

function parseJsonIfPossible(text) {
  if (typeof text !== 'string') {
    return text;
  }
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

function isTransportEnvelope(payload) {
  return payload != null
    && typeof payload === 'object'
    && !Array.isArray(payload)
    && Object.hasOwn(payload, 'version')
    && Object.hasOwn(payload, 'timestamp')
    && Object.hasOwn(payload, 'nonce')
    && Object.hasOwn(payload, 'data')
    && Object.hasOwn(payload, 'tag');
}

function unwrapBrickApiResponse(payload) {
  if (!isBrickApiResponse(payload)) {
    return payload;
  }
  return payload.data;
}

function isBrickApiResponse(payload) {
  return payload != null
    && typeof payload === 'object'
    && !Array.isArray(payload)
    && Object.hasOwn(payload, 'code')
    && Object.hasOwn(payload, 'category')
    && Object.hasOwn(payload, 'data')
    && ['SUCCESS', 'INFO', 'WARNING', 'success', 'info', 'warning'].includes(String(payload.category));
}

async function loadTransportFrontend() {
  return import('@wildbuck/core-transport-frontend');
}
