import { request as brickRequest } from '@wildbuck/core-api-frontend';
import { bootstrapBrickClient, loadBrickClientMeta } from '@wildbuck/core-client-meta-frontend';

const ALLOWED_FIELDS = new Set([
  'schemaVersion',
  'eventId',
  'occurredAt',
  'eventType',
  'appCode',
  'moduleCode',
  'featureCode',
  'pageCode',
  'actionCode',
  'result',
  'traceId',
  'durationMs',
  'routeName',
  'subjectHash',
  'roleCodes',
]);

const ALLOWED_EVENT_TYPES = new Set(['PAGE_VIEW', 'FEATURE_ENTER', 'ACTION']);
const ALLOWED_RESULTS = new Set(['SUCCESS', 'FAILURE', 'CANCELLED', 'ABANDONED']);
const STABLE_CODE_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const ROUTE_NAME_PATTERN = /^[a-z0-9]+(?:[.-][a-z0-9]+)*$/;
const ROLE_CODE_PATTERN = /^[a-z0-9]+(?:[-_][a-z0-9]+)*$/;
const SUBJECT_HASH_PATTERN = /^(?:sha256:)?[a-f0-9]{32,128}$/;
const MAX_EVENT_ID_LENGTH = 128;
const MAX_CODE_LENGTH = 64;
const MAX_TRACE_ID_LENGTH = 128;
const MAX_ROUTE_NAME_LENGTH = 128;
const MAX_SUBJECT_HASH_LENGTH = 128;
const MAX_ROLE_CODE_LENGTH = 64;
const MAX_ROLE_CODES = 32;
const MODULE_MATRIX_FIELDS = new Set(['featureCode', 'pageCode', 'routeName', 'viewActionCode']);

const DEFAULT_CONFIG = Object.freeze({
  enabled: false,
  endpoint: '/brick/usage-events/collect',
  appCode: undefined,
  sender: defaultSender,
  now: () => new Date(),
  randomId: defaultRandomId,
  onError: undefined,
});

let config = { ...DEFAULT_CONFIG };

export function configureUsageEvents(nextConfig = {}) {
  if (nextConfig == null || typeof nextConfig !== 'object' || Array.isArray(nextConfig)) {
    throw new TypeError('Buck usage event config must be an object');
  }
  config = {
    ...config,
    ...nextConfig,
    enabled: Boolean(nextConfig.enabled ?? config.enabled),
    endpoint: String(nextConfig.endpoint ?? config.endpoint),
    appCode: nextConfig.appCode === undefined ? config.appCode : optionalString(nextConfig.appCode),
  };
}

export function resetUsageEventConfigForTesting() {
  config = { ...DEFAULT_CONFIG };
}

export async function bootstrapUsageEventsFromClientMeta(metaOrOptions = {}) {
  const options = isClientMetaLike(metaOrOptions) ? {} : normalizeBootstrapOptions(metaOrOptions);
  try {
    const meta = isClientMetaLike(metaOrOptions)
      ? metaOrOptions
      : await loadBrickClientMeta(options);
    return applyUsageEventsClientMeta(meta, options.overrides);
  } catch (error) {
    notifyBootstrapError(error, options);
    configureUsageEvents({ enabled: false });
    return {
      bootstrapped: false,
      enabled: false,
      reason: 'client-meta-failed',
      message: error.message,
    };
  }
}

export function applyUsageEventsClientMeta(meta, overrides = {}) {
  if (overrides == null || typeof overrides !== 'object' || Array.isArray(overrides)) {
    throw new TypeError('Buck usage event client meta overrides must be an object');
  }

  let result = {
    bootstrapped: false,
    enabled: false,
    reason: 'capability-missing',
  };
  const normalizedMeta = bootstrapBrickClient(meta, {
    usageEvent(capability, clientMeta) {
      const usageEventMeta = normalizeUsageEventClientMeta(capability);
      const enabled = Boolean(usageEventMeta.enabled);
      const nextConfig = {
        enabled,
        appCode: clientMeta.appCode,
        endpoint: usageEventMeta.collectEndpoint ?? DEFAULT_CONFIG.endpoint,
        ...overrides,
      };
      configureUsageEvents(nextConfig);
      result = {
        bootstrapped: true,
        enabled: Boolean(nextConfig.enabled),
        endpoint: nextConfig.endpoint,
        appCode: nextConfig.appCode,
      };
    },
  });

  if (!result.bootstrapped) {
    const enabled = Boolean(overrides.enabled ?? false);
    configureUsageEvents({
      enabled,
      appCode: normalizedMeta.appCode,
      ...overrides,
    });
  }
  return result;
}

export async function trackUsageEvent(input = {}) {
  if (!config.enabled) {
    return { tracked: false, reason: 'disabled' };
  }

  let payload;
  try {
    payload = buildUsageEventPayload(input);
  } catch (error) {
    notifyError(error, { phase: 'validate' });
    return { tracked: false, reason: 'invalid', message: error.message };
  }

  try {
    await config.sender(payload, { endpoint: config.endpoint });
    return { tracked: true };
  } catch (error) {
    notifyError(error, { phase: 'send', payload });
    return { tracked: false, reason: 'send-failed', message: error.message };
  }
}

export function trackPageView(input = {}) {
  return trackUsageEvent({
    ...input,
    eventType: 'PAGE_VIEW',
    actionCode: 'view',
    result: 'SUCCESS',
  });
}

export function trackFeatureEnter(input = {}) {
  return trackUsageEvent({
    ...input,
    eventType: 'FEATURE_ENTER',
    actionCode: 'enter',
    result: 'SUCCESS',
  });
}

export function trackActionComplete(input = {}) {
  return trackUsageEvent({
    ...input,
    eventType: 'ACTION',
    result: 'SUCCESS',
  });
}

export function trackActionFailure(input = {}) {
  return trackUsageEvent({
    ...input,
    eventType: 'ACTION',
    result: 'FAILURE',
  });
}

export function createModuleUsageTracker(moduleCode, matrix = {}) {
  const normalizedModuleCode = normalizeTrackerCode(moduleCode, 'moduleCode', STABLE_CODE_PATTERN);
  const normalizedMatrix = normalizeModuleUsageMatrix(matrix);

  function trackPage(pageKey) {
    const page = resolveModuleUsageEntry(normalizedMatrix.pages, pageKey, 'page');
    return trackPageView({
      moduleCode: normalizedModuleCode,
      ...page,
    });
  }

  function trackOpen(featureKey, actionCode, result = 'SUCCESS') {
    const feature = resolveModuleUsageEntry(normalizedMatrix.features, featureKey, 'feature');
    return trackUsageEvent({
      eventType: 'FEATURE_ENTER',
      result: requiredEnum(result, 'result', ALLOWED_RESULTS),
      moduleCode: normalizedModuleCode,
      featureCode: feature.featureCode,
      pageCode: feature.pageCode,
      routeName: feature.routeName,
      actionCode: normalizeTrackerCode(actionCode ?? feature.viewActionCode ?? 'enter', 'actionCode', STABLE_CODE_PATTERN),
    });
  }

  function trackActionResult(featureKey, actionCode, result) {
    return trackModuleActionResult(normalizedModuleCode, normalizedMatrix, featureKey, actionCode, result);
  }

  async function trackAction(featureKey, actionCode, asyncFn) {
    if (typeof asyncFn !== 'function') {
      throw new TypeError('Usage event module action runner must be a function');
    }
    const feature = resolveModuleUsageEntry(normalizedMatrix.features, featureKey, 'feature');
    const normalizedActionCode = normalizeTrackerCode(actionCode, 'actionCode', STABLE_CODE_PATTERN);
    try {
      const result = await asyncFn();
      await trackModuleActionResult(normalizedModuleCode, normalizedMatrix, featureKey, normalizedActionCode, 'SUCCESS', feature);
      return result;
    } catch (error) {
      await trackModuleActionResult(normalizedModuleCode, normalizedMatrix, featureKey, normalizedActionCode, 'FAILURE', feature);
      throw error;
    }
  }

  return Object.freeze({
    moduleCode: normalizedModuleCode,
    matrix: normalizedMatrix,
    trackPage,
    trackOpen,
    trackAction,
    trackActionResult,
  });
}

export function buildUsageEventPayload(input = {}) {
  if (input == null || typeof input !== 'object' || Array.isArray(input)) {
    throw new TypeError('Usage event must be an object');
  }
  validateAllowedFields(input);

  const payload = {
    schemaVersion: positiveIntegerOrDefault(input.schemaVersion, 1, 'schemaVersion'),
    eventId: requiredLimitedString(optionalString(input.eventId) ?? config.randomId(), 'eventId', MAX_EVENT_ID_LENGTH),
    occurredAt: normalizeOccurredAt(input.occurredAt),
    eventType: requiredEnum(input.eventType, 'eventType', ALLOWED_EVENT_TYPES),
    appCode: requiredPatternString(input.appCode ?? config.appCode, 'appCode', MAX_CODE_LENGTH, STABLE_CODE_PATTERN),
    moduleCode: requiredPatternString(input.moduleCode, 'moduleCode', MAX_CODE_LENGTH, STABLE_CODE_PATTERN),
    featureCode: requiredPatternString(input.featureCode, 'featureCode', MAX_CODE_LENGTH, STABLE_CODE_PATTERN),
    pageCode: requiredPatternString(input.pageCode, 'pageCode', MAX_CODE_LENGTH, STABLE_CODE_PATTERN),
    actionCode: requiredPatternString(input.actionCode, 'actionCode', MAX_CODE_LENGTH, STABLE_CODE_PATTERN),
    result: requiredEnum(input.result, 'result', ALLOWED_RESULTS),
  };

  putOptionalLimitedString(payload, 'traceId', input.traceId, MAX_TRACE_ID_LENGTH);
  putOptionalNumber(payload, 'durationMs', input.durationMs);
  putOptionalPatternString(payload, 'routeName', input.routeName, MAX_ROUTE_NAME_LENGTH, ROUTE_NAME_PATTERN);
  putOptionalPatternString(payload, 'subjectHash', input.subjectHash, MAX_SUBJECT_HASH_LENGTH, SUBJECT_HASH_PATTERN);
  const roleCodes = normalizeRoleCodes(input.roleCodes);
  if (roleCodes.length > 0) {
    payload.roleCodes = roleCodes;
  }
  return payload;
}

async function defaultSender(payload, context) {
  return brickRequest(context?.endpoint ?? DEFAULT_CONFIG.endpoint, {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

function validateAllowedFields(input) {
  for (const field of Object.keys(input)) {
    if (!ALLOWED_FIELDS.has(field)) {
      throw new TypeError(`Usage event field is not allowed: ${field}`);
    }
  }
}

function requiredString(value, fieldName) {
  const normalized = optionalString(value);
  if (normalized == null) {
    throw new TypeError(`${fieldName} must be a non-empty string`);
  }
  return normalized;
}

function requiredLimitedString(value, fieldName, maxLength) {
  const normalized = requiredString(value, fieldName);
  ensureMaxLength(normalized, fieldName, maxLength);
  return normalized;
}

function requiredPatternString(value, fieldName, maxLength, pattern) {
  const normalized = requiredLimitedString(value, fieldName, maxLength);
  if (!pattern.test(normalized)) {
    throw new TypeError(`${fieldName} format is invalid`);
  }
  return normalized;
}

function requiredEnum(value, fieldName, allowedValues) {
  const normalized = requiredString(value, fieldName);
  if (!allowedValues.has(normalized)) {
    throw new TypeError(`${fieldName} is not allowed`);
  }
  return normalized;
}

function optionalString(value) {
  if (value == null) {
    return undefined;
  }
  if (typeof value !== 'string') {
    throw new TypeError('Usage event string fields must be strings');
  }
  const trimmed = value.trim();
  return trimmed === '' ? undefined : trimmed;
}

function positiveIntegerOrDefault(value, defaultValue, fieldName) {
  if (value == null) {
    return defaultValue;
  }
  if (!Number.isInteger(value) || value < 1) {
    throw new TypeError(`${fieldName} must be a positive integer`);
  }
  return value;
}

function putOptionalLimitedString(payload, fieldName, value, maxLength) {
  const normalized = optionalString(value);
  if (normalized != null) {
    ensureMaxLength(normalized, fieldName, maxLength);
    payload[fieldName] = normalized;
  }
}

function putOptionalPatternString(payload, fieldName, value, maxLength, pattern) {
  const normalized = optionalString(value);
  if (normalized == null) {
    return;
  }
  ensureMaxLength(normalized, fieldName, maxLength);
  if (!pattern.test(normalized)) {
    throw new TypeError(`${fieldName} format is invalid`);
  }
  payload[fieldName] = normalized;
}

function putOptionalNumber(payload, fieldName, value) {
  if (value == null) {
    return;
  }
  if (!Number.isFinite(value) || value < 0) {
    throw new TypeError(`${fieldName} must be a non-negative finite number`);
  }
  payload[fieldName] = value;
}

function normalizeOccurredAt(value) {
  if (value == null) {
    return new Date(config.now()).toISOString();
  }
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) {
    throw new TypeError('occurredAt must be a valid date');
  }
  return date.toISOString();
}

function normalizeRoleCodes(roleCodes) {
  if (roleCodes == null) {
    return [];
  }
  if (!Array.isArray(roleCodes)) {
    throw new TypeError('roleCodes must be an array');
  }
  const normalized = [];
  const seen = new Set();
  for (const roleCode of roleCodes) {
    const value = requiredPatternString(roleCode, 'roleCodes', MAX_ROLE_CODE_LENGTH, ROLE_CODE_PATTERN);
    if (!seen.has(value)) {
      seen.add(value);
      normalized.push(value);
    }
  }
  if (normalized.length > MAX_ROLE_CODES) {
    throw new TypeError(`roleCodes must not contain more than ${MAX_ROLE_CODES} items`);
  }
  return normalized;
}

function trackModuleActionResult(moduleCode, matrix, featureKey, actionCode, result, resolvedFeature) {
  const feature = resolvedFeature ?? resolveModuleUsageEntry(matrix.features, featureKey, 'feature');
  const normalizedActionCode = normalizeTrackerCode(actionCode, 'actionCode', STABLE_CODE_PATTERN);
  return trackUsageEvent({
    eventType: 'ACTION',
    result: requiredEnum(result, 'result', ALLOWED_RESULTS),
    moduleCode,
    featureCode: feature.featureCode,
    pageCode: feature.pageCode,
    routeName: feature.routeName,
    actionCode: normalizedActionCode,
  });
}

function normalizeModuleUsageMatrix(matrix) {
  if (!isPlainObject(matrix)) {
    throw new TypeError('Usage event module matrix must be an object');
  }
  for (const field of Object.keys(matrix)) {
    if (field !== 'pages' && field !== 'features') {
      throw new TypeError(`Usage event module matrix field is not allowed: ${field}`);
    }
  }
  return deepFreeze({
    pages: normalizeModuleUsageEntries(matrix.pages ?? {}, 'pages'),
    features: normalizeModuleUsageEntries(matrix.features ?? {}, 'features'),
  });
}

function normalizeModuleUsageEntries(entries, groupName) {
  if (!isPlainObject(entries)) {
    throw new TypeError(`Usage event module matrix ${groupName} must be an object`);
  }
  const normalized = {};
  for (const [entryKey, entry] of Object.entries(entries)) {
    if (!entryKey) {
      throw new TypeError('Usage event module matrix key must be non-empty');
    }
    normalized[entryKey] = normalizeModuleUsageEntry(entry);
  }
  return normalized;
}

function normalizeModuleUsageEntry(entry) {
  if (!isPlainObject(entry)) {
    throw new TypeError('Usage event module matrix entry must be an object');
  }
  for (const field of Object.keys(entry)) {
    if (!MODULE_MATRIX_FIELDS.has(field)) {
      throw new TypeError(`Usage event module matrix field is not allowed: ${field}`);
    }
  }
  const normalized = {
    featureCode: normalizeTrackerCode(entry.featureCode, 'featureCode', STABLE_CODE_PATTERN),
    pageCode: normalizeTrackerCode(entry.pageCode, 'pageCode', STABLE_CODE_PATTERN),
  };
  const routeName = normalizeOptionalTrackerCode(entry.routeName, 'routeName', ROUTE_NAME_PATTERN);
  if (routeName != null) {
    normalized.routeName = routeName;
  }
  const viewActionCode = normalizeOptionalTrackerCode(entry.viewActionCode, 'viewActionCode', STABLE_CODE_PATTERN);
  if (viewActionCode != null) {
    normalized.viewActionCode = viewActionCode;
  }
  return normalized;
}

function resolveModuleUsageEntry(entries, entryKey, entryType) {
  const entry = entries[String(entryKey)];
  if (!entry) {
    throw new TypeError(`Unknown usage event ${entryType}: ${String(entryKey)}`);
  }
  return entry;
}

function normalizeTrackerCode(value, fieldName, pattern) {
  const normalized = requiredLimitedString(value, fieldName, fieldName === 'routeName' ? MAX_ROUTE_NAME_LENGTH : MAX_CODE_LENGTH);
  if (!pattern.test(normalized)) {
    throw new TypeError(`Usage event ${fieldName} format is invalid`);
  }
  return normalized;
}

function normalizeOptionalTrackerCode(value, fieldName, pattern) {
  const normalized = optionalString(value);
  if (normalized == null) {
    return undefined;
  }
  ensureMaxLength(normalized, fieldName, fieldName === 'routeName' ? MAX_ROUTE_NAME_LENGTH : MAX_CODE_LENGTH);
  if (!pattern.test(normalized)) {
    throw new TypeError(`Usage event ${fieldName} format is invalid`);
  }
  return normalized;
}

function normalizeUsageEventClientMeta(value) {
  if (value == null || typeof value !== 'object' || Array.isArray(value)) {
    throw new TypeError('Buck usage event client meta must be an object');
  }
  const enabled = Boolean(value.enabled);
  const schemaVersion = positiveIntegerOrDefault(value.schemaVersion, 1, 'schemaVersion');
  const collectEndpoint = optionalUsageEventEndpoint(value.collectEndpoint);
  if (enabled && collectEndpoint == null) {
    throw new TypeError('Buck usage event collectEndpoint must be configured when enabled');
  }
  return {
    enabled,
    schemaVersion,
    collectEndpoint,
  };
}

function optionalUsageEventEndpoint(value) {
  const normalized = optionalString(value);
  if (normalized == null) {
    return undefined;
  }
  if (!normalized.startsWith('/')) {
    throw new TypeError('Buck usage event collectEndpoint must be an absolute path');
  }
  return normalized;
}

function isClientMetaLike(value) {
  return value != null
    && typeof value === 'object'
    && !Array.isArray(value)
    && Object.hasOwn(value, 'capabilities');
}

function normalizeBootstrapOptions(value) {
  if (value == null) {
    return {};
  }
  if (typeof value !== 'object' || Array.isArray(value)) {
    throw new TypeError('Buck usage event client meta bootstrap options must be an object');
  }
  return value;
}

function notifyBootstrapError(error, options) {
  if (typeof options?.onError === 'function') {
    options.onError(error, { phase: 'client-meta' });
    return;
  }
  notifyError(error, { phase: 'client-meta' });
}

function defaultRandomId() {
  if (globalThis.crypto && typeof globalThis.crypto.randomUUID === 'function') {
    return globalThis.crypto.randomUUID();
  }
  return `usage-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function notifyError(error, context) {
  if (typeof config.onError !== 'function') {
    return;
  }
  try {
    config.onError(error, context);
  } catch {
    // 埋点错误回调也不能影响业务页面主流程。
  }
}

function ensureMaxLength(value, fieldName, maxLength) {
  if (value.length > maxLength) {
    throw new TypeError(`${fieldName} length must not exceed ${maxLength}`);
  }
}

function isPlainObject(value) {
  return value != null
    && typeof value === 'object'
    && !Array.isArray(value)
    && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
}

function deepFreeze(value) {
  if (value == null || typeof value !== 'object') {
    return value;
  }
  for (const child of Object.values(value)) {
    deepFreeze(child);
  }
  return Object.freeze(value);
}
