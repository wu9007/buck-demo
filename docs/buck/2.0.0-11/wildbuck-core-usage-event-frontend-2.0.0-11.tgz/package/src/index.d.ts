export interface BrickUsageEventInput {
  schemaVersion?: number;
  eventId?: string;
  occurredAt?: string | Date;
  eventType?: string;
  appCode?: string;
  moduleCode: string;
  featureCode: string;
  pageCode: string;
  actionCode?: string;
  result?: string;
  traceId?: string;
  durationMs?: number;
  routeName?: string;
  subjectHash?: string;
  roleCodes?: string[];
}

export interface BrickUsageEventConfig {
  enabled?: boolean;
  endpoint?: string;
  appCode?: string;
  sender?: (payload: Record<string, unknown>, context: { endpoint: string }) => Promise<unknown> | unknown;
  now?: () => Date | string | number;
  randomId?: () => string;
  onError?: (error: unknown, context: Record<string, unknown>) => void;
}

export interface BrickUsageEventTrackResult {
  tracked: boolean;
  reason?: 'disabled' | 'invalid' | 'send-failed';
  message?: string;
}

export type BrickUsageEventResult = 'SUCCESS' | 'FAILURE' | 'CANCELLED' | 'ABANDONED';

export interface BrickUsageEventsClientMetaBootstrapOptions {
  endpoint?: string;
  requestClient?: (path: string, init: RequestInit) => Promise<unknown>;
  overrides?: BrickUsageEventConfig;
  onError?: (error: unknown, context: Record<string, unknown>) => void;
}

export interface BrickUsageEventsClientMetaBootstrapResult {
  bootstrapped: boolean;
  enabled: boolean;
  endpoint?: string;
  appCode?: string;
  reason?: 'capability-missing' | 'client-meta-failed';
  message?: string;
}

export interface BrickModuleUsageEventEntry {
  featureCode: string;
  pageCode: string;
  routeName?: string;
  viewActionCode?: string;
}

export interface BrickModuleUsageEventMatrix {
  pages?: Record<string, BrickModuleUsageEventEntry>;
  features?: Record<string, BrickModuleUsageEventEntry>;
}

export interface BrickModuleUsageTracker {
  moduleCode: string;
  matrix: Readonly<{
    pages: Readonly<Record<string, Readonly<BrickModuleUsageEventEntry>>>;
    features: Readonly<Record<string, Readonly<BrickModuleUsageEventEntry>>>;
  }>;
  trackPage(pageKey: string): Promise<BrickUsageEventTrackResult>;
  trackOpen(featureKey: string, actionCode?: string, result?: BrickUsageEventResult): Promise<BrickUsageEventTrackResult>;
  trackActionResult(featureKey: string, actionCode: string, result: BrickUsageEventResult): Promise<BrickUsageEventTrackResult>;
  trackAction<T>(featureKey: string, actionCode: string, asyncFn: () => Promise<T> | T): Promise<T>;
}

export function configureUsageEvents(config: BrickUsageEventConfig): void;
export function resetUsageEventConfigForTesting(): void;
export function bootstrapUsageEventsFromClientMeta(
  metaOrOptions?: unknown | BrickUsageEventsClientMetaBootstrapOptions,
): Promise<BrickUsageEventsClientMetaBootstrapResult>;
export function applyUsageEventsClientMeta(
  meta: unknown,
  overrides?: BrickUsageEventConfig,
): BrickUsageEventsClientMetaBootstrapResult;
export function buildUsageEventPayload(input: BrickUsageEventInput): Record<string, unknown>;
export function trackUsageEvent(input: BrickUsageEventInput): Promise<BrickUsageEventTrackResult>;
export function trackPageView(input: Omit<BrickUsageEventInput, 'eventType' | 'actionCode' | 'result'>): Promise<BrickUsageEventTrackResult>;
export function trackFeatureEnter(input: Omit<BrickUsageEventInput, 'eventType' | 'actionCode' | 'result'>): Promise<BrickUsageEventTrackResult>;
export function trackActionComplete(input: Omit<BrickUsageEventInput, 'eventType' | 'result'>): Promise<BrickUsageEventTrackResult>;
export function trackActionFailure(input: Omit<BrickUsageEventInput, 'eventType' | 'result'>): Promise<BrickUsageEventTrackResult>;
export function createModuleUsageTracker(
  moduleCode: string,
  matrix: BrickModuleUsageEventMatrix,
): BrickModuleUsageTracker;
