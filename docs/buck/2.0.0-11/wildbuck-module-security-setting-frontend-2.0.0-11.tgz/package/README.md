# security-setting frontend

安全设置的前端模块包。

## 结构

- `src/generated`
  - 合同生成的 SDK、类型和错误定义
- `src/features/login-security`
  - 登录安全配置页面、路由、权限和 API 薄封装
- `src/features/password-policy`
  - 密码策略、初始密码、周期改密和密码生命周期动作页面、路由、权限和 API 薄封装
- `src/routes`
  - 模块级路由聚合出口

## i18n

- 词条键：`module.security-setting.*`
- 公开入口：`@wildbuck/module-security-setting-frontend/i18n`（`resolveSecuritySettingMessages` / `useSecuritySettingI18n`）
- 上层壳在 locale 同步时 `registerMessages('module-security-setting', resolveSecuritySettingMessages(locale))`

## 原则

- 不承载最终应用壳
- 不直接写原始接口字符串
- 登录安全和密码策略保持独立 feature 边界
- 对外暴露稳定的模块路由、权限和 feature registry
- 页面主文案走 i18n 词条，不硬编码中文
