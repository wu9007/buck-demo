import { createModuleUsageTracker } from '@wildbuck/core-usage-event-frontend';

export const SECURITY_SETTING_USAGE_EVENT_MODULE_CODE = 'security-setting';

export const securitySettingUsageEventMatrix = deepFreeze({
  pages: {
    loginSecurity: {
      featureCode: 'login-security',
      pageCode: 'login-security-page',
      routeName: 'security-setting.login-security',
    },
    passwordPolicy: {
      featureCode: 'password-policy',
      pageCode: 'password-policy-page',
      routeName: 'security-setting.password-policy',
    },
    transportSecurity: {
      featureCode: 'transport-security',
      pageCode: 'transport-security-page',
      routeName: 'security-setting.transport-security',
    },
    sessionToken: {
      featureCode: 'session-token',
      pageCode: 'session-token-page',
      routeName: 'security-setting.session-token',
    },
  },
  features: {
    'login-method': {
      featureCode: 'login-security-entry',
      pageCode: 'login-security-page',
      routeName: 'security-setting.login-security',
      viewActionCode: 'open-detail',
    },
    captcha: {
      featureCode: 'captcha-policy',
      pageCode: 'login-security-page',
      routeName: 'security-setting.login-security',
      viewActionCode: 'open-config',
    },
    'failure-freeze': {
      featureCode: 'login-failure-freeze-policy',
      pageCode: 'login-security-page',
      routeName: 'security-setting.login-security',
      viewActionCode: 'open-config',
    },
    mfa: {
      featureCode: 'mfa-policy',
      pageCode: 'login-security-page',
      routeName: 'security-setting.login-security',
      viewActionCode: 'open-config',
    },
    'verification-code': {
      featureCode: 'verification-code-policy',
      pageCode: 'login-security-page',
      routeName: 'security-setting.login-security',
      viewActionCode: 'open-config',
    },
    'device-check': {
      featureCode: 'device-check-policy',
      pageCode: 'login-security-page',
      routeName: 'security-setting.login-security',
      viewActionCode: 'open-config',
    },
    'session-token': {
      featureCode: 'session-token-policy',
      pageCode: 'session-token-page',
      routeName: 'security-setting.session-token',
      viewActionCode: 'open-config',
    },

    strength: {
      featureCode: 'password-strength-policy',
      pageCode: 'password-policy-page',
      routeName: 'security-setting.password-policy',
      viewActionCode: 'open-config',
    },
    'weak-password': {
      featureCode: 'weak-password-policy',
      pageCode: 'password-policy-page',
      routeName: 'security-setting.password-policy',
      viewActionCode: 'open-config',
    },
    'initial-password': {
      featureCode: 'initial-password-policy',
      pageCode: 'password-policy-page',
      routeName: 'security-setting.password-policy',
      viewActionCode: 'open-config',
    },
    cycle: {
      featureCode: 'password-cycle-policy',
      pageCode: 'password-policy-page',
      routeName: 'security-setting.password-policy',
      viewActionCode: 'open-config',
    },
    'lifecycle-actions': {
      featureCode: 'password-lifecycle-policy',
      pageCode: 'password-policy-page',
      routeName: 'security-setting.password-policy',
      viewActionCode: 'open-config',
    },
    'protected-range': {
      featureCode: 'transport-protected-range',
      pageCode: 'transport-security-page',
      routeName: 'security-setting.transport-security',
      viewActionCode: 'open-config',
    },
    'request-digest': {
      featureCode: 'transport-request-digest',
      pageCode: 'transport-security-page',
      routeName: 'security-setting.transport-security',
      viewActionCode: 'open-config',
    },
    execution: {
      featureCode: 'transport-execution-policy',
      pageCode: 'transport-security-page',
      routeName: 'security-setting.transport-security',
      viewActionCode: 'open-config',
    },
    replay: {
      featureCode: 'transport-replay-policy',
      pageCode: 'transport-security-page',
      routeName: 'security-setting.transport-security',
      viewActionCode: 'open-config',
    },
  },
});

export const securitySettingUsageTracker = createModuleUsageTracker(
  SECURITY_SETTING_USAGE_EVENT_MODULE_CODE,
  securitySettingUsageEventMatrix,
);

function deepFreeze(value) {
  if (value == null || typeof value !== 'object') {
    return value;
  }
  for (const child of Object.values(value)) {
    deepFreeze(child);
  }
  return Object.freeze(value);
}
