export interface BrickFrontendRouteRecord {
  id: string;
  featureKey: string;
  path: string;
  title: string;
  abbr?: string;
  iconName?: string;
  iconText?: string;
  eyebrow?: string;
  summary?: string;
  messages?: Record<string, string>;
  permission: string;
  component: () => Promise<unknown>;
}

export interface BrickFrontendModuleMeta {
  displayName: string;
}

export interface BrickFrontendFeatureDefinition {
  featureKey: string;
  routes: BrickFrontendRouteRecord[];
  permissions: Record<string, string>;
}

export declare const securitySettingFeatureRegistry: {
  loginSecurity: BrickFrontendFeatureDefinition;
  passwordPolicy: BrickFrontendFeatureDefinition;
  transportSecurity: BrickFrontendFeatureDefinition;
};

export declare const securitySettingPermissionMap: {
  loginSecurity: Record<string, string>;
  passwordPolicy: Record<string, string>;
  transportSecurity: Record<string, string>;
};

export declare const securitySettingRoutes: BrickFrontendRouteRecord[];
export declare const brickModuleKey: string;
export declare const brickModuleMeta: BrickFrontendModuleMeta;
export declare const brickFeatureRegistry: {
  loginSecurity: BrickFrontendFeatureDefinition;
  passwordPolicy: BrickFrontendFeatureDefinition;
  transportSecurity: BrickFrontendFeatureDefinition;
};
export declare const brickPermissionMap: {
  loginSecurity: Record<string, string>;
  passwordPolicy: Record<string, string>;
  transportSecurity: Record<string, string>;
};
export declare const brickRoutes: BrickFrontendRouteRecord[];

export type SecuritySettingUsageEventPageKey = 'loginSecurity' | 'passwordPolicy' | 'transportSecurity';
export type SecuritySettingUsageEventPolicyKey =
  | 'login-method'
  | 'captcha'
  | 'failure-freeze'
  | 'mfa'
  | 'verification-code'
  | 'strength'
  | 'weak-password'
  | 'initial-password'
  | 'cycle'
  | 'lifecycle-actions'
  | 'protected-range'
  | 'request-digest'
  | 'execution'
  | 'replay';
export interface SecuritySettingUsageEventPageEntry {
  featureCode: string;
  pageCode: string;
  routeName: string;
}
export interface SecuritySettingUsageEventFeatureEntry extends SecuritySettingUsageEventPageEntry {
  viewActionCode: 'open-config' | 'open-detail';
}
export declare const SECURITY_SETTING_USAGE_EVENT_MODULE_CODE: 'security-setting';
export declare const securitySettingUsageEventMatrix: Readonly<{
  pages: Record<SecuritySettingUsageEventPageKey, Readonly<SecuritySettingUsageEventPageEntry>>;
  features: Record<SecuritySettingUsageEventPolicyKey, Readonly<SecuritySettingUsageEventFeatureEntry>>;
}>;
export declare const securitySettingUsageTracker: import('@wildbuck/core-usage-event-frontend').BrickModuleUsageTracker;
