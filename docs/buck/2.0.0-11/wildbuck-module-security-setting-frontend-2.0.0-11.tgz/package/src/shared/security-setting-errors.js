/**
 * Unified security-setting user-facing error resolution.
 * Always prefer server payload + catalog via core-api helpers; never bare HTTP nnn.
 */
import { resolveBrickErrorFromCatalog, formatBrickCatalogError } from '@wildbuck/core-api-frontend';
import { securitySettingErrors } from '../generated/errors';

/**
 * @param {unknown} error
 * @param {string} [fallbackCode]
 * @returns {string}
 */
export function resolveSecuritySettingErrorMessage(error, fallbackCode = 'SECURITY_SETTING_LOGIN_SETTING_SAVE_FAILED') {
  return resolveBrickErrorFromCatalog(error, securitySettingErrors, {
    fallbackCode,
    localeHint: 'zh-CN',
  }).text;
}

/**
 * @param {string} code
 * @returns {string}
 */
export function formatSecuritySettingCatalogError(code) {
  const definition = securitySettingErrors[code];
  return formatBrickCatalogError(definition, { localeHint: 'zh-CN' });
}
