/**
 * Shared posture summarization for login / password / transport.
 * Feature modules only build domain items + gap text.
 */

/**
 * @typedef {'success' | 'warning' | 'danger' | 'info'} PostureTone
 * @typedef {'healthy' | 'attention' | 'elevated' | 'critical'} PostureLevel
 * @typedef {{ key: string, enabled?: boolean, severity?: number, tone?: PostureTone, [k: string]: unknown }} PostureItem
 */

/**
 * Map max severity → operator-facing level.
 * @param {number} maxSeverity
 * @returns {PostureLevel}
 */
export function postureLevelFromSeverity(maxSeverity) {
  if (maxSeverity >= 3) return 'critical';
  if (maxSeverity >= 2) return 'elevated';
  if (maxSeverity >= 1) return 'attention';
  return 'healthy';
}

/**
 * @param {PostureLevel} level
 * @returns {PostureTone}
 */
export function postureToneFromLevel(level) {
  if (level === 'critical') return 'danger';
  if (level === 'elevated' || level === 'attention') return 'warning';
  return 'success';
}

/**
 * Summarize posture items into level / tone / score.
 *
 * @param {PostureItem[]} items
 * @param {{
 *   offWeightKeys?: string[],
 *   severityWeight?: number,
 *   offWeight?: number,
 * }} [options]
 *   offWeightKeys: item keys excluded from "off" penalty (e.g. login-method, protected-range)
 * @returns {{ level: PostureLevel, tone: PostureTone, items: PostureItem[], score: number, maxSeverity: number }}
 */
export function summarizePostureItems(items, options = {}) {
  const list = Array.isArray(items) ? items : [];
  const severityWeight = options.severityWeight ?? 25;
  const offWeightUnit = options.offWeight ?? 5;
  const skipKeys = new Set(options.offWeightKeys || []);

  const maxSeverity = list.reduce((max, item) => Math.max(max, Number(item?.severity) || 0), 0);
  const level = postureLevelFromSeverity(maxSeverity);
  const tone = postureToneFromLevel(level);
  const offWeight = list.filter((item) => !item?.enabled && !skipKeys.has(item?.key)).length;
  const score = Math.max(0, 100 - maxSeverity * severityWeight - offWeight * offWeightUnit);

  return {
    level,
    tone,
    items: list,
    score,
    maxSeverity,
  };
}
