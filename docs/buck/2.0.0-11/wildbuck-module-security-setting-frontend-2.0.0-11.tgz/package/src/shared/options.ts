import { createOptionRequest, loadBrickOptions } from '@wildbuck/core-option-frontend';

export type SecuritySettingOptionItem = {
  label: string;
  value: string;
  description?: string;
  disabled?: boolean;
};

export async function loadSecuritySettingOptionItems(optionCode: string): Promise<SecuritySettingOptionItem[]> {
  const options = await loadBrickOptions([
    createOptionRequest(optionCode),
  ]);
  return normalizeSecuritySettingOptionItems(options[optionCode]);
}

export function normalizeSecuritySettingOptionItems(options: unknown): SecuritySettingOptionItem[] {
  if (!Array.isArray(options)) {
    return [];
  }
  return options
    .map((option) => {
      if (option == null || typeof option !== 'object') {
        return null;
      }
      const value = String((option as { value?: unknown }).value ?? '').trim();
      const label = String((option as { label?: unknown }).label ?? value).trim();
      const description = String((option as { description?: unknown }).description ?? '').trim();
      const disabled = Boolean((option as { disabled?: unknown }).disabled);
      return value
        ? { value, label: label || value, description: description || undefined, disabled }
        : null;
    })
    .filter((option): option is SecuritySettingOptionItem => option !== null);
}
