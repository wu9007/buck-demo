/**
 * Shared form helpers for security-setting login / password / transport.
 * Single clampInt (trunc) and stable policiesEqual — no per-feature copies.
 */

/**
 * Clamp to [min, max] using Math.trunc for integer policy fields.
 * Non-finite input uses fallback (defaults to min).
 *
 * @param {unknown} value
 * @param {number} min
 * @param {number} max
 * @param {number} [fallback=min]
 * @returns {number}
 */
export function clampInt(value, min, max, fallback = min) {
  const n = Number(value);
  if (!Number.isFinite(n)) {
    return fallback;
  }
  return Math.min(max, Math.max(min, Math.trunc(n)));
}

/**
 * Slider/input max: at least the fallback, and never below current value.
 * @param {unknown} currentValue
 * @param {number} fallback
 * @returns {number}
 */
export function scaleMax(currentValue, fallback) {
  return Math.max(Number(currentValue) || fallback, fallback);
}

/**
 * Push field key when value is outside [min, max] or non-finite.
 * @param {string[]} errors
 * @param {string} key
 * @param {unknown} value
 * @param {number} min
 * @param {number} max
 */
export function pushRange(errors, key, value, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n) || n < min || n > max) {
    errors.push(key);
  }
}

/**
 * Deep equality with sorted object keys so key insertion order does not flip dirty state.
 * @param {unknown} a
 * @param {unknown} b
 * @returns {boolean}
 */
export function policiesEqual(a, b) {
  return stableStringify(a) === stableStringify(b);
}

/**
 * @param {unknown} value
 * @returns {string}
 */
export function stableStringify(value) {
  if (value === null || typeof value !== 'object') {
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) {
    return `[${value.map((item) => stableStringify(item)).join(',')}]`;
  }
  const keys = Object.keys(value).sort();
  return `{${keys.map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(',')}}`;
}
