if (typeof document !== 'undefined') {
  void import('./settings-page.css');
}

import { loginSecurityFeature } from './features/login-security/index.js';
import { passwordPolicyFeature } from './features/password-policy/index.js';
import { transportSecurityFeature } from './features/transport-security/index.js';
import { sessionTokenFeature } from './features/session-token/index.js';
import { securitySettingRoutes, securitySettingWorkbenchCards } from './routes/index.js';

export const securitySettingFeatureRegistry = {
  loginSecurity: loginSecurityFeature,
  passwordPolicy: passwordPolicyFeature,
  transportSecurity: transportSecurityFeature,
  sessionToken: sessionTokenFeature,
};

export const securitySettingPermissionMap = {
  loginSecurity: loginSecurityFeature.permissions,
  passwordPolicy: passwordPolicyFeature.permissions,
  transportSecurity: transportSecurityFeature.permissions,
  sessionToken: sessionTokenFeature.permissions,
};

export const brickModuleKey = 'security-setting';
export const brickModuleMeta = {
  displayName: '安全配置',
};
export const brickFeatureRegistry = securitySettingFeatureRegistry;
export const brickPermissionMap = securitySettingPermissionMap;
export const brickRoutes = securitySettingRoutes;

export { securitySettingRoutes, securitySettingWorkbenchCards };
export {
  SECURITY_SETTING_USAGE_EVENT_MODULE_CODE,
  securitySettingUsageEventMatrix,
  securitySettingUsageTracker,
} from './usage-events.js';
