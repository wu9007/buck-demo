export type SecuritySettingUsageEventPageKey = 'loginSecurity' | 'passwordPolicy' | 'transportSecurity';
export type SecuritySettingLoginPolicyKey =
  | 'login-method'
  | 'captcha'
  | 'failure-freeze'
  | 'mfa'
  | 'verification-code';
export type SecuritySettingPasswordPolicyKey =
  | 'strength'
  | 'weak-password'
  | 'initial-password'
  | 'cycle'
  | 'lifecycle-actions';
export type SecuritySettingTransportPolicyKey =
  | 'protected-range'
  | 'request-digest'
  | 'execution'
  | 'replay';
export type SecuritySettingUsageEventPolicyKey =
  | SecuritySettingLoginPolicyKey
  | SecuritySettingPasswordPolicyKey
  | SecuritySettingTransportPolicyKey;

export interface SecuritySettingUsageEventPageEntry {
  featureCode: string;
  pageCode: string;
  routeName: string;
}

export interface SecuritySettingUsageEventFeatureEntry extends SecuritySettingUsageEventPageEntry {
  viewActionCode: 'open-config' | 'open-detail';
}

export declare const SECURITY_SETTING_USAGE_EVENT_MODULE_CODE: 'security-setting';
export declare const securitySettingUsageEventMatrix: Readonly<{
  pages: Record<SecuritySettingUsageEventPageKey, Readonly<SecuritySettingUsageEventPageEntry>>;
  features: Record<SecuritySettingUsageEventPolicyKey, Readonly<SecuritySettingUsageEventFeatureEntry>>;
}>;
export declare const securitySettingUsageTracker: import('@wildbuck/core-usage-event-frontend').BrickModuleUsageTracker;
