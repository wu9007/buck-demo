<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { isBrickSessionError } from '@wildbuck/core-api-frontend';
import { showBrickStatus } from '@wildbuck/core-ui-frontend/status';
import {
  BrickPageBlock,
  BrickSettingsCard as SecuritySettingsCard,
  BrickSettingsDrawer as SecuritySettingsDrawer,
  BrickSettingsDrawerSection,
  BrickSettingsGrid,
} from '@wildbuck/core-ui-frontend/patterns';
import type { LoginSecuritySetting, SecurityPolicyImpactItem } from '../../../generated/types';
import { resolveSecuritySettingErrorMessage } from '../../../shared/security-setting-errors.js';
import {
  securitySettingUsageTracker,
} from '../../../usage-events';
import {
  loadSecuritySettingOptionItems,
  type SecuritySettingOptionItem,
} from '../../../shared/options';
import { useSecuritySettingI18n } from '../../../i18n.js';
import {
  loadLoginSecuritySetting,
  saveLoginCaptchaPolicy,
  saveLoginDeviceCheckPolicy,
  saveLoginFailureFreezePolicy,
  saveLoginMfaPolicy,
  saveLoginVerificationCodePolicy,
} from '../api/login-security';
import {
  disableLoginFederatedSource,
  enableLoginFederatedSource,
  listLoginFederatedSources,
} from '../api/login-federated-sources.js';
import {
  cloneLoginSetting,
  createDefaultLoginSetting,
  impactRiskKey,
  impactStatusKey,
  normalizeLoginPolicySlice,
  normalizeMfaMode,
  policiesEqual,
  resolveLoginPolicyState,
  scaleMax,
  validateLoginPolicySlice,
} from '../lib/login-form.js';
import {
  buildLoginPosture,
  describeLoginPostureGaps,
  loginPolicyRiskTone,
} from '../lib/login-posture.js';

type PolicyTone = 'default' | 'success' | 'warning' | 'danger';
type LoginPolicyKey = 'login-method' | 'captcha' | 'failure-freeze' | 'mfa' | 'verification-code' | 'device-check';

type PolicyCard = {
  key: LoginPolicyKey;
  title: string;
  description: string;
  statusLabel: string;
  statusTone: PolicyTone;
  summaryItems: Array<{ label: string; value: string | number; tone?: PolicyTone }>;
  riskLabel?: string;
  riskTone?: PolicyTone;
  actionText?: string;
  saveable?: boolean;
};

const { t } = useSecuritySettingI18n();

const MFA_MODE_OPTION_CODE = 'security_setting_login_mfa_mode';
const smallCountMarks = { 1: '1', 3: '3', 5: '5', 10: '10' };
const minuteMarks = computed(() => ({
  5: t('module.security-setting.marks.min5'),
  30: t('module.security-setting.marks.min30'),
  60: t('module.security-setting.marks.hour1'),
  120: t('module.security-setting.marks.hour2'),
}));
const longMinuteMarks = computed(() => ({
  30: t('module.security-setting.marks.min30'),
  480: t('module.security-setting.marks.hour8'),
  1440: t('module.security-setting.marks.day1'),
}));
const shortMinuteMarks = computed(() => ({
  1: t('module.security-setting.marks.min1'),
  5: t('module.security-setting.marks.min5'),
  10: t('module.security-setting.marks.min10'),
  30: t('module.security-setting.marks.min30'),
}));
const impactPolicyKeyByLoginPolicy: Partial<Record<LoginPolicyKey, string>> = {
  mfa: 'login.mfa',
};

const loading = ref(true);
const saving = ref(false);
const loadFailed = ref(false);
const drawerVisible = ref(false);
const activePolicy = ref<LoginPolicyKey | null>(null);
const form = ref<LoginSecuritySetting>(createDefaultLoginSetting() as LoginSecuritySetting);
const draft = ref<LoginSecuritySetting>(createDefaultLoginSetting() as LoginSecuritySetting);
const mfaModeOptions = ref<SecuritySettingOptionItem[]>([]);

/** 外部身份源登录入口：主数据在联邦模块；开关写登录安全白名单 */
type FederatedSourceRow = {
  identitySourceId: string;
  sourceKey: string;
  displayName: string;
  sourceType: string;
  verificationStatus: string;
  loginEntryEnabled: boolean;
  secretConfigured?: boolean;
};
const federatedSources = ref<FederatedSourceRow[]>([]);
const federatedLoading = ref(false);
const federatedLoadFailed = ref(false);
const federatedTogglingKey = ref('');
const federatedEnabledCount = computed(
  () => federatedSources.value.filter((row) => row.loginEntryEnabled).length,
);

const posture = computed(() => buildLoginPosture(form.value));
const postureGaps = computed(() => describeLoginPostureGaps(form.value, {
  mfaOff: t('module.security-setting.loginSecurity.posture.gap.mfaOff'),
  freezeOff: t('module.security-setting.loginSecurity.posture.gap.freezeOff'),
  captchaOff: t('module.security-setting.loginSecurity.posture.gap.captchaOff'),
  codeOff: t('module.security-setting.loginSecurity.posture.gap.codeOff'),
  mfaWithoutCode: t('module.security-setting.loginSecurity.posture.gap.mfaWithoutCode'),
}));
const postureLevelLabel = computed(() => t(
  `module.security-setting.loginSecurity.posture.level.${posture.value.level}`,
));

const policyCards = computed<PolicyCard[]>(() => [
  {
    key: 'login-method',
    title: t('module.security-setting.loginSecurity.card.loginMethod.title'),
    description: t('module.security-setting.loginSecurity.card.loginMethod.description'),
    statusLabel: t('module.security-setting.loginSecurity.card.loginMethod.status'),
    statusTone: 'success',
    riskLabel: t('module.security-setting.loginSecurity.card.loginMethod.risk'),
    riskTone: loginPolicyRiskTone('login-method', form.value) as PolicyTone,
    actionText: t('module.security-setting.loginSecurity.card.loginMethod.action'),
    saveable: false,
    summaryItems: [
      { label: t('module.security-setting.common.summary'), value: formatLoginMethodSummary() },
    ],
  },
  {
    key: 'captcha',
    title: t('module.security-setting.loginSecurity.card.captcha.title'),
    description: t('module.security-setting.loginSecurity.card.captcha.description'),
    statusLabel: enabledLabel(form.value.captchaEnabled),
    statusTone: enabledTone(form.value.captchaEnabled),
    riskLabel: t('module.security-setting.loginSecurity.card.captcha.risk'),
    riskTone: loginPolicyRiskTone('captcha', form.value) as PolicyTone,
    summaryItems: [
      { label: t('module.security-setting.common.summary'), value: formatCaptchaTriggerFormula(form.value) },
    ],
  },
  {
    key: 'failure-freeze',
    title: t('module.security-setting.loginSecurity.card.failureFreeze.title'),
    description: t('module.security-setting.loginSecurity.card.failureFreeze.description'),
    statusLabel: enabledLabel(form.value.loginFailureFreezeEnabled),
    statusTone: enabledTone(form.value.loginFailureFreezeEnabled),
    riskLabel: t('module.security-setting.loginSecurity.card.failureFreeze.risk'),
    riskTone: loginPolicyRiskTone('failure-freeze', form.value) as PolicyTone,
    summaryItems: [
      { label: t('module.security-setting.common.summary'), value: formatLoginFreezeSummary(form.value) },
    ],
  },
  {
    key: 'mfa',
    title: t('module.security-setting.loginSecurity.card.mfa.title'),
    description: t('module.security-setting.loginSecurity.card.mfa.description'),
    statusLabel: enabledLabel(form.value.mfaEnabled),
    statusTone: enabledTone(form.value.mfaEnabled),
    riskLabel: t('module.security-setting.loginSecurity.card.mfa.risk'),
    riskTone: loginPolicyRiskTone('mfa', form.value) as PolicyTone,
    summaryItems: [
      { label: t('module.security-setting.common.summary'), value: formatMfaSummary(form.value) },
    ],
  },
  {
    key: 'verification-code',
    title: t('module.security-setting.loginSecurity.card.verificationCode.title'),
    description: t('module.security-setting.loginSecurity.card.verificationCode.description'),
    statusLabel: enabledLabel(form.value.verificationCodeEnabled),
    statusTone: enabledTone(form.value.verificationCodeEnabled),
    riskLabel: t('module.security-setting.loginSecurity.card.verificationCode.risk'),
    riskTone: loginPolicyRiskTone('verification-code', form.value) as PolicyTone,
    summaryItems: [
      { label: t('module.security-setting.common.summary'), value: formatVerificationCodeSummary(form.value) },
    ],
  },
  {
    key: 'device-check',
    title: t('module.security-setting.loginSecurity.card.deviceCheck.title'),
    description: t('module.security-setting.loginSecurity.card.deviceCheck.description'),
    statusLabel: enabledLabel(form.value.deviceCheckEnabled),
    statusTone: enabledTone(form.value.deviceCheckEnabled),
    riskLabel: t('module.security-setting.loginSecurity.card.deviceCheck.risk'),
    riskTone: form.value.deviceCheckEnabled ? 'default' : 'warning',
    summaryItems: [
      { label: t('module.security-setting.common.summary'), value: formatDeviceCheckSummary(form.value) },
    ],
  },
]);

const activePolicyMeta = computed(() => policyCards.value.find((item) => item.key === activePolicy.value) || null);
const activePolicyChanged = computed(() => {
  if (!activePolicy.value || activePolicyMeta.value?.saveable === false) {
    return false;
  }
  return !policiesEqual(
    resolveLoginPolicyState(activePolicy.value, draft.value),
    resolveLoginPolicyState(activePolicy.value, form.value),
  );
});
const activePolicyImpactItems = computed<SecurityPolicyImpactItem[]>(() => {
  const policyKey = activePolicy.value ? impactPolicyKeyByLoginPolicy[activePolicy.value] : undefined;
  if (!policyKey) {
    return [];
  }
  return form.value.impactAnalysis.items.filter((item) => item.policyKey === policyKey);
});
const mfaModeChoices = computed(() => mfaModeOptions.value.map((option) => ({
  value: option.value,
  label: option.label,
  description: option.description,
  disabled: option.disabled,
})));

onMounted(async () => {
  void securitySettingUsageTracker.trackPage('loginSecurity');
  await load();
});

async function load() {
  loading.value = true;
  loadFailed.value = false;
  try {
    await loadMfaModeOptions();
    form.value = await loadLoginSecuritySetting();
    draft.value = cloneLoginSetting(form.value) as LoginSecuritySetting;
    // 卡片摘要需要已启用身份源数量；失败不阻断登录安全主配置。
    await loadFederatedSources({ quiet: true });
  } catch (error) {
    if (isBrickSessionError(error)) {
      return;
    }
    loadFailed.value = true;
    showBrickStatus(resolveErrorMessage(error), 'error');
  } finally {
    loading.value = false;
  }
}

async function loadFederatedSources(options: { quiet?: boolean } = {}) {
  federatedLoading.value = true;
  federatedLoadFailed.value = false;
  try {
    federatedSources.value = (await listLoginFederatedSources()) as FederatedSourceRow[];
  } catch (error) {
    federatedSources.value = [];
    federatedLoadFailed.value = true;
    if (!options.quiet && !isBrickSessionError(error)) {
      showBrickStatus(
        t('module.security-setting.loginSecurity.drawer.loginMethod.federatedLoadFailed'),
        'error',
      );
    }
  } finally {
    federatedLoading.value = false;
  }
}

async function loadMfaModeOptions() {
  try {
    mfaModeOptions.value = await loadSecuritySettingOptionItems(MFA_MODE_OPTION_CODE);
  } catch {
    mfaModeOptions.value = [];
  }
}

function openPolicyDrawer(key: LoginPolicyKey) {
  activePolicy.value = key;
  draft.value = cloneLoginSetting(form.value) as LoginSecuritySetting;
  drawerVisible.value = true;
  void securitySettingUsageTracker.trackOpen(key);
  if (key === 'login-method') {
    void loadFederatedSources();
  }
}

function canEnableFederatedEntry(row: FederatedSourceRow) {
  return row.verificationStatus === 'VERIFIED' && row.secretConfigured !== false;
}

function federatedStatusLabel(status: string) {
  if (status === 'VERIFIED') {
    return t('module.security-setting.loginSecurity.drawer.loginMethod.federatedStatusVerified');
  }
  if (status === 'VERIFICATION_FAILED') {
    return t('module.security-setting.loginSecurity.drawer.loginMethod.federatedStatusFailed');
  }
  return t('module.security-setting.loginSecurity.drawer.loginMethod.federatedStatusUnverified');
}

async function onFederatedEntryToggle(row: FederatedSourceRow, nextEnabled: boolean) {
  if (!row?.sourceKey || federatedTogglingKey.value) {
    return;
  }
  if (nextEnabled && !canEnableFederatedEntry(row)) {
    showBrickStatus(
      row.verificationStatus !== 'VERIFIED'
        ? t('module.security-setting.loginSecurity.drawer.loginMethod.federatedNeedVerify')
        : t('module.security-setting.loginSecurity.drawer.loginMethod.federatedNeedSecret'),
      'warning',
    );
    return;
  }
  federatedTogglingKey.value = row.sourceKey;
  try {
    if (nextEnabled) {
      await enableLoginFederatedSource(row.sourceKey);
    } else {
      await disableLoginFederatedSource(row.sourceKey);
    }
    await loadFederatedSources();
    showBrickStatus(t('module.security-setting.common.saved', {
      title: t('module.security-setting.loginSecurity.card.loginMethod.title'),
    }), 'success');
  } catch (error) {
    if (isBrickSessionError(error)) {
      return;
    }
    showBrickStatus(resolveErrorMessage(error), 'error');
    await loadFederatedSources({ quiet: true });
  } finally {
    federatedTogglingKey.value = '';
  }
}

function openIdentitySourceManage() {
  window.location.assign('/identity-federation/auth-sources');
}

function updateDrawerVisible(value: boolean) {
  drawerVisible.value = value;
  if (!value) {
    activePolicy.value = null;
  }
}

async function saveActivePolicy() {
  const policy = activePolicy.value;
  if (!policy) {
    return;
  }
  if (activePolicyMeta.value?.saveable === false) {
    updateDrawerVisible(false);
    return;
  }

  const normalized = normalizeLoginPolicySlice(policy, draft.value) as LoginSecuritySetting;
  const validation = validateLoginPolicySlice(policy, normalized);
  if (!validation.ok) {
    showBrickStatus(t('module.security-setting.common.validation.invalid', {
      fields: validation.errors.join(', '),
    }), 'error');
    return;
  }
  draft.value = normalized;

  saving.value = true;
  try {
    form.value = await securitySettingUsageTracker.trackAction(policy, 'save', () => saveLoginPolicySlice(policy, normalized));
    draft.value = cloneLoginSetting(form.value) as LoginSecuritySetting;
    showBrickStatus(t('module.security-setting.common.saved', {
      title: activePolicyMeta.value?.title || t('module.security-setting.loginSecurity.policyDefaultTitle'),
    }), 'success');
    updateDrawerVisible(false);
  } catch (error) {
    if (isBrickSessionError(error)) {
      return;
    }
    showBrickStatus(resolveErrorMessage(error), 'error');
  } finally {
    saving.value = false;
  }
}

function saveLoginPolicySlice(policy: LoginPolicyKey, source: LoginSecuritySetting = draft.value): Promise<LoginSecuritySetting> {
  if (policy === 'captcha') {
    return saveLoginCaptchaPolicy({
      settingId: source.settingId,
      captchaEnabled: source.captchaEnabled,
      captchaTtlMinutes: source.captchaTtlMinutes,
      captchaFailureThreshold: source.captchaFailureThreshold,
      captchaFailureWindowMinutes: source.captchaFailureWindowMinutes,
      captchaRequiredDurationMinutes: source.captchaRequiredDurationMinutes,
    });
  }
  if (policy === 'failure-freeze') {
    return saveLoginFailureFreezePolicy({
      settingId: source.settingId,
      loginFailureFreezeEnabled: source.loginFailureFreezeEnabled,
      loginFailureWindowMinutes: source.loginFailureWindowMinutes,
      loginFailureMaxFailures: source.loginFailureMaxFailures,
      loginFailureLockMinutes: source.loginFailureLockMinutes,
    });
  }
  if (policy === 'mfa') {
    const mfaEnabled = source.mfaEnabled;
    return saveLoginMfaPolicy({
      settingId: source.settingId,
      mfaEnabled,
      mfaDefaultMode: mfaEnabled ? normalizeMfaMode(source.mfaDefaultMode) : 'NONE',
    });
  }
  if (policy === 'verification-code') {
    return saveLoginVerificationCodePolicy({
      settingId: source.settingId,
      verificationCodeEnabled: source.verificationCodeEnabled,
      verificationCodeTtlMinutes: source.verificationCodeTtlMinutes,
      verificationCodeSendWindowMinutes: source.verificationCodeSendWindowMinutes,
      verificationCodeMaxSendsPerWindow: source.verificationCodeMaxSendsPerWindow,
    });
  }
  if (policy === 'device-check') {
    return saveLoginDeviceCheckPolicy({
      settingId: source.settingId,
      deviceCheckEnabled: source.deviceCheckEnabled,
      deviceCheckRequireDeviceId: source.deviceCheckRequireDeviceId,
    });
  }
  return Promise.resolve(form.value);
}

function enabledLabel(enabled: boolean): string {
  return enabled
    ? t('module.security-setting.common.enabled')
    : t('module.security-setting.common.disabled');
}

function enabledTone(enabled: boolean): PolicyTone {
  return enabled ? 'success' : 'warning';
}

function impactStatusLabel(status?: string): string {
  return t(`module.security-setting.common.impactStatus.${impactStatusKey(status)}`);
}

function impactRiskLabel(riskLevel?: string): string {
  return t(`module.security-setting.common.impactRisk.${impactRiskKey(riskLevel)}`);
}

function resolveMfaModeLabel(value: string) {
  const normalized = normalizeMfaMode(value);
  return mfaModeOptions.value.find((option) => option.value === normalized)?.label || normalized;
}

function formatLoginMethodSummary() {
  if (federatedLoadFailed.value && federatedSources.value.length === 0) {
    return t('module.security-setting.loginSecurity.card.loginMethod.summaryUnknown');
  }
  return t('module.security-setting.loginSecurity.card.loginMethod.summary', {
    count: federatedEnabledCount.value,
  });
}

function formatCaptchaTriggerFormula(setting: LoginSecuritySetting) {
  return t('module.security-setting.loginSecurity.card.captcha.summary', {
    window: setting.captchaFailureWindowMinutes,
    threshold: setting.captchaFailureThreshold,
    duration: setting.captchaRequiredDurationMinutes,
  });
}

function formatLoginFreezeSummary(setting: LoginSecuritySetting) {
  return t('module.security-setting.loginSecurity.card.failureFreeze.summary', {
    window: setting.loginFailureWindowMinutes,
    max: setting.loginFailureMaxFailures,
    lock: setting.loginFailureLockMinutes,
  });
}

function formatMfaSummary(setting: LoginSecuritySetting) {
  const modeLabel = resolveMfaModeLabel(setting.mfaDefaultMode);
  return setting.mfaEnabled
    ? t('module.security-setting.loginSecurity.card.mfa.summaryEnabled', { mode: modeLabel })
    : t('module.security-setting.loginSecurity.card.mfa.summaryDisabled', { mode: modeLabel });
}

function formatVerificationCodeSummary(setting: LoginSecuritySetting) {
  return t('module.security-setting.loginSecurity.card.verificationCode.summary', {
    ttl: setting.verificationCodeTtlMinutes,
    window: setting.verificationCodeSendWindowMinutes,
    max: setting.verificationCodeMaxSendsPerWindow,
  });
}

function formatDeviceCheckSummary(setting: LoginSecuritySetting) {
  if (!setting.deviceCheckEnabled) {
    return t('module.security-setting.loginSecurity.card.deviceCheck.summaryDisabled');
  }
  return setting.deviceCheckRequireDeviceId
    ? t('module.security-setting.loginSecurity.card.deviceCheck.summaryRequireId')
    : t('module.security-setting.loginSecurity.card.deviceCheck.summaryOptionalId');
}

function resolveErrorMessage(error: unknown) {
  return resolveSecuritySettingErrorMessage(error, 'SECURITY_SETTING_LOGIN_SETTING_SAVE_FAILED');
}
</script>

<template>
  <article class="console-settings-page security-setting-page login-security-console">
    <BrickPageBlock
      :eyebrow="t('module.security-setting.loginSecurity.page.eyebrow')"
      :title="t('module.security-setting.loginSecurity.page.title')"
      :description="t('module.security-setting.loginSecurity.page.description')"
      :loading="loading"
      :loading-text="t('module.security-setting.loginSecurity.page.loading')"
    >
      <section
        v-if="!loadFailed"
        class="security-posture"
        data-guide-anchor="posture"
        :class="`security-posture--${posture.tone}`"
      >
        <div class="security-posture__head">
          <div>
            <p class="security-posture__eyebrow">{{ t('module.security-setting.loginSecurity.posture.eyebrow') }}</p>
            <h2 class="security-posture__title">{{ postureLevelLabel }}</h2>
            <p class="security-posture__hint">{{ t('module.security-setting.loginSecurity.posture.hint') }}</p>
          </div>
          <strong class="security-posture__score">{{ posture.score }}</strong>
        </div>
        <ul v-if="postureGaps.length" class="security-posture__gaps">
          <li v-for="gap in postureGaps" :key="gap">{{ gap }}</li>
        </ul>
      </section>

      <BrickSettingsGrid v-if="!loadFailed" data-guide-anchor="summary">
        <SecuritySettingsCard
          v-for="policy in policyCards"
          :key="policy.key"
          :title="policy.title"
          :description="policy.description"
          :status-label="policy.statusLabel"
          :status-tone="policy.statusTone"
          :summary-items="policy.summaryItems"
          :risk-label="policy.riskLabel"
          :risk-tone="policy.riskTone"
          :action-text="policy.actionText"
          @open="openPolicyDrawer(policy.key)"
        />
      </BrickSettingsGrid>
    </BrickPageBlock>

    <section v-if="loadFailed" class="state-panel">
      <p class="state-text">{{ t('module.security-setting.loginSecurity.page.loadFailed') }}</p>
      <el-button type="primary" plain @click="load">{{ t('module.security-setting.common.reload') }}</el-button>
    </section>

    <SecuritySettingsDrawer
      v-if="activePolicyMeta"
      :model-value="drawerVisible"
      :title="activePolicyMeta.title"
      :description="activePolicyMeta.description"
      :status-label="activePolicyMeta.statusLabel"
      :status-tone="activePolicyMeta.statusTone"
      :changed="activePolicyChanged"
      :saving="saving"
      :saveable="activePolicyMeta.saveable !== false"
      :save-text="t('module.security-setting.common.savePolicy')"
      @update:model-value="updateDrawerVisible"
      @save="saveActivePolicy"
    >
      <BrickSettingsDrawerSection
        v-if="activePolicyImpactItems.length"
        :title="t('module.security-setting.common.impactTitle')"
        :description="t('module.security-setting.common.impactDescription')"
      >
        <ul class="policy-impact-list">
          <li
            v-for="item in activePolicyImpactItems"
            :key="`${item.policyKey}:${item.dependencyKey}`"
            class="policy-impact-item"
            :data-status="item.status"
          >
            <div class="policy-impact-item__row">
              <strong class="policy-impact-item__title">{{ item.title }}</strong>
              <span class="policy-impact-item__badge">{{ impactStatusLabel(item.status) }} · {{ impactRiskLabel(item.riskLevel) }}</span>
            </div>
            <p v-if="item.recovery && (item.status === 'BLOCKED' || item.status === 'RISK')" class="policy-impact-item__recovery">
              {{ item.recovery }}
            </p>
          </li>
        </ul>
      </BrickSettingsDrawerSection>

      <BrickSettingsDrawerSection
        v-if="activePolicy === 'login-method'"
        :title="t('module.security-setting.loginSecurity.drawer.loginMethod.title')"
        :description="t('module.security-setting.loginSecurity.drawer.loginMethod.description')"
      >
        <el-form label-position="top" class="setting-form brick-required-form">
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.loginMethod.passwordLogin')">
            <div class="readonly-field">{{ t('module.security-setting.loginSecurity.drawer.loginMethod.passwordLoginValue') }}</div>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.loginMethod.accountSupport')">
            <div class="readonly-field">{{ t('module.security-setting.loginSecurity.drawer.loginMethod.accountSupportValue') }}</div>
          </el-form-item>

          <el-form-item
            :label="t('module.security-setting.loginSecurity.drawer.loginMethod.federatedTitle')"
            class="setting-form__full"
          >
            <p class="field-hint">
              {{ t('module.security-setting.loginSecurity.drawer.loginMethod.federatedHint') }}
            </p>
            <el-alert
              v-if="federatedLoadFailed"
              type="warning"
              :closable="false"
              show-icon
              class="login-method-federated-alert"
              :title="t('module.security-setting.loginSecurity.drawer.loginMethod.federatedLoadFailed')"
            />
            <el-table
              v-else
              v-loading="federatedLoading"
              :data="federatedSources"
              size="small"
              stripe
              class="login-method-federated-table"
              data-testid="login-method-federated-sources"
              :empty-text="t('module.security-setting.loginSecurity.drawer.loginMethod.federatedEmpty')"
            >
              <el-table-column
                prop="displayName"
                :label="t('module.security-setting.loginSecurity.drawer.loginMethod.federatedColName')"
                min-width="120"
              />
              <el-table-column
                prop="sourceKey"
                :label="t('module.security-setting.loginSecurity.drawer.loginMethod.federatedColKey')"
                min-width="100"
              >
                <template #default="{ row }">
                  <code>{{ row.sourceKey }}</code>
                </template>
              </el-table-column>
              <el-table-column
                :label="t('module.security-setting.loginSecurity.drawer.loginMethod.federatedColStatus')"
                width="100"
              >
                <template #default="{ row }">
                  {{ federatedStatusLabel(row.verificationStatus) }}
                </template>
              </el-table-column>
              <el-table-column
                :label="t('module.security-setting.loginSecurity.drawer.loginMethod.federatedColEntry')"
                width="120"
              >
                <template #default="{ row }">
                  <el-switch
                    :model-value="Boolean(row.loginEntryEnabled)"
                    :disabled="federatedTogglingKey === row.sourceKey
                      || (!row.loginEntryEnabled && !canEnableFederatedEntry(row))"
                    :loading="federatedTogglingKey === row.sourceKey"
                    :title="!canEnableFederatedEntry(row) && !row.loginEntryEnabled
                      ? (row.verificationStatus !== 'VERIFIED'
                        ? t('module.security-setting.loginSecurity.drawer.loginMethod.federatedNeedVerify')
                        : t('module.security-setting.loginSecurity.drawer.loginMethod.federatedNeedSecret'))
                      : undefined"
                    data-testid="login-method-federated-toggle"
                    @change="(value: boolean) => onFederatedEntryToggle(row, value)"
                  />
                </template>
              </el-table-column>
            </el-table>
            <div class="login-method-federated-actions">
              <el-button link type="primary" data-testid="login-method-open-authsource" @click="openIdentitySourceManage">
                {{ t('module.security-setting.loginSecurity.drawer.loginMethod.federatedManage') }}
              </el-button>
            </div>
          </el-form-item>

          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.loginMethod.reserved')" class="setting-form__full">
            <div class="readonly-field">
              {{ t('module.security-setting.loginSecurity.drawer.loginMethod.reservedValue') }}
            </div>
          </el-form-item>
        </el-form>
      </BrickSettingsDrawerSection>

      <BrickSettingsDrawerSection
        v-if="activePolicy === 'captcha'"
        :title="t('module.security-setting.loginSecurity.drawer.captcha.title')"
        :description="t('module.security-setting.loginSecurity.drawer.captcha.description')"
      >
        <el-form label-position="top" class="setting-form brick-required-form" :class="{ 'is-muted': !draft.captchaEnabled }">
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.captcha.status')" class="setting-form__full" required>
            <el-switch
              v-model="draft.captchaEnabled"
              :active-text="t('module.security-setting.common.enable')"
              :inactive-text="t('module.security-setting.common.disable')"
              inline-prompt
            />
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.captcha.statusHint') }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.captcha.threshold')" class="setting-form__full" required>
            <el-slider
              v-model="draft.captchaFailureThreshold"
              :min="1"
              :max="scaleMax(draft.captchaFailureThreshold, 10)"
              :marks="smallCountMarks"
              :disabled="!draft.captchaEnabled"
            />
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.captcha.thresholdHint', { count: draft.captchaFailureThreshold }) }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.captcha.window')" class="setting-form__full" required>
            <el-slider
              v-model="draft.captchaFailureWindowMinutes"
              :min="1"
              :max="scaleMax(draft.captchaFailureWindowMinutes, 120)"
              :marks="minuteMarks"
              :disabled="!draft.captchaEnabled"
            />
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.captcha.windowHint', { minutes: draft.captchaFailureWindowMinutes }) }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.captcha.duration')" class="setting-form__full" required>
            <el-slider
              v-model="draft.captchaRequiredDurationMinutes"
              :min="1"
              :max="scaleMax(draft.captchaRequiredDurationMinutes, 1440)"
              :marks="longMinuteMarks"
              :disabled="!draft.captchaEnabled"
            />
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.captcha.durationHint', { minutes: draft.captchaRequiredDurationMinutes }) }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.captcha.ttl')" class="setting-form__full" required>
            <el-slider
              v-model="draft.captchaTtlMinutes"
              :min="1"
              :max="scaleMax(draft.captchaTtlMinutes, 30)"
              :marks="shortMinuteMarks"
              :disabled="!draft.captchaEnabled"
            />
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.captcha.ttlHint', { minutes: draft.captchaTtlMinutes }) }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.captcha.formula')" class="setting-form__full">
            <div class="readonly-field readonly-field--formula">
              {{ formatCaptchaTriggerFormula(draft) }}{{ t('module.security-setting.loginSecurity.drawer.captcha.formulaSuffix') }}
            </div>
          </el-form-item>
        </el-form>
      </BrickSettingsDrawerSection>

      <BrickSettingsDrawerSection
        v-if="activePolicy === 'failure-freeze'"
        :title="t('module.security-setting.loginSecurity.drawer.failureFreeze.title')"
        :description="t('module.security-setting.loginSecurity.drawer.failureFreeze.description')"
      >
        <el-form label-position="top" class="setting-form brick-required-form" :class="{ 'is-muted': !draft.loginFailureFreezeEnabled }">
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.failureFreeze.status')" class="setting-form__full" required>
            <el-switch
              v-model="draft.loginFailureFreezeEnabled"
              :active-text="t('module.security-setting.common.enable')"
              :inactive-text="t('module.security-setting.common.disable')"
              inline-prompt
            />
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.failureFreeze.statusHint') }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.failureFreeze.window')" class="setting-form__full" required>
            <el-slider
              v-model="draft.loginFailureWindowMinutes"
              :min="1"
              :max="scaleMax(draft.loginFailureWindowMinutes, 120)"
              :marks="minuteMarks"
              :disabled="!draft.loginFailureFreezeEnabled"
            />
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.failureFreeze.windowHint', { minutes: draft.loginFailureWindowMinutes }) }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.failureFreeze.max')" class="setting-form__full" required>
            <el-slider
              v-model="draft.loginFailureMaxFailures"
              :min="1"
              :max="scaleMax(draft.loginFailureMaxFailures, 10)"
              :marks="smallCountMarks"
              :disabled="!draft.loginFailureFreezeEnabled"
            />
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.failureFreeze.maxHint', { count: draft.loginFailureMaxFailures }) }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.failureFreeze.lock')" class="setting-form__full" required>
            <el-slider
              v-model="draft.loginFailureLockMinutes"
              :min="1"
              :max="scaleMax(draft.loginFailureLockMinutes, 1440)"
              :marks="longMinuteMarks"
              :disabled="!draft.loginFailureFreezeEnabled"
            />
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.failureFreeze.lockHint', { minutes: draft.loginFailureLockMinutes }) }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.failureFreeze.formula')" class="setting-form__full">
            <div class="readonly-field readonly-field--formula">
              {{ t('module.security-setting.loginSecurity.drawer.failureFreeze.formulaValue', {
                window: draft.loginFailureWindowMinutes,
                max: draft.loginFailureMaxFailures,
                lock: draft.loginFailureLockMinutes,
              }) }}
            </div>
          </el-form-item>
        </el-form>
      </BrickSettingsDrawerSection>

      <BrickSettingsDrawerSection
        v-if="activePolicy === 'mfa'"
        :title="t('module.security-setting.loginSecurity.drawer.mfa.title')"
        :description="t('module.security-setting.loginSecurity.drawer.mfa.description')"
      >
        <el-form label-position="top" class="setting-form brick-required-form" :class="{ 'is-muted': !draft.mfaEnabled }">
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.mfa.status')" class="setting-form__full" required>
            <el-switch
              v-model="draft.mfaEnabled"
              :active-text="t('module.security-setting.common.enable')"
              :inactive-text="t('module.security-setting.common.disable')"
              inline-prompt
            />
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.mfa.statusHint') }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.mfa.firstFactor')">
            <div class="readonly-field">{{ t('module.security-setting.loginSecurity.drawer.mfa.firstFactorValue') }}</div>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.mfa.secondFactor')" class="setting-form__full" required>
            <el-radio-group
              :model-value="normalizeMfaMode(draft.mfaDefaultMode)"
              :disabled="!draft.mfaEnabled"
              @update:model-value="draft.mfaDefaultMode = String($event)"
            >
              <el-radio
                v-for="option in mfaModeChoices"
                :key="option.value"
                :value="option.value"
                :disabled="option.disabled"
              >
                {{ option.label }}
              </el-radio>
            </el-radio-group>
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.mfa.secondFactorHint') }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.mfa.chain')" class="setting-form__full">
            <div class="readonly-field readonly-field--formula">
              {{ draft.mfaEnabled
                ? t('module.security-setting.loginSecurity.drawer.mfa.chainEnabled', { mode: resolveMfaModeLabel(draft.mfaDefaultMode) })
                : t('module.security-setting.loginSecurity.drawer.mfa.chainDisabled') }}
            </div>
          </el-form-item>
        </el-form>
      </BrickSettingsDrawerSection>

      <BrickSettingsDrawerSection
        v-if="activePolicy === 'verification-code'"
        :title="t('module.security-setting.loginSecurity.drawer.verificationCode.title')"
        :description="t('module.security-setting.loginSecurity.drawer.verificationCode.description')"
      >
        <el-form label-position="top" class="setting-form brick-required-form" :class="{ 'is-muted': !draft.verificationCodeEnabled }">
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.verificationCode.status')" class="setting-form__full" required>
            <el-switch
              v-model="draft.verificationCodeEnabled"
              :active-text="t('module.security-setting.common.enable')"
              :inactive-text="t('module.security-setting.common.disable')"
              inline-prompt
            />
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.verificationCode.statusHint') }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.verificationCode.ttl')" class="setting-form__full" required>
            <el-slider
              v-model="draft.verificationCodeTtlMinutes"
              :min="1"
              :max="scaleMax(draft.verificationCodeTtlMinutes, 30)"
              :marks="shortMinuteMarks"
              :disabled="!draft.verificationCodeEnabled"
            />
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.verificationCode.ttlHint', { minutes: draft.verificationCodeTtlMinutes }) }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.verificationCode.window')" class="setting-form__full" required>
            <el-slider
              v-model="draft.verificationCodeSendWindowMinutes"
              :min="1"
              :max="scaleMax(draft.verificationCodeSendWindowMinutes, 120)"
              :marks="minuteMarks"
              :disabled="!draft.verificationCodeEnabled"
            />
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.verificationCode.windowHint', { minutes: draft.verificationCodeSendWindowMinutes }) }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.verificationCode.max')" class="setting-form__full" required>
            <el-slider
              v-model="draft.verificationCodeMaxSendsPerWindow"
              :min="1"
              :max="scaleMax(draft.verificationCodeMaxSendsPerWindow, 10)"
              :marks="smallCountMarks"
              :disabled="!draft.verificationCodeEnabled"
            />
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.verificationCode.maxHint', { count: draft.verificationCodeMaxSendsPerWindow }) }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.verificationCode.rate')" class="setting-form__full">
            <div class="readonly-field readonly-field--formula">
              {{ t('module.security-setting.loginSecurity.drawer.verificationCode.rateValue', {
                window: draft.verificationCodeSendWindowMinutes,
                max: draft.verificationCodeMaxSendsPerWindow,
                ttl: draft.verificationCodeTtlMinutes,
              }) }}
            </div>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.verificationCode.boundary')" class="setting-form__full">
            <div class="readonly-field">{{ t('module.security-setting.loginSecurity.drawer.verificationCode.boundaryValue') }}</div>
          </el-form-item>
        </el-form>
      </BrickSettingsDrawerSection>

      <BrickSettingsDrawerSection
        v-if="activePolicy === 'device-check'"
        :title="t('module.security-setting.loginSecurity.drawer.deviceCheck.title')"
        :description="t('module.security-setting.loginSecurity.drawer.deviceCheck.description')"
      >
        <el-form label-position="top" class="setting-form brick-required-form" :class="{ 'is-muted': !draft.deviceCheckEnabled }">
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.deviceCheck.status')" class="setting-form__full" required>
            <el-switch
              v-model="draft.deviceCheckEnabled"
              :active-text="t('module.security-setting.common.enable')"
              :inactive-text="t('module.security-setting.common.disable')"
              inline-prompt
            />
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.deviceCheck.statusHint') }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.loginSecurity.drawer.deviceCheck.requireId')" class="setting-form__full" required>
            <el-switch
              v-model="draft.deviceCheckRequireDeviceId"
              :active-text="t('module.security-setting.common.enable')"
              :inactive-text="t('module.security-setting.common.disable')"
              inline-prompt
              :disabled="!draft.deviceCheckEnabled"
            />
            <span class="field-hint">{{ t('module.security-setting.loginSecurity.drawer.deviceCheck.requireIdHint') }}</span>
          </el-form-item>
        </el-form>
      </BrickSettingsDrawerSection>
    </SecuritySettingsDrawer>
  </article>
</template>

<style>
@import "../../../settings-page.css";
@import "../../../security-posture.css";

.login-security-console .state-panel {
  display: grid;
  justify-items: start;
  gap: 16px;
}

.login-method-federated-alert {
  margin-bottom: 12px;
}

.login-method-federated-table {
  width: 100%;
  margin-top: 8px;
}

.login-method-federated-actions {
  margin-top: 10px;
}
</style>
