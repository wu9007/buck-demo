import {
  getLoginSecuritySetting,
  updateLoginCaptchaPolicySetting,
  updateLoginDeviceCheckPolicySetting,
  updateLoginFailureFreezePolicySetting,
  updateLoginMfaPolicySetting,
  updateLoginVerificationCodePolicySetting,
} from '../../../generated/sdk';
import type {
  LoginCaptchaPolicySetting,
  LoginDeviceCheckPolicySetting,
  LoginFailureFreezePolicySetting,
  LoginMfaPolicySetting,
  LoginSecuritySetting,
  LoginVerificationCodePolicySetting,
} from '../../../generated/types';

export async function loadLoginSecuritySetting(settingId = 'login-security'): Promise<LoginSecuritySetting> {
  return getLoginSecuritySetting({ settingId });
}

export async function saveLoginCaptchaPolicy(input: LoginCaptchaPolicySetting): Promise<LoginSecuritySetting> {
  return updateLoginCaptchaPolicySetting(input);
}

export async function saveLoginFailureFreezePolicy(input: LoginFailureFreezePolicySetting): Promise<LoginSecuritySetting> {
  return updateLoginFailureFreezePolicySetting(input);
}

export async function saveLoginMfaPolicy(input: LoginMfaPolicySetting): Promise<LoginSecuritySetting> {
  return updateLoginMfaPolicySetting(input);
}

export async function saveLoginVerificationCodePolicy(input: LoginVerificationCodePolicySetting): Promise<LoginSecuritySetting> {
  return updateLoginVerificationCodePolicySetting(input);
}

export async function saveLoginDeviceCheckPolicy(input: LoginDeviceCheckPolicySetting): Promise<LoginSecuritySetting> {
  return updateLoginDeviceCheckPolicySetting(input);
}
