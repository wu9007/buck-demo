export const loginSecurityPermissions = {
  view: 'security-setting:login-security:view',
  manage: 'security-setting:login-security:manage',
};
