import { request as brickRequest } from '@wildbuck/core-api-frontend';

/**
 * 登录方式：身份源主数据在 identity-federation；登录入口白名单在登录安全。
 *
 * 注意：brickRequest 的 body 必须是 JSON 字符串。
 */

/**
 * @typedef {object} LoginFederatedSourceRow
 * @property {string} identitySourceId
 * @property {string} sourceKey
 * @property {string} displayName
 * @property {string} sourceType
 * @property {string} verificationStatus
 * @property {boolean} loginEntryEnabled
 * @property {boolean} [secretConfigured]
 */

/**
 * @returns {Promise<LoginFederatedSourceRow[]>}
 */
export async function listLoginFederatedSources() {
  const page = await brickRequest('/identity-federation/auth-sources/search', {
    method: 'POST',
    body: JSON.stringify({
      page: 1,
      size: 100,
    }),
  });
  const records = page?.records || page?.items || [];
  return Array.isArray(records) ? records : [];
}

/**
 * @param {string} sourceKey
 */
export async function enableLoginFederatedSource(sourceKey) {
  return brickRequest('/security-setting/login-security/federated-login-entries/enable', {
    method: 'POST',
    body: JSON.stringify({ sourceKey }),
  });
}

/**
 * @param {string} sourceKey
 */
export async function disableLoginFederatedSource(sourceKey) {
  return brickRequest('/security-setting/login-security/federated-login-entries/disable', {
    method: 'POST',
    body: JSON.stringify({ sourceKey }),
  });
}
