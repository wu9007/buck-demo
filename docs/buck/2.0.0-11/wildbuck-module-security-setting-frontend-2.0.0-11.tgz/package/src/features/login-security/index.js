import { loginSecurityPermissions } from './permission/index.js';
import { loginSecurityRoutes } from './routes/index.js';

export const loginSecurityFeature = {
  featureKey: 'login-security',
  routes: loginSecurityRoutes,
  permissions: loginSecurityPermissions,
};
