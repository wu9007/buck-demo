import { transportSecurityPermissions } from './permission/index.js';
import { transportSecurityRoutes } from './routes/index.js';

export const transportSecurityFeature = {
  featureKey: 'transport-security',
  routes: transportSecurityRoutes,
  permissions: transportSecurityPermissions,
};
