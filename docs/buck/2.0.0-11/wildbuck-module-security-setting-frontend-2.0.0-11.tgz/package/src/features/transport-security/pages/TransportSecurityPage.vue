<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { isBrickSessionError } from '@wildbuck/core-api-frontend';
import { showBrickStatus } from '@wildbuck/core-ui-frontend/status';
import {
  BrickPageBlock,
  BrickSettingsCard as SecuritySettingsCard,
  BrickSettingsDrawer as SecuritySettingsDrawer,
  BrickSettingsDrawerSection,
  BrickSettingsGrid,
  BrickRiskConfirm,
} from '@wildbuck/core-ui-frontend/patterns';
import type { SecurityPolicyImpactItem, TransportSecuritySetting } from '../../../generated/types';
import { resolveSecuritySettingErrorMessage } from '../../../shared/security-setting-errors.js';
import {
  securitySettingUsageTracker,
} from '../../../usage-events';
import {
  loadSecuritySettingOptionItems,
  type SecuritySettingOptionItem,
} from '../../../shared/options';
import { useSecuritySettingI18n } from '../../../i18n.js';
import {
  loadTransportSecuritySetting,
  saveTransportExecutionPolicy,
  saveTransportProtectedRangePolicy,
  saveTransportReplayPolicy,
  saveTransportRequestDigestPolicy,
} from '../api/transport-security';
import {
  DEFAULT_PROTECTED_URL_REGEX,
  DEFAULT_REQUEST_DIGEST_PERMIT_URL_REGEXES,
  DEFAULT_REQUEST_DIGEST_PROTECTED_HEADERS,
  createDefaultTransportSetting as createDefaultTransportSettingBase,
  normalizeDigestAlgorithm,
  normalizeHeaderName,
  normalizeLineList,
  normalizeLineText,
  normalizeRegexList,
  normalizeRegexText,
  validateTransportPolicySlice,
} from '../lib/transport-form.js';
import {
  buildTransportPosture,
  describePostureGaps,
  policiesEqual,
  policyRiskTone,
} from '../lib/transport-posture.js';

type PolicyTone = 'default' | 'success' | 'warning' | 'danger';
type TransportPolicyKey = 'protected-range' | 'request-digest' | 'execution' | 'replay';
type PolicyCard = {
  key: TransportPolicyKey;
  title: string;
  description: string;
  statusLabel: string;
  statusTone: PolicyTone;
  summaryItems: Array<{ label: string; value: string | number; tone?: PolicyTone }>;
  riskLabel?: string;
  riskTone?: PolicyTone;
};

const { t } = useSecuritySettingI18n();

const impactPolicyKeyByTransportPolicy: Partial<Record<TransportPolicyKey, string>> = {
  'protected-range': 'transport.protected-range',
  'request-digest': 'transport.request-digest',
};

const loading = ref(true);
const saving = ref(false);
const saveConfirmVisible = ref(false);
const loadFailed = ref(false);
const drawerVisible = ref(false);
const activePolicy = ref<TransportPolicyKey | null>(null);
const protectedRegexDraft = ref('');
const requestDigestProtectedHeadersDraft = ref('');
const requestDigestPermitRegexDraft = ref('');
const defaultProtectedUrlRegex = DEFAULT_PROTECTED_URL_REGEX;
const DIGEST_ALGORITHM_OPTION_CODE = 'security_setting_transport_digest_algorithm';
const plaintextChoices = computed(() => [
  { value: 'reject', label: t('module.security-setting.transportSecurity.choice.rejectPlaintext'), description: t('module.security-setting.transportSecurity.choice.rejectPlaintextDesc') },
  { value: 'allow', label: t('module.security-setting.transportSecurity.choice.allowPlaintext'), description: t('module.security-setting.transportSecurity.choice.allowPlaintextDesc') },
]);
const responseEncryptionChoices = computed(() => [
  { value: 'encrypt', label: t('module.security-setting.transportSecurity.choice.encryptResponse'), description: t('module.security-setting.transportSecurity.choice.encryptResponseDesc') },
  { value: 'plain', label: t('module.security-setting.transportSecurity.choice.plainResponse'), description: t('module.security-setting.transportSecurity.choice.plainResponseDesc') },
]);
const secondsMarks = computed(() => ({
  30: t('module.security-setting.marks.sec30'),
  60: t('module.security-setting.marks.min1Long'),
  300: t('module.security-setting.marks.min5Long'),
  600: t('module.security-setting.marks.min10Long'),
}));
const replayTtlMarks = computed(() => ({
  60: t('module.security-setting.marks.min1Long'),
  300: t('module.security-setting.marks.min5Long'),
  600: t('module.security-setting.marks.min10Long'),
  3600: t('module.security-setting.marks.hour1'),
}));
const digestAlgorithmOptions = ref<SecuritySettingOptionItem[]>([]);
const form = ref<TransportSecuritySetting>(createDefaultTransportSetting());
const draftForm = ref<TransportSecuritySetting>(createDefaultTransportSetting());

const policyCards = computed<PolicyCard[]>(() => [
  {
    key: 'protected-range',
    title: t('module.security-setting.transportSecurity.card.protectedRange.title'),
    description: t('module.security-setting.transportSecurity.card.protectedRange.description'),
    statusLabel: t('module.security-setting.transportSecurity.rulesCount', {
      count: normalizeRegexList(form.value.protectedUrlRegexes).length,
    }),
    statusTone: policyRiskTone('protected-range', form.value) === 'warning' ? 'warning' : 'default',
    riskLabel: t('module.security-setting.transportSecurity.card.protectedRange.risk'),
    riskTone: policyRiskTone('protected-range', form.value) as PolicyTone,
    summaryItems: [
      { label: t('module.security-setting.common.summary'), value: formatProtectedRangeSummary(form.value) },
    ],
  },
  {
    key: 'request-digest',
    title: t('module.security-setting.transportSecurity.card.requestDigest.title'),
    description: t('module.security-setting.transportSecurity.card.requestDigest.description'),
    statusLabel: enabledLabel(form.value.requestDigestEnabled),
    statusTone: enabledTone(form.value.requestDigestEnabled),
    riskLabel: t('module.security-setting.transportSecurity.card.requestDigest.risk'),
    riskTone: policyRiskTone('request-digest', form.value) as PolicyTone,
    summaryItems: [
      { label: t('module.security-setting.common.summary'), value: formatRequestDigestSummary(form.value) },
    ],
  },
  {
    key: 'execution',
    title: t('module.security-setting.transportSecurity.card.execution.title'),
    description: t('module.security-setting.transportSecurity.card.execution.description'),
    statusLabel: enabledLabel(form.value.enabled),
    statusTone: enabledTone(form.value.enabled),
    riskLabel: t('module.security-setting.transportSecurity.card.execution.risk'),
    riskTone: policyRiskTone('execution', form.value) as PolicyTone,
    summaryItems: [
      { label: t('module.security-setting.common.summary'), value: formatTransportExecutionSummary(form.value) },
    ],
  },
  {
    key: 'replay',
    title: t('module.security-setting.transportSecurity.card.replay.title'),
    description: t('module.security-setting.transportSecurity.card.replay.description'),
    statusLabel: enabledLabel(form.value.replayProtectionEnabled),
    statusTone: enabledTone(form.value.replayProtectionEnabled),
    riskLabel: t('module.security-setting.transportSecurity.card.replay.risk'),
    riskTone: policyRiskTone('replay', form.value) as PolicyTone,
    summaryItems: [
      { label: t('module.security-setting.common.summary'), value: formatReplaySummary(form.value) },
    ],
  },
]);

const posture = computed(() => buildTransportPosture(form.value));
const postureGaps = computed(() => describePostureGaps(form.value, {
  transportOff: t('module.security-setting.transportSecurity.posture.gap.transportOff'),
  plaintextAllowed: t('module.security-setting.transportSecurity.posture.gap.plaintextAllowed'),
  digestOff: t('module.security-setting.transportSecurity.posture.gap.digestOff'),
  replayOff: t('module.security-setting.transportSecurity.posture.gap.replayOff'),
  noProtectedRange: t('module.security-setting.transportSecurity.posture.gap.noProtectedRange'),
}));
const postureLevelLabel = computed(() => {
  const level = posture.value.level;
  return t(`module.security-setting.transportSecurity.posture.level.${level}`);
});

const activePolicyMeta = computed(() => policyCards.value.find((item) => item.key === activePolicy.value) || null);
const activePolicyChanged = computed(() => {
  if (!activePolicy.value) {
    return false;
  }
  return !policiesEqual(
    resolvePolicyState(activePolicy.value, buildNormalizedForm()),
    resolvePolicyState(activePolicy.value, form.value),
  );
});
const activePolicyImpactItems = computed<SecurityPolicyImpactItem[]>(() => {
  const policyKey = activePolicy.value ? impactPolicyKeyByTransportPolicy[activePolicy.value] : undefined;
  if (!policyKey) {
    return [];
  }
  return form.value.impactAnalysis.items.filter((item) => item.policyKey === policyKey);
});
const digestAlgorithmChoices = computed(() => digestAlgorithmOptions.value.map((option) => ({
  value: option.value,
  label: option.label,
  description: option.description,
  disabled: option.disabled,
})));

onMounted(async () => {
  void securitySettingUsageTracker.trackPage('transportSecurity');
  await load();
});

async function load() {
  loading.value = true;
  loadFailed.value = false;
  try {
    await loadDigestAlgorithmOptions();
    form.value = normalizeTransportSetting(await loadTransportSecuritySetting());
    draftForm.value = cloneTransportSetting(form.value);
    syncDraftFields(draftForm.value);
  } catch (error) {
    if (isBrickSessionError(error)) {
      return;
    }
    loadFailed.value = true;
    showBrickStatus(resolveSaveErrorMessage(error), 'error');
  } finally {
    loading.value = false;
  }
}

async function loadDigestAlgorithmOptions() {
  try {
    digestAlgorithmOptions.value = await loadSecuritySettingOptionItems(DIGEST_ALGORITHM_OPTION_CODE);
  } catch {
    digestAlgorithmOptions.value = [];
  }
}

function openPolicyDrawer(key: TransportPolicyKey) {
  activePolicy.value = key;
  draftForm.value = cloneTransportSetting(form.value);
  syncDraftFields(draftForm.value);
  drawerVisible.value = true;
  void securitySettingUsageTracker.trackOpen(key);
}

function updateDrawerVisible(value: boolean) {
  drawerVisible.value = value;
  if (!value) {
    activePolicy.value = null;
  }
}

function openSaveConfirm() {
  if (saving.value || !activePolicy.value) {
    return;
  }
  const validation = validateTransportPolicySlice(activePolicy.value, buildNormalizedForm());
  if (!validation.valid) {
    showBrickStatus(t('module.security-setting.transportSecurity.validation.invalid', {
      fields: validation.errors.join(', '),
    }), 'error');
    return;
  }
  saveConfirmVisible.value = true;
}

async function saveActivePolicy() {
  const policy = activePolicy.value;
  if (!policy) {
    return;
  }
  const validation = validateTransportPolicySlice(policy, buildNormalizedForm());
  if (!validation.valid) {
    showBrickStatus(t('module.security-setting.transportSecurity.validation.invalid', {
      fields: validation.errors.join(', '),
    }), 'error');
    saveConfirmVisible.value = false;
    return;
  }
  saving.value = true;
  try {
    form.value = normalizeTransportSetting(await securitySettingUsageTracker.trackAction(policy, 'save', () =>
      saveTransportPolicySlice(policy),
    ));
    draftForm.value = cloneTransportSetting(form.value);
    syncDraftFields(draftForm.value);
    showBrickStatus(t('module.security-setting.common.saved', {
      title: activePolicyMeta.value?.title || t('module.security-setting.transportSecurity.policyDefaultTitle'),
    }), 'success');
    updateDrawerVisible(false);
  } catch (error) {
    if (isBrickSessionError(error)) {
      return;
    }
    showBrickStatus(resolveSaveErrorMessage(error), 'error');
  } finally {
    saving.value = false;
    saveConfirmVisible.value = false;
  }
}

function saveTransportPolicySlice(policy: TransportPolicyKey): Promise<TransportSecuritySetting> {
  const source = buildNormalizedForm();
  if (policy === 'protected-range') {
    return saveTransportProtectedRangePolicy({
      settingId: source.settingId,
      protectedUrlRegexes: source.protectedUrlRegexes,
    });
  }
  if (policy === 'request-digest') {
    return saveTransportRequestDigestPolicy({
      settingId: source.settingId,
      requestDigestEnabled: source.requestDigestEnabled,
      requestDigestAlgorithm: source.requestDigestAlgorithm,
      requestDigestHeaderName: source.requestDigestHeaderName,
      requestDigestProtectedHeaders: source.requestDigestProtectedHeaders,
      requestDigestPermitUrlRegexes: source.requestDigestPermitUrlRegexes,
    });
  }
  if (policy === 'execution') {
    return saveTransportExecutionPolicy({
      settingId: source.settingId,
      enabled: source.enabled,
      providerType: 'SOFT_GM',
      rejectPlaintext: source.rejectPlaintext,
      encryptResponse: source.encryptResponse,
    });
  }
  if (policy === 'replay') {
    return saveTransportReplayPolicy({
      settingId: source.settingId,
      metadataHeaderName: source.metadataHeaderName,
      replayProtectionEnabled: source.replayProtectionEnabled,
      timestampSkewSeconds: source.timestampSkewSeconds,
      replayTtlSeconds: source.replayTtlSeconds,
    });
  }
  return Promise.resolve(form.value);
}

function buildNormalizedForm(): TransportSecuritySetting {
  return normalizeTransportSetting({
    ...draftForm.value,
    protectedUrlRegexes: normalizeRegexText(protectedRegexDraft.value, [defaultProtectedUrlRegex]),
    requestDigestProtectedHeaders: normalizeLineText(
      requestDigestProtectedHeadersDraft.value,
      defaultRequestDigestProtectedHeaders,
    ),
    requestDigestPermitUrlRegexes: normalizeRegexText(
      requestDigestPermitRegexDraft.value,
      defaultRequestDigestPermitUrlRegexes,
    ),
  });
}

function resolvePolicyState(policy: TransportPolicyKey, setting: TransportSecuritySetting) {
  if (policy === 'protected-range') {
    return {
      protectedUrlRegexes: normalizeRegexList(setting.protectedUrlRegexes, [defaultProtectedUrlRegex]),
    };
  }
  if (policy === 'request-digest') {
    return {
      requestDigestEnabled: setting.requestDigestEnabled,
      requestDigestAlgorithm: normalizeDigestAlgorithm(setting.requestDigestAlgorithm),
      requestDigestHeaderName: normalizeHeaderName(setting.requestDigestHeaderName, 'rd'),
      requestDigestProtectedHeaders: normalizeLineList(setting.requestDigestProtectedHeaders, defaultRequestDigestProtectedHeaders),
      requestDigestPermitUrlRegexes: normalizeRegexList(setting.requestDigestPermitUrlRegexes, defaultRequestDigestPermitUrlRegexes),
    };
  }
  if (policy === 'execution') {
    return {
      enabled: setting.enabled,
      providerType: 'SOFT_GM',
      rejectPlaintext: setting.rejectPlaintext,
      encryptResponse: setting.encryptResponse,
    };
  }
  if (policy === 'replay') {
    return {
      metadataHeaderName: normalizeHeaderName(setting.metadataHeaderName, 'X-Brick-Transport-Key'),
      replayProtectionEnabled: setting.replayProtectionEnabled,
      timestampSkewSeconds: setting.timestampSkewSeconds,
      replayTtlSeconds: setting.replayTtlSeconds,
    };
  }
  return {};
}

function normalizeTransportSetting(setting: TransportSecuritySetting): TransportSecuritySetting {
  return {
    ...setting,
    providerType: 'SOFT_GM',
    requestDigestAlgorithm: normalizeDigestAlgorithm(setting.requestDigestAlgorithm),
    requestDigestHeaderName: normalizeHeaderName(setting.requestDigestHeaderName, 'rd'),
    protectedUrlRegexes: normalizeRegexList(setting.protectedUrlRegexes, [defaultProtectedUrlRegex]),
    requestDigestProtectedHeaders: normalizeLineList(
      setting.requestDigestProtectedHeaders,
      defaultRequestDigestProtectedHeaders,
    ),
    requestDigestPermitUrlRegexes: normalizeRegexList(
      setting.requestDigestPermitUrlRegexes,
      defaultRequestDigestPermitUrlRegexes,
    ),
  };
}

function syncDraftFields(setting: TransportSecuritySetting) {
  protectedRegexDraft.value = normalizeRegexList(setting.protectedUrlRegexes, [defaultProtectedUrlRegex]).join('\n');
  requestDigestProtectedHeadersDraft.value = normalizeLineList(
    setting.requestDigestProtectedHeaders,
    defaultRequestDigestProtectedHeaders,
  ).join('\n');
  requestDigestPermitRegexDraft.value = normalizeRegexList(
    setting.requestDigestPermitUrlRegexes,
    defaultRequestDigestPermitUrlRegexes,
  ).join('\n');
}

function enabledLabel(enabled: boolean): string {
  return enabled
    ? t('module.security-setting.common.enabled')
    : t('module.security-setting.common.disabled');
}

function enabledTone(enabled: boolean): PolicyTone {
  return enabled ? 'success' : 'warning';
}

function impactStatusLabel(status?: string): string {
  if (status === 'BLOCKED') {
    return t('module.security-setting.common.impactStatus.blocked');
  }
  if (status === 'RISK') {
    return t('module.security-setting.common.impactStatus.risk');
  }
  if (status === 'SATISFIED') {
    return t('module.security-setting.common.impactStatus.satisfied');
  }
  return t('module.security-setting.common.impactStatus.hint');
}

function impactRiskLabel(riskLevel?: string): string {
  if (riskLevel === 'HIGH') {
    return t('module.security-setting.common.impactRisk.high');
  }
  if (riskLevel === 'MEDIUM') {
    return t('module.security-setting.common.impactRisk.medium');
  }
  if (riskLevel === 'LOW') {
    return t('module.security-setting.common.impactRisk.low');
  }
  return t('module.security-setting.common.impactRisk.none');
}

function transportImplementationLabel(providerType?: string | null): string {
  return t('module.security-setting.transportSecurity.implementation');
}

function formatProtectedRangeSummary(setting: TransportSecuritySetting) {
  const count = normalizeRegexList(setting.protectedUrlRegexes).length;
  return t('module.security-setting.transportSecurity.card.protectedRange.summary', { count });
}

function formatRequestDigestSummary(setting: TransportSecuritySetting) {
  const algorithm = normalizeDigestAlgorithm(setting.requestDigestAlgorithm);
  const permitCount = normalizeRegexList(
    setting.requestDigestPermitUrlRegexes,
    defaultRequestDigestPermitUrlRegexes,
  ).length;
  return setting.requestDigestEnabled
    ? t('module.security-setting.transportSecurity.card.requestDigest.summaryEnabled', {
      algorithm,
      count: permitCount,
    })
    : t('module.security-setting.transportSecurity.card.requestDigest.summaryDisabled', {
      count: permitCount,
    });
}

function formatTransportExecutionSummary(setting: TransportSecuritySetting) {
  const plaintextText = setting.rejectPlaintext
    ? t('module.security-setting.transportSecurity.card.execution.rejectPlaintext')
    : t('module.security-setting.transportSecurity.card.execution.allowPlaintext');
  const responseText = setting.encryptResponse
    ? t('module.security-setting.transportSecurity.card.execution.encryptResponse')
    : t('module.security-setting.transportSecurity.card.execution.plainResponse');
  return t('module.security-setting.transportSecurity.card.execution.summary', {
    impl: transportImplementationLabel(setting.providerType),
    plaintext: plaintextText,
    response: responseText,
  });
}

function formatReplaySummary(setting: TransportSecuritySetting) {
  const params = { skew: setting.timestampSkewSeconds, ttl: setting.replayTtlSeconds };
  return setting.replayProtectionEnabled
    ? t('module.security-setting.transportSecurity.card.replay.summaryEnabled', params)
    : t('module.security-setting.transportSecurity.card.replay.summaryDisabled', params);
}

function scaleMax(currentValue: number, fallback: number) {
  return Math.max(Number(currentValue) || fallback, fallback);
}

const defaultRequestDigestProtectedHeaders = [...DEFAULT_REQUEST_DIGEST_PROTECTED_HEADERS];
const defaultRequestDigestPermitUrlRegexes = [...DEFAULT_REQUEST_DIGEST_PERMIT_URL_REGEXES];

function cloneTransportSetting(setting: TransportSecuritySetting): TransportSecuritySetting {
  return JSON.parse(JSON.stringify(setting)) as TransportSecuritySetting;
}

function createDefaultTransportSetting(): TransportSecuritySetting {
  return createDefaultTransportSettingBase() as TransportSecuritySetting;
}

function resolveSaveErrorMessage(error?: unknown) {
  return resolveSecuritySettingErrorMessage(error, 'SECURITY_SETTING_TRANSPORT_SECURITY_SAVE_FAILED');
}
</script>

<template>
  <article class="console-settings-page security-setting-page transport-security-console">
    <BrickPageBlock
      :eyebrow="t('module.security-setting.transportSecurity.page.eyebrow')"
      :title="t('module.security-setting.transportSecurity.page.title')"
      :description="t('module.security-setting.transportSecurity.page.description')"
      :loading="loading"
      :loading-text="t('module.security-setting.transportSecurity.page.loading')"
    >
      <section
        v-if="!loadFailed"
        class="security-posture"
        data-guide-anchor="posture"
        :class="`security-posture--${posture.tone}`"
      >
        <div class="security-posture__head">
          <div>
            <p class="security-posture__eyebrow">{{ t('module.security-setting.transportSecurity.posture.eyebrow') }}</p>
            <h2 class="security-posture__title">{{ postureLevelLabel }}</h2>
            <p class="security-posture__hint">{{ t('module.security-setting.transportSecurity.posture.hint') }}</p>
          </div>
          <strong class="security-posture__score">{{ posture.score }}</strong>
        </div>
        <ul v-if="postureGaps.length" class="security-posture__gaps">
          <li v-for="gap in postureGaps" :key="gap">{{ gap }}</li>
        </ul>
      </section>

      <BrickSettingsGrid v-if="!loadFailed" data-guide-anchor="summary">
        <SecuritySettingsCard
          v-for="policy in policyCards"
          :key="policy.key"
          :title="policy.title"
          :description="policy.description"
          :status-label="policy.statusLabel"
          :status-tone="policy.statusTone"
          :summary-items="policy.summaryItems"
          :risk-label="policy.riskLabel"
          :risk-tone="policy.riskTone"
          @open="openPolicyDrawer(policy.key)"
        />
      </BrickSettingsGrid>
    </BrickPageBlock>

    <section v-if="loadFailed" class="state-panel">
      <p class="state-text">{{ t('module.security-setting.transportSecurity.page.loadFailed') }}</p>
      <el-button type="primary" plain @click="load">{{ t('module.security-setting.common.reload') }}</el-button>
    </section>

    <SecuritySettingsDrawer
      v-if="activePolicyMeta"
      :model-value="drawerVisible"
      :title="activePolicyMeta.title"
      :description="activePolicyMeta.description"
      :status-label="activePolicyMeta.statusLabel"
      :status-tone="activePolicyMeta.statusTone"
      :changed="activePolicyChanged"
      :saving="saving"
      :save-text="t('module.security-setting.common.savePolicy')"
      @update:model-value="updateDrawerVisible"
      @save="openSaveConfirm"
    >
      <BrickSettingsDrawerSection
        v-if="activePolicyImpactItems.length"
        :title="t('module.security-setting.common.impactTitle')"
        :description="t('module.security-setting.common.impactDescription')"
      >
        <!-- Compact impact list: title + status only; recovery when action is needed. Avoid wall-of-text. -->
        <ul class="policy-impact-list">
          <li
            v-for="item in activePolicyImpactItems"
            :key="`${item.policyKey}:${item.dependencyKey}`"
            class="policy-impact-item"
            :data-status="item.status"
          >
            <div class="policy-impact-item__row">
              <strong class="policy-impact-item__title">{{ item.title }}</strong>
              <span class="policy-impact-item__badge">{{ impactStatusLabel(item.status) }} · {{ impactRiskLabel(item.riskLevel) }}</span>
            </div>
            <p v-if="item.recovery && (item.status === 'BLOCKED' || item.status === 'RISK')" class="policy-impact-item__recovery">
              {{ item.recovery }}
            </p>
          </li>
        </ul>
      </BrickSettingsDrawerSection>

      <BrickSettingsDrawerSection
        v-if="activePolicy === 'protected-range'"
        :title="t('module.security-setting.transportSecurity.drawer.protectedRange.title')"
        :description="t('module.security-setting.transportSecurity.drawer.protectedRange.description')"
      >
        <el-form label-position="top" class="setting-form brick-required-form">
          <el-form-item :label="t('module.security-setting.transportSecurity.drawer.protectedRange.regex')" class="setting-form__full">
            <el-input v-model="protectedRegexDraft" type="textarea" :rows="4" placeholder="^/brick/login$" />
            <small class="field-hint">{{ t('module.security-setting.transportSecurity.drawer.protectedRange.regexHint') }}</small>
          </el-form-item>
          <div class="readonly-field setting-form__full regex-default-note">
            <span>{{ t('module.security-setting.transportSecurity.drawer.protectedRange.defaultBuiltin') }}</span>
            <strong>{{ defaultProtectedUrlRegex }}</strong>
          </div>
        </el-form>
      </BrickSettingsDrawerSection>

      <BrickSettingsDrawerSection
        v-if="activePolicy === 'request-digest'"
        :title="t('module.security-setting.transportSecurity.drawer.requestDigest.title')"
        :description="t('module.security-setting.transportSecurity.drawer.requestDigest.description')"
      >
        <el-form label-position="top" class="setting-form brick-required-form">
          <el-form-item :label="t('module.security-setting.transportSecurity.drawer.requestDigest.status')" class="setting-form__full" required>
            <el-switch v-model="draftForm.requestDigestEnabled" :active-text="t('module.security-setting.common.enable')" :inactive-text="t('module.security-setting.common.disable')" inline-prompt />
          </el-form-item>
          <el-form-item :label="t('module.security-setting.transportSecurity.drawer.requestDigest.algorithm')" class="setting-form__full" required>
            <el-radio-group v-model="draftForm.requestDigestAlgorithm" :disabled="!draftForm.requestDigestEnabled">
              <el-radio
                v-for="option in digestAlgorithmChoices"
                :key="option.value"
                :value="option.value"
                :disabled="option.disabled"
              >
                {{ option.label }}
              </el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.transportSecurity.drawer.requestDigest.header')" required>
            <el-input v-model="draftForm.requestDigestHeaderName" :disabled="!draftForm.requestDigestEnabled" />
          </el-form-item>
          <el-form-item :label="t('module.security-setting.transportSecurity.drawer.requestDigest.protectedHeaders')" class="setting-form__full" required>
            <el-input v-model="requestDigestProtectedHeadersDraft" type="textarea" :rows="4" :disabled="!draftForm.requestDigestEnabled" />
            <small class="field-hint">{{ t('module.security-setting.transportSecurity.drawer.requestDigest.protectedHeadersHint') }}</small>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.transportSecurity.drawer.requestDigest.permit')" class="setting-form__full">
            <el-input v-model="requestDigestPermitRegexDraft" type="textarea" :rows="4" :disabled="!draftForm.requestDigestEnabled" />
            <small class="field-hint">{{ t('module.security-setting.transportSecurity.drawer.requestDigest.permitHint') }}</small>
          </el-form-item>
        </el-form>
      </BrickSettingsDrawerSection>

      <BrickSettingsDrawerSection
        v-if="activePolicy === 'execution'"
        :title="t('module.security-setting.transportSecurity.drawer.execution.title')"
        :description="t('module.security-setting.transportSecurity.drawer.execution.description')"
      >
        <el-form label-position="top" class="setting-form brick-required-form" :class="{ 'is-muted': !draftForm.enabled }">
          <el-form-item :label="t('module.security-setting.transportSecurity.drawer.execution.status')" class="setting-form__full" required>
            <el-switch v-model="draftForm.enabled" :active-text="t('module.security-setting.common.enable')" :inactive-text="t('module.security-setting.common.disable')" inline-prompt />
            <span class="field-hint">{{ t('module.security-setting.transportSecurity.drawer.execution.statusHint') }}</span>
          </el-form-item>
          <div class="readonly-field setting-form__full">
            <span>{{ t('module.security-setting.transportSecurity.drawer.execution.impl') }}</span>
            <strong>{{ transportImplementationLabel(draftForm.providerType) }}</strong>
          </div>
          <el-form-item :label="t('module.security-setting.transportSecurity.drawer.execution.plaintext')" class="setting-form__full" required>
            <el-radio-group
              :model-value="draftForm.rejectPlaintext ? 'reject' : 'allow'"
              :disabled="!draftForm.enabled"
              @update:model-value="draftForm.rejectPlaintext = $event === 'reject'"
            >
              <el-radio v-for="option in plaintextChoices" :key="option.value" :value="option.value">
                {{ option.label }}
              </el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.transportSecurity.drawer.execution.response')" class="setting-form__full" required>
            <el-radio-group
              :model-value="draftForm.encryptResponse ? 'encrypt' : 'plain'"
              :disabled="!draftForm.enabled"
              @update:model-value="draftForm.encryptResponse = $event === 'encrypt'"
            >
              <el-radio v-for="option in responseEncryptionChoices" :key="option.value" :value="option.value">
                {{ option.label }}
              </el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.transportSecurity.drawer.execution.result')" class="setting-form__full">
            <div class="readonly-field readonly-field--formula">
              {{ t('module.security-setting.transportSecurity.drawer.execution.resultValue') }}
            </div>
          </el-form-item>
        </el-form>
      </BrickSettingsDrawerSection>

      <BrickSettingsDrawerSection
        v-if="activePolicy === 'replay'"
        :title="t('module.security-setting.transportSecurity.drawer.replay.title')"
        :description="t('module.security-setting.transportSecurity.drawer.replay.description')"
      >
        <el-form label-position="top" class="setting-form brick-required-form" :class="{ 'is-muted': !draftForm.enabled }">
          <el-form-item :label="t('module.security-setting.transportSecurity.drawer.replay.metadataHeader')" class="setting-form__full" required>
            <el-input v-model="draftForm.metadataHeaderName" type="text" />
          </el-form-item>
          <el-form-item :label="t('module.security-setting.transportSecurity.drawer.replay.status')" class="setting-form__full" required>
            <el-switch v-model="draftForm.replayProtectionEnabled" :active-text="t('module.security-setting.common.enable')" :inactive-text="t('module.security-setting.common.disable')" inline-prompt />
            <span class="field-hint">{{ t('module.security-setting.transportSecurity.drawer.replay.statusHint') }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.transportSecurity.drawer.replay.skew')" class="setting-form__full" required>
            <el-slider
              v-model="draftForm.timestampSkewSeconds"
              :min="1"
              :max="scaleMax(draftForm.timestampSkewSeconds, 600)"
              :marks="secondsMarks"
              :disabled="!draftForm.enabled"
            />
            <span class="field-hint">{{ t('module.security-setting.transportSecurity.drawer.replay.skewHint', { seconds: draftForm.timestampSkewSeconds }) }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.transportSecurity.drawer.replay.ttl')" class="setting-form__full" required>
            <el-slider
              v-model="draftForm.replayTtlSeconds"
              :min="1"
              :max="scaleMax(draftForm.replayTtlSeconds, 3600)"
              :marks="replayTtlMarks"
              :disabled="!draftForm.enabled || !draftForm.replayProtectionEnabled"
            />
            <span class="field-hint">{{ t('module.security-setting.transportSecurity.drawer.replay.ttlHint', { seconds: draftForm.replayTtlSeconds }) }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.transportSecurity.drawer.replay.fields')" class="setting-form__full">
            <div class="readonly-field">{{ t('module.security-setting.transportSecurity.drawer.replay.fieldsValue') }}</div>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.transportSecurity.drawer.replay.window')" class="setting-form__full">
            <div class="readonly-field readonly-field--formula">
              {{ t('module.security-setting.transportSecurity.drawer.replay.windowValue') }}
            </div>
          </el-form-item>
        </el-form>
      </BrickSettingsDrawerSection>
    </SecuritySettingsDrawer>

    <BrickRiskConfirm
      v-model="saveConfirmVisible"
      :title="t('module.security-setting.transportSecurity.confirm.title')"
      :description="t('module.security-setting.transportSecurity.confirm.description', {
        title: activePolicyMeta?.title || t('module.security-setting.transportSecurity.policyDefaultTitle'),
      })"
      :impact="[
        t('module.security-setting.transportSecurity.confirm.impact1'),
        t('module.security-setting.transportSecurity.confirm.impact2'),
      ]"
      :confirm-text="t('module.security-setting.transportSecurity.confirm.confirm')"
      :cancel-text="t('module.security-setting.transportSecurity.confirm.cancel')"
      :loading="saving"
      @confirm="saveActivePolicy"
    />
  </article>
</template>

<style>
@import "../../../settings-page.css";
@import "../../../security-posture.css";

.transport-security-console .state-panel {
  display: grid;
  justify-items: start;
  gap: 16px;
}
</style>
