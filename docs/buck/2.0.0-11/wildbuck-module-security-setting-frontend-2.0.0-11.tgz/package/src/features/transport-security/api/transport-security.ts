import {
  getTransportSecuritySetting,
  updateTransportExecutionPolicySetting,
  updateTransportProtectedRangePolicySetting,
  updateTransportReplayPolicySetting,
  updateTransportRequestDigestPolicySetting,
} from '../../../generated/sdk';
import type {
  TransportExecutionPolicySetting,
  TransportProtectedRangePolicySetting,
  TransportReplayPolicySetting,
  TransportRequestDigestPolicySetting,
  TransportSecuritySetting,
} from '../../../generated/types';

export async function loadTransportSecuritySetting(settingId = 'transport-security'): Promise<TransportSecuritySetting> {
  return getTransportSecuritySetting({ settingId });
}

export async function saveTransportProtectedRangePolicy(
  input: TransportProtectedRangePolicySetting,
): Promise<TransportSecuritySetting> {
  return updateTransportProtectedRangePolicySetting(input);
}

export async function saveTransportRequestDigestPolicy(
  input: TransportRequestDigestPolicySetting,
): Promise<TransportSecuritySetting> {
  return updateTransportRequestDigestPolicySetting(input);
}

export async function saveTransportExecutionPolicy(
  input: TransportExecutionPolicySetting,
): Promise<TransportSecuritySetting> {
  return updateTransportExecutionPolicySetting(input);
}

export async function saveTransportReplayPolicy(
  input: TransportReplayPolicySetting,
): Promise<TransportSecuritySetting> {
  return updateTransportReplayPolicySetting(input);
}
