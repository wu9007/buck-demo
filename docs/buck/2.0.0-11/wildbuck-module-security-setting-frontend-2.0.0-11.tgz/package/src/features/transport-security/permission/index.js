export const transportSecurityPermissions = {
  view: 'security-setting:transport-security:view',
  manage: 'security-setting:transport-security:manage',
};
