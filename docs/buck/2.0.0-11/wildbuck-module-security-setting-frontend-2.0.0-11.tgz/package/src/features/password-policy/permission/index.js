export const passwordPolicyPermissions = {
  view: 'security-setting:password-policy:view',
  manage: 'security-setting:password-policy:manage',
};
