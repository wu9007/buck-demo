<script setup lang="ts">
import {
  BrickPageBlock,
  BrickSettingsCard as SecuritySettingsCard,
  BrickSettingsDrawer as SecuritySettingsDrawer,
  BrickSettingsDrawerSection,
  BrickSettingsGrid,
} from '@wildbuck/core-ui-frontend/patterns';
import { usePasswordPolicyWorkspace } from '../composables/usePasswordPolicyWorkspace';

const {
  t,
  passwordLengthMarks,
  initialPasswordValidDayMarks,
  periodicChangeDayMarks,
  noticeDayMarks,
  repeatTimesMarks,
  characterRuleChoices,
  exclusionRuleChoices,
  initialPasswordWriteChoices,
  loading,
  saving,
  loadFailed,
  drawerVisible,
  activePolicy,
  replaceInitialPassword,
  initialPasswordDraft,
  initialPasswordConfigured,
  policyForm,
  draftPolicy,
  actionForm,
  draftAction,
  actionOptions,
  weakScanStarting,
  weakScanRunning,
  weakScanStatus,
  weakScanInlineError,
  posture,
  postureGaps,
  postureLevelLabel,
  weakScanHitRows,
  weakScanProgressStatus,
  weakScanStatusLabel,
  weakScanFinished,
  policyCards,
  weakPasswordCount,
  draftStrengthCharacterRules,
  draftStrengthExclusionRules,
  strengthPreviewMessage,
  weakPasswordRawCount,
  weakPasswordDuplicateCount,
  lifecycleActionChoices,
  activePolicyMeta,
  activePolicyChanged,
  openPolicyDrawer,
  updateDrawerVisible,
  saveActivePolicy,
  load,
  startWeakPasswordScan,
  updateDraftAction,
  scaleMax,
} = usePasswordPolicyWorkspace();
</script>

<template>
  <article class="console-settings-page security-setting-page password-policy-console">
    <BrickPageBlock
      :eyebrow="t('module.security-setting.passwordPolicy.page.eyebrow')"
      :title="t('module.security-setting.passwordPolicy.page.title')"
      :description="t('module.security-setting.passwordPolicy.page.description')"
      :loading="loading"
      :loading-text="t('module.security-setting.passwordPolicy.page.loading')"
    >
      <section
        v-if="!loadFailed"
        class="security-posture"
        data-guide-anchor="posture"
        :class="`security-posture--${posture.tone}`"
      >
        <div class="security-posture__head">
          <div>
            <p class="security-posture__eyebrow">{{ t('module.security-setting.passwordPolicy.posture.eyebrow') }}</p>
            <h2 class="security-posture__title">{{ postureLevelLabel }}</h2>
            <p class="security-posture__hint">{{ t('module.security-setting.passwordPolicy.posture.hint') }}</p>
          </div>
          <strong class="security-posture__score">{{ posture.score }}</strong>
        </div>
        <ul v-if="postureGaps.length" class="security-posture__gaps">
          <li v-for="gap in postureGaps" :key="gap">{{ gap }}</li>
        </ul>
      </section>

      <BrickSettingsGrid v-if="!loadFailed" data-guide-anchor="summary">
        <SecuritySettingsCard
          v-for="policy in policyCards"
          :key="policy.key"
          :title="policy.title"
          :description="policy.description"
          :status-label="policy.statusLabel"
          :status-tone="policy.statusTone"
          :summary-items="policy.summaryItems"
          :risk-label="policy.riskLabel"
          :risk-tone="policy.riskTone"
          @open="openPolicyDrawer(policy.key)"
        />
      </BrickSettingsGrid>
    </BrickPageBlock>

    <section v-if="loadFailed" class="state-panel">
      <p class="state-text">{{ t('module.security-setting.passwordPolicy.page.loadFailed') }}</p>
      <el-button type="primary" plain @click="load">{{ t('module.security-setting.common.reload') }}</el-button>
    </section>

    <SecuritySettingsDrawer
      v-if="activePolicyMeta"
      :model-value="drawerVisible"
      :title="activePolicyMeta.title"
      :description="activePolicyMeta.description"
      :status-label="activePolicyMeta.statusLabel"
      :status-tone="activePolicyMeta.statusTone"
      :changed="activePolicyChanged"
      :saving="saving"
      :save-text="t('module.security-setting.common.savePolicy')"
      @update:model-value="updateDrawerVisible"
      @save="saveActivePolicy"
    >
      <BrickSettingsDrawerSection
        v-if="activePolicy === 'strength'"
        :title="t('module.security-setting.passwordPolicy.drawer.strength.title')"
        :description="t('module.security-setting.passwordPolicy.drawer.strength.description')"
      >
        <el-form label-position="top" class="setting-form brick-required-form" :class="{ 'is-muted': !draftPolicy.strengthEnabled }">
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.strength.status')" class="setting-form__full" required>
            <el-switch v-model="draftPolicy.strengthEnabled" :active-text="t('module.security-setting.common.enable')" :inactive-text="t('module.security-setting.common.disable')" inline-prompt />
            <span class="field-hint">{{ t('module.security-setting.passwordPolicy.drawer.strength.statusHint') }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.strength.minLength')" class="setting-form__full" required>
            <el-slider v-model="draftPolicy.minLength" :min="6" :max="scaleMax(draftPolicy.minLength, 32)" :marks="passwordLengthMarks" :disabled="!draftPolicy.strengthEnabled" />
            <span class="field-hint">
              {{ draftPolicy.minLength >= 12
                ? t('module.security-setting.passwordPolicy.drawer.strength.minLengthHintOk', { min: draftPolicy.minLength })
                : t('module.security-setting.passwordPolicy.drawer.strength.minLengthHintLow', { min: draftPolicy.minLength }) }}
            </span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.strength.charset')" class="setting-form__full" required>
            <el-checkbox-group v-model="draftStrengthCharacterRules" :disabled="!draftPolicy.strengthEnabled">
              <el-checkbox v-for="option in characterRuleChoices" :key="option.value" :value="option.value">
                {{ option.label }}
              </el-checkbox>
            </el-checkbox-group>
            <span class="field-hint">{{ t('module.security-setting.passwordPolicy.drawer.strength.charsetHint') }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.strength.exclusion')" class="setting-form__full" required>
            <el-checkbox-group v-model="draftStrengthExclusionRules" :disabled="!draftPolicy.strengthEnabled">
              <el-checkbox v-for="option in exclusionRuleChoices" :key="option.value" :value="option.value">
                {{ option.label }}
              </el-checkbox>
            </el-checkbox-group>
            <span class="field-hint">{{ t('module.security-setting.passwordPolicy.drawer.strength.exclusionHint') }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.strength.preview')" class="setting-form__full">
            <div class="readonly-field readonly-field--formula">{{ strengthPreviewMessage }}</div>
          </el-form-item>
        </el-form>
      </BrickSettingsDrawerSection>

      <BrickSettingsDrawerSection
        v-if="activePolicy === 'weak-password'"
        :title="t('module.security-setting.passwordPolicy.drawer.weakPassword.title')"
        :description="t('module.security-setting.passwordPolicy.drawer.weakPassword.description')"
      >
        <el-form label-position="top" class="setting-form brick-required-form" :class="{ 'is-muted': !draftPolicy.weakPasswordEnabled }">
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.weakPassword.status')" class="setting-form__full" required>
            <el-switch v-model="draftPolicy.weakPasswordEnabled" :active-text="t('module.security-setting.common.enable')" :inactive-text="t('module.security-setting.common.disable')" inline-prompt />
            <span class="field-hint">{{ t('module.security-setting.passwordPolicy.drawer.weakPassword.statusHint') }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.weakPassword.loginCheck')" class="setting-form__full" required>
            <el-switch
              v-model="draftPolicy.loginCheckEnabled"
              :disabled="!draftPolicy.weakPasswordEnabled"
              :active-text="t('module.security-setting.common.enable')"
              :inactive-text="t('module.security-setting.common.disable')"
              inline-prompt
            />
            <span class="field-hint">{{ t('module.security-setting.passwordPolicy.drawer.weakPassword.loginCheckHint') }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.weakPassword.loginHit')" class="setting-form__full" required>
            <el-radio-group v-model="draftPolicy.loginHitAction" :disabled="!draftPolicy.weakPasswordEnabled || !draftPolicy.loginCheckEnabled">
              <el-radio v-for="option in lifecycleActionChoices" :key="option.value" :value="option.value">
                {{ option.label }}
              </el-radio>
            </el-radio-group>
            <span class="field-hint">{{ t('module.security-setting.passwordPolicy.drawer.weakPassword.loginHitHint') }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.weakPassword.list')" class="setting-form__full">
            <el-input v-model="draftPolicy.weakPasswords" type="textarea" :rows="8" :placeholder="t('module.security-setting.passwordPolicy.drawer.weakPassword.listPlaceholder')" />
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.weakPassword.normalize')" class="setting-form__full">
            <div class="readonly-field readonly-field--formula">
              {{ t('module.security-setting.passwordPolicy.drawer.weakPassword.normalizeValue', {
                raw: weakPasswordRawCount,
                unique: normalizeWeakPasswordList(draftPolicy.weakPasswords || '').length,
                dup: weakPasswordDuplicateCount,
              }) }}
            </div>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.weakPassword.scanTitle')" class="setting-form__full">
            <div class="weak-password-scan-panel">
              <div class="weak-password-scan-panel__header">
                <div>
                  <strong>{{ t('module.security-setting.passwordPolicy.drawer.weakPassword.scanHeading') }}</strong>
                  <p class="field-hint">{{ t('module.security-setting.passwordPolicy.drawer.weakPassword.scanHint') }}</p>
                </div>
                <el-button
                  type="primary"
                  :loading="weakScanStarting || weakScanRunning"
                  :disabled="!draftPolicy.weakPasswordEnabled || weakScanRunning"
                  @click="startWeakPasswordScan"
                >
                  {{ weakScanRunning
                    ? t('module.security-setting.passwordPolicy.drawer.weakPassword.scanRunning')
                    : t('module.security-setting.passwordPolicy.drawer.weakPassword.scanStart') }}
                </el-button>
              </div>

              <el-alert
                v-if="weakScanInlineError"
                class="weak-password-scan-panel__alert"
                type="error"
                :closable="false"
                show-icon
                :title="weakScanInlineError"
              />

              <div v-if="weakScanStatus" class="weak-password-scan-panel__body">
                <div class="weak-password-scan-panel__progress">
                  <div class="weak-password-scan-panel__progress-meta">
                    <span>{{ t('module.security-setting.passwordPolicy.drawer.weakPassword.progress') }}</span>
                    <span>{{ weakScanStatusLabel }} · {{ weakScanStatus.percent || 0 }}%</span>
                  </div>
                  <el-progress
                    :percentage="weakScanStatus.percent || 0"
                    :status="weakScanProgressStatus"
                    :stroke-width="14"
                    striped
                    :striped-flow="weakScanRunning"
                  />
                  <p class="field-hint">{{ weakScanStatus.message || t('module.security-setting.passwordPolicy.drawer.weakPassword.waiting') }}</p>
                </div>

                <div class="weak-password-scan-panel__stats">
                  <div class="weak-password-scan-stat">
                    <span class="weak-password-scan-stat__label">{{ t('module.security-setting.passwordPolicy.drawer.weakPassword.totalAccounts') }}</span>
                    <strong>{{ weakScanStatus.totalAccounts || 0 }}</strong>
                  </div>
                  <div class="weak-password-scan-stat">
                    <span class="weak-password-scan-stat__label">{{ t('module.security-setting.passwordPolicy.drawer.weakPassword.scanned') }}</span>
                    <strong>{{ weakScanStatus.scannedAccounts || 0 }}</strong>
                  </div>
                  <div class="weak-password-scan-stat">
                    <span class="weak-password-scan-stat__label">{{ t('module.security-setting.passwordPolicy.drawer.weakPassword.hits') }}</span>
                    <strong :class="{ 'is-warning': (weakScanStatus.hitCount || 0) > 0 }">
                      {{ weakScanStatus.hitCount || 0 }}
                    </strong>
                  </div>
                </div>

                <div v-if="weakScanFinished && weakScanStatus.status === 'COMPLETED'" class="weak-password-scan-panel__result">
                  <div class="weak-password-scan-panel__result-title">
                    {{ t('module.security-setting.passwordPolicy.drawer.weakPassword.result') }}
                    <span v-if="weakScanHitRows.length > 0" class="weak-password-scan-panel__result-badge">
                      {{ t('module.security-setting.passwordPolicy.drawer.weakPassword.resultBadge', { count: weakScanHitRows.length }) }}
                    </span>
                  </div>
                  <el-table
                    v-if="weakScanHitRows.length > 0"
                    :data="weakScanHitRows"
                    size="small"
                    class="weak-password-scan__hits"
                    max-height="280"
                    stripe
                  >
                    <el-table-column type="index" label="#" width="56" />
                    <el-table-column prop="username" :label="t('module.security-setting.passwordPolicy.drawer.weakPassword.hitUsername')" min-width="200" />
                  </el-table>
                  <div v-else class="weak-password-scan-panel__empty">
                    {{ t('module.security-setting.passwordPolicy.drawer.weakPassword.emptyHits') }}
                  </div>
                </div>
              </div>
            </div>
          </el-form-item>
        </el-form>
      </BrickSettingsDrawerSection>

      <BrickSettingsDrawerSection
        v-if="activePolicy === 'initial-password'"
        :title="t('module.security-setting.passwordPolicy.drawer.initialPassword.title')"
        :description="t('module.security-setting.passwordPolicy.drawer.initialPassword.description')"
      >
        <el-form label-position="top" class="setting-form brick-required-form" :class="{ 'is-muted': !draftPolicy.initialPasswordEnabled && !replaceInitialPassword }">
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.initialPassword.status')" class="setting-form__full" required>
            <el-switch v-model="draftPolicy.initialPasswordEnabled" :active-text="t('module.security-setting.common.enable')" :inactive-text="t('module.security-setting.common.disable')" inline-prompt />
            <span class="field-hint">{{ t('module.security-setting.passwordPolicy.drawer.initialPassword.statusHint') }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.initialPassword.current')" class="setting-form__full">
            <div class="readonly-field">{{ initialPasswordConfigured
              ? t('module.security-setting.passwordPolicy.drawer.initialPassword.currentConfigured')
              : t('module.security-setting.passwordPolicy.drawer.initialPassword.currentEmpty') }}</div>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.initialPassword.validDays')" class="setting-form__full" required>
            <el-slider
              v-model="draftPolicy.initialPasswordValidDays"
              :min="1"
              :max="scaleMax(draftPolicy.initialPasswordValidDays, 90)"
              :marks="initialPasswordValidDayMarks"
              :disabled="!draftPolicy.initialPasswordEnabled"
            />
            <span class="field-hint">{{ t('module.security-setting.passwordPolicy.drawer.initialPassword.validDaysHint', { days: draftPolicy.initialPasswordValidDays }) }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.initialPassword.writeMode')" class="setting-form__full">
            <el-radio-group :model-value="replaceInitialPassword ? 'replace' : 'keep'" @update:model-value="replaceInitialPassword = $event === 'replace'">
              <el-radio v-for="option in initialPasswordWriteChoices" :key="option.value" :value="option.value">
                {{ option.label }}
              </el-radio>
            </el-radio-group>
            <span class="field-hint">{{ t('module.security-setting.passwordPolicy.drawer.initialPassword.writeModeHint') }}</span>
          </el-form-item>
          <el-form-item v-if="replaceInitialPassword" :label="t('module.security-setting.passwordPolicy.drawer.initialPassword.newPassword')" class="setting-form__full">
            <el-input v-model="initialPasswordDraft" type="password" show-password :placeholder="t('module.security-setting.passwordPolicy.drawer.initialPassword.newPasswordPlaceholder')" />
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.initialPassword.writeOnly')" class="setting-form__full">
            <div class="readonly-field">{{ t('module.security-setting.passwordPolicy.drawer.initialPassword.writeOnlyValue') }}</div>
          </el-form-item>
        </el-form>
      </BrickSettingsDrawerSection>

      <BrickSettingsDrawerSection
        v-if="activePolicy === 'cycle'"
        :title="t('module.security-setting.passwordPolicy.drawer.cycle.title')"
        :description="t('module.security-setting.passwordPolicy.drawer.cycle.description')"
      >
        <el-form label-position="top" class="setting-form brick-required-form">
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.cycle.status')" class="setting-form__full" required>
            <el-switch v-model="draftPolicy.periodicChangeEnabled" :active-text="t('module.security-setting.common.enable')" :inactive-text="t('module.security-setting.common.disable')" inline-prompt />
            <span class="field-hint">{{ t('module.security-setting.passwordPolicy.drawer.cycle.statusHint') }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.cycle.days')" class="setting-form__full" required>
            <el-slider
              v-model="draftPolicy.periodicChangeDays"
              :min="1"
              :max="scaleMax(draftPolicy.periodicChangeDays, 365)"
              :marks="periodicChangeDayMarks"
              :disabled="!draftPolicy.periodicChangeEnabled"
            />
            <span class="field-hint">{{ t('module.security-setting.passwordPolicy.drawer.cycle.daysHint', { days: draftPolicy.periodicChangeDays }) }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.cycle.notice')" class="setting-form__full" required>
            <el-slider
              v-model="draftPolicy.periodicChangeNoticeDays"
              :min="0"
              :max="scaleMax(draftPolicy.periodicChangeNoticeDays, 90)"
              :marks="noticeDayMarks"
              :disabled="!draftPolicy.periodicChangeEnabled"
            />
            <span class="field-hint">{{ t('module.security-setting.passwordPolicy.drawer.cycle.noticeHint', { days: draftPolicy.periodicChangeNoticeDays }) }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.cycle.repeatStatus')" class="setting-form__full" required>
            <el-switch v-model="draftPolicy.noRepeatCycleEnabled" :active-text="t('module.security-setting.common.enable')" :inactive-text="t('module.security-setting.common.disable')" inline-prompt />
            <span class="field-hint">{{ t('module.security-setting.passwordPolicy.drawer.cycle.repeatStatusHint') }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.cycle.repeatTimes')" class="setting-form__full" required>
            <el-slider
              v-model="draftPolicy.noRepeatCycleTimes"
              :min="1"
              :max="scaleMax(draftPolicy.noRepeatCycleTimes, 24)"
              :marks="repeatTimesMarks"
              :disabled="!draftPolicy.noRepeatCycleEnabled"
            />
            <span class="field-hint">{{ t('module.security-setting.passwordPolicy.drawer.cycle.repeatTimesHint', { times: draftPolicy.noRepeatCycleTimes }) }}</span>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.cycle.timeline')" class="setting-form__full">
            <div class="readonly-field readonly-field--formula">
              {{ t('module.security-setting.passwordPolicy.drawer.cycle.timelineValue', { days: draftPolicy.periodicChangeNoticeDays }) }}
            </div>
          </el-form-item>
        </el-form>
      </BrickSettingsDrawerSection>

      <BrickSettingsDrawerSection
        v-if="activePolicy === 'lifecycle-actions'"
        :title="t('module.security-setting.passwordPolicy.drawer.lifecycle.title')"
        :description="t('module.security-setting.passwordPolicy.drawer.lifecycle.description')"
      >
        <el-form label-position="top" class="setting-form brick-required-form">
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.lifecycle.expiring')" class="setting-form__full" required>
            <el-radio-group
              :model-value="draftAction.passwordExpiringSoonAction"
              @update:model-value="updateDraftAction('passwordExpiringSoonAction', String($event))"
            >
              <el-radio v-for="option in lifecycleActionChoices" :key="option.value" :value="option.value" :disabled="option.disabled">
                {{ option.label }}
              </el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.lifecycle.expired')" class="setting-form__full" required>
            <el-radio-group
              :model-value="draftAction.passwordExpiredAction"
              @update:model-value="updateDraftAction('passwordExpiredAction', String($event))"
            >
              <el-radio v-for="option in lifecycleActionChoices" :key="option.value" :value="option.value" :disabled="option.disabled">
                {{ option.label }}
              </el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.lifecycle.initial')" class="setting-form__full" required>
            <el-radio-group
              :model-value="draftAction.initialPasswordAction"
              @update:model-value="updateDraftAction('initialPasswordAction', String($event))"
            >
              <el-radio v-for="option in lifecycleActionChoices" :key="option.value" :value="option.value" :disabled="option.disabled">
                {{ option.label }}
              </el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.lifecycle.adminReset')" class="setting-form__full" required>
            <el-radio-group
              :model-value="draftAction.adminResetAction"
              @update:model-value="updateDraftAction('adminResetAction', String($event))"
            >
              <el-radio v-for="option in lifecycleActionChoices" :key="option.value" :value="option.value" :disabled="option.disabled">
                {{ option.label }}
              </el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="t('module.security-setting.passwordPolicy.drawer.lifecycle.actionNote')" class="setting-form__full">
            <div class="readonly-field">{{ t('module.security-setting.passwordPolicy.drawer.lifecycle.actionNoteValue') }}</div>
          </el-form-item>
        </el-form>
      </BrickSettingsDrawerSection>
    </SecuritySettingsDrawer>
  </article>
</template>

<style>
@import "../../../settings-page.css";
@import "../../../security-posture.css";

.password-policy-console .state-panel {
  display: grid;
  justify-items: start;
  gap: 16px;
}

.weak-password-scan-panel {
  display: grid;
  gap: 14px;
  width: 100%;
  padding: 14px 16px;
  border: 1px solid var(--el-border-color-lighter, #e5e7eb);
  border-radius: 10px;
  background: var(--el-fill-color-blank, #fff);
}

.weak-password-scan-panel__header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
}

.weak-password-scan-panel__header strong {
  display: block;
  margin-bottom: 4px;
  font-size: 14px;
}

.weak-password-scan-panel__alert {
  width: 100%;
}

.weak-password-scan-panel__body {
  display: grid;
  gap: 14px;
}

.weak-password-scan-panel__progress {
  display: grid;
  gap: 8px;
}

.weak-password-scan-panel__progress-meta {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  font-size: 13px;
  color: var(--el-text-color-regular, #606266);
}

.weak-password-scan-panel__stats {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 10px;
}

.weak-password-scan-stat {
  display: grid;
  gap: 4px;
  padding: 10px 12px;
  border-radius: 8px;
  background: var(--el-fill-color-light, #f5f7fa);
}

.weak-password-scan-stat__label {
  font-size: 12px;
  color: var(--el-text-color-secondary, #909399);
}

.weak-password-scan-stat strong {
  font-size: 18px;
  line-height: 1.2;
}

.weak-password-scan-stat strong.is-warning {
  color: var(--el-color-warning, #e6a23c);
}

.weak-password-scan-panel__result {
  display: grid;
  gap: 10px;
}

.weak-password-scan-panel__result-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 600;
  font-size: 13px;
}

.weak-password-scan-panel__result-badge {
  display: inline-flex;
  align-items: center;
  padding: 0 8px;
  border-radius: 999px;
  background: var(--el-color-warning-light-9, #fdf6ec);
  color: var(--el-color-warning, #e6a23c);
  font-size: 12px;
  font-weight: 500;
}

.weak-password-scan-panel__empty {
  padding: 16px;
  border-radius: 8px;
  background: var(--el-fill-color-light, #f5f7fa);
  color: var(--el-text-color-secondary, #909399);
  font-size: 13px;
}

.weak-password-scan__hits {
  width: 100%;
}
</style>
