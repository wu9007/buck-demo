import { passwordPolicyPermissions } from './permission/index.js';
import { passwordPolicyRoutes } from './routes/index.js';

export const passwordPolicyFeature = {
  featureKey: 'password-policy',
  routes: passwordPolicyRoutes,
  permissions: passwordPolicyPermissions,
};
