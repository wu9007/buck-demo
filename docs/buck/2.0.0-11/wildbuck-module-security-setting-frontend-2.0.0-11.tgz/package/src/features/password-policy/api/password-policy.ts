import {
  getPasswordPolicySetting,
  getWeakPasswordScanStatus,
  startWeakPasswordScan,
  updateInitialPasswordPolicySetting,
  updatePasswordCyclePolicySetting,
  updatePasswordLifecyclePolicySetting,
  updatePasswordStrengthPolicySetting,
  updateWeakPasswordPolicySetting,
} from '../../../generated/sdk';
import type {
  InitialPasswordPolicySetting,
  PasswordCyclePolicySetting,
  PasswordLifecyclePolicySetting,
  PasswordPolicySetting,
  PasswordStrengthPolicySetting,
  WeakPasswordPolicySetting,
  WeakPasswordScanStartResult,
  WeakPasswordScanStatus,
} from '../../../generated/types';

export async function loadPasswordPolicySetting(settingId = 'password-policy'): Promise<PasswordPolicySetting> {
  return getPasswordPolicySetting({ settingId });
}

export async function savePasswordStrengthPolicy(input: PasswordStrengthPolicySetting): Promise<PasswordPolicySetting> {
  return updatePasswordStrengthPolicySetting(input);
}

export async function saveWeakPasswordPolicy(input: WeakPasswordPolicySetting): Promise<PasswordPolicySetting> {
  return updateWeakPasswordPolicySetting(input);
}

export async function beginWeakPasswordScan(): Promise<WeakPasswordScanStartResult> {
  return startWeakPasswordScan(undefined);
}

export async function loadWeakPasswordScanStatus(scanId: string): Promise<WeakPasswordScanStatus> {
  return getWeakPasswordScanStatus(scanId, undefined);
}

export async function saveInitialPasswordPolicy(input: InitialPasswordPolicySetting): Promise<PasswordPolicySetting> {
  return updateInitialPasswordPolicySetting(input);
}

export async function savePasswordCyclePolicy(input: PasswordCyclePolicySetting): Promise<PasswordPolicySetting> {
  return updatePasswordCyclePolicySetting(input);
}

export async function savePasswordLifecyclePolicy(input: PasswordLifecyclePolicySetting): Promise<PasswordPolicySetting> {
  return updatePasswordLifecyclePolicySetting(input);
}
