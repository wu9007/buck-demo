/**
 * Password policy page workspace (#425).
 * Keeps PasswordPolicyPage.vue as a thin template shell.
 */
import { computed, onMounted, ref } from 'vue';
import { isBrickSessionError } from '@wildbuck/core-api-frontend';
import { showBrickStatus } from '@wildbuck/core-ui-frontend/status';
import type { PasswordPolicySetting } from '../../../generated/types';
import {
  formatSecuritySettingCatalogError,
  resolveSecuritySettingErrorMessage,
} from '../../../shared/security-setting-errors.js';
import {
  securitySettingUsageTracker,
} from '../../../usage-events';
import {
  loadSecuritySettingOptionItems,
  type SecuritySettingOptionItem,
} from '../../../shared/options';
import { useSecuritySettingI18n } from '../../../i18n.js';
import {
  beginWeakPasswordScan,
  loadPasswordPolicySetting,
  loadWeakPasswordScanStatus,
  saveInitialPasswordPolicy,
  savePasswordCyclePolicy,
  savePasswordLifecyclePolicy,
  savePasswordStrengthPolicy,
  saveWeakPasswordPolicy,
} from '../api/password-policy';
import type { WeakPasswordScanStatus } from '../../../generated/types';
import {
  clonePasswordPolicy,
  countPasswordCharacterRules,
  countPasswordExclusionRules,
  createDefaultLifecycleActions,
  createDefaultPasswordPolicy,
  normalizePasswordPolicySlice,
  normalizeWeakPasswordList,
  normalizeWeakPasswords,
  policiesEqual,
  resolvePasswordPolicyState,
  scaleMax,
  validatePasswordPolicySlice,
} from '../lib/password-form.js';
import {
  buildPasswordPosture,
  describePasswordPostureGaps,
  passwordPolicyRiskTone,
} from '../lib/password-posture.js';

export function usePasswordPolicyWorkspace() {


  type PolicyTone = 'default' | 'success' | 'warning' | 'danger';
  type PasswordPolicyKey = 'strength' | 'weak-password' | 'initial-password' | 'cycle' | 'lifecycle-actions';
  type PasswordLifecycleActions = Pick<
    PasswordPolicySetting,
    'passwordExpiringSoonAction' | 'passwordExpiredAction' | 'initialPasswordAction' | 'adminResetAction'
  >;

  type PolicyCard = {
    key: PasswordPolicyKey;
    title: string;
    description: string;
    statusLabel: string;
    statusTone: PolicyTone;
    summaryItems: Array<{ label: string; value: string | number; tone?: PolicyTone }>;
    riskLabel?: string;
    riskTone?: PolicyTone;
  };

  const { t } = useSecuritySettingI18n();

  const PASSWORD_LIFECYCLE_ACTION_OPTION_CODE = 'security_setting_password_lifecycle_action';
  const passwordLengthMarks = computed(() => ({
    8: t('module.security-setting.marks.length.basic'),
    12: t('module.security-setting.marks.length.recommended'),
    16: t('module.security-setting.marks.length.high'),
    24: t('module.security-setting.marks.length.strict'),
  }));
  const initialPasswordValidDayMarks = computed(() => ({
    1: t('module.security-setting.marks.day.today'),
    7: t('module.security-setting.marks.day.week'),
    30: t('module.security-setting.marks.day.month'),
    90: t('module.security-setting.marks.day.quarter'),
  }));
  const periodicChangeDayMarks = computed(() => ({
    30: t('module.security-setting.marks.day.30'),
    90: t('module.security-setting.marks.day.90'),
    180: t('module.security-setting.marks.day.halfYear'),
    365: t('module.security-setting.marks.day.year'),
  }));
  const noticeDayMarks = computed(() => ({
    0: t('module.security-setting.marks.notice.none'),
    7: t('module.security-setting.marks.day.week'),
    15: t('module.security-setting.marks.notice.halfMonth'),
    30: t('module.security-setting.marks.day.month'),
  }));
  const repeatTimesMarks = computed(() => ({
    3: t('module.security-setting.marks.times.3'),
    6: t('module.security-setting.marks.times.6'),
    12: t('module.security-setting.marks.times.12'),
    24: t('module.security-setting.marks.times.24'),
  }));
  const characterRuleChoices = computed(() => [
    { value: 'uppercase', label: t('module.security-setting.passwordPolicy.rule.uppercase'), description: t('module.security-setting.passwordPolicy.rule.uppercaseDesc') },
    { value: 'lowercase', label: t('module.security-setting.passwordPolicy.rule.lowercase'), description: t('module.security-setting.passwordPolicy.rule.lowercaseDesc') },
    { value: 'digit', label: t('module.security-setting.passwordPolicy.rule.digit'), description: t('module.security-setting.passwordPolicy.rule.digitDesc') },
    { value: 'special', label: t('module.security-setting.passwordPolicy.rule.special'), description: t('module.security-setting.passwordPolicy.rule.specialDesc') },
  ]);
  const exclusionRuleChoices = computed(() => [
    { value: 'username', label: t('module.security-setting.passwordPolicy.rule.excludeUsername'), description: t('module.security-setting.passwordPolicy.rule.excludeUsernameDesc') },
    { value: 'phone', label: t('module.security-setting.passwordPolicy.rule.excludePhone'), description: t('module.security-setting.passwordPolicy.rule.excludePhoneDesc') },
    { value: 'email', label: t('module.security-setting.passwordPolicy.rule.excludeEmail'), description: t('module.security-setting.passwordPolicy.rule.excludeEmailDesc') },
  ]);
  const initialPasswordWriteChoices = computed(() => [
    { value: 'keep', label: t('module.security-setting.passwordPolicy.initialWrite.keep'), description: t('module.security-setting.passwordPolicy.initialWrite.keepDesc') },
    { value: 'replace', label: t('module.security-setting.passwordPolicy.initialWrite.replace'), description: t('module.security-setting.passwordPolicy.initialWrite.replaceDesc') },
  ]);

  const loading = ref(true);
  const saving = ref(false);
  const loadFailed = ref(false);
  const drawerVisible = ref(false);
  const activePolicy = ref<PasswordPolicyKey | null>(null);
  const replaceInitialPassword = ref(false);
  const initialPasswordDraft = ref('');
  const initialPasswordConfigured = ref(false);
  const policyForm = ref<PasswordPolicySetting>(createDefaultPasswordPolicy() as PasswordPolicySetting);
  const draftPolicy = ref<PasswordPolicySetting>(createDefaultPasswordPolicy() as PasswordPolicySetting);
  const actionForm = ref<PasswordLifecycleActions>(createDefaultLifecycleActions() as PasswordLifecycleActions);
  const draftAction = ref<PasswordLifecycleActions>(createDefaultLifecycleActions() as PasswordLifecycleActions);
  const actionOptions = ref<SecuritySettingOptionItem[]>([]);
  const weakScanStarting = ref(false);
  const weakScanRunning = ref(false);
  const weakScanStatus = ref<WeakPasswordScanStatus | null>(null);
  const weakScanInlineError = ref('');
  let weakScanTimer: ReturnType<typeof setInterval> | null = null;

  const posture = computed(() => buildPasswordPosture(policyForm.value, {
    initialPasswordConfigured: initialPasswordConfigured.value,
  }));
  const postureGaps = computed(() => describePasswordPostureGaps(policyForm.value, {
    strengthOff: t('module.security-setting.passwordPolicy.posture.gap.strengthOff'),
    minLengthLow: t('module.security-setting.passwordPolicy.posture.gap.minLengthLow'),
    minLengthSoft: t('module.security-setting.passwordPolicy.posture.gap.minLengthSoft'),
    weakOff: t('module.security-setting.passwordPolicy.posture.gap.weakOff'),
    weakEmpty: t('module.security-setting.passwordPolicy.posture.gap.weakEmpty'),
    initialMissing: t('module.security-setting.passwordPolicy.posture.gap.initialMissing'),
    historyOff: t('module.security-setting.passwordPolicy.posture.gap.historyOff'),
    expiredNotBlock: t('module.security-setting.passwordPolicy.posture.gap.expiredNotBlock'),
    resetNotBlock: t('module.security-setting.passwordPolicy.posture.gap.resetNotBlock'),
    rotationTooShort: t('module.security-setting.passwordPolicy.posture.gap.rotationTooShort'),
  }, { initialPasswordConfigured: initialPasswordConfigured.value }));
  const postureLevelLabel = computed(() => t(
    `module.security-setting.passwordPolicy.posture.level.${posture.value.level}`,
  ));

  const weakScanHitRows = computed(() => {
    const raw = weakScanStatus.value?.hitUsernames || '';
    return raw
      .split(',')
      .map((item) => item.trim())
      .filter(Boolean)
      .map((username) => ({ username }));
  });

  const weakScanProgressStatus = computed(() => {
    const status = weakScanStatus.value?.status;
    if (status === 'FAILED') {
      return 'exception';
    }
    if (status === 'COMPLETED') {
      return 'success';
    }
    return undefined;
  });

  const weakScanStatusLabel = computed(() => {
    const status = weakScanStatus.value?.status;
    if (status === 'PENDING') {
      return t('module.security-setting.passwordPolicy.drawer.weakPassword.statusPending');
    }
    if (status === 'RUNNING') {
      return t('module.security-setting.passwordPolicy.drawer.weakPassword.statusRunning');
    }
    if (status === 'COMPLETED') {
      return t('module.security-setting.passwordPolicy.drawer.weakPassword.statusCompleted');
    }
    if (status === 'FAILED') {
      return t('module.security-setting.passwordPolicy.drawer.weakPassword.statusFailed');
    }
    return t('module.security-setting.passwordPolicy.drawer.weakPassword.statusIdle');
  });

  const weakScanFinished = computed(() => {
    const status = weakScanStatus.value?.status;
    return status === 'COMPLETED' || status === 'FAILED';
  });

  async function startWeakPasswordScan() {
    if (weakScanRunning.value || weakScanStarting.value) {
      return;
    }
    weakScanInlineError.value = '';
    if (!draftPolicy.value.weakPasswordEnabled) {
      weakScanInlineError.value = t('module.security-setting.passwordPolicy.drawer.weakPassword.scanNeedEnable');
      return;
    }
    if (normalizeWeakPasswordList(draftPolicy.value.weakPasswords || '').length === 0
      && normalizeWeakPasswordList(policyForm.value.weakPasswords || '').length === 0) {
      weakScanInlineError.value = t('module.security-setting.passwordPolicy.drawer.weakPassword.scanNeedList');
      return;
    }
    weakScanStarting.value = true;
    weakScanStatus.value = {
      scanId: '',
      status: 'PENDING',
      totalAccounts: 0,
      scannedAccounts: 0,
      hitCount: 0,
      percent: 0,
      message: t('module.security-setting.passwordPolicy.drawer.weakPassword.scanCreating'),
      hitUsernames: '',
    };
    try {
      const started = await beginWeakPasswordScan();
      if (!started?.scanId) {
        weakScanStatus.value = {
          ...weakScanStatus.value!,
          status: 'FAILED',
          percent: 100,
          message: t('module.security-setting.passwordPolicy.drawer.weakPassword.scanCreateFailed'),
        };
        weakScanInlineError.value = t('module.security-setting.passwordPolicy.drawer.weakPassword.scanCreateFailed');
        return;
      }
      weakScanRunning.value = true;
      weakScanStatus.value = {
        scanId: started.scanId,
        status: started.status || 'PENDING',
        totalAccounts: 0,
        scannedAccounts: 0,
        hitCount: 0,
        percent: 0,
        message: t('module.security-setting.passwordPolicy.drawer.weakPassword.scanCreated'),
        hitUsernames: '',
      };
      await pollWeakPasswordScan(started.scanId);
    } catch (error) {
      weakScanRunning.value = false;
      weakScanInlineError.value = resolveSecuritySettingErrorMessage(
        error,
        'SECURITY_SETTING_WEAK_PASSWORD_SCAN_UNAVAILABLE',
      );
      weakScanStatus.value = {
        scanId: weakScanStatus.value?.scanId || '',
        status: 'FAILED',
        totalAccounts: 0,
        scannedAccounts: 0,
        hitCount: 0,
        percent: 100,
        message: weakScanInlineError.value,
        hitUsernames: '',
      };
    } finally {
      weakScanStarting.value = false;
    }
  }

  async function pollWeakPasswordScan(scanId: string) {
    if (weakScanTimer) {
      clearInterval(weakScanTimer);
      weakScanTimer = null;
    }
    const finish = () => {
      weakScanRunning.value = false;
      if (weakScanTimer) {
        clearInterval(weakScanTimer);
        weakScanTimer = null;
      }
    };
    const tick = async () => {
      try {
        const status = await loadWeakPasswordScanStatus(scanId);
        weakScanStatus.value = status;
        if (status.status === 'FAILED') {
          weakScanInlineError.value = status.message || t('module.security-setting.passwordPolicy.drawer.weakPassword.scanFailed');
          finish();
          return;
        }
        if (status.status === 'COMPLETED') {
          weakScanInlineError.value = '';
          finish();
        }
      } catch (error) {
        weakScanInlineError.value = resolveSecuritySettingErrorMessage(
          error,
          'SECURITY_SETTING_WEAK_PASSWORD_SCAN_NOT_FOUND',
        );
        weakScanStatus.value = {
          scanId,
          status: 'FAILED',
          totalAccounts: weakScanStatus.value?.totalAccounts || 0,
          scannedAccounts: weakScanStatus.value?.scannedAccounts || 0,
          hitCount: weakScanStatus.value?.hitCount || 0,
          percent: 100,
          message: weakScanInlineError.value,
          hitUsernames: weakScanStatus.value?.hitUsernames || '',
        };
        finish();
      }
    };
    await tick();
    if (weakScanRunning.value) {
      weakScanTimer = setInterval(() => {
        void tick();
      }, 800);
    }
  }

  const policyCards = computed<PolicyCard[]>(() => [
    {
      key: 'strength',
      title: t('module.security-setting.passwordPolicy.card.strength.title'),
      description: t('module.security-setting.passwordPolicy.card.strength.description'),
      statusLabel: enabledLabel(policyForm.value.strengthEnabled),
      statusTone: enabledTone(policyForm.value.strengthEnabled),
      riskLabel: t('module.security-setting.passwordPolicy.card.strength.risk'),
      riskTone: passwordPolicyRiskTone('strength', policyForm.value) as PolicyTone,
      summaryItems: [
        { label: t('module.security-setting.common.summary'), value: formatPasswordStrengthSummary(policyForm.value) },
      ],
    },
    {
      key: 'weak-password',
      title: t('module.security-setting.passwordPolicy.card.weakPassword.title'),
      description: t('module.security-setting.passwordPolicy.card.weakPassword.description'),
      statusLabel: enabledLabel(policyForm.value.weakPasswordEnabled),
      statusTone: enabledTone(policyForm.value.weakPasswordEnabled),
      riskLabel: t('module.security-setting.passwordPolicy.card.weakPassword.risk'),
      riskTone: passwordPolicyRiskTone('weak-password', policyForm.value) as PolicyTone,
      summaryItems: [
        { label: t('module.security-setting.common.summary'), value: formatWeakPasswordSummary(policyForm.value, weakPasswordCount.value) },
      ],
    },
    {
      key: 'initial-password',
      title: t('module.security-setting.passwordPolicy.card.initialPassword.title'),
      description: t('module.security-setting.passwordPolicy.card.initialPassword.description'),
      statusLabel: enabledLabel(policyForm.value.initialPasswordEnabled),
      statusTone: enabledTone(policyForm.value.initialPasswordEnabled),
      riskLabel: initialPasswordConfigured.value
        ? t('module.security-setting.common.configured')
        : t('module.security-setting.common.notConfigured'),
      riskTone: passwordPolicyRiskTone('initial-password', policyForm.value, {
        initialPasswordConfigured: initialPasswordConfigured.value,
      }) as PolicyTone,
      summaryItems: [
        { label: t('module.security-setting.common.summary'), value: formatInitialPasswordSummary(policyForm.value) },
      ],
    },
    {
      key: 'cycle',
      title: t('module.security-setting.passwordPolicy.card.cycle.title'),
      description: t('module.security-setting.passwordPolicy.card.cycle.description'),
      statusLabel: policyForm.value.periodicChangeEnabled || policyForm.value.noRepeatCycleEnabled
        ? t('module.security-setting.common.partialEnabled')
        : t('module.security-setting.common.disabled'),
      statusTone: policyForm.value.periodicChangeEnabled || policyForm.value.noRepeatCycleEnabled ? 'success' : 'warning',
      riskLabel: t('module.security-setting.passwordPolicy.card.cycle.risk'),
      riskTone: passwordPolicyRiskTone('cycle', policyForm.value) as PolicyTone,
      summaryItems: [
        { label: t('module.security-setting.common.summary'), value: formatPasswordCycleSummary(policyForm.value) },
      ],
    },
    {
      key: 'lifecycle-actions',
      title: t('module.security-setting.passwordPolicy.card.lifecycle.title'),
      description: t('module.security-setting.passwordPolicy.card.lifecycle.description'),
      statusLabel: t('module.security-setting.common.running'),
      statusTone: 'success',
      riskLabel: t('module.security-setting.passwordPolicy.card.lifecycle.risk'),
      riskTone: passwordPolicyRiskTone('lifecycle-actions', {
        ...policyForm.value,
        ...actionForm.value,
      }) as PolicyTone,
      summaryItems: [
        { label: t('module.security-setting.common.summary'), value: formatPasswordLifecycleSummary(actionForm.value) },
      ],
    },
  ]);

  const weakPasswordCount = computed(() => normalizeWeakPasswordList(policyForm.value.weakPasswords || '').length);
  const draftStrengthCharacterRules = computed<string[]>({
    get: () => [
      draftPolicy.value.requireUppercase ? 'uppercase' : '',
      draftPolicy.value.requireLowercase ? 'lowercase' : '',
      draftPolicy.value.requireDigit ? 'digit' : '',
      draftPolicy.value.requireSpecial ? 'special' : '',
    ].filter(Boolean),
    set: (values) => {
      const selected = new Set(values);
      draftPolicy.value.requireUppercase = selected.has('uppercase');
      draftPolicy.value.requireLowercase = selected.has('lowercase');
      draftPolicy.value.requireDigit = selected.has('digit');
      draftPolicy.value.requireSpecial = selected.has('special');
    },
  });
  const draftStrengthExclusionRules = computed<string[]>({
    get: () => [
      draftPolicy.value.excludeUsername ? 'username' : '',
      draftPolicy.value.excludePhone ? 'phone' : '',
      draftPolicy.value.excludeEmail ? 'email' : '',
    ].filter(Boolean),
    set: (values) => {
      const selected = new Set(values);
      draftPolicy.value.excludeUsername = selected.has('username');
      draftPolicy.value.excludePhone = selected.has('phone');
      draftPolicy.value.excludeEmail = selected.has('email');
    },
  });
  const strengthPreviewMessage = computed(() => {
    const characterCount = draftStrengthCharacterRules.value.length;
    const exclusionCount = draftStrengthExclusionRules.value.length;
    return t('module.security-setting.passwordPolicy.preview.strength', {
      min: draftPolicy.value.minLength,
      charCount: characterCount,
      exclusion: exclusionCount > 0
        ? t('module.security-setting.passwordPolicy.preview.exclusionOn', { count: exclusionCount })
        : t('module.security-setting.passwordPolicy.preview.exclusionOff'),
    });
  });
  const weakPasswordRawCount = computed(() => (draftPolicy.value.weakPasswords || '')
    .split(/\r?\n|,|，/)
    .map((item) => item.trim())
    .filter(Boolean).length);
  const weakPasswordDuplicateCount = computed(() => Math.max(
    weakPasswordRawCount.value - normalizeWeakPasswordList(draftPolicy.value.weakPasswords || '').length,
    0,
  ));
  const lifecycleActionChoices = computed(() => actionOptions.value.map((option) => ({
    value: option.value,
    label: option.label,
    description: option.description,
    disabled: option.disabled,
  })));
  const activePolicyMeta = computed(() => policyCards.value.find((item) => item.key === activePolicy.value) || null);
  const activePolicyChanged = computed(() => {
    if (!activePolicy.value) {
      return false;
    }
    return !policiesEqual(
      resolvePasswordPolicyState(activePolicy.value, draftPolicy.value, draftAction.value),
      resolvePasswordPolicyState(activePolicy.value, policyForm.value, actionForm.value),
    ) || (activePolicy.value === 'initial-password' && replaceInitialPassword.value && Boolean(initialPasswordDraft.value));
  });

  onMounted(async () => {
    void securitySettingUsageTracker.trackPage('passwordPolicy');
    await load();
  });

  async function load() {
    loading.value = true;
    loadFailed.value = false;
    try {
      await loadPasswordLifecycleActionOptions();
      const policySetting = await loadPasswordPolicySetting();
      policyForm.value = policySetting;
      draftPolicy.value = clonePasswordPolicy(policySetting) as PasswordPolicySetting;
      actionForm.value = {
        passwordExpiringSoonAction: policySetting.passwordExpiringSoonAction || 'REMIND',
        passwordExpiredAction: policySetting.passwordExpiredAction || 'BLOCK',
        initialPasswordAction: policySetting.initialPasswordAction || 'BLOCK',
        adminResetAction: policySetting.adminResetAction || 'BLOCK',
      };
      draftAction.value = { ...actionForm.value };
      initialPasswordConfigured.value = Boolean(policySetting.initialPassword);
    } catch (error) {
      if (isBrickSessionError(error)) {
        return;
      }
      loadFailed.value = true;
      showBrickStatus(resolveSaveErrorMessage(error), 'error');
    } finally {
      loading.value = false;
    }
  }

  async function loadPasswordLifecycleActionOptions() {
    try {
      actionOptions.value = await loadSecuritySettingOptionItems(PASSWORD_LIFECYCLE_ACTION_OPTION_CODE);
    } catch {
      actionOptions.value = [];
    }
  }

  function openPolicyDrawer(key: PasswordPolicyKey) {
    activePolicy.value = key;
    draftPolicy.value = clonePasswordPolicy(policyForm.value);
    draftAction.value = { ...actionForm.value };
    replaceInitialPassword.value = false;
    initialPasswordDraft.value = '';
    drawerVisible.value = true;
    void securitySettingUsageTracker.trackOpen(key);
  }

  function updateDrawerVisible(value: boolean) {
    drawerVisible.value = value;
    if (!value) {
      activePolicy.value = null;
    }
  }

  async function saveActivePolicy() {
    const policy = activePolicy.value;
    if (!policy) {
      return;
    }

    if (policy === 'lifecycle-actions') {
      const validation = validatePasswordPolicySlice(policy, draftPolicy.value, draftAction.value);
      if (!validation.ok) {
        showBrickStatus(t('module.security-setting.common.validation.invalid', {
          fields: validation.errors.join(', '),
        }), 'error');
        return;
      }
    } else {
      const normalized = normalizePasswordPolicySlice(policy, draftPolicy.value);
      const validation = validatePasswordPolicySlice(policy, normalized, draftAction.value);
      if (!validation.ok) {
        showBrickStatus(t('module.security-setting.common.validation.invalid', {
          fields: validation.errors.join(', '),
        }), 'error');
        return;
      }
      draftPolicy.value = normalized as PasswordPolicySetting;
    }

    saving.value = true;
    try {
      await securitySettingUsageTracker.trackAction(policy, 'save', async () => {
        if (policy === 'lifecycle-actions') {
          await saveLifecycleActions();
        } else {
          await savePasswordPolicySlice(policy);
        }
      });
      showBrickStatus(t('module.security-setting.common.saved', {
        title: activePolicyMeta.value?.title || t('module.security-setting.passwordPolicy.policyDefaultTitle'),
      }), 'success');
      updateDrawerVisible(false);
    } catch (error) {
      if (isBrickSessionError(error)) {
        return;
      }
      showBrickStatus(resolveSaveErrorMessage(error), 'error');
    } finally {
      saving.value = false;
    }
  }

  async function savePasswordPolicySlice(policy: PasswordPolicyKey) {
    const savedPolicy = await savePasswordPolicySliceRequest(policy);
    policyForm.value = savedPolicy;
    draftPolicy.value = clonePasswordPolicy(savedPolicy);
    if (policy === 'initial-password') {
      initialPasswordConfigured.value = initialPasswordConfigured.value
        || Boolean(initialPasswordDraft.value || savedPolicy.initialPassword);
      replaceInitialPassword.value = false;
      initialPasswordDraft.value = '';
    }
  }

  async function saveLifecycleActions() {
    const savedPolicy = await savePasswordLifecyclePolicy({
      settingId: policyForm.value.settingId,
      ...draftAction.value,
    });
    policyForm.value = savedPolicy;
    draftPolicy.value = clonePasswordPolicy(savedPolicy);
    actionForm.value = {
      passwordExpiringSoonAction: savedPolicy.passwordExpiringSoonAction,
      passwordExpiredAction: savedPolicy.passwordExpiredAction,
      initialPasswordAction: savedPolicy.initialPasswordAction,
      adminResetAction: savedPolicy.adminResetAction,
    };
    draftAction.value = { ...actionForm.value };
  }

  function savePasswordPolicySliceRequest(policy: PasswordPolicyKey): Promise<PasswordPolicySetting> {
    const source = draftPolicy.value;
    if (policy === 'strength') {
      return savePasswordStrengthPolicy({
        settingId: source.settingId,
        strengthEnabled: source.strengthEnabled,
        minLength: source.minLength,
        requireUppercase: source.requireUppercase,
        requireLowercase: source.requireLowercase,
        requireDigit: source.requireDigit,
        requireSpecial: source.requireSpecial,
        excludeUsername: source.excludeUsername,
        excludePhone: source.excludePhone,
        excludeEmail: source.excludeEmail,
      });
    }
    if (policy === 'weak-password') {
      return saveWeakPasswordPolicy({
        settingId: source.settingId,
        weakPasswordEnabled: source.weakPasswordEnabled,
        weakPasswords: normalizeWeakPasswords(source.weakPasswords || ''),
        loginCheckEnabled: source.loginCheckEnabled ?? true,
        loginHitAction: source.loginHitAction || 'REMIND',
      });
    }
    if (policy === 'initial-password') {
      return saveInitialPasswordPolicy({
        settingId: source.settingId,
        initialPasswordEnabled: source.initialPasswordEnabled,
        initialPasswordValidDays: source.initialPasswordValidDays,
        initialPassword: replaceInitialPassword.value ? initialPasswordDraft.value : undefined,
      });
    }
    if (policy === 'cycle') {
      return savePasswordCyclePolicy({
        settingId: source.settingId,
        periodicChangeEnabled: source.periodicChangeEnabled,
        periodicChangeDays: source.periodicChangeDays,
        periodicChangeNoticeDays: source.periodicChangeNoticeDays,
        noRepeatCycleEnabled: source.noRepeatCycleEnabled,
        noRepeatCycleTimes: source.noRepeatCycleTimes,
      });
    }
    return Promise.resolve(policyForm.value);
  }

  function enabledLabel(enabled: boolean): string {
    return enabled
      ? t('module.security-setting.common.enabled')
      : t('module.security-setting.common.disabled');
  }

  function enabledTone(enabled: boolean): PolicyTone {
    return enabled ? 'success' : 'warning';
  }

  function resolveActionLabel(value: string) {
    return actionOptions.value.find((option) => option.value === value)?.label || value;
  }

  function formatPasswordStrengthSummary(setting: PasswordPolicySetting) {
    const characterCount = countPasswordCharacterRules(setting);
    const exclusionCount = countPasswordExclusionRules(setting);
    const exclusionText = exclusionCount > 0
      ? t('module.security-setting.passwordPolicy.card.strength.exclusionOn', { count: exclusionCount })
      : t('module.security-setting.passwordPolicy.card.strength.exclusionOff');
    return t('module.security-setting.passwordPolicy.card.strength.summary', {
      min: setting.minLength,
      charCount: characterCount,
      exclusion: exclusionText,
    });
  }

  function formatWeakPasswordSummary(setting: PasswordPolicySetting, count: number) {
    if (!setting.weakPasswordEnabled) {
      return t('module.security-setting.passwordPolicy.card.weakPassword.summaryDisabled', { count });
    }
    const login = setting.loginCheckEnabled
      ? (setting.loginHitAction === 'BLOCK'
        ? t('module.security-setting.passwordPolicy.card.weakPassword.loginOnBlock')
        : t('module.security-setting.passwordPolicy.card.weakPassword.loginOnRemind'))
      : t('module.security-setting.passwordPolicy.card.weakPassword.loginOff');
    return t('module.security-setting.passwordPolicy.card.weakPassword.summaryEnabled', { count, login });
  }

  function formatInitialPasswordSummary(setting: PasswordPolicySetting) {
    return t('module.security-setting.passwordPolicy.card.initialPassword.summary', {
      days: setting.initialPasswordValidDays,
    });
  }

  function formatPasswordCycleSummary(setting: PasswordPolicySetting) {
    const changeText = setting.periodicChangeEnabled
      ? t('module.security-setting.passwordPolicy.card.cycle.changeOn', {
        days: setting.periodicChangeDays,
        notice: setting.periodicChangeNoticeDays,
      })
      : t('module.security-setting.passwordPolicy.card.cycle.changeOff');
    const repeatText = setting.noRepeatCycleEnabled
      ? t('module.security-setting.passwordPolicy.card.cycle.repeatOn', { times: setting.noRepeatCycleTimes })
      : t('module.security-setting.passwordPolicy.card.cycle.repeatOff');
    return t('module.security-setting.passwordPolicy.card.cycle.summary', { change: changeText, repeat: repeatText });
  }

  function formatPasswordLifecycleSummary(actions: PasswordLifecycleActions) {
    return t('module.security-setting.passwordPolicy.card.lifecycle.summary', {
      expiring: resolveActionLabel(actions.passwordExpiringSoonAction),
      expired: resolveActionLabel(actions.passwordExpiredAction),
      reset: resolveActionLabel(actions.adminResetAction),
    });
  }

  function updateDraftAction(key: keyof PasswordLifecycleActions, value: string) {
    draftAction.value[key] = value;
  }

  function resolveSaveErrorMessage(error?: unknown) {
    if (error == null) {
      return formatSecuritySettingCatalogError('SECURITY_SETTING_PASSWORD_POLICY_SAVE_FAILED');
    }
    return resolveSecuritySettingErrorMessage(error, 'SECURITY_SETTING_PASSWORD_POLICY_SAVE_FAILED');
  }


  return {
    t,
    passwordLengthMarks,
    initialPasswordValidDayMarks,
    periodicChangeDayMarks,
    noticeDayMarks,
    repeatTimesMarks,
    characterRuleChoices,
    exclusionRuleChoices,
    initialPasswordWriteChoices,
    loading,
    saving,
    loadFailed,
    drawerVisible,
    activePolicy,
    replaceInitialPassword,
    initialPasswordDraft,
    initialPasswordConfigured,
    policyForm,
    draftPolicy,
    actionForm,
    draftAction,
    actionOptions,
    weakScanStarting,
    weakScanRunning,
    weakScanStatus,
    weakScanInlineError,
    posture,
    postureGaps,
    postureLevelLabel,
    weakScanHitRows,
    weakScanProgressStatus,
    weakScanStatusLabel,
    weakScanFinished,
    policyCards,
    weakPasswordCount,
    draftStrengthCharacterRules,
    draftStrengthExclusionRules,
    strengthPreviewMessage,
    weakPasswordRawCount,
    weakPasswordDuplicateCount,
    lifecycleActionChoices,
    activePolicyMeta,
    activePolicyChanged,
    openPolicyDrawer,
    updateDrawerVisible,
    saveActivePolicy,
    load,
    startWeakPasswordScan,
    pollWeakPasswordScan,
    savePasswordPolicySlice,
    saveLifecycleActions,
    updateDraftAction,
    scaleMax,
  };
}
