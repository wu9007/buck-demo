export const sessionTokenPermissions = {
  view: 'security-setting:session-token:view',
  manage: 'security-setting:session-token:manage',
};
