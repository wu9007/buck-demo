import { sessionTokenPermissions } from './permission/index.js';
import { sessionTokenRoutes } from './routes/index.js';

export const sessionTokenFeature = {
  featureKey: 'session-token',
  routes: sessionTokenRoutes,
  permissions: sessionTokenPermissions,
};
