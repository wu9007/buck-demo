import {
  getSessionTokenSetting,
  updateSessionTokenPolicySetting,
} from '../../../generated/sdk';
import type {
  SessionTokenPolicySetting,
  SessionTokenSetting,
} from '../../../generated/types';

export async function loadSessionTokenSetting(settingId = 'session-token'): Promise<SessionTokenSetting> {
  return getSessionTokenSetting({ settingId });
}

export async function saveSessionTokenPolicy(input: SessionTokenPolicySetting): Promise<SessionTokenSetting> {
  return updateSessionTokenPolicySetting(input);
}
