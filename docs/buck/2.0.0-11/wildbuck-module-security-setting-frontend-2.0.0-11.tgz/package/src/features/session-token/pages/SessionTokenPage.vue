<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { isBrickSessionError } from '@wildbuck/core-api-frontend';
import { showBrickStatus } from '@wildbuck/core-ui-frontend/status';
import {
  BrickPageBlock,
  BrickSettingsCard as SecuritySettingsCard,
  BrickSettingsDrawer as SecuritySettingsDrawer,
  BrickSettingsDrawerSection,
  BrickSettingsGrid,
  BrickSettingsScale,
} from '@wildbuck/core-ui-frontend/patterns';
import type { SessionTokenSetting } from '../../../generated/types';
import { resolveSecuritySettingErrorMessage } from '../../../shared/security-setting-errors.js';
import { securitySettingUsageTracker } from '../../../usage-events';
import { useSecuritySettingI18n } from '../../../i18n.js';
import { loadSessionTokenSetting, saveSessionTokenPolicy } from '../api/session-token';
import {
  ACCESS_TTL_MAX,
  ACCESS_TTL_MIN,
  EXPIRATION_STRATEGIES,
  REFRESH_TTL_MAX,
  REFRESH_TTL_MIN,
  SESSION_TOKEN_POLICY_KEY,
  buildSessionTokenSavePayload,
  buildSparseSliderMarks,
  cloneSessionTokenSetting,
  createDefaultSessionTokenSetting,
  formatSessionTokenDuration,
  normalizeSessionTokenPolicySlice,
  policiesEqual,
  resolveSessionTokenPolicyState,
  scaleMax,
  validateSessionTokenPolicySlice,
} from '../lib/session-token-form.js';
import {
  buildSessionTokenPosture,
  describeSessionTokenPostureGaps,
  sessionTokenPolicyRiskTone,
} from '../lib/session-token-posture.js';

type PolicyTone = 'default' | 'success' | 'warning' | 'danger';
type SessionTokenPolicyKey = typeof SESSION_TOKEN_POLICY_KEY;

type PolicyCard = {
  key: SessionTokenPolicyKey;
  title: string;
  description: string;
  statusLabel: string;
  statusTone: PolicyTone;
  summaryItems: Array<{ label: string; value: string | number; tone?: PolicyTone }>;
  riskLabel?: string;
  riskTone?: PolicyTone;
  actionText?: string;
};

const { t } = useSecuritySettingI18n();

const EXPIRATION_OPTIONS = EXPIRATION_STRATEGIES.map((value) => ({
  value,
  labelKey: `module.security-setting.sessionToken.strategy.${
    value === 'LOGIN_OUT' ? 'loginOut' : 'screenLock'
  }`,
}));

const loading = ref(true);
const saving = ref(false);
const loadFailed = ref(false);
const drawerVisible = ref(false);
const activePolicy = ref<SessionTokenPolicyKey | null>(null);
const form = ref<SessionTokenSetting>(createDefaultSessionTokenSetting() as SessionTokenSetting);
const draft = ref<SessionTokenSetting>(createDefaultSessionTokenSetting() as SessionTokenSetting);

const accessSliderMax = computed(() => scaleMax(draft.value.accessTokenTtlMinutes, 480));
const refreshSliderMax = computed(() => scaleMax(draft.value.refreshTokenTtlMinutes, 10080));

/** Sparse marks as array for BrickSettingsScale (object form also accepted). */
const accessMarks = computed(() => {
  const map = buildSparseSliderMarks([
    { value: 1, label: t('module.security-setting.marks.min1') },
    { value: 5, label: t('module.security-setting.marks.min5') },
    { value: 15, label: t('module.security-setting.marks.min15') },
    { value: 60, label: t('module.security-setting.marks.hour1') },
    { value: 120, label: t('module.security-setting.marks.hour2') },
    { value: 480, label: t('module.security-setting.marks.hour8') },
  ], ACCESS_TTL_MIN, accessSliderMax.value);
  return Object.entries(map).map(([value, label]) => ({ value: Number(value), label }));
});

const refreshMarks = computed(() => {
  const map = buildSparseSliderMarks([
    { value: 2, label: t('module.security-setting.marks.min2') },
    { value: 15, label: t('module.security-setting.marks.min15') },
    { value: 60, label: t('module.security-setting.marks.hour1') },
    { value: 480, label: t('module.security-setting.marks.hour8') },
    { value: 1440, label: t('module.security-setting.marks.day1') },
    { value: 10080, label: t('module.security-setting.marks.day7') },
  ], REFRESH_TTL_MIN, refreshSliderMax.value);
  return Object.entries(map).map(([value, label]) => ({ value: Number(value), label }));
});

const posture = computed(() => buildSessionTokenPosture(form.value));
const postureGaps = computed(() => describeSessionTokenPostureGaps(form.value, {
  secretMissing: t('module.security-setting.sessionToken.posture.gap.secretMissing'),
  refreshNotLonger: t('module.security-setting.sessionToken.posture.gap.refreshNotLonger'),
}));
const postureLevelLabel = computed(() => t(
  `module.security-setting.sessionToken.posture.level.${posture.value.level}`,
));

const strategyLabel = computed(() => strategyLabelOf(form.value.expirationStrategy));

const policyCards = computed<PolicyCard[]>(() => {
  const riskTone = sessionTokenPolicyRiskTone(SESSION_TOKEN_POLICY_KEY, form.value) as PolicyTone;
  return [
    {
      key: SESSION_TOKEN_POLICY_KEY,
      title: t('module.security-setting.sessionToken.card.policy.title'),
      description: t('module.security-setting.sessionToken.card.policy.description'),
      statusLabel: formatDuration(form.value.accessTokenTtlMinutes),
      statusTone: riskTone === 'warning' || riskTone === 'danger' ? 'warning' : 'success',
      riskLabel: t('module.security-setting.sessionToken.card.policy.risk'),
      riskTone,
      actionText: t('module.security-setting.sessionToken.card.policy.action'),
      summaryItems: [
        {
          label: t('module.security-setting.common.summary'),
          value: t('module.security-setting.sessionToken.card.policy.summary', {
            access: formatDuration(form.value.accessTokenTtlMinutes),
            refresh: formatDuration(form.value.refreshTokenTtlMinutes),
            strategy: strategyLabel.value,
          }),
        },
      ],
    },
  ];
});

const activePolicyMeta = computed(() => policyCards.value.find((item) => item.key === activePolicy.value) || null);
const activePolicyChanged = computed(() => {
  if (!activePolicy.value) {
    return false;
  }
  return !policiesEqual(
    resolveSessionTokenPolicyState(activePolicy.value, draft.value),
    resolveSessionTokenPolicyState(activePolicy.value, form.value),
  );
});

onMounted(async () => {
  void securitySettingUsageTracker.trackPage('sessionToken');
  await load();
});

async function load() {
  loading.value = true;
  loadFailed.value = false;
  try {
    form.value = await loadSessionTokenSetting();
    draft.value = cloneSessionTokenSetting(form.value) as SessionTokenSetting;
  } catch (error) {
    // Global session recovery owns 401 UI — do not flip page to load-failed or toast.
    if (isBrickSessionError(error)) {
      return;
    }
    loadFailed.value = true;
    showBrickStatus(resolveErrorMessage(error), 'error');
  } finally {
    loading.value = false;
  }
}

function openPolicyDrawer(key: SessionTokenPolicyKey) {
  activePolicy.value = key;
  draft.value = cloneSessionTokenSetting(form.value) as SessionTokenSetting;
  drawerVisible.value = true;
  void securitySettingUsageTracker.trackOpen(key);
}

function updateDrawerVisible(value: boolean) {
  drawerVisible.value = value;
  if (!value) {
    activePolicy.value = null;
  }
}

async function saveActivePolicy() {
  if (saving.value || !activePolicy.value) {
    return;
  }
  const policy = activePolicy.value;
  const normalized = normalizeSessionTokenPolicySlice(policy, draft.value) as SessionTokenSetting;
  draft.value = normalized;
  const validation = validateSessionTokenPolicySlice(policy, normalized);
  if (!validation.valid) {
    if (validation.errors.includes('refreshMustBeLonger')) {
      showBrickStatus(t('module.security-setting.sessionToken.validation.refreshMustBeLonger'), 'error');
    } else {
      showBrickStatus(t('module.security-setting.sessionToken.validation.invalid'), 'error');
    }
    return;
  }
  saving.value = true;
  try {
    // rememberMe 后端字段仍保留，登录页未接「记住我」；保存时沿用库内值避免误改语义。
    const payload = buildSessionTokenSavePayload(normalized, form.value);
    form.value = await securitySettingUsageTracker.trackAction(policy, 'save', () => saveSessionTokenPolicy(payload));
    draft.value = cloneSessionTokenSetting(form.value) as SessionTokenSetting;
    updateDrawerVisible(false);
    // TTL/strategy apply to newly issued tokens — first sentence must drive re-login acceptance.
    showBrickStatus(t('module.security-setting.common.savedNeedRelogin', {
      title: activePolicyMeta.value?.title || t('module.security-setting.sessionToken.page.title'),
    }), 'success');
  } catch (error) {
    if (isBrickSessionError(error)) {
      return;
    }
    showBrickStatus(resolveErrorMessage(error), 'error');
  } finally {
    saving.value = false;
  }
}

function resolveErrorMessage(error: unknown) {
  return resolveSecuritySettingErrorMessage(error, 'SECURITY_SETTING_SESSION_TOKEN_SAVE_FAILED');
}

function formatDuration(minutes: number) {
  return formatSessionTokenDuration(minutes, t);
}

function strategyLabelOf(strategy: string) {
  const hit = EXPIRATION_OPTIONS.find((item) => item.value === strategy);
  return hit ? t(hit.labelKey) : strategy;
}

function strategyPreviewKey(strategy: string) {
  if (strategy === 'SCREEN_LOCK') {
    return 'module.security-setting.sessionToken.strategy.preview.screenLock';
  }
  return 'module.security-setting.sessionToken.strategy.preview.loginOut';
}
</script>

<template>
  <article class="console-settings-page security-setting-page session-token-console">
    <BrickPageBlock
      :eyebrow="t('module.security-setting.sessionToken.page.eyebrow')"
      :title="t('module.security-setting.sessionToken.page.title')"
      :description="t('module.security-setting.sessionToken.page.description')"
      :loading="loading"
      :loading-text="t('module.security-setting.sessionToken.page.loading')"
    >
      <section
        v-if="!loadFailed"
        class="security-posture"
        data-guide-anchor="posture"
        :class="`security-posture--${posture.tone}`"
      >
        <div class="security-posture__head">
          <div>
            <p class="security-posture__eyebrow">{{ t('module.security-setting.sessionToken.posture.eyebrow') }}</p>
            <h2 class="security-posture__title">{{ postureLevelLabel }}</h2>
            <p class="security-posture__hint">{{ t('module.security-setting.sessionToken.posture.hint') }}</p>
          </div>
          <strong class="security-posture__score">{{ posture.score }}</strong>
        </div>
        <ul v-if="postureGaps.length" class="security-posture__gaps">
          <li v-for="gap in postureGaps" :key="gap">{{ gap }}</li>
        </ul>
      </section>

      <!--
        单卡页：共享 grid 在 auto-fit + 1fr 下会拉满整行；外层限宽，避免与登录安全多卡宽度脱节。
        不用 :deep 改子组件 scoped grid（优先级打不过）。
      -->
      <div v-if="!loadFailed" class="session-token-policy-wrap" data-guide-anchor="summary">
        <BrickSettingsGrid>
          <SecuritySettingsCard
            v-for="policy in policyCards"
            :key="policy.key"
            :title="policy.title"
            :description="policy.description"
            :status-label="policy.statusLabel"
            :status-tone="policy.statusTone"
            :summary-items="policy.summaryItems"
            :risk-label="policy.riskLabel"
            :risk-tone="policy.riskTone"
            :action-text="policy.actionText"
            @open="openPolicyDrawer(policy.key)"
          />
        </BrickSettingsGrid>
      </div>
    </BrickPageBlock>

    <section v-if="loadFailed" class="state-panel">
      <p class="state-text">{{ t('module.security-setting.sessionToken.page.loadFailed') }}</p>
      <el-button type="primary" plain @click="load">{{ t('module.security-setting.common.reload') }}</el-button>
    </section>

    <SecuritySettingsDrawer
      v-if="activePolicyMeta"
      :model-value="drawerVisible"
      :title="activePolicyMeta.title"
      :description="activePolicyMeta.description"
      :status-label="activePolicyMeta.statusLabel"
      :status-tone="activePolicyMeta.statusTone"
      :changed="activePolicyChanged"
      :saving="saving"
      :save-text="t('module.security-setting.common.savePolicy')"
      @update:model-value="updateDrawerVisible"
      @save="saveActivePolicy"
    >
      <BrickSettingsDrawerSection
        :title="t('module.security-setting.sessionToken.drawer.policyTitle')"
        :description="t('module.security-setting.sessionToken.drawer.policyDescription')"
      >
        <el-form label-position="top" class="setting-form brick-required-form session-token-form">
          <BrickSettingsScale
            v-model="draft.accessTokenTtlMinutes"
            :label="t('module.security-setting.sessionToken.drawer.accessTtl')"
            :description="t('module.security-setting.sessionToken.drawer.accessTtlHint')"
            :value-label="formatDuration(draft.accessTokenTtlMinutes)"
            :min="ACCESS_TTL_MIN"
            :max="accessSliderMax"
            :input-max="ACCESS_TTL_MAX"
            :step="1"
            :marks="accessMarks"
            :unit="t('module.security-setting.sessionToken.drawer.minutesUnit')"
            show-input
            required
          />
          <BrickSettingsScale
            v-model="draft.refreshTokenTtlMinutes"
            :label="t('module.security-setting.sessionToken.drawer.refreshTtl')"
            :description="t('module.security-setting.sessionToken.drawer.refreshTtlHint')"
            :value-label="formatDuration(draft.refreshTokenTtlMinutes)"
            :min="REFRESH_TTL_MIN"
            :max="refreshSliderMax"
            :input-max="REFRESH_TTL_MAX"
            :step="1"
            :marks="refreshMarks"
            :unit="t('module.security-setting.sessionToken.drawer.minutesUnit')"
            show-input
            required
          />
          <el-form-item :label="t('module.security-setting.sessionToken.drawer.expirationStrategy')" required class="setting-form__full">
            <el-select v-model="draft.expirationStrategy" style="width: 100%">
              <el-option
                v-for="item in EXPIRATION_OPTIONS"
                :key="item.value"
                :label="t(item.labelKey)"
                :value="item.value"
              />
            </el-select>
            <span class="field-hint">{{ t(strategyPreviewKey(draft.expirationStrategy)) }}</span>
            <span class="field-hint field-hint--secondary">{{ t('module.security-setting.sessionToken.drawer.expirationStrategyHint') }}</span>
          </el-form-item>
        </el-form>
      </BrickSettingsDrawerSection>
    </SecuritySettingsDrawer>
  </article>
</template>

<style>
@import "../../../settings-page.css";
@import "../../../security-posture.css";

/*
 * Cap the host of the single policy card. Child settings-grid is scoped and uses
 * auto-fit + 1fr; limiting this wrapper is what actually stops full-row stretch.
 * Width aligns with login-security cards (~1/3 of content area ≈ 320–360px).
 */
.session-token-console .field-hint--secondary {
  display: block;
  margin-top: 4px;
  opacity: 0.85;
}

.session-token-policy-wrap {
  width: 100%;
  max-width: 360px;
}

/* Slider layout is owned by BrickSettingsScale — no page-local el-slider overrides. */
</style>
