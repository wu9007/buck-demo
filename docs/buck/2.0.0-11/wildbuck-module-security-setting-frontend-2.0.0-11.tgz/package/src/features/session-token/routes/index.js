export const sessionTokenRoutes = [
  {
    id: 'security-setting.session-token',
    featureKey: 'session-token',
    path: '/security-setting/session-token',
    title: '会话令牌策略',
    abbr: '令',
    eyebrow: '安全配置 / 会话令牌',
    summary: '管理访问令牌寿命、静默续期与过期处理策略。',
    guide: {
      title: '会话令牌策略任务路径',
      steps: [
        {
          anchor: 'posture',
          title: '先看会话令牌态势',
          body: '态势综合部署密钥、续期窗口与静默续期开关，优先补齐关键缺口。',
        },
        {
          anchor: 'summary',
          title: '再看策略卡片',
          body: '按访问寿命、静默续期与过期处理分片查看当前状态与风险。',
        },
        {
          anchor: 'settings',
          title: '再调整策略分片',
          body: '打开对应卡片抽屉修改字段子集，避免一次堆叠全部配置。',
        },
        {
          anchor: 'save-area',
          title: '保存后影响新签发令牌',
          body: '保存对新登录签发的令牌生效；已在线会话仍按签发时的时长失效。',
        },
      ],
    },
    messages: {
      viewTitle: '会话令牌',
      submitLabel: '保存会话令牌策略',
    },
    permission: 'security-setting:session-token:view',
    component: () => import('../pages/SessionTokenPage.vue'),
  },
];
