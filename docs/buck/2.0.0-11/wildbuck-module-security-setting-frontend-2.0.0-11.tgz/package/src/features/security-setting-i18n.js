import { formatBrickI18nMessage, normalizeBrickLocale } from '@wildbuck/core-i18n-frontend';
import {
  useBrickConsoleI18n,
} from '@wildbuck/core-ui-frontend/i18n';
import {
  SECURITY_SETTING_MESSAGES,
  SECURITY_SETTING_MESSAGES_EN_US,
  SECURITY_SETTING_MESSAGES_ZH_CN,
} from './security-setting-i18n-messages.js';

/**
 * Resolve flat security-setting message table for a Buck locale.
 * @param {unknown} locale
 * @returns {Readonly<Record<string, string>>}
 */
export function resolveSecuritySettingMessages(locale) {
  const normalized = normalizeBrickLocale(locale);
  return SECURITY_SETTING_MESSAGES[normalized] ?? SECURITY_SETTING_MESSAGES_ZH_CN;
}

/**
 * Translate security-setting keys with runtime first, then pack fallback.
 * @param {unknown} runtime
 * @param {string} key
 * @param {Record<string, unknown>} [params]
 * @param {string} [fallbackLocale]
 */
export function translateSecuritySetting(runtime, key, params = {}, fallbackLocale = 'zh-CN') {
  const messageKey = String(key ?? '');
  if (!messageKey) {
    return '';
  }
  if (runtime && typeof runtime.t === 'function') {
    const resolved = runtime.t(messageKey, params);
    if (resolved != null && resolved !== '' && resolved !== messageKey) {
      return String(resolved);
    }
  }
  const locale = normalizeBrickLocale(
    typeof runtime?.getLocale === 'function' ? runtime.getLocale() : fallbackLocale,
    fallbackLocale,
  );
  const pack = resolveSecuritySettingMessages(locale);
  const template = pack[messageKey] ?? SECURITY_SETTING_MESSAGES_ZH_CN[messageKey];
  if (typeof template === 'string') {
    return formatBrickI18nMessage(template, params);
  }
  return messageKey;
}

/**
 * Vue inject helper for security-setting SFCs.
 * Tracks runtime revision so setLocale / registerMessages re-render templates that call t().
 */
export function useSecuritySettingI18n() {
  const { i18n, revision, locale, t: consoleT } = useBrickConsoleI18n();

  function t(key, params) {
    void revision.value;
    const fromRuntime = consoleT(key, params);
    if (fromRuntime != null && fromRuntime !== '' && fromRuntime !== key) {
      return fromRuntime;
    }
    return translateSecuritySetting(i18n, key, params, locale.value);
  }

  return {
    i18n,
    revision,
    locale,
    t,
  };
}

export {
  SECURITY_SETTING_MESSAGES,
  SECURITY_SETTING_MESSAGES_EN_US,
  SECURITY_SETTING_MESSAGES_ZH_CN,
};
