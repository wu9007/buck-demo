import { loginSecurityRoutes } from '../features/login-security/routes/index.js';
import { passwordPolicyRoutes } from '../features/password-policy/routes/index.js';
import { transportSecurityRoutes } from '../features/transport-security/routes/index.js';
import { sessionTokenRoutes } from '../features/session-token/routes/index.js';

export const securitySettingRoutes = [
  ...loginSecurityRoutes,
  ...passwordPolicyRoutes,
  ...transportSecurityRoutes,
  ...sessionTokenRoutes,
];

export const securitySettingWorkbenchCards = [
  {
    cardId: 'security-setting.login-security.summary',
    title: '登录安全策略',
    summary: '查看用户名登录、短信或邮箱多因子认证、验证码能力、失败冻结与设备校验。',
    routeId: 'security-setting.login-security',
    priority: 50,
  },
  {
    cardId: 'security-setting.password-policy.summary',
    title: '密码策略',
    summary: '查看复杂度、弱密码库和周期策略。',
    routeId: 'security-setting.password-policy',
    priority: 60,
  },
  {
    cardId: 'security-setting.transport-security.summary',
    title: '传输安全配置',
    summary: '统一检查当前软国密传输、明文拒绝和重放防护窗口。',
    routeId: 'security-setting.transport-security',
    priority: 70,
  },
  {
    cardId: 'security-setting.session-token.summary',
    title: '会话令牌策略',
    summary: '管理访问令牌寿命、静默续期与过期处理策略。',
    routeId: 'security-setting.session-token',
    priority: 80,
  },
];
