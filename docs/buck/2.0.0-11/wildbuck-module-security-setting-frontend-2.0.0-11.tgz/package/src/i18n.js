export {
  SECURITY_SETTING_MESSAGES,
  SECURITY_SETTING_MESSAGES_EN_US,
  SECURITY_SETTING_MESSAGES_ZH_CN,
  resolveSecuritySettingMessages,
  translateSecuritySetting,
  useSecuritySettingI18n,
} from './features/security-setting-i18n.js';
