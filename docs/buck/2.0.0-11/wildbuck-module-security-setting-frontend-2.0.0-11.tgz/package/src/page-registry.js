if (typeof document !== 'undefined') {
  void import('./settings-page.css');
}

export const brickRouteComponentLoaders = {
  'security-setting.login-security': () => import('./features/login-security/pages/LoginSecurityPage.vue'),
  'security-setting.password-policy': () => import('./features/password-policy/pages/PasswordPolicyPage.vue'),
  'security-setting.transport-security': () => import('./features/transport-security/pages/TransportSecurityPage.vue'),
  'security-setting.session-token': () => import('./features/session-token/pages/SessionTokenPage.vue'),
};
