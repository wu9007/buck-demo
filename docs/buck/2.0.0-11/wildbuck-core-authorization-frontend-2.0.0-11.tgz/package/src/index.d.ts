export interface BrickRouteMenu {
  title?: string;
  icon?: string;
  order?: number;
}

export interface BrickModuleRoute {
  path: string;
  title: string;
  permission?: string;
  menu?: BrickRouteMenu | false;
  meta?: Record<string, unknown>;
}

export interface BrickModuleManifest {
  id: string;
  name: string;
  permissions?: readonly string[];
  routes: readonly BrickModuleRoute[];
  meta?: Record<string, unknown>;
}

export interface BrickNavigationItem {
  moduleId: string;
  moduleName: string;
  path: string;
  title: string;
  order: number;
}

export declare function defineBrickModule<T extends BrickModuleManifest>(
  moduleDefinition: T,
): Readonly<Omit<T, 'permissions' | 'routes'> & {
  permissions: readonly string[];
  routes: readonly BrickModuleRoute[];
}>;

export declare function collectBrickPermissions(modules: readonly BrickModuleManifest[]): string[];

export declare function buildBrickNavigation(
  modules: readonly BrickModuleManifest[],
  grantedPermissions?: readonly string[],
): BrickNavigationItem[];
