function requiredString(value, fieldName) {
  if (typeof value !== 'string' || value.trim() === '') {
    throw new TypeError(`${fieldName} must be a non-empty string`);
  }
  return value.trim();
}

function normalizePermissions(permissions) {
  if (permissions == null) {
    return [];
  }
  if (!Array.isArray(permissions)) {
    throw new TypeError('module permissions must be an array');
  }
  return [...new Set(permissions.map((permission) => requiredString(permission, 'permission')))].sort();
}

function normalizeRoute(route) {
  if (route == null || typeof route !== 'object' || Array.isArray(route)) {
    throw new TypeError('module route must be an object');
  }

  const normalized = {
    ...route,
    path: requiredString(route.path, 'route path'),
    title: requiredString(route.title, 'route title'),
  };

  if (route.permission != null) {
    normalized.permission = requiredString(route.permission, 'route permission');
  }

  if (route.menu && typeof route.menu === 'object') {
    normalized.menu = Object.freeze({
      ...route.menu,
      order: Number.isFinite(route.menu.order) ? route.menu.order : 0,
    });
  }

  return Object.freeze(normalized);
}

function normalizeRoutes(routes) {
  if (!Array.isArray(routes)) {
    throw new TypeError('module routes must be an array');
  }
  return routes.map(normalizeRoute);
}

export function defineBrickModule(moduleDefinition) {
  if (moduleDefinition == null || typeof moduleDefinition !== 'object' || Array.isArray(moduleDefinition)) {
    throw new TypeError('module definition must be an object');
  }

  return Object.freeze({
    ...moduleDefinition,
    id: requiredString(moduleDefinition.id, 'module id'),
    name: requiredString(moduleDefinition.name, 'module name'),
    permissions: Object.freeze(normalizePermissions(moduleDefinition.permissions)),
    routes: Object.freeze(normalizeRoutes(moduleDefinition.routes)),
  });
}

export function collectBrickPermissions(modules) {
  const permissions = new Set();

  for (const moduleDefinition of modules ?? []) {
    for (const permission of moduleDefinition.permissions ?? []) {
      permissions.add(requiredString(permission, 'permission'));
    }
    for (const route of moduleDefinition.routes ?? []) {
      if (route.permission != null) {
        permissions.add(requiredString(route.permission, 'route permission'));
      }
    }
  }

  return [...permissions].sort();
}

export function buildBrickNavigation(modules, grantedPermissions = []) {
  const granted = new Set(grantedPermissions);
  const items = [];

  for (const moduleDefinition of modules ?? []) {
    for (const route of moduleDefinition.routes ?? []) {
      if (!route.menu) {
        continue;
      }
      if (route.permission && !granted.has(route.permission)) {
        continue;
      }

      items.push({
        moduleId: moduleDefinition.id,
        moduleName: moduleDefinition.name,
        path: route.path,
        title: route.menu.title ?? route.title,
        order: route.menu.order ?? 0,
      });
    }
  }

  return items.sort((left, right) => left.order - right.order || left.path.localeCompare(right.path));
}
