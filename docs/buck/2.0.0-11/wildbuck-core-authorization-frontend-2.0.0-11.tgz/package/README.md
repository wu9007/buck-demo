# @wildbuck/core-authorization-frontend

Buck 前端鉴权和模块导航辅助包。

这个包把模块路由、权限和导航元数据放在一个小契约里，让上层应用和 AI 开发线程可以围绕业务模块理解前端权限上下文，不需要在零散文件之间来回跳转。

```js
import { defineBrickModule } from '@wildbuck/core-authorization-frontend';

export const iamModule = defineBrickModule({
  id: 'iam',
  name: 'IAM',
  permissions: ['iam:employee:list'],
  routes: [
    {
      path: '/iam/employees',
      title: 'Employees',
      permission: 'iam:employee:list',
      menu: { order: 10 },
    },
  ],
});
```
