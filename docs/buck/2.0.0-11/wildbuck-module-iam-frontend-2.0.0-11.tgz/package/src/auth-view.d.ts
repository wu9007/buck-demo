declare const authView: unknown;

export default authView;
