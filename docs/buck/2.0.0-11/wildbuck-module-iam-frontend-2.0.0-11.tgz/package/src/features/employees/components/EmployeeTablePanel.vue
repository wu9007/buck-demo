<script setup lang="ts">
import { computed, ref } from 'vue';
import { BrickPaginationBar, BrickRiskConfirm, BrickStepUpConfirm, BrickTableMoreMenu } from '@wildbuck/core-ui-frontend/patterns';
import type { EmployeeSummary } from '../../../generated/types';
import { BrickTableActions as IamTableActions } from '@wildbuck/core-ui-frontend/patterns';
import { verifyIamStepUpPassword } from '../../../shared/step-up.js';
import { maskEmail } from '../../../shared/sensitive';
import { useIamI18n } from '../../management-i18n.js';

const props = defineProps<{
  employeeAvatarUrls: Record<string, string>;
  employees: EmployeeSummary[];
  loading: boolean;
  page: number;
  pageSize: number;
  pageSizeOptions: number[];
  pageSummary: string;
  total: number;
  selectedEmployeeId?: string;
  /** 是否处于已应用筛选（空态 / meta） */
  filterActive?: boolean;
}>();

const emit = defineEmits<{
  create: [];
  delete: [employeeId: string];
  open: [employeeId: string];
  unlock: [employeeId: string];
  resetPassword: [employeeId: string];
  'update:page': [value: number];
  'update:pageSize': [value: number];
}>();

const { t } = useIamI18n();

type StepUpAction = 'unlock' | 'resetPassword';

const stepUpVisible = ref(false);
const stepUpAction = ref<StepUpAction>('unlock');
const stepUpEmployeeId = ref('');
const pendingDeleteId = ref('');
const riskDeleteVisible = ref(false);

const stepUpTitle = computed(() => (
  stepUpAction.value === 'resetPassword'
    ? t('module.iam.employees.list.stepUpResetTitle')
    : t('module.iam.employees.list.stepUpUnlockTitle')
));

const stepUpDescription = computed(() => (
  stepUpAction.value === 'resetPassword'
    ? t('module.iam.employees.list.stepUpResetDescription')
    : t('module.iam.employees.list.stepUpUnlockDescription')
));

const emptyText = computed(() => {
  if (props.loading) {
    return t('module.iam.employees.list.loading');
  }
  if (props.filterActive) {
    return t('module.iam.employees.list.emptyFiltered');
  }
  return t('module.iam.employees.list.empty');
});

const headerMeta = computed(() => {
  if (props.filterActive) {
    return t('module.iam.employees.list.filteredMeta', {
      visible: props.employees.length,
      total: props.total,
    });
  }
  return t('module.iam.employees.list.totalMeta', { total: props.total });
});

function resolveAvatarFallback(employeeName: string) {
  const compact = (employeeName || t('module.iam.employees.avatarFallback')).replace(/\s+/g, '');
  return compact.length <= 2 ? compact.toUpperCase() : compact.slice(0, 2).toUpperCase();
}

function openStepUp(action: StepUpAction, employeeId: string) {
  stepUpAction.value = action;
  stepUpEmployeeId.value = employeeId;
  stepUpVisible.value = true;
}

function openDeleteRisk(employeeId: string) {
  pendingDeleteId.value = employeeId;
  riskDeleteVisible.value = true;
}

async function verifyPassword(password: string) {
  return verifyIamStepUpPassword(password, t('module.iam.employees.detail.stepUpFailed'));
}

function onStepUpSuccess() {
  const employeeId = stepUpEmployeeId.value;
  const action = stepUpAction.value;
  stepUpEmployeeId.value = '';
  if (!employeeId) {
    return;
  }
  if (action === 'unlock') {
    emit('unlock', employeeId);
    return;
  }
  if (action === 'resetPassword') {
    emit('resetPassword', employeeId);
  }
}

function confirmDelete() {
  if (pendingDeleteId.value) {
    emit('delete', pendingDeleteId.value);
  }
  pendingDeleteId.value = '';
  riskDeleteVisible.value = false;
}

function onMoreCommand(command: string, employeeId: string) {
  if (command === 'unlock') {
    openStepUp('unlock', employeeId);
    return;
  }
  if (command === 'resetPassword') {
    openStepUp('resetPassword', employeeId);
  }
}

function onRowClick(row: EmployeeSummary) {
  emit('open', row.employeeId);
}
</script>

<template>
  <el-card shadow="never" class="iam-list-panel employee-table-panel" data-guide-anchor="list">
    <template #header>
      <div class="iam-list-panel__header">
        <div>
          <h2>{{ t('module.iam.employees.list.title') }}</h2>
          <p>{{ t('module.iam.employees.list.subtitle') }}</p>
        </div>
        <span class="iam-list-panel__meta" data-testid="employee-list-meta">{{ headerMeta }}</span>
      </div>
    </template>

    <el-table
      v-if="employees.length > 0 || loading"
      :data="employees"
      v-loading="loading"
      row-key="employeeId"
      :highlight-current-row="true"
      :current-row-key="selectedEmployeeId"
      :empty-text="emptyText"
      @row-click="onRowClick"
    >
      <el-table-column :label="t('module.iam.employees.column.avatar')" width="72">
        <template #default="{ row }">
          <div class="employee-avatar-cell">
            <img
              v-if="row.avatarResourceId && employeeAvatarUrls[row.avatarResourceId]"
              :src="employeeAvatarUrls[row.avatarResourceId]"
              :alt="t('module.iam.employees.avatarAlt', { name: row.employeeName })"
              class="employee-avatar-cell__image"
            />
            <span v-else>{{ resolveAvatarFallback(row.employeeName) }}</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column :label="t('module.iam.employees.column.name')" min-width="160">
        <template #default="{ row }">
          <div class="iam-list-name">
            <div class="iam-list-name__copy">
              <!-- 主列只显示姓名；登录名用独立列，避免名称下堆字段 -->
              <strong>{{ row.employeeName }}</strong>
            </div>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="username" :label="t('module.iam.employees.column.username')" min-width="140" />
      <el-table-column :label="t('module.iam.employees.column.email')" min-width="200">
        <template #default="{ row }">
          {{ maskEmail(row.email) }}
        </template>
      </el-table-column>
      <el-table-column prop="organizationName" :label="t('module.iam.employees.column.organization')" min-width="180" />
      <el-table-column :label="t('module.iam.employees.column.enabled')" width="100">
        <template #default="{ row }">
          <el-tag :type="row.enabled ? 'success' : 'warning'" effect="plain">
            {{ row.enabled ? t('module.iam.common.enabled') : t('module.iam.common.disabled') }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column :label="t('module.iam.employees.column.actions')" width="240" fixed="right">
        <template #default="{ row }">
          <IamTableActions @click.stop>
            <el-button
              link
              type="primary"
              data-testid="employee-open-detail"
              @click.stop="$emit('open', row.employeeId)"
            >
              {{ t('module.iam.common.viewDetail') }}
            </el-button>
            <!-- 删除是风险操作：独立危险入口，不埋进「更多」 -->
            <el-button
              link
              type="danger"
              data-testid="employee-delete"
              @click.stop="openDeleteRisk(row.employeeId)"
            >
              {{ t('module.iam.common.delete') }}
            </el-button>
            <!-- 运维「更多」三点图标，操作列末位 -->
            <BrickTableMoreMenu @command="(command) => onMoreCommand(String(command), row.employeeId)">
              <el-dropdown-item command="unlock">
                {{ t('module.iam.employees.security.unlockButton') }}
              </el-dropdown-item>
              <el-dropdown-item command="resetPassword" divided>
                {{ t('module.iam.employees.security.resetTrigger') }}
              </el-dropdown-item>
            </BrickTableMoreMenu>
          </IamTableActions>
        </template>
      </el-table-column>
    </el-table>

    <p v-else class="iam-list-empty" data-testid="employee-list-empty">{{ emptyText }}</p>

    <BrickPaginationBar
      v-if="employees.length > 0 || total > 0"
      :page="page"
      :page-size="pageSize"
      :page-sizes="pageSizeOptions"
      :summary="pageSummary"
      :total="total"
      @update:page="$emit('update:page', $event)"
      @update:page-size="$emit('update:pageSize', $event)"
    />

    <BrickStepUpConfirm
      v-model="stepUpVisible"
      :title="stepUpTitle"
      :description="stepUpDescription"
      :impact="[t('module.iam.employees.list.stepUpImpact')]"
      :verify="verifyPassword"
      @success="onStepUpSuccess"
    />

    <BrickRiskConfirm
      v-model="riskDeleteVisible"
      :title="t('module.iam.employees.delete.title')"
      :description="t('module.iam.employees.delete.description')"
      :impact="[
        t('module.iam.employees.delete.impact1'),
        t('module.iam.employees.delete.impact2'),
      ]"
      :confirm-text="t('module.iam.employees.delete.confirm')"
      @confirm="confirmDelete"
      @cancel="pendingDeleteId = ''"
    />
  </el-card>
</template>

<style scoped>
@import "@wildbuck/core-ui-frontend/list-panel.css";

.employee-avatar-cell {
  width: 32px;
  height: 32px;
  display: grid;
  place-items: center;
  overflow: hidden;
  /* 头像：block 级圆角，非 999 胶囊 */
  border-radius: var(--console-block-radius, 4px);
  background: var(--console-block-bg, #f1f5f9);
  color: var(--console-title, #172033);
  font-size: 11px;
  font-weight: 600;
}

.employee-avatar-cell__image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

:deep(.el-dropdown-menu__item.is-danger) {
  color: var(--console-danger, #dc2626);
}
</style>
