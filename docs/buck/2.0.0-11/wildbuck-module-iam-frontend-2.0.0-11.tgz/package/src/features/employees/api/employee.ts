import {
  adminResetEmployeePassword,
  adminUnlockEmployee,
  assignEmployeeRoles,
  createEmployee as createEmployeeRequest,
  deleteEmployee,
  employeeDetail,
  employeeRoleAssignmentDetail,
  listOrganizations,
  listEmployees,
  updateEmployee,
} from '../../../generated/sdk';
import type {
  AdminResetEmployeePasswordResult,
  AssignEmployeeRolesRequest,
  CreateEmployeeRequest,
  EmployeeDetail,
  EmployeeRoleAssignment,
  EmployeeRoleAssignmentDetail,
  EmployeeSearchRequest,
  EmployeeSummary,
  OrganizationTreeNode,
  Page,
  UnlockEmployeeResult,
  UpdateEmployeeRequest,
} from '../../../generated/types';

export async function searchEmployees(input: EmployeeSearchRequest): Promise<Page<EmployeeSummary>> {
  return listEmployees(input);
}

export async function createEmployee(input: CreateEmployeeRequest): Promise<EmployeeDetail> {
  return createEmployeeRequest(input);
}

export async function loadOrganizationTree(): Promise<OrganizationTreeNode[]> {
  return listOrganizations(undefined);
}

export async function loadEmployeeDetail(employeeId: string): Promise<EmployeeDetail> {
  return employeeDetail(employeeId, undefined);
}

export async function saveEmployee(employeeId: string, input: UpdateEmployeeRequest): Promise<EmployeeDetail> {
  return updateEmployee(employeeId, input);
}

export async function removeEmployee(employeeId: string): Promise<void> {
  return deleteEmployee(employeeId, undefined);
}

export async function resetEmployeePassword(employeeId: string): Promise<AdminResetEmployeePasswordResult> {
  return adminResetEmployeePassword(employeeId, undefined);
}

export async function unlockEmployee(employeeId: string): Promise<UnlockEmployeeResult> {
  return adminUnlockEmployee(employeeId, undefined);
}

export async function loadEmployeeRoleAssignment(employeeId: string): Promise<EmployeeRoleAssignmentDetail> {
  return employeeRoleAssignmentDetail(employeeId, undefined);
}

export async function saveEmployeeRoles(
  employeeId: string,
  input: AssignEmployeeRolesRequest,
): Promise<EmployeeRoleAssignment> {
  return assignEmployeeRoles(employeeId, input);
}
