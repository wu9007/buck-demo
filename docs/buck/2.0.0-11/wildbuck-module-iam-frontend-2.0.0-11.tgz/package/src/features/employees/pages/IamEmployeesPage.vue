<script setup lang="ts">
import { onMounted } from 'vue';
import { BrickListPageActions, BrickPageHeader } from '@wildbuck/core-ui-frontend/patterns';
import EmployeeDrawerPanel from '../components/EmployeeDrawerPanel.vue';
import EmployeeFilterToolbar from '../components/EmployeeFilterToolbar.vue';
import EmployeeTablePanel from '../components/EmployeeTablePanel.vue';
import { useEmployeeWorkspace } from '../composables/useEmployeeWorkspace';
import { useIamI18n } from '../../management-i18n.js';
import { iamUsageTracker } from '../../../usage-events';

const emit = defineEmits<{
  shellContextMutated: [];
}>();

const { t } = useIamI18n();

const {
  activeTab,
  avatarPreviewUrl,
  avatarUploading,
  closeDrawer,
  clearEmployeeAvatar,
  detailForm,
  drawerVisible,
  deleteEmployee,
  editorMode,
  employeeDetail,
  employeeAvatarUrls,
  employees,
  filterActive,
  filters,
  initialize,
  listError,
  listLoading,
  openEmployee,
  organizationOptions,
  applyFilters,
  changePage,
  changePageSize,
  page,
  pageSize,
  pageSizeOptions,
  pageSummary,
  resetFilters,
  roleAssignment,
  selectedEmployee,
  selectedEmployeeId,
  selectedRoleIds,
  startCreateEmployee,
  submitDetail,
  submitPasswordReset,
  submitRoles,
  submitUnlock,
  total,
  uploadEmployeeAvatar,
} = useEmployeeWorkspace();

onMounted(() => {
  void iamUsageTracker.trackPage('employees');
  initialize();
});

async function saveDetail() {
  if (await submitDetail()) {
    emit('shellContextMutated');
  }
}

/** reactive 对象不能用 v-model 整对象赋值，字段级回写 */
function onFilterModelUpdate(next: {
  keyword?: string;
  organizationId?: string;
  enabled?: string;
}) {
  filters.keyword = next?.keyword ?? '';
  filters.organizationId = next?.organizationId ?? '';
  filters.enabled = next?.enabled ?? 'all';
}
</script>

<template>
  <article class="employees-page">
    <BrickPageHeader
      :eyebrow="t('module.iam.employees.page.eyebrow')"
      :title="t('module.iam.employees.page.title')"
      :description="t('module.iam.employees.page.description')"
    >
      <template #actions>
        <BrickListPageActions>
          <template #primary>
            <el-button type="primary" data-guide-anchor="primary-action" @click="startCreateEmployee">
              {{ t('module.iam.employees.page.create') }}
            </el-button>
          </template>
        </BrickListPageActions>
      </template>
    </BrickPageHeader>

    <EmployeeFilterToolbar
      :model-value="filters"
      :organization-options="organizationOptions"
      @update:model-value="onFilterModelUpdate"
      @search="applyFilters"
      @reset="resetFilters"
    />

    <p v-if="listError" class="state-text state-error">{{ listError }}</p>

    <EmployeeTablePanel
      :employee-avatar-urls="employeeAvatarUrls"
      :employees="employees"
      :loading="listLoading"
      :page="page"
      :page-size="pageSize"
      :page-size-options="pageSizeOptions"
      :page-summary="pageSummary"
      :total="total"
      :selected-employee-id="selectedEmployeeId"
      :filter-active="filterActive"
      @create="startCreateEmployee"
      @delete="deleteEmployee"
      @open="openEmployee"
      @unlock="submitUnlock"
      @reset-password="submitPasswordReset"
      @update:page="changePage"
      @update:page-size="changePageSize"
    />

    <EmployeeDrawerPanel
      :visible="drawerVisible"
      :active-tab="activeTab"
      :avatar-preview-url="avatarPreviewUrl"
      :avatar-uploading="avatarUploading"
      :selected-employee="selectedEmployee"
      :detail-form="detailForm"
      :employee-detail="employeeDetail"
      :editor-mode="editorMode"
      :organization-options="organizationOptions"
      :role-assignment="roleAssignment"
      :selected-role-ids="selectedRoleIds"
      @close="closeDrawer"
      @update:activeTab="activeTab = $event"
      @clear-avatar="clearEmployeeAvatar"
      @save-detail="saveDetail"
      @save-roles="submitRoles"
      @upload-avatar="uploadEmployeeAvatar"
      @update:selectedRoleIds="selectedRoleIds = $event"
    />
  </article>
</template>

<style scoped>
.employees-page {
  display: grid;
  gap: var(--console-page-gap, 18px);
  padding: 4px 0 12px;
  background: var(--console-page-bg, #f6f8f8);
}

.state-text {
  margin: 0;
  padding: var(--console-card-body-y, 16px) var(--console-card-body-x, 16px);
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: var(--console-card-radius, 8px);
  color: var(--console-text, #4a5a70);
  background: var(--console-card-bg, #ffffff);
  box-shadow: var(--console-card-shadow, 0 1px 2px rgba(15, 23, 42, 0.04));
}

.state-error {
  color: var(--console-danger, #b4232f);
}
</style>
