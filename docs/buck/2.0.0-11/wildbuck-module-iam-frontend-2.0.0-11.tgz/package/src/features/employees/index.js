import { employeePermissions } from './permission/index.js';
import { employeeRoutes } from './routes/index.js';

export const employeesFeature = {
  featureKey: 'employees',
  routes: employeeRoutes,
  permissions: employeePermissions,
};
