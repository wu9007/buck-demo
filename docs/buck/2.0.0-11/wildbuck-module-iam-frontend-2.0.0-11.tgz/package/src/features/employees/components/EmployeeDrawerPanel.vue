<script setup lang="ts">
import { BrickConsoleDrawer } from '@wildbuck/core-ui-frontend/shell';
import type {
  EmployeeDetail,
  EmployeeRoleAssignmentDetail,
  EmployeeSummary,
  UpdateEmployeeRequest,
} from '../../../generated/types';
import type { OrganizationOption } from '../composables/useEmployeeWorkspace';
import EmployeeDetailCard from './EmployeeDetailCard.vue';
import EmployeeRoleCard from './EmployeeRoleCard.vue';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

defineProps<{
  visible: boolean;
  activeTab: string;
  avatarPreviewUrl: string;
  avatarUploading: boolean;
  selectedEmployee: EmployeeSummary | null;
  detailForm: UpdateEmployeeRequest;
  employeeDetail: EmployeeDetail | null;
  editorMode: 'edit' | 'create';
  organizationOptions: OrganizationOption[];
  roleAssignment: EmployeeRoleAssignmentDetail | null;
  selectedRoleIds: string[];
}>();

defineEmits<{
  close: [];
  'update:activeTab': [value: string];
  clearAvatar: [];
  saveDetail: [];
  saveRoles: [];
  uploadAvatar: [file: File];
  'update:selectedRoleIds': [value: string[]];
}>();
</script>

<template>
  <BrickConsoleDrawer
    :model-value="visible"
    size="56%"
    :destroy-on-close="false"
    class="employee-drawer"
    :eyebrow="editorMode === 'create' ? t('module.iam.employees.page.create') : t('module.iam.employees.drawer.detailTitle')"
    :title="
      editorMode === 'create'
        ? detailForm.employeeName || t('module.iam.employees.page.create')
        : employeeDetail?.employeeName || selectedEmployee?.employeeName || t('module.iam.employees.drawer.noSelection')
    "
    :description="
      editorMode === 'create'
        ? t('module.iam.employees.drawer.createHint', { username: detailForm.username || t('module.iam.employees.drawer.pendingUsername') })
        : `${employeeDetail?.username || selectedEmployee?.username || t('module.iam.employees.drawer.noUsername')} · ${
            employeeDetail?.organizationName || selectedEmployee?.organizationName || t('module.iam.employees.drawer.noOrganization')
          }`
    "
    @close="$emit('close')"
  >
    <el-tabs
      :model-value="activeTab"
      class="employee-drawer__tabs"
      @update:model-value="$emit('update:activeTab', $event)"
    >
      <el-tab-pane :label="t('module.iam.employees.detail.basicTitle')" name="detail">
        <EmployeeDetailCard
          v-if="employeeDetail || selectedEmployee || editorMode === 'create'"
          :avatar-preview-url="avatarPreviewUrl"
          :avatar-uploading="avatarUploading"
          :detail-form="detailForm"
          :employee-detail="employeeDetail"
          :editor-mode="editorMode"
          :organization-options="organizationOptions"
          :selected-employee="selectedEmployee"
          @clear-avatar="$emit('clearAvatar')"
          @save="$emit('saveDetail')"
          @upload-avatar="$emit('uploadAvatar', $event)"
        />
      </el-tab-pane>

      <el-tab-pane v-if="editorMode === 'edit'" :label="t('module.iam.employees.roles.title')" name="roles">
        <EmployeeRoleCard
          :role-assignment="roleAssignment"
          :selected-role-ids="selectedRoleIds"
          @save="$emit('saveRoles')"
          @update:selected-role-ids="$emit('update:selectedRoleIds', $event)"
        />
      </el-tab-pane>
    </el-tabs>
  </BrickConsoleDrawer>
</template>

<style scoped>
.employee-drawer__tabs :deep(.el-tabs__header) {
  margin-bottom: 20px;
}

.employee-drawer__tabs :deep(.el-tab-pane) {
  display: grid;
  gap: 16px;
}
</style>
