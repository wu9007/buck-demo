export const employeePermissions = {
  list: 'iam:employee:list',
  edit: 'iam:employee:edit',
  resetPassword: 'iam:employee-password:reset',
  unlock: 'iam:employee:unlock',
  assignRole: 'iam:employee-role:assign',
};
