import { computed, onScopeDispose, reactive, ref } from 'vue';
import { isBrickSessionError } from '@wildbuck/core-api-frontend';
import { showBrickStatus } from '@wildbuck/core-ui-frontend';
import { iamErrors } from '../../../generated/errors';
import { resolveEmployeeErrorMessage } from '../lib/employee-errors';
import type {
  CreateEmployeeRequest,
  EmployeeDetail,
  EmployeeRoleAssignmentDetail,
  EmployeeSummary,
  OrganizationTreeNode,
  UpdateEmployeeRequest,
} from '../../../generated/types';
import {
  createEmployee,
  loadEmployeeDetail,
  loadEmployeeRoleAssignment,
  loadOrganizationTree,
  removeEmployee,
  resetEmployeePassword,
  saveEmployee,
  saveEmployeeRoles,
  searchEmployees,
  unlockEmployee,
} from '../api/employee';
import { loadImageResourceBlob, uploadImageResource } from '../../../shared/file-resource';
import { useIamI18n } from '../../management-i18n.js';
import {
  iamUsageTracker,
  resolveIamStatusAction,
} from '../../../usage-events';

export interface OrganizationOption {
  label: string;
  value: string;
}

type EditorMode = 'edit' | 'create';
const EMPLOYEE_PAGE_SIZE_OPTIONS = [10, 20, 50, 100];

export function useEmployeeWorkspace() {
  const { t } = useIamI18n();
  const employees = ref<EmployeeSummary[]>([]);
  const organizations = ref<OrganizationTreeNode[]>([]);
  const selectedEmployeeId = ref('');
  const editorMode = ref<EditorMode>('edit');
  const drawerVisible = ref(false);
  const activeTab = ref('detail');
  const filters = reactive({
    keyword: '',
    organizationId: '',
    enabled: 'all',
  });
  const total = ref(0);
  const page = ref(1);
  const pageSize = ref(20);
  const listLoading = ref(true);
  const panelLoading = ref(false);
  const listError = ref('');

  const employeeDetail = ref<EmployeeDetail | null>(null);
  const roleAssignment = ref<EmployeeRoleAssignmentDetail | null>(null);

  const detailForm = reactive<UpdateEmployeeRequest>({
    organizationId: '',
    username: '',
    employeeName: '',
    phoneNumber: '',
    email: '',
    idCardNumber: '',
    avatarResourceId: undefined,
    enabled: true,
  });

  const selectedRoleIds = ref<string[]>([]);
  const avatarPreviewUrl = ref('');
  const avatarUploading = ref(false);
  const employeeAvatarUrls = ref<Record<string, string>>({});
  const avatarObjectUrlLoads = new Map<string, Promise<string>>();
  let localAvatarPreviewUrl = '';

  const organizationOptions = computed(() => flattenOrganizations(organizations.value));
  const selectedEmployee = computed(() =>
    employees.value.find((employee) => employee.employeeId === selectedEmployeeId.value) ?? null,
  );
  /** 是否已应用非默认筛选（列表 meta / 空态） */
  const filterActive = computed(() => (
    Boolean(filters.keyword.trim())
    || Boolean(filters.organizationId)
    || filters.enabled !== 'all'
  ));
  const pageSummary = computed(() => t('module.iam.employees.list.loaded', { count: employees.value.length, total: total.value }));

  async function initialize() {
    // 仅加载列表与组织选项；详情在打开抽屉时再取，避免无抽屉预拉详情
    await Promise.all([reloadEmployees(), reloadOrganizations()]);
    if (!selectedEmployeeId.value && employees.value[0]?.employeeId) {
      selectedEmployeeId.value = employees.value[0].employeeId;
    }
  }

  async function reloadEmployees(preferredEmployeeId?: string) {
    listLoading.value = true;
    listError.value = '';
    try {
      const employeePage = await searchEmployees({
        keyword: filters.keyword.trim() || undefined,
        organizationId: filters.organizationId || undefined,
        enabled: filters.enabled === 'all' ? undefined : filters.enabled === 'true',
        page: page.value,
        size: pageSize.value,
      });
      employees.value = employeePage.records;
      total.value = employeePage.total;
      if (preferredEmployeeId && employees.value.some((employee) => employee.employeeId === preferredEmployeeId)) {
        selectedEmployeeId.value = preferredEmployeeId;
      } else if (!employees.value.some((employee) => employee.employeeId === selectedEmployeeId.value)) {
        selectedEmployeeId.value = employees.value[0]?.employeeId || '';
      }
      await syncVisibleEmployeeAvatarUrls();
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      employees.value = [];
      total.value = 0;
      selectedEmployeeId.value = '';
      listError.value = `${iamErrors.IAM_EMPLOYEE_NOT_FOUND.message}，${iamErrors.IAM_EMPLOYEE_NOT_FOUND.recovery}`;
      return false;
    } finally {
      listLoading.value = false;
    }
  }

  function assignFilters(next?: {
    keyword?: string;
    organizationId?: string;
    enabled?: string;
  }) {
    filters.keyword = next?.keyword ?? '';
    filters.organizationId = next?.organizationId ?? '';
    filters.enabled = next?.enabled ?? 'all';
  }

  /** 应用条件并重新查询（筛选栏 search 事件会带上 snapshot） */
  async function applyFilters(nextFilters?: {
    keyword?: string;
    organizationId?: string;
    enabled?: string;
  }) {
    if (nextFilters) {
      assignFilters(nextFilters);
    }
    page.value = 1;
    listError.value = '';
    const loaded = await reloadEmployees();
    if (selectedEmployeeId.value) {
      await reloadWorkspace(selectedEmployeeId.value);
    } else if (employees.value[0]?.employeeId) {
      selectedEmployeeId.value = employees.value[0].employeeId;
      await reloadWorkspace(selectedEmployeeId.value);
    }
    if (loaded) {
      void iamUsageTracker.trackActionResult('employee', 'search', 'SUCCESS');
    } else {
      void iamUsageTracker.trackActionResult('employee', 'search', 'FAILURE');
    }
    return loaded;
  }

  /**
   * 重置并重新查询。
   * 必须再次请求列表：仅清空 draft/输入框不够；忽略事件载荷，固定用默认空条件，避免载荷丢失导致沿用旧 keyword。
   */
  async function resetFilters() {
    assignFilters({ keyword: '', organizationId: '', enabled: 'all' });
    return applyFilters({ keyword: '', organizationId: '', enabled: 'all' });
  }

  async function changePage(nextPage: number) {
    if (nextPage < 1 || nextPage === page.value) {
      return;
    }
    page.value = nextPage;
    await reloadEmployees();
    if (selectedEmployeeId.value) {
      await reloadWorkspace(selectedEmployeeId.value);
    }
  }

  async function changePageSize(nextSize: number) {
    if (nextSize < 1 || nextSize === pageSize.value) {
      return;
    }
    pageSize.value = nextSize;
    page.value = 1;
    await reloadEmployees();
    if (selectedEmployeeId.value) {
      await reloadWorkspace(selectedEmployeeId.value);
    }
  }

  async function reloadOrganizations() {
    try {
      organizations.value = await loadOrganizationTree();
    } catch (error) {
      if (isBrickSessionError(error)) {
        return;
      }
      organizations.value = [];
    }
  }

  async function selectEmployee(employeeId: string) {
    if (!employeeId) {
      return false;
    }
    selectedEmployeeId.value = employeeId;
    return reloadWorkspace(employeeId);
  }

  async function openEmployee(employeeId: string) {
    editorMode.value = 'edit';
    activeTab.value = 'detail';
    const loaded = await selectEmployee(employeeId);
    drawerVisible.value = true;
    if (loaded) {
      void iamUsageTracker.trackOpen('employee', 'open-detail');
    } else {
      void iamUsageTracker.trackOpen('employee', 'open-detail', 'FAILURE');
    }
  }

  function startCreateEmployee() {
    selectedEmployeeId.value = '';
    employeeDetail.value = null;
    roleAssignment.value = null;
    selectedRoleIds.value = [];
    panelLoading.value = false;
    editorMode.value = 'create';
    activeTab.value = 'detail';
    resetDetailForm();
    releaseLocalAvatarPreview();
    avatarPreviewUrl.value = '';
    drawerVisible.value = true;
    void iamUsageTracker.trackOpen('employee', 'open-create');
  }

  function closeDrawer() {
    drawerVisible.value = false;
  }

  async function reloadWorkspace(employeeId = selectedEmployeeId.value) {
    if (!employeeId) {
      return false;
    }
    panelLoading.value = true;
    try {
      const [detail, roles] = await Promise.all([
        loadEmployeeDetail(employeeId),
        loadEmployeeRoleAssignment(employeeId),
      ]);
      if (editorMode.value === 'create' || selectedEmployeeId.value !== employeeId) {
        return false;
      }
      employeeDetail.value = detail;
      roleAssignment.value = roles;
      selectedRoleIds.value = [...roles.assignedRoleIds];
      fillDetailForm(detail);
      patchEmployeeSummary(detail);
      await syncAvatarPreview(detail.avatarResourceId);
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      showBrickStatus(
        `${iamErrors.IAM_EMPLOYEE_NOT_FOUND.message}，${iamErrors.IAM_EMPLOYEE_NOT_FOUND.recovery}`,
        'error',
      );
      return false;
    } finally {
      panelLoading.value = false;
    }
  }

  async function submitDetail() {
    if (editorMode.value === 'create') {
      return submitCreate();
    }
    if (!selectedEmployeeId.value) {
      return false;
    }
    const actionCode = resolveIamStatusAction(employeeDetail.value?.enabled, Boolean(detailForm.enabled));
    try {
      const detail = await saveEmployee(selectedEmployeeId.value, { ...detailForm });
      employeeDetail.value = detail;
      fillDetailForm(detail);
      patchEmployeeSummary(detail);
      await syncAvatarPreview(detail.avatarResourceId);
      showBrickStatus(t('module.iam.employees.status.saved', { name: detail.employeeName }), 'success');
      void iamUsageTracker.trackActionResult('employee', actionCode, 'SUCCESS');
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      showBrickStatus(resolveEmployeeErrorMessage(error, t('module.iam.employees.status.saveFailed')), 'error');
      void iamUsageTracker.trackActionResult('employee', actionCode, 'FAILURE');
      return false;
    }
  }

  async function submitCreate() {
    try {
      const detail = await createEmployee({
        ...detailForm,
      } satisfies CreateEmployeeRequest);
      page.value = 1;
      await reloadEmployees(detail.employeeId);
      selectedEmployeeId.value = detail.employeeId;
      editorMode.value = 'edit';
      await reloadWorkspace(detail.employeeId);
      showBrickStatus(t('module.iam.employees.status.created', { name: detail.employeeName }), 'success');
      void iamUsageTracker.trackActionResult('employee', 'create', 'SUCCESS');
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      showBrickStatus(resolveEmployeeErrorMessage(error, t('module.iam.employees.status.createFailed')), 'error');
      void iamUsageTracker.trackActionResult('employee', 'create', 'FAILURE');
      return false;
    }
  }

  async function deleteEmployee(employeeId: string) {
    if (!employeeId) {
      return;
    }
    try {
      const employee = employees.value.find((item) => item.employeeId === employeeId) ?? null;
      const employeeName = employee?.employeeName || employeeDetail.value?.employeeName || employeeId;
      await removeEmployee(employeeId);

      if (selectedEmployeeId.value === employeeId) {
        selectedEmployeeId.value = '';
        employeeDetail.value = null;
        roleAssignment.value = null;
        drawerVisible.value = false;
        editorMode.value = 'edit';
        activeTab.value = 'detail';
      }

      await reloadEmployees();
      showBrickStatus(t('module.iam.employees.status.deleted', { name: employeeName }), 'success');
    } catch (error) {
      if (isBrickSessionError(error)) {
        return;
      }
      showBrickStatus(t('module.iam.employees.status.deleteFailed'), 'error');
    }
  }

  async function submitPasswordReset(employeeId = selectedEmployeeId.value) {
    if (!employeeId) {
      return;
    }
    try {
      const result = await resetEmployeePassword(employeeId);
      const account = employees.value.find((item) => item.employeeId === employeeId);
      const username = account?.username || currentAccountLabel();
      const followUp = result.passwordChangeRequired ? t('module.iam.employees.status.passwordMustChange') : t('module.iam.employees.status.passwordPolicyRemind');
      showBrickStatus(t('module.iam.employees.status.passwordReset', { username, changedAt: result.changedAt, followUp }), 'success');
    } catch (error) {
      if (isBrickSessionError(error)) {
        return;
      }
      showBrickStatus(resolveEmployeeErrorMessage(error, t('module.iam.employees.status.passwordResetFailed')), 'error');
    }
  }

  async function submitUnlock(employeeId = selectedEmployeeId.value) {
    if (!employeeId) {
      return;
    }
    try {
      const result = await unlockEmployee(employeeId);
      const account = employees.value.find((item) => item.employeeId === employeeId);
      const accountLabel = account?.username || currentAccountLabel();
      showBrickStatus(
        result.unlocked ? t('module.iam.employees.status.unlocked', { username: accountLabel }) : t('module.iam.employees.status.notLocked', { username: accountLabel }),
        'success',
      );
    } catch (error) {
      if (isBrickSessionError(error)) {
        return;
      }
      showBrickStatus(t('module.iam.employees.status.unlockFailed'), 'error');
    }
  }

  async function uploadEmployeeAvatar(file: File) {
    avatarUploading.value = true;
    try {
      const uploaded = await uploadImageResource(file, 'EMPLOYEE_AVATAR');
      detailForm.avatarResourceId = uploaded.resourceId;
      replaceLocalAvatarPreview(window.URL.createObjectURL(file));
      showBrickStatus(t('module.iam.employees.status.avatarUploaded'), 'success');
      void iamUsageTracker.trackActionResult('employeeAvatar', 'upload-avatar', 'SUCCESS');
    } catch (error) {
      if (isBrickSessionError(error)) {
        return;
      }
      showBrickStatus(t('module.iam.employees.status.avatarUploadFailed'), 'error');
      void iamUsageTracker.trackActionResult('employeeAvatar', 'upload-avatar', 'FAILURE');
    } finally {
      avatarUploading.value = false;
    }
  }

  function clearEmployeeAvatar() {
    detailForm.avatarResourceId = undefined;
    releaseLocalAvatarPreview();
    avatarPreviewUrl.value = '';
  }

  async function submitRoles() {
    if (!selectedEmployeeId.value) {
      return;
    }
    try {
      const result = await saveEmployeeRoles(selectedEmployeeId.value, {
        roleIds: selectedRoleIds.value,
      });
      await reloadWorkspace(selectedEmployeeId.value);
      showBrickStatus(result.sessionsInvalidated ? t('module.iam.employees.status.rolesUpdatedInvalidated') : t('module.iam.employees.status.rolesUpdated'), 'success');
    } catch (error) {
      if (isBrickSessionError(error)) {
        return;
      }
      showBrickStatus(t('module.iam.employees.status.rolesUpdateFailed'), 'error');
    }
  }

  function fillDetailForm(detail: EmployeeDetail) {
    detailForm.organizationId = detail.organizationId;
    detailForm.username = detail.username;
    detailForm.employeeName = detail.employeeName;
    detailForm.phoneNumber = detail.phoneNumber;
    detailForm.email = detail.email;
    detailForm.idCardNumber = detail.idCardNumber;
    detailForm.avatarResourceId = detail.avatarResourceId;
    detailForm.enabled = detail.enabled;
  }

  function resetDetailForm() {
    detailForm.organizationId = organizationOptions.value[0]?.value || '';
    detailForm.username = '';
    detailForm.employeeName = '';
    detailForm.phoneNumber = '';
    detailForm.email = '';
    detailForm.idCardNumber = '';
    detailForm.avatarResourceId = undefined;
    detailForm.enabled = true;
  }

  function patchEmployeeSummary(detail: EmployeeDetail) {
    const index = employees.value.findIndex((employee) => employee.employeeId === detail.employeeId);
    if (index < 0) {
      return;
    }
    employees.value[index] = {
      ...employees.value[index],
      organizationId: detail.organizationId,
      organizationName: detail.organizationName || employees.value[index].organizationName,
      username: detail.username,
      employeeName: detail.employeeName,
      phoneNumber: detail.phoneNumber,
      email: detail.email,
      idCardNumber: detail.idCardNumber,
      avatarResourceId: detail.avatarResourceId,
      enabled: detail.enabled,
    };
  }

  async function createAvatarObjectUrl(resourceId: string): Promise<string> {
    try {
      const blob = await loadImageResourceBlob(resourceId);
      return window.URL.createObjectURL(blob);
    } catch {
      // 磁盘丢失/404：不抛到控制台循环重试，返回空由 UI 走 fallback
      return '';
    }
  }

  async function syncAvatarPreview(avatarResourceId?: string) {
    if (!avatarResourceId) {
      releaseLocalAvatarPreview();
      avatarPreviewUrl.value = '';
      return;
    }
    try {
      releaseLocalAvatarPreview();
      avatarPreviewUrl.value = await ensureEmployeeAvatarUrl(avatarResourceId);
    } catch {
      avatarPreviewUrl.value = '';
    }
  }

  async function syncVisibleEmployeeAvatarUrls() {
    const resourceIds = [...new Set(
      employees.value
        .map((employee) => employee.avatarResourceId)
        .filter((resourceId): resourceId is string => Boolean(resourceId)),
    )];
    await Promise.allSettled(resourceIds.map((resourceId) => ensureEmployeeAvatarUrl(resourceId)));
  }

  async function ensureEmployeeAvatarUrl(resourceId: string): Promise<string> {
    // Cache hits include empty string so missing blobs are not re-fetched (avoids 404 storms).
    if (Object.prototype.hasOwnProperty.call(employeeAvatarUrls.value, resourceId)) {
      return employeeAvatarUrls.value[resourceId] || '';
    }
    const pending = avatarObjectUrlLoads.get(resourceId);
    if (pending) {
      return pending;
    }
    const loading = createAvatarObjectUrl(resourceId).then((url) => {
      employeeAvatarUrls.value = {
        ...employeeAvatarUrls.value,
        [resourceId]: url,
      };
      avatarObjectUrlLoads.delete(resourceId);
      return url;
    });
    avatarObjectUrlLoads.set(resourceId, loading);
    return loading;
  }

  function replaceLocalAvatarPreview(url: string) {
    releaseLocalAvatarPreview();
    localAvatarPreviewUrl = url;
    avatarPreviewUrl.value = url;
  }

  function releaseLocalAvatarPreview() {
    if (!localAvatarPreviewUrl) {
      return;
    }
    window.URL.revokeObjectURL(localAvatarPreviewUrl);
    if (avatarPreviewUrl.value === localAvatarPreviewUrl) {
      avatarPreviewUrl.value = '';
    }
    localAvatarPreviewUrl = '';
  }

  function currentAccountLabel() {
    return (
      roleAssignment.value?.username
      || employeeDetail.value?.username
      || detailForm.username.trim()
      || selectedEmployee.value?.username
      || selectedEmployee.value?.employeeName
      || selectedEmployeeId.value
    );
  }

  onScopeDispose(() => {
    releaseLocalAvatarPreview();
    for (const url of Object.values(employeeAvatarUrls.value)) {
      window.URL.revokeObjectURL(url);
    }
    employeeAvatarUrls.value = {};
  });

  return {
    avatarPreviewUrl,
    avatarUploading,
    activeTab,
    applyFilters,
    changePage,
    changePageSize,
    closeDrawer,
    clearEmployeeAvatar,
    detailForm,
    drawerVisible,
    deleteEmployee,
    editorMode,
    employeeDetail,
    employeeAvatarUrls,
    employees,
    filterActive,
    filters,
    initialize,
    listError,
    listLoading,
    openEmployee,
    organizationOptions,
    page,
    pageSize,
    pageSizeOptions: EMPLOYEE_PAGE_SIZE_OPTIONS,
    pageSummary,
    panelLoading,
    resetFilters,
    roleAssignment,
    selectEmployee,
    selectedEmployee,
    selectedEmployeeId,
    selectedRoleIds,
    startCreateEmployee,
    total,
    submitDetail,
    submitPasswordReset,
    submitRoles,
    submitUnlock,
    uploadEmployeeAvatar,
  };
}

function flattenOrganizations(nodes: OrganizationTreeNode[], depth = 0): OrganizationOption[] {
  return nodes.flatMap((node) => [
    {
      label: `${'　'.repeat(depth)}${node.organizationName}`,
      value: node.organizationId,
    },
    ...flattenOrganizations(node.children, depth + 1),
  ]);
}
