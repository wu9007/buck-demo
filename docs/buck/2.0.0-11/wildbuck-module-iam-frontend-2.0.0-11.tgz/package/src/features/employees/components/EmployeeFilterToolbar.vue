<script setup lang="ts">
import { computed, watch } from 'vue';
import { BrickFilterToolbar, useBrickFilterDraft } from '@wildbuck/core-ui-frontend/patterns';
import { buildEmployeeEnabledFilterOptions } from '../../../shared/filter-options';
import type { OrganizationOption } from '../composables/useEmployeeWorkspace';
import { useIamI18n } from '../../management-i18n.js';

export type EmployeeListFilters = {
  keyword: string;
  organizationId: string;
  enabled: string;
};

const props = defineProps<{
  /** 已应用的查询条件（只读展示同步；控件绑定 draft） */
  modelValue: EmployeeListFilters;
  organizationOptions: OrganizationOption[];
}>();

const emit = defineEmits<{
  'update:modelValue': [EmployeeListFilters];
  search: [EmployeeListFilters];
  reset: [EmployeeListFilters];
}>();

const { t } = useIamI18n();
const enabledOptions = computed(() => buildEmployeeEnabledFilterOptions(t));

const defaultFilters = (): EmployeeListFilters => ({
  keyword: '',
  organizationId: '',
  enabled: 'all',
});

const { draft, resetDraft, replaceDraft, snapshot } = useBrickFilterDraft(defaultFilters);

// 父组件外部改写已应用条件时（少见）同步进草稿
watch(
  () => props.modelValue,
  (value) => {
    if (!value) {
      return;
    }
    // 仅当与 draft 不一致时写回，避免输入过程被打断
    const current = snapshot();
    if (
      current.keyword !== value.keyword
      || current.organizationId !== value.organizationId
      || current.enabled !== value.enabled
    ) {
      replaceDraft({
        keyword: value.keyword ?? '',
        organizationId: value.organizationId ?? '',
        enabled: value.enabled ?? 'all',
      });
    }
  },
  { deep: true, immediate: true },
);

function onSearch() {
  const next = snapshot();
  emit('update:modelValue', next);
  // search 必须带 snapshot，父组件据此赋值并 reload
  emit('search', next);
}

function onReset() {
  const next = resetDraft();
  emit('update:modelValue', next);
  // 父组件 reset 固定用空条件重新查询；载荷仅作同步，不依赖其是否到达
  emit('reset', next);
}
</script>

<template>
  <BrickFilterToolbar data-guide-anchor="filters" field-min-width="180px" data-testid="employee-filter-toolbar">
    <el-input
      v-model="draft.keyword"
      :placeholder="t('module.iam.employees.filter.keyword')"
      clearable
      data-testid="employee-filter-keyword"
      @keyup.enter="onSearch"
    />

    <el-select
      v-model="draft.organizationId"
      :placeholder="t('module.iam.employees.filter.organization')"
      clearable
      data-testid="employee-filter-organization"
    >
      <el-option
        v-for="option in organizationOptions"
        :key="option.value"
        :label="option.label"
        :value="option.value"
      />
    </el-select>

    <el-select
      v-model="draft.enabled"
      :placeholder="t('module.iam.employees.filter.enabled')"
      data-testid="employee-filter-enabled"
    >
      <el-option
        v-for="option in enabledOptions"
        :key="option.value"
        :label="option.label"
        :value="option.value"
      />
    </el-select>

    <template #actions>
      <el-button type="default" native-type="button" data-testid="employee-filter-reset" @click.prevent="onReset">
        {{ t('module.iam.common.resetFilters') }}
      </el-button>
      <el-button type="primary" native-type="button" data-testid="employee-filter-search" @click.prevent="onSearch">
        {{ t('module.iam.employees.filter.search') }}
      </el-button>
    </template>
  </BrickFilterToolbar>
</template>
