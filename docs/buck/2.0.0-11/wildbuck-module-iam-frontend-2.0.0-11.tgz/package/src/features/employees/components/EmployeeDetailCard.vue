<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { EditPen, View } from '@element-plus/icons-vue';
import { validateBrickRequiredFields } from '@wildbuck/core-ui-frontend';
import { BrickImageUploadField, BrickReadonlyCopyInput } from '@wildbuck/core-ui-frontend/fields';
import { BrickActionBar, BrickStepUpConfirm } from '@wildbuck/core-ui-frontend/patterns';
import type { EmployeeDetail, EmployeeSummary, UpdateEmployeeRequest } from '../../../generated/types';
import { maskEmail, maskIdCardNumber, maskPhoneNumber } from '../../../shared/sensitive';
import { verifyIamStepUpPassword } from '../../../shared/step-up.js';
import type { OrganizationOption } from '../composables/useEmployeeWorkspace';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

const props = defineProps<{
  avatarPreviewUrl: string;
  avatarUploading: boolean;
  detailForm: UpdateEmployeeRequest;
  employeeDetail: EmployeeDetail | null;
  editorMode: 'edit' | 'create';
  organizationOptions: OrganizationOption[];
  selectedEmployee: EmployeeSummary | null;
}>();

const emit = defineEmits<{
  clearAvatar: [];
  save: [];
  uploadAvatar: [file: File];
}>();

const organizationSelectRef = ref();
const usernameInputRef = ref();
const employeeNameInputRef = ref();
const phoneNumberInputRef = ref();
const emailInputRef = ref();
const idCardNumberInputRef = ref();
const sensitiveFieldEditorVisible = ref(props.editorMode === 'create');
/** After step-up: show unmasked phone/email/id on the read-only panel. */
const sensitivePlainVisible = ref(false);
const stepUpVisible = ref(false);
const stepUpPurpose = ref<'view' | 'edit'>('view');
const validationMessage = ref('');

const organizationLabel = computed(() => {
  const selectedOption = props.organizationOptions.find((option) => option.value === props.detailForm.organizationId);
  return selectedOption?.label.trim() || props.employeeDetail?.organizationName || props.selectedEmployee?.organizationName || t('module.iam.employees.detail.pendingOrganization');
});
const maskedPhoneNumber = computed(() => maskPhoneNumber(props.detailForm.phoneNumber, t('module.iam.common.notFilled')));
const maskedEmail = computed(() => maskEmail(props.detailForm.email, t('module.iam.common.notFilled')));
const maskedIdCardNumber = computed(() => maskIdCardNumber(props.detailForm.idCardNumber, t('module.iam.common.notFilled')));
const stepUpTitle = computed(() => (
  stepUpPurpose.value === 'edit'
    ? t('module.iam.employees.detail.stepUpEditTitle')
    : t('module.iam.employees.detail.stepUpViewTitle')
));
const stepUpDescription = computed(() => (
  stepUpPurpose.value === 'edit'
    ? t('module.iam.employees.detail.stepUpEditDescription')
    : t('module.iam.employees.detail.stepUpViewDescription')
));
const stepUpImpactItems = computed(() => [
  t('module.iam.employees.detail.stepUpImpactPhone'),
  t('module.iam.employees.detail.stepUpImpactIdCard'),
]);

watch(
  () => [props.editorMode, props.employeeDetail?.employeeId, props.selectedEmployee?.employeeId],
  () => {
    sensitiveFieldEditorVisible.value = props.editorMode === 'create';
    sensitivePlainVisible.value = false;
    stepUpVisible.value = false;
    validationMessage.value = '';
  },
);

watch(
  () => [
    props.detailForm.organizationId,
    props.detailForm.username,
    props.detailForm.employeeName,
    props.detailForm.phoneNumber,
    props.detailForm.email,
    props.detailForm.idCardNumber,
  ],
  () => {
    validationMessage.value = '';
  },
);

function resolveAvatarFallback() {
  const source = props.detailForm.employeeName?.trim() || props.selectedEmployee?.employeeName?.trim() || t('module.iam.employees.avatarFallback');
  const compact = source.replace(/\s+/g, '');
  return compact.length <= 2 ? compact.toUpperCase() : compact.slice(0, 2).toUpperCase();
}

function uploadAvatar(file: File) {
  emit('uploadAvatar', file);
}

function openStepUp(purpose: 'view' | 'edit') {
  stepUpPurpose.value = purpose;
  stepUpVisible.value = true;
}

function requestViewSensitivePlain() {
  if (sensitivePlainVisible.value) {
    return;
  }
  openStepUp('view');
}

function requestEditSensitive() {
  openStepUp('edit');
}

async function verifyStepUpPassword(password: string) {
  return verifyIamStepUpPassword(password, t('module.iam.employees.detail.stepUpFailed'));
}

function onStepUpSuccess() {
  if (stepUpPurpose.value === 'edit') {
    sensitiveFieldEditorVisible.value = true;
    sensitivePlainVisible.value = true;
    return;
  }
  sensitivePlainVisible.value = true;
}

function cancelSensitiveFieldEditing() {
  sensitiveFieldEditorVisible.value = false;
  props.detailForm.phoneNumber = props.employeeDetail?.phoneNumber || props.selectedEmployee?.phoneNumber || '';
  props.detailForm.email = props.employeeDetail?.email || props.selectedEmployee?.email || '';
  props.detailForm.idCardNumber = props.employeeDetail?.idCardNumber || props.selectedEmployee?.idCardNumber || '';
}

function handleSubmit() {
  const result = validateBrickRequiredFields([
    {
      label: t('module.iam.employees.filter.organization'),
      value: props.detailForm.organizationId,
      message: t('module.iam.employees.detail.organizationPlaceholder'),
      focusTarget: organizationSelectRef.value,
    },
    {
      label: t('module.iam.employees.column.username'),
      value: props.detailForm.username,
      focusTarget: usernameInputRef.value,
    },
    {
      label: t('module.iam.employees.column.name'),
      value: props.detailForm.employeeName,
      focusTarget: employeeNameInputRef.value,
    },
    {
      label: t('module.iam.employees.column.phone'),
      value: props.detailForm.phoneNumber,
      focusTarget: phoneNumberInputRef.value,
    },
    {
      label: t('module.iam.employees.column.email'),
      value: props.detailForm.email,
      focusTarget: emailInputRef.value,
    },
    {
      label: t('module.iam.employees.column.idCard'),
      value: props.detailForm.idCardNumber,
      focusTarget: idCardNumberInputRef.value,
    },
  ]);
  if (!result.ok) {
    validationMessage.value = result.message;
    return;
  }
  validationMessage.value = '';
  emit('save');
}
</script>

<template>
  <section class="console-detail-card">
    <div class="console-detail-card__header">
      <div>
        <h2>{{ editorMode === 'create' ? t('module.iam.employees.page.create') : t('module.iam.employees.drawer.detailTitle') }}</h2>
        <p>{{ editorMode === 'create' ? t('module.iam.employees.detail.createHint') : selectedEmployee?.employeeId }}</p>
      </div>
      <span class="console-summary-chip">{{ organizationLabel }}</span>
    </div>

    <el-alert
      v-if="validationMessage"
      class="console-detail-card__validation"
      type="error"
      :closable="false"
      :title="validationMessage"
    />

    <el-form class="console-detail-form brick-required-form" label-position="top" @submit.prevent="handleSubmit">
      <BrickImageUploadField
        class="console-detail-form__full"
        :label="t('module.iam.employees.detail.avatarLabel')"
        :description="t('module.iam.employees.detail.avatarHint')"
        :preview-url="avatarPreviewUrl"
        :preview-alt="t('module.iam.employees.avatarAlt', { name: detailForm.employeeName || selectedEmployee?.employeeName || t('module.iam.employees.avatarFallback') })"
        :fallback-text="resolveAvatarFallback()"
        :uploading="avatarUploading"
        :clear-disabled="!detailForm.avatarResourceId"
        :upload-text="t('module.iam.employees.detail.uploadAvatar')"
        :clear-text="t('module.iam.employees.detail.clearAvatar')"
        :resource-hint="t('module.iam.employees.detail.avatarFormats')"
        @upload="uploadAvatar"
        @clear="$emit('clearAvatar')"
      />

      <el-form-item>
        <template #label>
          <span class="console-required-label">{{ t('module.iam.employees.filter.organization') }}</span>
        </template>
        <el-select
          ref="organizationSelectRef"
          v-model="detailForm.organizationId"
          :aria-label="t('module.iam.employees.filter.organization')"
        >
          <el-option
            v-for="option in organizationOptions"
            :key="option.value"
            :label="option.label"
            :value="option.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <template #label>
          <span class="console-required-label">{{ t('module.iam.employees.column.username') }}</span>
        </template>
        <el-input
          ref="usernameInputRef"
          v-model.trim="detailForm.username"
          :aria-label="t('module.iam.employees.column.username')"
          type="text"
        />
      </el-form-item>
      <el-form-item>
        <template #label>
          <span class="console-required-label">{{ t('module.iam.employees.column.name') }}</span>
        </template>
        <el-input
          ref="employeeNameInputRef"
          v-model.trim="detailForm.employeeName"
          :aria-label="t('module.iam.employees.column.name')"
          type="text"
        />
      </el-form-item>
      <section
        v-if="editorMode === 'edit' && !sensitiveFieldEditorVisible"
        class="console-detail-form__full console-sensitive-field-panel"
      >
        <div class="console-sensitive-field-panel__header">
          <div class="console-sensitive-field-panel__copy">
            <span class="console-required-label">{{ t('module.iam.employees.detail.sensitive') }}</span>
            <small>{{ t('module.iam.employees.detail.sensitiveHint') }}</small>
          </div>
          <div class="console-sensitive-field-panel__actions" role="group" :aria-label="t('module.iam.employees.detail.sensitive')">
            <el-button
              v-if="!sensitivePlainVisible"
              class="console-sensitive-field-panel__icon-btn"
              text
              type="primary"
              :title="t('module.iam.employees.detail.viewSensitivePlain')"
              :aria-label="t('module.iam.employees.detail.viewSensitivePlain')"
              @click="requestViewSensitivePlain"
            >
              <el-icon :size="16"><View /></el-icon>
            </el-button>
            <el-button
              class="console-sensitive-field-panel__icon-btn"
              text
              type="primary"
              :title="t('module.iam.employees.detail.editSensitive')"
              :aria-label="t('module.iam.employees.detail.editSensitive')"
              @click="requestEditSensitive"
            >
              <el-icon :size="16"><EditPen /></el-icon>
            </el-button>
          </div>
        </div>
        <div class="console-two-column-grid">
          <BrickReadonlyCopyInput
            :label="sensitivePlainVisible ? t('module.iam.employees.column.phone') : t('module.iam.employees.detail.phoneMasked')"
            :model-value="detailForm.phoneNumber"
            :mask-text="maskedPhoneNumber"
            :copyable="sensitivePlainVisible"
            :masked="!sensitivePlainVisible"
          />
          <BrickReadonlyCopyInput
            :label="sensitivePlainVisible ? t('module.iam.employees.column.email') : t('module.iam.employees.detail.emailMasked')"
            :model-value="detailForm.email"
            :mask-text="maskedEmail"
            :copyable="sensitivePlainVisible"
            :masked="!sensitivePlainVisible"
          />
          <BrickReadonlyCopyInput
            class="console-sensitive-field-panel__full"
            :label="sensitivePlainVisible ? t('module.iam.employees.column.idCard') : t('module.iam.employees.detail.idCardMasked')"
            :model-value="detailForm.idCardNumber"
            :mask-text="maskedIdCardNumber"
            :copyable="sensitivePlainVisible"
            :masked="!sensitivePlainVisible"
          />
        </div>
      </section>

      <template v-else>
        <section
          v-if="editorMode === 'edit'"
          class="console-detail-form__full console-sensitive-field-panel console-sensitive-field-panel--editing"
        >
          <div class="console-sensitive-field-panel__header">
            <div>
              <span class="console-required-label">{{ t('module.iam.employees.detail.sensitive') }}</span>
              <small>{{ t('module.iam.employees.detail.sensitiveEditHint') }}</small>
            </div>
            <el-button @click="cancelSensitiveFieldEditing">{{ t('module.iam.employees.detail.cancelSensitive') }}</el-button>
          </div>
        </section>

        <el-form-item>
          <template #label>
            <span class="console-required-label">{{ t('module.iam.employees.column.phone') }}</span>
          </template>
          <el-input
            ref="phoneNumberInputRef"
            v-model.trim="detailForm.phoneNumber"
            :aria-label="t('module.iam.employees.column.phone')"
            type="text"
          />
        </el-form-item>
        <el-form-item>
          <template #label>
            <span class="console-required-label">{{ t('module.iam.employees.column.email') }}</span>
          </template>
          <el-input
            ref="emailInputRef"
            v-model.trim="detailForm.email"
            :aria-label="t('module.iam.employees.column.email')"
            type="text"
          />
        </el-form-item>
        <el-form-item>
          <template #label>
            <span class="console-required-label">{{ t('module.iam.employees.column.idCard') }}</span>
          </template>
          <el-input
            ref="idCardNumberInputRef"
            v-model.trim="detailForm.idCardNumber"
            :aria-label="t('module.iam.employees.column.idCard')"
            type="text"
          />
        </el-form-item>
      </template>

      <section v-if="editorMode === 'create'" class="console-detail-form__full console-sensitive-field-panel">
        <div class="console-sensitive-field-panel__header">
          <div>
            <span>{{ t('module.iam.employees.detail.passwordRules') }}</span>
            <small>{{ t('module.iam.employees.detail.passwordRulesHint') }}</small>
          </div>
        </div>
      </section>

      <div class="console-status-field">
        <div class="console-status-field__copy">
          <span class="console-required-label">{{ t('module.iam.common.enabledState') }}</span>
          <small>{{ t('module.iam.employees.detail.enabledHint') }}</small>
        </div>
        <div class="console-status-toggle" role="radiogroup" :aria-label="t('module.iam.common.enabledState')">
          <button
            type="button"
            class="console-status-toggle__option"
            :class="{ active: detailForm.enabled }"
            :aria-pressed="detailForm.enabled"
            @click="detailForm.enabled = true"
          >{{ t('module.iam.common.enabled') }}</button>
          <button
            type="button"
            class="console-status-toggle__option"
            :class="{ active: !detailForm.enabled }"
            :aria-pressed="!detailForm.enabled"
            @click="detailForm.enabled = false"
          >{{ t('module.iam.common.disabled') }}</button>
        </div>
      </div>

      <BrickActionBar class="console-detail-form__full">
        <template #primary>
          <el-button type="primary" native-type="button" @click="handleSubmit">
            {{ editorMode === 'create' ? t('module.iam.employees.page.create') : t('module.iam.employees.detail.save') }}
          </el-button>
        </template>
      </BrickActionBar>
    </el-form>

    <BrickStepUpConfirm
      v-model="stepUpVisible"
      :title="stepUpTitle"
      :description="stepUpDescription"
      :impact="stepUpImpactItems"
      :verify="verifyStepUpPassword"
      @success="onStepUpSuccess"
    />
  </section>
</template>

<style>
@import "../../../shared/detail-form.css";
</style>
