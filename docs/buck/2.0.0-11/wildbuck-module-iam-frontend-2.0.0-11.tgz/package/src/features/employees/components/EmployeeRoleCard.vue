<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { BrickActionBar } from '@wildbuck/core-ui-frontend/patterns';
import type { EmployeeRoleAssignmentDetail } from '../../../generated/types';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

const props = defineProps<{
  roleAssignment: EmployeeRoleAssignmentDetail | null;
  selectedRoleIds: string[];
}>();

const emit = defineEmits<{
  save: [];
  'update:selectedRoleIds': [value: string[]];
}>();

const roleIdsModel = computed({
  get: () => props.selectedRoleIds,
  set: (value: string[]) => emit('update:selectedRoleIds', value),
});

const availableRoles = computed(() => props.roleAssignment?.availableRoles ?? []);
const effectivePermissionCodes = computed(() => props.roleAssignment?.effectivePermissionCodes ?? []);
const selectedCount = computed(() => roleIdsModel.value.length);
const effectivePermissionCount = computed(() => effectivePermissionCodes.value.length);

/** 生效权限只读审计信息：默认折叠，避免角色分配主任务被长权限表冲淡 */
const effectivePermissionsVisible = ref(false);

watch(
  () => props.roleAssignment?.employeeId ?? props.roleAssignment?.username ?? '',
  () => {
    effectivePermissionsVisible.value = false;
  },
);

function toggleEffectivePermissions() {
  effectivePermissionsVisible.value = !effectivePermissionsVisible.value;
}
</script>

<template>
  <section class="console-detail-card">
    <div class="console-detail-card__header">
      <div>
        <h2>{{ t('module.iam.employees.roles.title') }}</h2>
        <p>{{ t('module.iam.employees.roles.subtitle') }}</p>
      </div>
      <span v-if="roleAssignment" class="console-summary-chip">
        {{ t('module.iam.employees.roles.selectedCount', { count: selectedCount }) }}
      </span>
    </div>

    <div v-if="roleAssignment" class="employee-role-card__body">
      <div class="employee-role-card__meta">
        <span class="employee-role-card__meta-label">{{ t('module.iam.employees.roles.usernameLabel') }}</span>
        <span class="employee-role-card__meta-value">{{ roleAssignment.username }}</span>
      </div>

      <section class="employee-role-card__section">
        <header class="employee-role-card__section-head">
          <h3>{{ t('module.iam.employees.roles.available') }}</h3>
          <p>{{ t('module.iam.employees.roles.availableHint') }}</p>
        </header>

        <el-checkbox-group v-model="roleIdsModel" class="employee-role-card__checks">
          <label
            v-for="role in availableRoles"
            :key="role.roleId"
            class="employee-role-card__check-row"
            :class="{ 'is-disabled': !role.enabled }"
          >
            <el-checkbox :label="role.roleId" :disabled="!role.enabled">
              <span class="employee-role-card__role-name">{{ role.roleName }}</span>
            </el-checkbox>
            <el-tag size="small" :type="role.enabled ? 'success' : 'info'" effect="plain">
              {{ role.enabled ? t('module.iam.common.enabled') : t('module.iam.common.disabled') }}
            </el-tag>
          </label>
        </el-checkbox-group>

        <p v-if="availableRoles.length === 0" class="employee-role-card__empty">
          {{ t('module.iam.employees.roles.emptyRoles') }}
        </p>

        <BrickActionBar>
          <template #primary>
            <el-button type="primary" @click="$emit('save')">{{ t('module.iam.roles.detail.save') }}</el-button>
          </template>
        </BrickActionBar>
      </section>

      <section class="employee-role-card__section employee-role-card__section--effective">
        <header class="employee-role-card__section-head employee-role-card__section-head--row">
          <div>
            <h3>{{ t('module.iam.employees.roles.effective') }}</h3>
            <p>{{ t('module.iam.employees.roles.effectiveHint') }}</p>
          </div>
          <el-button text type="primary" @click="toggleEffectivePermissions">
            {{
              effectivePermissionsVisible
                ? t('module.iam.employees.roles.hideEffective')
                : t('module.iam.employees.roles.showEffective', { count: effectivePermissionCount })
            }}
          </el-button>
        </header>

        <template v-if="effectivePermissionsVisible">
          <el-table
            v-if="effectivePermissionCodes.length > 0"
            :data="effectivePermissionCodes.map((code) => ({ code }))"
            row-key="code"
            size="small"
            class="employee-role-card__perm-table"
          >
            <el-table-column
              prop="code"
              :label="t('module.iam.employees.roles.permissionCode')"
              min-width="280"
            />
          </el-table>
          <p v-else class="employee-role-card__empty">
            {{ t('module.iam.employees.roles.emptyPermissions') }}
          </p>
        </template>
      </section>
    </div>
  </section>
</template>

<style>
@import "../../../shared/detail-form.css";
</style>

<style scoped>
.employee-role-card__body {
  display: grid;
  gap: var(--console-space-5, 20px);
  padding: 0;
}

.employee-role-card__meta {
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  gap: 8px 16px;
  padding-bottom: var(--console-space-3, 14px);
  border-bottom: 1px solid var(--console-card-border, #e6ebf2);
}

.employee-role-card__meta-label {
  color: var(--console-muted, #7e8ba0);
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.employee-role-card__meta-value {
  color: var(--console-title, #172033);
  font-size: 14px;
  font-weight: 600;
}

.employee-role-card__section {
  display: grid;
  gap: var(--console-space-3, 14px);
}

.employee-role-card__section-head h3 {
  margin: 0;
  color: var(--console-title, #172033);
  font-size: 14px;
  font-weight: 700;
}

.employee-role-card__section-head p {
  margin: 6px 0 0;
  color: var(--console-text, #4a5a70);
  font-size: 13px;
  line-height: 1.6;
}

.employee-role-card__section-head--row {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--console-space-3, 12px);
}

.employee-role-card__section-head--row > div {
  min-width: 0;
  flex: 1 1 auto;
}

.employee-role-card__section--effective {
  padding-top: var(--console-space-3, 12px);
  border-top: 1px solid var(--console-card-border, #e6ebf2);
}

.employee-role-card__checks {
  display: grid;
  gap: 0;
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: 0;
  overflow: hidden;
}

.employee-role-card__check-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 44px;
  padding: 10px 14px;
  border-bottom: 1px solid var(--console-card-border, #e6ebf2);
  background: var(--console-card-bg, #ffffff);
  cursor: pointer;
}

.employee-role-card__check-row:last-child {
  border-bottom: 0;
}

.employee-role-card__check-row.is-disabled {
  opacity: 0.62;
  cursor: not-allowed;
  background: var(--console-block-bg, #f8fafc);
}

.employee-role-card__role-name {
  color: var(--console-title, #172033);
  font-size: 14px;
  font-weight: 600;
}

.employee-role-card__empty {
  margin: 0;
  color: var(--console-muted, #7e8ba0);
  font-size: 13px;
}

.employee-role-card__perm-table {
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: 0;
  overflow: hidden;
}

.employee-role-card__perm-table :deep(.el-table__cell) {
  font-family: "SFMono-Regular", "Cascadia Code", ui-monospace, monospace;
  font-size: 12px;
}
</style>
