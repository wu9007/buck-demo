<script setup lang="ts">
import { ref } from 'vue';
import { validateBrickRequiredFields } from '@wildbuck/core-ui-frontend';
import { BrickActionBar } from '@wildbuck/core-ui-frontend/patterns';
import type { OrganizationDetail, OrganizationUpsertRequest } from '../../../generated/types';
import type { OrganizationOption, OrganizationTreeRow } from '../composables/useOrganizationWorkspace';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

const props = defineProps<{
  currentDetail: OrganizationDetail | null;
  editorMode: 'edit' | 'create';
  form: OrganizationUpsertRequest;
  parentOptions: OrganizationOption[];
  selectedOrganization: OrganizationTreeRow | null;
}>();

const emit = defineEmits<{
  save: [];
}>();

const organizationCodeInputRef = ref();
const organizationNameInputRef = ref();
const sortNoInputRef = ref();

function handleSubmit() {
  const result = validateBrickRequiredFields([
    {
      label: t('module.iam.organizations.detail.code'),
      value: props.form.organizationCode,
      focusTarget: organizationCodeInputRef.value,
    },
    {
      label: t('module.iam.organizations.detail.name'),
      value: props.form.organizationName,
      focusTarget: organizationNameInputRef.value,
    },
    {
      label: t('module.iam.common.sortNo'),
      value: props.form.sortNo,
      focusTarget: sortNoInputRef.value,
    },
  ]);
  if (!result.ok) {
    return;
  }
  emit('save');
}
</script>

<template>
  <section class="console-detail-card">
    <div class="console-detail-card__header">
      <div>
        <h2>{{ editorMode === 'create' ? t('module.iam.organizations.detail.createTitle') : t('module.iam.organizations.detail.editTitle') }}</h2>
        <p data-testid="organization-detail-hint">
          {{ editorMode === 'create' ? t('module.iam.organizations.detail.createHint') : (currentDetail?.organizationId || selectedOrganization?.organizationId) }}
        </p>
      </div>
    </div>

    <el-form class="console-detail-form brick-required-form" label-position="top" @submit.prevent="handleSubmit">
      <el-form-item :label="t('module.iam.organizations.detail.parentOptional')">
        <el-select v-model="form.parentId" clearable :placeholder="t('module.iam.organizations.detail.noParent')">
          <el-option v-for="option in parentOptions" :key="option.value" :label="option.label" :value="option.value" />
        </el-select>
      </el-form-item>
      <el-form-item :label="t('module.iam.organizations.detail.codeRequired')" required>
        <el-input ref="organizationCodeInputRef" v-model.trim="form.organizationCode" />
      </el-form-item>
      <el-form-item :label="t('module.iam.organizations.detail.nameRequired')" required>
        <el-input ref="organizationNameInputRef" v-model.trim="form.organizationName" />
      </el-form-item>
      <el-form-item :label="t('module.iam.common.sortNoRequired')" required>
        <el-input ref="sortNoInputRef" v-model.number="form.sortNo" type="number" min="0" />
      </el-form-item>
      <div class="console-status-field">
        <div class="console-status-field__copy">
          <span class="console-required-label">{{ t('module.iam.common.enabledRequired') }}</span>
          <small>{{ t('module.iam.organizations.detail.enabledHint') }}</small>
        </div>
        <div class="console-status-toggle" role="radiogroup" :aria-label="t('module.iam.common.enabledState')">
          <button
            type="button"
            class="console-status-toggle__option"
            :class="{ active: form.enabled }"
            :aria-pressed="form.enabled"
            @click="form.enabled = true"
          >{{ t('module.iam.common.enabled') }}</button>
          <button
            type="button"
            class="console-status-toggle__option"
            :class="{ active: !form.enabled }"
            :aria-pressed="!form.enabled"
            @click="form.enabled = false"
          >{{ t('module.iam.common.disabled') }}</button>
        </div>
      </div>
      <BrickActionBar class="console-detail-form__full">
        <template #primary>
          <el-button type="primary" native-type="submit">{{ t('module.iam.organizations.detail.save') }}</el-button>
        </template>
      </BrickActionBar>
    </el-form>
  </section>
</template>

<style>
@import "../../../shared/detail-form.css";
</style>
