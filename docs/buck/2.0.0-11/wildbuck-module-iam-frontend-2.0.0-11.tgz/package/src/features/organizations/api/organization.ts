import {
  createOrganization,
  deleteOrganization,
  listOrganizations,
  organizationDetail,
  updateOrganization,
} from '../../../generated/sdk';
import type { OrganizationDetail, OrganizationTreeNode, OrganizationUpsertRequest } from '../../../generated/types';

export async function loadOrganizationTree(): Promise<OrganizationTreeNode[]> {
  return listOrganizations(undefined);
}

export async function loadOrganizationDetail(organizationId: string): Promise<OrganizationDetail> {
  return organizationDetail(organizationId, undefined);
}

export async function saveNewOrganization(input: OrganizationUpsertRequest): Promise<OrganizationDetail> {
  return createOrganization(input);
}

export async function saveExistingOrganization(
  organizationId: string,
  input: OrganizationUpsertRequest,
): Promise<OrganizationDetail> {
  return updateOrganization(organizationId, input);
}

export async function removeOrganization(organizationId: string): Promise<void> {
  return deleteOrganization(organizationId, undefined);
}
