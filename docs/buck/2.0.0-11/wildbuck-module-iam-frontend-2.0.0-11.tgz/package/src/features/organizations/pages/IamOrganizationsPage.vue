<script setup lang="ts">
import { onMounted } from 'vue';
import { BrickListPageActions, BrickPageHeader } from '@wildbuck/core-ui-frontend/patterns';
import OrganizationDrawerPanel from '../components/OrganizationDrawerPanel.vue';
import OrganizationFilterToolbar from '../components/OrganizationFilterToolbar.vue';
import OrganizationTreeTablePanel from '../components/OrganizationTreeTablePanel.vue';
import { useOrganizationWorkspace } from '../composables/useOrganizationWorkspace';
import { iamUsageTracker } from '../../../usage-events';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

const {
  activeTab,
  closeDrawer,
  deleteOrganization,
  filteredTreeRows,
  filterActive,
  appliedFilters,
  applySearch,
  initialize,
  panelLoading,
  resetSearch,
  selectOrganization,
  selectedOrganizationId,
  selectedOrganization,
  startCreateChild,
  startCreateRoot,
  structureParentLabel,
  currentDetail,
  drawerVisible,
  editorMode,
  form,
  parentOptions,
  submitForm,
  treeError,
  treeLoading,
  treeRows,
} = useOrganizationWorkspace();

onMounted(() => {
  void iamUsageTracker.trackPage('organizations');
  initialize();
});

/** reactive 对象不能用 v-model 整对象赋值，字段级回写 */
function onFilterModelUpdate(next: {
  keyword?: string;
  enabled?: string;
  level?: string;
}) {
  appliedFilters.keyword = next?.keyword ?? '';
  appliedFilters.enabled = next?.enabled ?? 'all';
  appliedFilters.level = next?.level ?? 'all';
}
</script>

<template>
  <article class="organizations-page">
    <BrickPageHeader
      :eyebrow="t('module.iam.organizations.page.eyebrow')"
      :title="t('module.iam.organizations.page.title')"
      :description="t('module.iam.organizations.page.description')"
    >
      <template #actions>
        <BrickListPageActions>
          <template #primary>
            <el-button type="primary" data-guide-anchor="primary-action" @click="startCreateRoot">
              {{ t('module.iam.organizations.page.createRoot') }}
            </el-button>
          </template>
        </BrickListPageActions>
      </template>
    </BrickPageHeader>

    <OrganizationFilterToolbar
      :model-value="appliedFilters"
      @update:model-value="onFilterModelUpdate"
      @search="applySearch"
      @reset="resetSearch"
    />

    <p v-if="treeError" class="state-text state-error">{{ treeError }}</p>

    <OrganizationTreeTablePanel
      :rows="filteredTreeRows"
      :loading="treeLoading"
      :selected-organization-id="selectedOrganizationId"
      :filter-active="filterActive"
      :total-count="treeRows.length"
      @delete="deleteOrganization"
      @open="selectOrganization"
      @create-root="startCreateRoot"
      @create-child="startCreateChild"
    />

    <OrganizationDrawerPanel
      :visible="drawerVisible"
      :active-tab="activeTab"
      :current-detail="currentDetail"
      :editor-mode="editorMode"
      :form="form"
      :parent-options="parentOptions"
      :selected-organization="selectedOrganization"
      :structure-parent-label="structureParentLabel"
      :panel-loading="panelLoading"
      @close="closeDrawer"
      @update:active-tab="activeTab = $event"
      @save="submitForm"
    />
  </article>
</template>

<style scoped>
.organizations-page {
  display: grid;
  gap: var(--console-page-gap, 18px);
  padding: 4px 0 12px;
  background: var(--console-page-bg, #f6f8f8);
}

.state-text {
  margin: 0;
  padding: var(--console-card-body-y, 18px) var(--console-card-body-x, 18px);
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: var(--console-card-radius, 8px);
  color: var(--console-text, #4a5a70);
  background: var(--console-card-bg, #ffffff);
  box-shadow: var(--console-card-shadow, 0 1px 2px rgba(22, 67, 76, 0.04));
}

.state-error {
  color: var(--console-danger, #b4232f);
}
</style>
