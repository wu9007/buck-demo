export const organizationPermissions = {
  list: 'iam:organization:list',
  edit: 'iam:organization:edit',
};
