import { organizationPermissions } from './permission/index.js';
import { organizationRoutes } from './routes/index.js';

export const organizationsFeature = {
  featureKey: 'organizations',
  routes: organizationRoutes,
  permissions: organizationPermissions,
};
