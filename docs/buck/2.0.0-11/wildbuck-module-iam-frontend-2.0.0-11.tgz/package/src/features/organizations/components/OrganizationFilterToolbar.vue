<script setup lang="ts">
import { computed, watch } from 'vue';
import { BrickFilterToolbar, useBrickFilterDraft } from '@wildbuck/core-ui-frontend/patterns';
import {
  buildEnabledStateFilterOptions,
  buildOrganizationLevelFilterOptions,
} from '../../../shared/filter-options';
import { useIamI18n } from '../../management-i18n.js';

export type OrganizationListFilters = {
  keyword: string;
  enabled: string;
  level: string;
};

const props = defineProps<{
  /** 已应用的查询条件（列表过滤用）；控件只绑定 draft */
  modelValue: OrganizationListFilters;
}>();

const emit = defineEmits<{
  'update:modelValue': [OrganizationListFilters];
  search: [OrganizationListFilters];
  reset: [OrganizationListFilters];
}>();

const { t } = useIamI18n();
const enabledOptions = computed(() => buildEnabledStateFilterOptions(t));
const levelOptions = computed(() => buildOrganizationLevelFilterOptions(t));

const defaultFilters = (): OrganizationListFilters => ({
  keyword: '',
  enabled: 'all',
  level: 'all',
});

const { draft, resetDraft, replaceDraft, snapshot } = useBrickFilterDraft(defaultFilters);

watch(
  () => props.modelValue,
  (value) => {
    if (!value) {
      return;
    }
    const current = snapshot();
    if (
      current.keyword !== value.keyword
      || current.enabled !== value.enabled
      || current.level !== value.level
    ) {
      replaceDraft({
        keyword: value.keyword ?? '',
        enabled: value.enabled ?? 'all',
        level: value.level ?? 'all',
      });
    }
  },
  { deep: true, immediate: true },
);

function onSearch() {
  const next = snapshot();
  emit('update:modelValue', next);
  emit('search', next);
}

function onReset() {
  const next = resetDraft();
  emit('update:modelValue', next);
  emit('reset', next);
}
</script>

<template>
  <BrickFilterToolbar data-guide-anchor="filters" field-min-width="180px" data-testid="organization-filter-toolbar">
    <el-input
      v-model="draft.keyword"
      :placeholder="t('module.iam.organizations.filter.keyword')"
      clearable
      data-testid="organization-filter-keyword"
      @keyup.enter="onSearch"
    />

    <el-select
      v-model="draft.enabled"
      :placeholder="t('module.iam.common.enabledState')"
      data-testid="organization-filter-enabled"
    >
      <el-option
        v-for="option in enabledOptions"
        :key="option.value"
        :label="option.label"
        :value="option.value"
      />
    </el-select>

    <el-select
      v-model="draft.level"
      :placeholder="t('module.iam.organizations.filter.level')"
      data-testid="organization-filter-level"
    >
      <el-option
        v-for="option in levelOptions"
        :key="option.value"
        :label="option.label"
        :value="option.value"
      />
    </el-select>

    <template #actions>
      <el-button native-type="button" data-testid="organization-filter-reset" @click.prevent="onReset">
        {{ t('module.iam.common.resetFilters') }}
      </el-button>
      <el-button type="primary" native-type="button" data-testid="organization-filter-search" @click.prevent="onSearch">
        {{ t('module.iam.organizations.filter.search') }}
      </el-button>
    </template>
  </BrickFilterToolbar>
</template>
