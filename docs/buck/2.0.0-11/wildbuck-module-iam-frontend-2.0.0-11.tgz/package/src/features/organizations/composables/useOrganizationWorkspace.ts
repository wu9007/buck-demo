import { computed, reactive, ref } from 'vue';
import { isBrickSessionError } from '@wildbuck/core-api-frontend';
import { showBrickStatus } from '@wildbuck/core-ui-frontend';
import { iamErrors } from '../../../generated/errors';
import type { OrganizationDetail, OrganizationTreeNode, OrganizationUpsertRequest } from '../../../generated/types';
import {
  loadOrganizationDetail,
  loadOrganizationTree,
  removeOrganization,
  saveExistingOrganization,
  saveNewOrganization,
} from '../api/organization';
import { resolveOrganizationErrorMessage } from '../lib/organization-errors';
import { useIamI18n } from '../../management-i18n.js';
import {
  iamUsageTracker,
  resolveIamStatusAction,
} from '../../../usage-events';

export interface OrganizationTreeRow {
  depth: number;
  enabled: boolean;
  organizationCode: string;
  organizationId: string;
  organizationName: string;
  parentId?: string;
  parentName: string;
  sortNo: number;
  levelLabel: string;
  children?: OrganizationTreeRow[];
  hasChildren?: boolean;
}

export interface OrganizationOption {
  label: string;
  value: string;
}

type EditorMode = 'edit' | 'create';

export function useOrganizationWorkspace() {
  const { t } = useIamI18n();
  const organizations = ref<OrganizationTreeNode[]>([]);
  const selectedOrganizationId = ref('');
  const treeLoading = ref(true);
  const panelLoading = ref(false);
  const drawerVisible = ref(false);
  const activeTab = ref('detail');
  const treeError = ref('');
  const editorMode = ref<EditorMode>('edit');
  const currentDetail = ref<OrganizationDetail | null>(null);
  /** 已应用筛选（仅查询/重置时更新；输入框草稿在 FilterToolbar 内） */
  const appliedFilters = reactive({
    keyword: '',
    enabled: 'all',
    level: 'all',
  });

  const form = reactive<OrganizationUpsertRequest>({
    parentId: undefined,
    organizationCode: '',
    organizationName: '',
    sortNo: 10,
    enabled: true,
  });

  const treeRows = computed(() => flattenTreeRows(organizations.value, t));
  const filteredTreeRows = computed(() => filterTreeRows(organizations.value, appliedFilters, t));
  /** 是否已应用非默认筛选（列表 meta / 空态） */
  const filterActive = computed(() => (
    Boolean(appliedFilters.keyword.trim())
    || appliedFilters.enabled !== 'all'
    || appliedFilters.level !== 'all'
  ));
  const organizationMetrics = computed(() => ({
    total: treeRows.value.length,
    enabled: treeRows.value.filter((row) => row.enabled).length,
    roots: treeRows.value.filter((row) => !row.parentId).length,
  }));
  const selectedOrganization = computed(
    () => treeRows.value.find((row) => row.organizationId === selectedOrganizationId.value) ?? null,
  );
  /**
   * 结构卡「上级组织」展示名：
   * - 编辑态用当前节点 parentName
   * - 新增子组织时 selected 是父节点，应展示 form.parentId 对应名称，不能用父节点的 parentName
   */
  const structureParentLabel = computed(() => {
    if (editorMode.value === 'create') {
      if (!form.parentId) {
        return t('module.iam.organizations.structure.noParentLabel');
      }
      const parent = treeRows.value.find((row) => row.organizationId === form.parentId);
      return parent?.organizationName || t('module.iam.organizations.structure.noParentLabel');
    }
    return selectedOrganization.value?.parentName || t('module.iam.organizations.structure.noParentLabel');
  });
  const parentOptions = computed(() => {
    const excludedIds = editorMode.value === 'edit' ? collectDescendantIds(organizations.value, selectedOrganizationId.value) : new Set<string>();
    return treeRows.value
      .filter((row) => !excludedIds.has(row.organizationId))
      .map((row) => ({
        label: `${'　'.repeat(row.depth)}${row.organizationName}`,
        value: row.organizationId,
      }));
  });

  async function initialize() {
    await reloadOrganizations();
    if (treeRows.value.length > 0) {
      selectedOrganizationId.value = treeRows.value[0].organizationId;
    } else {
      startCreateRoot();
    }
  }

  async function reloadOrganizations(preferredOrganizationId?: string) {
    treeLoading.value = true;
    treeError.value = '';
    try {
      organizations.value = await loadOrganizationTree();
      const rows = flattenTreeRows(organizations.value, t);
      const nextSelection =
        preferredOrganizationId && rows.some((row) => row.organizationId === preferredOrganizationId)
          ? preferredOrganizationId
          : selectedOrganizationId.value && rows.some((row) => row.organizationId === selectedOrganizationId.value)
            ? selectedOrganizationId.value
            : rows[0]?.organizationId || '';
      selectedOrganizationId.value = nextSelection;
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      organizations.value = [];
      selectedOrganizationId.value = '';
      treeError.value = `${iamErrors.IAM_ORGANIZATION_NOT_FOUND.message}，${iamErrors.IAM_ORGANIZATION_NOT_FOUND.recovery}`;
      return false;
    } finally {
      treeLoading.value = false;
    }
  }

  function applySearch(next?: {
    keyword: string;
    enabled: string;
    level: string;
  }) {
    if (next) {
      appliedFilters.keyword = next.keyword ?? '';
      appliedFilters.enabled = next.enabled ?? 'all';
      appliedFilters.level = next.level ?? 'all';
    }
    void iamUsageTracker.trackActionResult('organization', 'search', 'SUCCESS');
  }

  function resetSearch(next?: {
    keyword: string;
    enabled: string;
    level: string;
  }) {
    appliedFilters.keyword = next?.keyword ?? '';
    appliedFilters.enabled = next?.enabled ?? 'all';
    appliedFilters.level = next?.level ?? 'all';
    void iamUsageTracker.trackActionResult('organization', 'search', 'SUCCESS');
  }

  async function selectOrganization(organizationId: string, options: { trackEnter?: boolean } = {}) {
    if (!organizationId) {
      return false;
    }
    const shouldTrackEnter = options.trackEnter ?? true;
    selectedOrganizationId.value = organizationId;
    editorMode.value = 'edit';
    panelLoading.value = true;
    drawerVisible.value = true;
    activeTab.value = 'detail';
    try {
      const detail = await loadOrganizationDetail(organizationId);
      currentDetail.value = detail;
      fillForm(detail);
      if (shouldTrackEnter) {
        void iamUsageTracker.trackOpen('organization', 'open-detail');
      }
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      showBrickStatus(
        `${iamErrors.IAM_ORGANIZATION_NOT_FOUND.message}，${iamErrors.IAM_ORGANIZATION_NOT_FOUND.recovery}`,
        'error',
      );
      if (shouldTrackEnter) {
        void iamUsageTracker.trackOpen('organization', 'open-detail', 'FAILURE');
      }
      return false;
    } finally {
      panelLoading.value = false;
    }
  }

  function startCreateRoot() {
    editorMode.value = 'create';
    selectedOrganizationId.value = '';
    currentDetail.value = null;
    drawerVisible.value = true;
    activeTab.value = 'detail';
    fillForm({
      organizationId: '',
      parentId: undefined,
      organizationCode: '',
      organizationName: '',
      sortNo: nextSortNo(undefined),
      enabled: true,
    });
    void iamUsageTracker.trackOpen('organization', 'open-create');
  }

  function startCreateChild(organizationId?: string) {
    editorMode.value = 'create';
    currentDetail.value = null;
    selectedOrganizationId.value = organizationId || selectedOrganizationId.value;
    drawerVisible.value = true;
    activeTab.value = 'detail';
    fillForm({
      organizationId: '',
      parentId: selectedOrganizationId.value || undefined,
      organizationCode: '',
      organizationName: '',
      sortNo: nextSortNo(selectedOrganizationId.value || undefined),
      enabled: true,
    });
    void iamUsageTracker.trackOpen('organization', 'open-create');
  }

  async function submitForm() {
    const isCreating = editorMode.value === 'create';
    const actionCode = isCreating
      ? 'create'
      : resolveIamStatusAction(currentDetail.value?.enabled, Boolean(form.enabled));
    try {
      const payload = normalizeForm();
      const detail =
        isCreating
          ? await saveNewOrganization(payload)
          : await saveExistingOrganization(selectedOrganizationId.value, payload);
      await reloadOrganizations(detail.organizationId);
      await selectOrganization(detail.organizationId, { trackEnter: false });
      showBrickStatus(t('module.iam.organizations.status.saved', { name: detail.organizationName }), 'success');
      void iamUsageTracker.trackActionResult('organization', actionCode, 'SUCCESS');
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      showBrickStatus(resolveOrganizationErrorMessage(error), 'error');
      void iamUsageTracker.trackActionResult('organization', actionCode, 'FAILURE');
      return false;
    }
  }

  async function deleteSelectedOrganization() {
    await deleteOrganization(selectedOrganizationId.value);
  }

  async function deleteOrganization(organizationId: string) {
    if (!organizationId) {
      return false;
    }
    try {
      const row = treeRows.value.find((item) => item.organizationId === organizationId) ?? null;
      const organizationName = row?.organizationName || currentDetail.value?.organizationName || organizationId;
      await removeOrganization(organizationId);

      if (selectedOrganizationId.value === organizationId) {
        currentDetail.value = null;
        selectedOrganizationId.value = '';
        drawerVisible.value = false;
        activeTab.value = 'detail';
      }

      await reloadOrganizations();
      showBrickStatus(t('module.iam.organizations.status.deleted', { name: organizationName }), 'success');
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      showBrickStatus(resolveOrganizationErrorMessage(error), 'error');
      return false;
    }
  }

  function closeDrawer() {
    drawerVisible.value = false;
    activeTab.value = 'detail';
  }

  function fillForm(detail: Pick<OrganizationDetail, 'parentId' | 'organizationCode' | 'organizationName' | 'sortNo' | 'enabled'>) {
    form.parentId = detail.parentId || undefined;
    form.organizationCode = detail.organizationCode;
    form.organizationName = detail.organizationName;
    form.sortNo = detail.sortNo;
    form.enabled = detail.enabled;
  }

  function normalizeForm(): OrganizationUpsertRequest {
    return {
      parentId: form.parentId || undefined,
      organizationCode: form.organizationCode.trim(),
      organizationName: form.organizationName.trim(),
      sortNo: Number(form.sortNo) || 0,
      enabled: Boolean(form.enabled),
    };
  }

  function nextSortNo(parentId?: string) {
    const siblings = treeRows.value.filter((row) => (row.parentId || '') === (parentId || ''));
    const maxSortNo = siblings.reduce((max, row) => Math.max(max, row.sortNo), 0);
    return maxSortNo + 10;
  }

  return {
    activeTab,
    appliedFilters,
    applySearch,
    currentDetail,
    closeDrawer,
    deleteOrganization,
    deleteSelectedOrganization,
    drawerVisible,
    editorMode,
    filterActive,
    filteredTreeRows,
    form,
    initialize,
    organizationMetrics,
    panelLoading,
    parentOptions,
    resetSearch,
    selectOrganization,
    selectedOrganization,
    selectedOrganizationId,
    startCreateChild,
    startCreateRoot,
    structureParentLabel,
    submitForm,
    treeError,
    treeLoading,
    treeRows,
  };
}

type Translate = (key: string, params?: Record<string, unknown>) => string;

function flattenTreeRows(
  nodes: OrganizationTreeNode[],
  t: Translate,
  depth = 0,
  rows: OrganizationTreeRow[] = [],
  parentName?: string,
): OrganizationTreeRow[] {
  // 根节点上级列显示「—」，避免与实体「根组织」混淆
  const resolvedParentName = parentName ?? t('module.iam.organizations.structure.noParentLabel');
  for (const node of nodes) {
    rows.push(createTreeRow(node, depth, resolvedParentName, t));
    flattenTreeRows(node.children || [], t, depth + 1, rows, node.organizationName);
  }
  return rows;
}

function filterTreeRows(
  nodes: OrganizationTreeNode[],
  filters: {
    keyword: string;
    enabled: string;
    level: string;
  },
  t: Translate,
  depth = 0,
  parentName?: string,
): OrganizationTreeRow[] {
  const resolvedParentName = parentName ?? t('module.iam.organizations.structure.noParentLabel');
  const rows: OrganizationTreeRow[] = [];
  for (const node of nodes) {
    const row = createTreeRow(node, depth, resolvedParentName, t);
    const children = filterTreeRows(node.children || [], filters, t, depth + 1, node.organizationName);
    const matchesSelf = matchesOrganizationFilters(row, filters);

    if (!matchesSelf && children.length === 0) {
      continue;
    }

    rows.push({
      ...row,
      children,
      hasChildren: children.length > 0,
    });
  }
  return rows;
}

function createTreeRow(
  node: OrganizationTreeNode,
  depth: number,
  parentName: string,
  t: Translate,
): OrganizationTreeRow {
  return {
    depth,
    enabled: node.enabled,
    organizationCode: node.organizationCode,
    organizationId: node.organizationId,
    organizationName: node.organizationName,
    parentId: node.parentId,
    parentName,
    sortNo: node.sortNo,
    levelLabel: t('module.iam.organizations.structure.levelLabel', { depth: depth + 1 }),
  };
}

function matchesOrganizationFilters(
  row: OrganizationTreeRow,
  filters: {
    keyword: string;
    enabled: string;
    level: string;
  },
) {
  const keyword = filters.keyword.trim().toLowerCase();
  const matchesKeyword =
    !keyword
    || row.organizationName.toLowerCase().includes(keyword)
    || row.organizationCode.toLowerCase().includes(keyword);
  const matchesEnabled =
    filters.enabled === 'all' ||
    (filters.enabled === 'enabled' ? row.enabled : !row.enabled);
  const matchesLevel =
    filters.level === 'all' ||
    (filters.level === '3+' ? row.depth + 1 >= 3 : String(row.depth + 1) === filters.level);

  return matchesKeyword && matchesEnabled && matchesLevel;
}

function collectDescendantIds(nodes: OrganizationTreeNode[], organizationId: string) {
  const descendants = new Set<string>();
  if (!organizationId) {
    return descendants;
  }
  const target = findTreeNode(nodes, organizationId);
  if (!target) {
    return descendants;
  }
  walkTree(target, descendants);
  return descendants;
}

function findTreeNode(nodes: OrganizationTreeNode[], organizationId: string): OrganizationTreeNode | null {
  for (const node of nodes) {
    if (node.organizationId === organizationId) {
      return node;
    }
    const nested = findTreeNode(node.children || [], organizationId);
    if (nested) {
      return nested;
    }
  }
  return null;
}

function walkTree(node: OrganizationTreeNode, descendants: Set<string>) {
  descendants.add(node.organizationId);
  for (const child of node.children || []) {
    walkTree(child, descendants);
  }
}
