<script setup lang="ts">
import type { OrganizationUpsertRequest } from '../../../generated/types';
import type { OrganizationTreeRow } from '../composables/useOrganizationWorkspace';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

defineProps<{
  editorMode: 'edit' | 'create';
  form: OrganizationUpsertRequest;
  selectedOrganization: OrganizationTreeRow | null;
  /** 上级组织展示名（新增子组织时不能用 selected 的 parentName） */
  structureParentLabel: string;
}>();
</script>

<template>
  <section class="console-detail-card">
    <div class="console-detail-card__header">
      <div>
        <h2>{{ t('module.iam.organizations.drawer.tab.structure') }}</h2>
        <p>{{ t('module.iam.organizations.structure.subtitle') }}</p>
      </div>
    </div>

    <div class="console-detail-body">
      <div class="console-two-column-grid">
        <article class="console-subcard">
          <h3>{{ t('module.iam.organizations.column.parent') }}</h3>
          <p data-testid="organization-structure-parent">{{ structureParentLabel }}</p>
        </article>

        <article class="console-subcard">
          <h3>{{ t('module.iam.organizations.structure.current') }}</h3>
          <p>{{ form.parentId ? t('module.iam.organizations.structure.parentActive') : t('module.iam.organizations.structure.root') }}</p>
        </article>

        <article class="console-subcard">
          <h3>{{ t('module.iam.common.enabledState') }}</h3>
          <p>{{ form.enabled ? t('module.iam.organizations.structure.enabled') : t('module.iam.organizations.structure.disabled') }}</p>
        </article>

        <article v-if="editorMode === 'edit'" class="console-subcard">
          <h3>{{ t('module.iam.organizations.structure.deleteEntry') }}</h3>
          <p>{{ t('module.iam.organizations.structure.deleteHint') }}</p>
        </article>
      </div>
    </div>
  </section>
</template>

<style>
@import "../../../shared/detail-form.css";
</style>
