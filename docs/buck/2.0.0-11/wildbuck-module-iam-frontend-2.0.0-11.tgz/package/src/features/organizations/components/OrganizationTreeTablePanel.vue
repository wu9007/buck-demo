<script setup lang="ts">
import { computed } from 'vue';
import { BrickRiskConfirm } from '@wildbuck/core-ui-frontend/patterns';
import type { OrganizationTreeRow } from '../composables/useOrganizationWorkspace';
import { BrickTableActions as IamTableActions } from '@wildbuck/core-ui-frontend/patterns';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

const props = defineProps<{
  rows: OrganizationTreeRow[];
  loading: boolean;
  selectedOrganizationId: string;
  /** 是否处于已应用筛选（用于空态文案） */
  filterActive?: boolean;
  /** 未筛选时的节点总数 */
  totalCount?: number;
}>();

const emit = defineEmits<{
  delete: [organizationId: string];
  open: [organizationId: string];
  createRoot: [];
  createChild: [organizationId: string];
}>();

const visibleCount = computed(() => countRows(props.rows));

const emptyText = computed(() => {
  if (props.loading) {
    return t('module.iam.organizations.tree.loading');
  }
  if (props.filterActive) {
    return t('module.iam.organizations.list.emptyFiltered');
  }
  return t('module.iam.organizations.tree.empty');
});

const headerMeta = computed(() => {
  if (props.filterActive) {
    return t('module.iam.organizations.list.filteredMeta', {
      visible: visibleCount.value,
      total: props.totalCount ?? visibleCount.value,
    });
  }
  return t('module.iam.organizations.list.totalMeta', { total: visibleCount.value });
});

function countRows(rows: OrganizationTreeRow[]): number {
  let total = 0;
  for (const row of rows) {
    total += 1;
    if (row.children?.length) {
      total += countRows(row.children);
    }
  }
  return total;
}

function onRowClick(row: OrganizationTreeRow) {
  emit('open', row.organizationId);
}
</script>

<template>
  <el-card shadow="never" class="iam-list-panel organization-tree-table-panel" data-guide-anchor="list">
    <template #header>
      <div class="iam-list-panel__header">
        <div>
          <h2>{{ t('module.iam.organizations.list.title') }}</h2>
          <p>{{ t('module.iam.organizations.list.subtitle') }}</p>
        </div>
        <span class="iam-list-panel__meta" data-testid="organization-list-meta">{{ headerMeta }}</span>
      </div>
    </template>

    <el-table
      v-if="rows.length > 0 || loading"
      :data="rows"
      row-key="organizationId"
      :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
      :default-expand-all="true"
      :highlight-current-row="true"
      :current-row-key="selectedOrganizationId"
      :empty-text="emptyText"
      v-loading="loading"
      @row-click="onRowClick"
    >
      <el-table-column :label="t('module.iam.organizations.detail.name')" min-width="220">
        <template #default="{ row }">
          <div class="iam-list-name" :style="{ paddingLeft: `${Math.max(0, row.depth) * 12}px` }">
            <div class="iam-list-name__copy">
              <!-- 列表主列只展示组织名称；编码见独立列 -->
              <strong>{{ row.organizationName }}</strong>
            </div>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="organizationCode" :label="t('module.iam.organizations.column.code')" min-width="140" />
      <el-table-column prop="parentName" :label="t('module.iam.organizations.column.parent')" min-width="160" />
      <el-table-column prop="levelLabel" :label="t('module.iam.organizations.filter.level')" width="110" />
      <el-table-column prop="sortNo" :label="t('module.iam.common.sortNo')" width="90" />
      <el-table-column :label="t('module.iam.common.status')" width="100">
        <template #default="{ row }">
          <el-tag :type="row.enabled ? 'success' : 'warning'" effect="plain">
            {{ row.enabled ? t('module.iam.common.enabled') : t('module.iam.common.disabled') }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column :label="t('module.iam.common.actions')" width="280" fixed="right">
        <template #default="{ row }">
          <IamTableActions @click.stop>
            <el-button
              link
              type="primary"
              data-testid="organization-open-detail"
              @click.stop="$emit('open', row.organizationId)"
            >{{ t('module.iam.common.viewDetail') }}</el-button>
            <el-button
              link
              data-testid="organization-create-child"
              @click.stop="$emit('createChild', row.organizationId)"
            >{{ t('module.iam.common.createChild') }}</el-button>
            <BrickRiskConfirm
              :title="t('module.iam.organizations.delete.title')"
              :description="t('module.iam.organizations.delete.description')"
              :impact="[t('module.iam.organizations.delete.impact1'), t('module.iam.organizations.delete.impact2')]"
              :confirm-text="t('module.iam.organizations.delete.confirm')"
              @confirm="$emit('delete', row.organizationId)"
            >
              <!-- 必须调用 slot 的 open；@click.stop  alone 会拦住 trigger 父级 openConfirm -->
              <template #trigger="{ open }">
                <el-button
                  link
                  type="danger"
                  data-testid="organization-delete"
                  @click.stop="open"
                >{{ t('module.iam.common.delete') }}</el-button>
              </template>
            </BrickRiskConfirm>
          </IamTableActions>
        </template>
      </el-table-column>
    </el-table>

    <p v-else class="iam-list-empty" data-testid="organization-list-empty">{{ emptyText }}</p>
  </el-card>
</template>

<style scoped>
@import "@wildbuck/core-ui-frontend/list-panel.css";
</style>
