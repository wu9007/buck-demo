<script setup lang="ts">
import { computed } from 'vue';
import { BrickConsoleDrawer } from '@wildbuck/core-ui-frontend/shell';
import type { OrganizationDetail, OrganizationUpsertRequest } from '../../../generated/types';
import type { OrganizationOption, OrganizationTreeRow } from '../composables/useOrganizationWorkspace';
import OrganizationDetailCard from './OrganizationDetailCard.vue';
import OrganizationStructureCard from './OrganizationStructureCard.vue';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

const props = defineProps<{
  visible: boolean;
  activeTab: string;
  currentDetail: OrganizationDetail | null;
  editorMode: 'edit' | 'create';
  form: OrganizationUpsertRequest;
  parentOptions: OrganizationOption[];
  selectedOrganization: OrganizationTreeRow | null;
  structureParentLabel: string;
  panelLoading: boolean;
}>();

defineEmits<{
  close: [];
  save: [];
  'update:activeTab': [value: string];
}>();

const drawerEyebrow = computed(() => (
  props.editorMode === 'create'
    ? t('module.iam.organizations.drawer.createTitle')
    : t('module.iam.organizations.drawer.detailTitle')
));

const drawerTitle = computed(() => (
  props.form.organizationName
  || props.selectedOrganization?.organizationName
  || t('module.iam.organizations.drawer.unnamed')
));

const drawerDescription = computed(() => {
  const code = props.form.organizationCode || t('module.iam.organizations.drawer.noCode');
  const kind = props.form.parentId
    ? t('module.iam.organizations.drawer.childKind')
    : t('module.iam.organizations.drawer.rootKind');
  return t('module.iam.organizations.drawer.meta', { code, kind });
});
</script>

<template>
  <BrickConsoleDrawer
    :model-value="visible"
    size="52%"
    :destroy-on-close="false"
    class="organization-drawer"
    :eyebrow="drawerEyebrow"
    :title="drawerTitle"
    :description="drawerDescription"
    @close="$emit('close')"
  >
    <p v-if="panelLoading" class="drawer-state-text" data-testid="organization-drawer-loading">
      {{ t('module.iam.organizations.drawer.loading') }}
    </p>

    <el-tabs
      v-else
      :model-value="activeTab"
      class="organization-drawer__tabs"
      data-testid="organization-drawer-tabs"
      @update:model-value="$emit('update:activeTab', $event)"
    >
      <el-tab-pane :label="t('module.iam.organizations.drawer.tab.detail')" name="detail">
        <OrganizationDetailCard
          :current-detail="currentDetail"
          :editor-mode="editorMode"
          :form="form"
          :parent-options="parentOptions"
          :selected-organization="selectedOrganization"
          @save="$emit('save')"
        />
      </el-tab-pane>
      <el-tab-pane :label="t('module.iam.organizations.drawer.tab.structure')" name="structure">
        <OrganizationStructureCard
          :editor-mode="editorMode"
          :form="form"
          :selected-organization="selectedOrganization"
          :structure-parent-label="structureParentLabel"
        />
      </el-tab-pane>
    </el-tabs>
  </BrickConsoleDrawer>
</template>

<style scoped>
.organization-drawer__tabs :deep(.el-tabs__header) {
  margin-bottom: 20px;
}

.organization-drawer__tabs :deep(.el-tab-pane) {
  display: grid;
  gap: 16px;
}

.drawer-state-text {
  margin: 0;
  padding: var(--console-drawer-padding, 18px) 4px;
  color: var(--console-text, #4a5a70);
}
</style>
