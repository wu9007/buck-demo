<script setup lang="ts">
import { computed, watch } from 'vue';
import { BrickFilterToolbar, useBrickFilterDraft } from '@wildbuck/core-ui-frontend/patterns';
import {
  buildEnabledStateFilterOptions,
  buildFunctionPointFilterOptions,
} from '../../../shared/filter-options';
import type { FunctionPointSelectionOption } from '../composables/useMenuWorkspace';
import { useIamI18n } from '../../management-i18n.js';

export type MenuListFilters = {
  keyword: string;
  functionPointId: string;
  enabled: string;
};

const props = defineProps<{
  modelValue: MenuListFilters;
  functionPointOptions: FunctionPointSelectionOption[];
}>();

const emit = defineEmits<{
  'update:modelValue': [MenuListFilters];
  search: [MenuListFilters];
  reset: [MenuListFilters];
}>();

const { t } = useIamI18n();
const enabledOptions = computed(() => buildEnabledStateFilterOptions(t));
const functionPointFilters = computed(() => buildFunctionPointFilterOptions(t));

const defaultFilters = (): MenuListFilters => ({
  keyword: '',
  functionPointId: 'all',
  enabled: 'all',
});

const { draft, resetDraft, replaceDraft, snapshot } = useBrickFilterDraft(defaultFilters);

watch(
  () => props.modelValue,
  (value) => {
    if (!value) {
      return;
    }
    const current = snapshot();
    if (
      current.keyword !== value.keyword
      || current.functionPointId !== value.functionPointId
      || current.enabled !== value.enabled
    ) {
      replaceDraft({
        keyword: value.keyword ?? '',
        functionPointId: value.functionPointId ?? 'all',
        enabled: value.enabled ?? 'all',
      });
    }
  },
  { deep: true, immediate: true },
);

function onSearch() {
  const next = snapshot();
  emit('update:modelValue', next);
  emit('search', next);
}

function onReset() {
  const next = resetDraft();
  emit('update:modelValue', next);
  emit('reset', next);
}
</script>

<template>
  <BrickFilterToolbar data-guide-anchor="filters" field-min-width="180px" data-testid="menu-filter-toolbar">
    <el-input
      v-model="draft.keyword"
      :placeholder="t('module.iam.menus.filter.keyword')"
      clearable
      data-testid="menu-filter-keyword"
      @keyup.enter="onSearch"
    />

    <el-select
      v-model="draft.functionPointId"
      :placeholder="t('module.iam.menus.column.function')"
      data-testid="menu-filter-function"
    >
      <el-option
        v-for="option in functionPointFilters"
        :key="option.value"
        :label="option.label"
        :value="option.value"
      />
      <el-option
        v-for="option in functionPointOptions"
        :key="option.value"
        :label="option.label"
        :value="option.value"
        :disabled="option.disabled"
      />
    </el-select>

    <el-select
      v-model="draft.enabled"
      :placeholder="t('module.iam.common.enabledState')"
      data-testid="menu-filter-enabled"
    >
      <el-option
        v-for="option in enabledOptions"
        :key="option.value"
        :label="option.label"
        :value="option.value"
      />
    </el-select>

    <template #actions>
      <el-button native-type="button" data-testid="menu-filter-reset" @click.prevent="onReset">
        {{ t('module.iam.common.resetFilters') }}
      </el-button>
      <el-button type="primary" native-type="button" data-testid="menu-filter-search" @click.prevent="onSearch">
        {{ t('module.iam.menus.filter.search') }}
      </el-button>
    </template>
  </BrickFilterToolbar>
</template>
