import { menuPermissions } from './permission/index.js';
import { menuRoutes } from './routes/index.js';

export const menusFeature = {
  featureKey: 'menus',
  routes: menuRoutes,
  permissions: menuPermissions,
};
