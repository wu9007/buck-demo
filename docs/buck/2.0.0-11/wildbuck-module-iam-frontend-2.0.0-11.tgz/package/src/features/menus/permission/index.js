export const menuPermissions = {
  list: 'iam:menu:list',
  edit: 'iam:menu:edit',
};
