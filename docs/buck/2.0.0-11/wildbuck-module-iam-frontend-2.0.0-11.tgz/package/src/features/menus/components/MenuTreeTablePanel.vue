<script setup lang="ts">
import { computed } from 'vue';
import type { MenuTreeRow } from '../composables/useMenuWorkspace';
import { BrickTableActions as IamTableActions } from '@wildbuck/core-ui-frontend/patterns';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

const props = defineProps<{
  rows: MenuTreeRow[];
  loading: boolean;
  selectedMenuId: string;
  filterActive?: boolean;
  totalCount?: number;
}>();

const emit = defineEmits<{
  open: [menuId: string];
  createRoot: [];
  createChild: [menuId: string];
}>();

const visibleCount = computed(() => countRows(props.rows));

const emptyText = computed(() => {
  if (props.loading) {
    return t('module.iam.menus.tree.loading');
  }
  if (props.filterActive) {
    return t('module.iam.menus.list.emptyFiltered');
  }
  return t('module.iam.menus.tree.empty');
});

const headerMeta = computed(() => {
  if (props.filterActive) {
    return t('module.iam.menus.list.filteredMeta', {
      visible: visibleCount.value,
      total: props.totalCount ?? visibleCount.value,
    });
  }
  return t('module.iam.menus.list.totalMeta', { total: visibleCount.value });
});

function countRows(rows: MenuTreeRow[]): number {
  let total = 0;
  for (const row of rows) {
    total += 1;
    if (row.children?.length) {
      total += countRows(row.children);
    }
  }
  return total;
}

function onRowClick(row: MenuTreeRow) {
  emit('open', row.menuId);
}
</script>

<template>
  <el-card shadow="never" class="iam-list-panel menu-tree-table-panel" data-guide-anchor="list">
    <template #header>
      <div class="iam-list-panel__header">
        <div>
          <h2>{{ t('module.iam.menus.list.title') }}</h2>
          <p>{{ t('module.iam.menus.list.subtitle') }}</p>
        </div>
        <span class="iam-list-panel__meta" data-testid="menu-list-meta">{{ headerMeta }}</span>
      </div>
    </template>

    <el-table
      v-if="rows.length > 0 || loading"
      :data="rows"
      row-key="menuId"
      :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
      :default-expand-all="true"
      :highlight-current-row="true"
      :current-row-key="selectedMenuId"
      :empty-text="emptyText"
      v-loading="loading"
      @row-click="onRowClick"
    >
      <el-table-column :label="t('module.iam.menus.detail.nameLabel')" min-width="240">
        <template #default="{ row }">
          <div class="iam-list-name" :style="{ paddingLeft: `${Math.max(0, row.depth) * 12}px` }">
            <div class="iam-list-name__copy">
              <!-- 列表只展示菜单名称；menuCode 为内部编码，不向操作者暴露 -->
              <strong>{{ row.menuName }}</strong>
            </div>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="functionPointName" :label="t('module.iam.menus.column.function')" min-width="160" />
      <el-table-column prop="parentName" :label="t('module.iam.menus.column.parent')" min-width="140" />
      <el-table-column prop="sortNo" :label="t('module.iam.common.sortNo')" width="90" />
      <el-table-column :label="t('module.iam.common.status')" width="100">
        <template #default="{ row }">
          <el-tag :type="row.enabled ? 'success' : 'warning'" effect="plain">
            {{ row.enabled ? t('module.iam.common.enabled') : t('module.iam.common.disabled') }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column :label="t('module.iam.common.actions')" width="220" fixed="right">
        <template #default="{ row }">
          <IamTableActions @click.stop>
            <el-button
              link
              type="primary"
              data-testid="menu-open-detail"
              @click.stop="$emit('open', row.menuId)"
            >{{ t('module.iam.common.viewDetail') }}</el-button>
            <el-button
              link
              data-testid="menu-create-child"
              @click.stop="$emit('createChild', row.menuId)"
            >{{ t('module.iam.common.createChild') }}</el-button>
          </IamTableActions>
        </template>
      </el-table-column>
    </el-table>

    <p v-else class="iam-list-empty" data-testid="menu-list-empty">{{ emptyText }}</p>
  </el-card>
</template>

<style scoped>
@import "@wildbuck/core-ui-frontend/list-panel.css";
</style>
