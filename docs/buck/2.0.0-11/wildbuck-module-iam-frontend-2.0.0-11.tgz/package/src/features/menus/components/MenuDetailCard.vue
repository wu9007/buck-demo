<script setup lang="ts">
import { ref } from 'vue';
import { validateBrickRequiredFields } from '@wildbuck/core-ui-frontend';
import { BrickImageUploadField } from '@wildbuck/core-ui-frontend/fields';
import { BrickActionBar, BrickRiskConfirm } from '@wildbuck/core-ui-frontend/patterns';
import type { MenuDetail, MenuUpsertRequest } from '../../../generated/types';
import type { FunctionPointSelectionOption, MenuOption, MenuTreeRow } from '../composables/useMenuWorkspace';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

const props = defineProps<{
  functionPointOptions: FunctionPointSelectionOption[];
  iconPreviewUrl: string;
  iconUploading: boolean;
  currentDetail: MenuDetail | null;
  editorMode: 'edit' | 'create';
  form: MenuUpsertRequest;
  parentOptions: MenuOption[];
  selectedMenu: MenuTreeRow | null;
}>();

const menuNameInputRef = ref();
const sortNoInputRef = ref();

const emit = defineEmits<{
  clearIcon: [];
  delete: [];
  save: [];
  uploadIcon: [file: File];
}>();

function resolveIconFallback() {
  const source = props.form.menuName?.trim() || props.selectedMenu?.menuName?.trim() || t('module.iam.menus.detail.menuFallback');
  const compact = source.replace(/\s+/g, '');
  return compact.length <= 2 ? compact.toUpperCase() : compact.slice(0, 2).toUpperCase();
}

function resolveIconHint() {
  return props.form.icon?.trim() || props.currentDetail?.icon?.trim() || t('module.iam.menus.detail.noDefaultIcon');
}

function uploadIcon(file: File) {
  emit('uploadIcon', file);
}

function handleSubmit() {
  const result = validateBrickRequiredFields([
    {
      label: t('module.iam.menus.detail.nameLabel'),
      value: props.form.menuName,
      focusTarget: menuNameInputRef.value,
    },
    {
      label: t('module.iam.common.sortNo'),
      value: props.form.sortNo,
      focusTarget: sortNoInputRef.value,
    },
  ]);
  if (!result.ok) {
    return;
  }
  emit('save');
}
</script>

<template>
  <section class="console-detail-card">
    <div class="console-detail-card__header">
      <div>
        <h2>{{ editorMode === 'create' ? t('module.iam.menus.page.create') : t('module.iam.menus.drawer.detailTitle') }}</h2>
        <p>{{ editorMode === 'create' ? t('module.iam.menus.page.create') : currentDetail?.menuId || selectedMenu?.menuId }}</p>
      </div>
      <span class="console-summary-chip">
        {{ form.parentId ? t('module.iam.menus.detail.attachParent') : t('module.iam.menus.stats.roots') }}
      </span>
    </div>

    <el-form class="console-detail-form brick-required-form" label-position="top" @submit.prevent="handleSubmit">
      <el-form-item :label="t('module.iam.menus.detail.parentOptional')">
        <el-select v-model="form.parentId" clearable :placeholder="t('module.iam.menus.detail.noParent')">
          <el-option
            v-for="option in parentOptions"
            :key="option.value"
            :label="option.label"
            :value="option.value"
          />
        </el-select>
      </el-form-item>

      <el-form-item :label="t('module.iam.menus.detail.functionOptional')">
        <el-select v-model="form.functionPointId" clearable :placeholder="t('module.iam.menus.detail.noFunction')">
          <el-option
            v-for="option in functionPointOptions"
            :key="option.value"
            :label="`${option.label}${option.disabled ? t('module.iam.menus.detail.disabledSuffix') : ''}`"
            :value="option.value"
            :disabled="option.disabled"
          />
        </el-select>
        <small class="console-field-hint">{{ t('module.iam.menus.detail.functionHint') }}</small>
      </el-form-item>

      <el-form-item :label="t('module.iam.menus.detail.nameRequired')" required>
        <el-input ref="menuNameInputRef" v-model.trim="form.menuName" :placeholder="t('module.iam.menus.detail.namePlaceholder')" />
      </el-form-item>

      <el-form-item :label="t('module.iam.common.sortNoRequired')" required>
        <el-input ref="sortNoInputRef" v-model.number="form.sortNo" type="number" min="0" />
      </el-form-item>

      <section class="console-status-field">
        <div class="console-status-field__copy">
          <span class="console-required-label">{{ t('module.iam.common.enabledRequired') }}</span>
          <small>{{ t('module.iam.menus.detail.enabledHint') }}</small>
        </div>
        <div class="console-status-toggle" role="radiogroup" :aria-label="t('module.iam.common.enabledState')">
          <button
            type="button"
            class="console-status-toggle__option"
            :class="{ active: form.enabled }"
            :aria-pressed="form.enabled"
            @click="form.enabled = true"
          >{{ t('module.iam.common.enabled') }}</button>
          <button
            type="button"
            class="console-status-toggle__option"
            :class="{ active: !form.enabled }"
            :aria-pressed="!form.enabled"
            @click="form.enabled = false"
          >{{ t('module.iam.common.disabled') }}</button>
        </div>
      </section>

      <BrickImageUploadField
        class="console-detail-form__full"
        :label="t('module.iam.menus.detail.iconOptional')"
        :description="t('module.iam.menus.detail.iconHint')"
        :preview-url="iconPreviewUrl"
        :preview-alt="t('module.iam.menus.detail.iconAlt', { name: form.menuName || selectedMenu?.menuName || t('module.iam.menus.detail.menuFallback') })"
        :fallback-text="resolveIconFallback()"
        :uploading="iconUploading"
        :clear-disabled="!form.iconResourceId"
        :upload-text="t('module.iam.menus.detail.uploadIcon')"
        :clear-text="t('module.iam.menus.detail.clearIcon')"
        :resource-hint="t('module.iam.menus.detail.iconIdHint', { hint: resolveIconHint() })"
        @upload="uploadIcon"
        @clear="$emit('clearIcon')"
      />

      <BrickActionBar class="console-detail-form__full">
        <template #primary>
          <el-button type="primary" native-type="submit">{{ t('module.iam.menus.detail.save') }}</el-button>
        </template>
        <template #danger>
          <BrickRiskConfirm
            v-if="editorMode === 'edit'"
            :title="t('module.iam.menus.detail.deleteTitle')"
            :description="t('module.iam.menus.detail.deleteDescription')"
            :impact="[t('module.iam.menus.detail.deleteImpact1'), t('module.iam.menus.detail.deleteImpact2')]"
            :confirm-text="t('module.iam.menus.detail.deleteTitle')"
            @confirm="$emit('delete')"
          >
            <template #trigger>
              <el-button type="danger" plain>{{ t('module.iam.menus.detail.delete') }}</el-button>
            </template>
          </BrickRiskConfirm>
        </template>
      </BrickActionBar>
    </el-form>
  </section>
</template>

<style>
@import "../../../shared/detail-form.css";
</style>
