import { computed, onScopeDispose, reactive, ref } from 'vue';
import { isBrickSessionError } from '@wildbuck/core-api-frontend';
import { showBrickStatus } from '@wildbuck/core-ui-frontend';
import { iamErrors } from '../../../generated/errors';
import type { FunctionPointOption, MenuDetail, MenuTreeNode, MenuUpsertRequest } from '../../../generated/types';
import {
  loadMenuDetail,
  loadMenuTree,
  loadRegisteredMenuFunctionOptions,
  removeMenu,
  saveExistingMenu,
  saveNewMenu,
} from '../api/menu';
import { resolveMenuErrorMessage } from '../lib/menu-errors';
import { loadImageResourceBlob, uploadImageResource } from '../../../shared/file-resource';
import { useIamI18n } from '../../management-i18n.js';
import {
  iamUsageTracker,
  resolveIamStatusAction,
} from '../../../usage-events';

export interface MenuTreeRow {
  children?: MenuTreeRow[];
  depth: number;
  enabled: boolean;
  functionPointId?: string;
  functionPointName: string;
  hasChildren?: boolean;
  menuCategory?: string;
  menuCode: string;
  iconResourceId?: string;
  menuId: string;
  menuName: string;
  menuType: number;
  parentId?: string;
  parentName: string;
  routePath?: string;
  sortNo: number;
}

export interface MenuOption {
  label: string;
  value: string;
}

export interface FunctionPointSelectionOption {
  disabled: boolean;
  label: string;
  value: string;
}

type EditorMode = 'edit' | 'create';

export function useMenuWorkspace() {
  const { t } = useIamI18n();
  const menus = ref<MenuTreeNode[]>([]);
  const selectedMenuId = ref('');
  const treeLoading = ref(true);
  const panelLoading = ref(false);
  const drawerVisible = ref(false);
  const treeError = ref('');
  const editorMode = ref<EditorMode>('edit');
  const currentDetail = ref<MenuDetail | null>(null);
  const functionPoints = ref<FunctionPointOption[]>([]);
  /** 已应用筛选；输入草稿在 MenuFilterToolbar 内 */
  const appliedFilters = reactive({
    keyword: '',
    functionPointId: 'all',
    enabled: 'all',
  });

  const form = reactive<MenuUpsertRequest>({
    functionPointId: undefined,
    parentId: undefined,
    menuCode: '',
    menuName: '',
    menuType: 0,
    menuCategory: '',
    routePath: '',
    terminalType: '',
    icon: '',
    iconResourceId: undefined,
    sortNo: 10,
    enabled: true,
  });
  const iconPreviewUrl = ref('');
  const iconUploading = ref(false);
  const menuIconUrls = ref<Record<string, string>>({});
  const iconObjectUrlLoads = new Map<string, Promise<string>>();
  let localIconPreviewUrl = '';

  const functionNamesById = computed(() => new Map(functionPoints.value.map((item) => [item.functionPointId, item.functionPointName])));
  const treeRows = computed(() => flattenTreeRows(menus.value, functionNamesById.value));
  const filteredTreeRows = computed(() => filterTreeRows(menus.value, functionNamesById.value, appliedFilters));
  /** 是否已应用非默认筛选（列表 meta / 空态） */
  const filterActive = computed(() => (
    Boolean(appliedFilters.keyword.trim())
    || appliedFilters.functionPointId !== 'all'
    || appliedFilters.enabled !== 'all'
  ));
  const menuMetrics = computed(() => ({
    total: treeRows.value.length,
    enabled: treeRows.value.filter((row) => row.enabled).length,
    roots: treeRows.value.filter((row) => !row.parentId).length,
  }));
  const selectedMenu = computed(() => treeRows.value.find((row) => row.menuId === selectedMenuId.value) ?? null);
  const parentOptions = computed(() => {
    const editingMenuId = currentDetail.value?.menuId || selectedMenuId.value;
    const excludedIds = editorMode.value === 'edit' ? collectDescendantIds(menus.value, editingMenuId) : new Set<string>();
    return treeRows.value
      .filter((row) => !excludedIds.has(row.menuId))
      .map((row) => ({
        label: `${'　'.repeat(row.depth)}${row.menuName}`,
        value: row.menuId,
      }));
  });
  const functionPointOptions = computed<FunctionPointSelectionOption[]>(() =>
    functionPoints.value.map((functionPoint) => ({
      disabled: !functionPoint.enabled,
      label: `${functionPoint.functionPointName} (${functionPoint.functionPointCode})`,
      value: functionPoint.functionPointId,
    })),
  );

  async function initialize() {
    const routeIntent = consumeManagementRouteIntent('iam.menus.list');
    const preferredMenuId = routeIntent?.menuId;
    await Promise.all([reloadMenus(), reloadFunctionPoints()]);
    if (preferredMenuId && treeRows.value.some((row) => row.menuId === preferredMenuId)) {
      await selectMenu(preferredMenuId);
    } else if (!selectedMenuId.value && treeRows.value.length > 0) {
      selectedMenuId.value = treeRows.value[0].menuId;
    }
  }

  async function reloadFunctionPoints() {
    try {
      functionPoints.value = await loadRegisteredMenuFunctionOptions();
    } catch (error) {
      if (isBrickSessionError(error)) {
        return;
      }
      functionPoints.value = [];
    }
  }

  async function reloadMenus(preferredMenuId?: string) {
    treeLoading.value = true;
    treeError.value = '';
    try {
      menus.value = await loadMenuTree();
      const rows = flattenTreeRows(menus.value, functionNamesById.value);
      const nextSelection =
        preferredMenuId && rows.some((row) => row.menuId === preferredMenuId)
          ? preferredMenuId
          : selectedMenuId.value && rows.some((row) => row.menuId === selectedMenuId.value)
            ? selectedMenuId.value
            : rows[0]?.menuId || '';
      selectedMenuId.value = nextSelection;
      // List table does not render uploaded icons; only detail drawer needs iconPreviewUrl.
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      menus.value = [];
      selectedMenuId.value = '';
      treeError.value = `${iamErrors.IAM_MENU_NOT_FOUND.message}，${iamErrors.IAM_MENU_NOT_FOUND.recovery}`;
      return false;
    } finally {
      treeLoading.value = false;
    }
  }

  function applySearch(next?: {
    keyword: string;
    functionPointId: string;
    enabled: string;
  }) {
    if (next) {
      appliedFilters.keyword = next.keyword ?? '';
      appliedFilters.functionPointId = next.functionPointId ?? 'all';
      appliedFilters.enabled = next.enabled ?? 'all';
    }
    void iamUsageTracker.trackActionResult('menu', 'search', 'SUCCESS');
  }

  function resetSearch(next?: {
    keyword: string;
    functionPointId: string;
    enabled: string;
  }) {
    appliedFilters.keyword = next?.keyword ?? '';
    appliedFilters.functionPointId = next?.functionPointId ?? 'all';
    appliedFilters.enabled = next?.enabled ?? 'all';
    void iamUsageTracker.trackActionResult('menu', 'search', 'SUCCESS');
  }

  async function selectMenu(menuId: string, options: { trackEnter?: boolean } = {}) {
    if (!menuId) {
      return false;
    }
    const shouldTrackEnter = options.trackEnter ?? true;
    selectedMenuId.value = menuId;
    editorMode.value = 'edit';
    panelLoading.value = true;
    drawerVisible.value = true;
    try {
      const detail = await loadMenuDetail(menuId);
      currentDetail.value = detail;
      fillForm(detail);
      await syncIconPreview(detail.iconResourceId);
      if (shouldTrackEnter) {
        void iamUsageTracker.trackOpen('menu', 'open-detail');
      }
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      showBrickStatus(`${iamErrors.IAM_MENU_NOT_FOUND.message}，${iamErrors.IAM_MENU_NOT_FOUND.recovery}`, 'error');
      if (shouldTrackEnter) {
        void iamUsageTracker.trackOpen('menu', 'open-detail', 'FAILURE');
      }
      return false;
    } finally {
      panelLoading.value = false;
    }
  }

  function startCreateRoot() {
    editorMode.value = 'create';
    selectedMenuId.value = '';
    currentDetail.value = null;
    drawerVisible.value = true;
    fillForm({
      menuId: '',
      functionPointId: undefined,
      parentId: undefined,
      menuCode: '',
      menuName: '',
      menuType: 0,
      menuCategory: '',
      routePath: '',
      terminalType: '',
      icon: '',
      iconResourceId: undefined,
      sortNo: nextSortNo(undefined),
      enabled: true,
    });
    void iamUsageTracker.trackOpen('menu', 'open-create');
  }

  function startCreateChild(menuId?: string) {
    const parentId = menuId || selectedMenuId.value || undefined;
    const parent = parentId ? treeRows.value.find((row) => row.menuId === parentId) ?? null : null;
    editorMode.value = 'create';
    selectedMenuId.value = parentId || '';
    currentDetail.value = null;
    drawerVisible.value = true;
    fillForm({
      menuId: '',
      functionPointId: parent?.functionPointId || currentDetail.value?.functionPointId || undefined,
      parentId,
      menuCode: '',
      menuName: '',
      menuType: 0,
      menuCategory: '',
      routePath: '',
      terminalType: '',
      icon: '',
      iconResourceId: undefined,
      sortNo: nextSortNo(parentId),
      enabled: true,
    });
    void iamUsageTracker.trackOpen('menu', 'open-create');
  }

  async function submitForm() {
    const isCreating = editorMode.value === 'create';
    const actionCode = isCreating
      ? 'create'
      : resolveIamStatusAction(currentDetail.value?.enabled, Boolean(form.enabled));
    const editingMenuId = currentDetail.value?.menuId || selectedMenuId.value;
    try {
      const payload = normalizeForm();
      const detail =
        isCreating
          ? await saveNewMenu(payload)
          : await saveExistingMenu(editingMenuId, payload);
      await reloadMenus(detail.menuId);
      await selectMenu(detail.menuId, { trackEnter: false });
      showBrickStatus(t('module.iam.menus.status.saved', { name: detail.menuName }), 'success');
      void iamUsageTracker.trackActionResult('menu', actionCode, 'SUCCESS');
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      showBrickStatus(resolveMenuErrorMessage(error), 'error');
      void iamUsageTracker.trackActionResult('menu', actionCode, 'FAILURE');
      return false;
    }
  }

  async function deleteSelectedMenu() {
    const editingMenuId = currentDetail.value?.menuId || selectedMenuId.value;
    if (editorMode.value !== 'edit' || !editingMenuId) {
      return false;
    }
    try {
      const menuName = currentDetail.value?.menuName || selectedMenu.value?.menuName || editingMenuId;
      await removeMenu(editingMenuId);
      currentDetail.value = null;
      selectedMenuId.value = '';
      drawerVisible.value = false;
      await reloadMenus();
      showBrickStatus(t('module.iam.menus.status.deleted', { name: menuName }), 'success');
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      showBrickStatus(resolveMenuErrorMessage(error), 'error');
      return false;
    }
  }

  function closeDrawer() {
    drawerVisible.value = false;
  }

  async function uploadMenuIcon(file: File) {
    iconUploading.value = true;
    try {
      const uploaded = await uploadImageResource(file, 'MENU_ICON');
      form.iconResourceId = uploaded.resourceId;
      replaceLocalIconPreview(window.URL.createObjectURL(file));
      showBrickStatus(t('module.iam.menus.status.iconUploaded'), 'success');
    } catch (error) {
      if (isBrickSessionError(error)) {
        return;
      }
      showBrickStatus(t('module.iam.menus.status.iconUploadFailed'), 'error');
    } finally {
      iconUploading.value = false;
    }
  }

  function clearMenuIcon() {
    form.iconResourceId = undefined;
    releaseLocalIconPreview();
    iconPreviewUrl.value = '';
  }

  function fillForm(detail: Pick<MenuDetail, 'functionPointId' | 'parentId' | 'menuCode' | 'menuName' | 'menuType' | 'menuCategory' | 'routePath' | 'terminalType' | 'icon' | 'iconResourceId' | 'sortNo' | 'enabled'>) {
    form.functionPointId = detail.functionPointId || undefined;
    form.parentId = detail.parentId || undefined;
    form.menuCode = detail.menuCode;
    form.menuName = detail.menuName;
    form.menuType = detail.menuType;
    form.menuCategory = detail.menuCategory || '';
    form.routePath = detail.routePath || '';
    form.terminalType = detail.terminalType || '';
    form.icon = detail.icon || '';
    form.iconResourceId = detail.iconResourceId || undefined;
    form.sortNo = detail.sortNo;
    form.enabled = detail.enabled;
  }

  function normalizeForm(): MenuUpsertRequest {
    // menuCode 为内部键：管理端不采集；空则不提交，由后端从功能目录推导或自动生成。
    const menuCode = form.menuCode?.trim();
    return {
      functionPointId: form.functionPointId?.trim() || undefined,
      parentId: form.parentId || undefined,
      ...(menuCode ? { menuCode } : {}),
      menuName: form.menuName.trim(),
      menuType: form.menuType,
      menuCategory: form.menuCategory?.trim() || undefined,
      routePath: form.routePath?.trim() || undefined,
      terminalType: form.terminalType?.trim() || undefined,
      icon: form.icon?.trim() || undefined,
      iconResourceId: form.iconResourceId?.trim() || undefined,
      sortNo: Number(form.sortNo) || 0,
      enabled: Boolean(form.enabled),
    };
  }

  function nextSortNo(parentId?: string) {
    const siblings = treeRows.value.filter((row) => (row.parentId || '') === (parentId || ''));
    const maxSortNo = siblings.reduce((max, row) => Math.max(max, row.sortNo), 0);
    return maxSortNo + 10;
  }

  async function createMenuIconObjectUrl(resourceId: string): Promise<string> {
    try {
      const blob = await loadImageResourceBlob(resourceId);
      return window.URL.createObjectURL(blob);
    } catch {
      // Missing blob (404 / disabled): detail preview falls back to empty, no throw.
      return '';
    }
  }

  async function syncIconPreview(iconResourceId?: string) {
    if (!iconResourceId) {
      releaseLocalIconPreview();
      iconPreviewUrl.value = '';
      return;
    }
    releaseLocalIconPreview();
    iconPreviewUrl.value = await ensureMenuIconUrl(iconResourceId);
  }

  async function ensureMenuIconUrl(resourceId: string): Promise<string> {
    // Cache hits include empty string so broken MENU_ICON blobs are not re-fetched.
    if (Object.prototype.hasOwnProperty.call(menuIconUrls.value, resourceId)) {
      return menuIconUrls.value[resourceId] || '';
    }
    const pending = iconObjectUrlLoads.get(resourceId);
    if (pending) {
      return pending;
    }
    const loading = createMenuIconObjectUrl(resourceId).then((url) => {
      menuIconUrls.value = {
        ...menuIconUrls.value,
        [resourceId]: url,
      };
      iconObjectUrlLoads.delete(resourceId);
      return url;
    });
    iconObjectUrlLoads.set(resourceId, loading);
    return loading;
  }

  function replaceLocalIconPreview(url: string) {
    releaseLocalIconPreview();
    localIconPreviewUrl = url;
    iconPreviewUrl.value = url;
  }

  function releaseLocalIconPreview() {
    if (!localIconPreviewUrl) {
      return;
    }
    window.URL.revokeObjectURL(localIconPreviewUrl);
    if (iconPreviewUrl.value === localIconPreviewUrl) {
      iconPreviewUrl.value = '';
    }
    localIconPreviewUrl = '';
  }

  onScopeDispose(() => {
    releaseLocalIconPreview();
    for (const url of Object.values(menuIconUrls.value)) {
      if (url) {
        window.URL.revokeObjectURL(url);
      }
    }
    menuIconUrls.value = {};
  });

  return {
    closeDrawer,
    clearMenuIcon,
    currentDetail,
    deleteSelectedMenu,
    drawerVisible,
    editorMode,
    appliedFilters,
    applySearch,
    filterActive,
    filteredTreeRows,
    form,
    functionPointOptions,
    initialize,
    iconPreviewUrl,
    iconUploading,
    menuMetrics,
    menuIconUrls,
    panelLoading,
    parentOptions,
    resetSearch,
    selectMenu,
    selectedMenu,
    selectedMenuId,
    startCreateChild,
    startCreateRoot,
    submitForm,
    treeError,
    treeLoading,
    treeRows,
    uploadMenuIcon,
  };
}

function flattenTreeRows(
  nodes: MenuTreeNode[],
  functionNamesById: Map<string, string>,
  depth = 0,
  rows: MenuTreeRow[] = [],
  parentName = '—',
): MenuTreeRow[] {
  for (const node of nodes) {
    rows.push(createTreeRow(node, functionNamesById, depth, parentName));
    flattenTreeRows(node.children || [], functionNamesById, depth + 1, rows, node.menuName);
  }
  return rows;
}

function filterTreeRows(
  nodes: MenuTreeNode[],
  functionNamesById: Map<string, string>,
  filters: {
    keyword: string;
    functionPointId: string;
    enabled: string;
  },
  depth = 0,
  parentName = '—',
): MenuTreeRow[] {
  const rows: MenuTreeRow[] = [];
  for (const node of nodes) {
    const row = createTreeRow(node, functionNamesById, depth, parentName);
    const children = filterTreeRows(node.children || [], functionNamesById, filters, depth + 1, node.menuName);
    const matchesSelf = matchesMenuFilters(row, filters);

    if (!matchesSelf && children.length === 0) {
      continue;
    }

    rows.push({
      ...row,
      children,
      hasChildren: children.length > 0,
    });
  }
  return rows;
}

function createTreeRow(
  node: MenuTreeNode,
  functionNamesById: Map<string, string>,
  depth: number,
  parentName: string,
): MenuTreeRow {
  return {
    depth,
    enabled: node.enabled,
    functionPointId: node.functionPointId || undefined,
    functionPointName: node.functionPointId ? functionNamesById.get(node.functionPointId) || '—' : '—',
    menuCategory: node.menuCategory || undefined,
    menuCode: node.menuCode,
    iconResourceId: node.iconResourceId || undefined,
    menuId: node.menuId,
    menuName: node.menuName,
    menuType: node.menuType,
    parentId: node.parentId || undefined,
    parentName,
    routePath: node.routePath || undefined,
    sortNo: node.sortNo,
  };
}

function matchesMenuFilters(
  row: MenuTreeRow,
  filters: {
    keyword: string;
    functionPointId: string;
    enabled: string;
  },
) {
  const keyword = filters.keyword.trim().toLowerCase();
  const matchesKeyword =
    !keyword
    || row.menuName.toLowerCase().includes(keyword)
    || row.menuCode.toLowerCase().includes(keyword)
    || row.parentName.toLowerCase().includes(keyword)
    || row.functionPointName.toLowerCase().includes(keyword);
  const matchesFunction =
    filters.functionPointId === 'all'
    || (filters.functionPointId === 'none' ? !row.functionPointId : row.functionPointId === filters.functionPointId);
  const matchesEnabled =
    filters.enabled === 'all'
    || (filters.enabled === 'enabled' ? row.enabled : !row.enabled);

  return matchesKeyword && matchesFunction && matchesEnabled;
}

function collectDescendantIds(nodes: MenuTreeNode[], menuId: string) {
  const descendants = new Set<string>();
  if (!menuId) {
    return descendants;
  }
  const target = findTreeNode(nodes, menuId);
  if (!target) {
    return descendants;
  }
  walkTree(target, descendants);
  return descendants;
}

function findTreeNode(nodes: MenuTreeNode[], menuId: string): MenuTreeNode | null {
  for (const node of nodes) {
    if (node.menuId === menuId) {
      return node;
    }
    const child = findTreeNode(node.children || [], menuId);
    if (child) {
      return child;
    }
  }
  return null;
}

function walkTree(node: MenuTreeNode, bucket: Set<string>) {
  bucket.add(node.menuId);
  for (const child of node.children || []) {
    walkTree(child, bucket);
  }
}

function consumeManagementRouteIntent(routeId: string): Record<string, string> | null {
  if (typeof window === 'undefined') {
    return null;
  }
  const raw = window.sessionStorage.getItem('brick.management.intent');
  if (!raw) {
    return null;
  }
  try {
    const intent = JSON.parse(raw);
    if (intent?.routeId !== routeId || !intent.selection || typeof intent.selection !== 'object') {
      return null;
    }
    window.sessionStorage.removeItem('brick.management.intent');
    return intent.selection as Record<string, string>;
  } catch {
    return null;
  }
}
