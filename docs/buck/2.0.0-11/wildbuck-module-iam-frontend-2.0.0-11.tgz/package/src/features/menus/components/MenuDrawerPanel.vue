<script setup lang="ts">
import { BrickConsoleDrawer } from '@wildbuck/core-ui-frontend/shell';
import type { MenuDetail, MenuUpsertRequest } from '../../../generated/types';
import type { FunctionPointSelectionOption, MenuOption, MenuTreeRow } from '../composables/useMenuWorkspace';
import MenuDetailCard from './MenuDetailCard.vue';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

defineProps<{
  visible: boolean;
  iconPreviewUrl: string;
  iconUploading: boolean;
  currentDetail: MenuDetail | null;
  editorMode: 'edit' | 'create';
  form: MenuUpsertRequest;
  functionPointOptions: FunctionPointSelectionOption[];
  panelLoading: boolean;
  parentOptions: MenuOption[];
  selectedMenu: MenuTreeRow | null;
}>();

defineEmits<{
  clearIcon: [];
  close: [];
  save: [];
  delete: [];
  uploadIcon: [file: File];
}>();
</script>

<template>
  <BrickConsoleDrawer
    :model-value="visible"
    size="52%"
    :destroy-on-close="false"
    class="menu-drawer"
    :eyebrow="t('module.iam.menus.drawer.detailTitle')"
    :title="form.menuName || selectedMenu?.menuName || t('module.iam.menus.drawer.unnamed')"
    :description="
      `${form.functionPointId ? t('module.iam.menus.drawer.functionKind') : t('module.iam.menus.drawer.customKind')} · ${
        form.parentId ? t('module.iam.menus.drawer.childKind') : t('module.iam.menus.stats.roots')
      }`
    "
    @close="$emit('close')"
  >
    <p v-if="panelLoading" class="drawer-state-text">{{ t('module.iam.menus.drawer.loading') }}</p>

    <MenuDetailCard
      v-else
      :current-detail="currentDetail"
      :editor-mode="editorMode"
      :form="form"
      :function-point-options="functionPointOptions"
      :icon-preview-url="iconPreviewUrl"
      :icon-uploading="iconUploading"
      :parent-options="parentOptions"
      :selected-menu="selectedMenu"
      @clear-icon="$emit('clearIcon')"
      @save="$emit('save')"
      @delete="$emit('delete')"
      @upload-icon="$emit('uploadIcon', $event)"
    />
  </BrickConsoleDrawer>
</template>

<style scoped>
.drawer-state-text {
  margin: 0;
  padding: var(--console-drawer-padding, 18px) 4px;
  color: var(--console-text, #4a5a70);
}
</style>
