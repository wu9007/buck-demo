<script setup lang="ts">
import { onMounted } from 'vue';
import { BrickListPageActions, BrickPageHeader } from '@wildbuck/core-ui-frontend/patterns';
import MenuDrawerPanel from '../components/MenuDrawerPanel.vue';
import MenuFilterToolbar from '../components/MenuFilterToolbar.vue';
import MenuTreeTablePanel from '../components/MenuTreeTablePanel.vue';
import { useMenuWorkspace } from '../composables/useMenuWorkspace';
import { iamUsageTracker } from '../../../usage-events';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

const emit = defineEmits<{
  shellContextMutated: [];
}>();

const {
  closeDrawer,
  clearMenuIcon,
  currentDetail,
  deleteSelectedMenu,
  drawerVisible,
  editorMode,
  filteredTreeRows,
  filterActive,
  appliedFilters,
  applySearch,
  form,
  functionPointOptions,
  iconPreviewUrl,
  iconUploading,
  initialize,
  panelLoading,
  parentOptions,
  resetSearch,
  selectMenu,
  selectedMenu,
  selectedMenuId,
  startCreateChild,
  startCreateRoot,
  submitForm,
  treeError,
  treeLoading,
  treeRows,
  uploadMenuIcon,
} = useMenuWorkspace();

onMounted(() => {
  void iamUsageTracker.trackPage('menus');
  initialize();
});

async function saveMenu() {
  if (await submitForm()) {
    emit('shellContextMutated');
  }
}

async function removeMenu() {
  if (await deleteSelectedMenu()) {
    emit('shellContextMutated');
  }
}

function onFilterModelUpdate(next: {
  keyword?: string;
  functionPointId?: string;
  enabled?: string;
}) {
  appliedFilters.keyword = next?.keyword ?? '';
  appliedFilters.functionPointId = next?.functionPointId ?? 'all';
  appliedFilters.enabled = next?.enabled ?? 'all';
}
</script>

<template>
  <article class="menus-page">
    <BrickPageHeader
      :eyebrow="t('module.iam.menus.page.eyebrow')"
      :title="t('module.iam.menus.page.title')"
      :description="t('module.iam.menus.page.description')"
    >
      <template #actions>
        <BrickListPageActions>
          <template #primary>
            <el-button type="primary" data-guide-anchor="primary-action" @click="startCreateRoot">
              {{ t('module.iam.menus.page.createRoot') }}
            </el-button>
          </template>
        </BrickListPageActions>
      </template>
    </BrickPageHeader>

    <MenuFilterToolbar
      :model-value="appliedFilters"
      :function-point-options="functionPointOptions"
      @update:model-value="onFilterModelUpdate"
      @search="applySearch"
      @reset="resetSearch"
    />

    <p v-if="treeError" class="state-text state-error">{{ treeError }}</p>

    <MenuTreeTablePanel
      :rows="filteredTreeRows"
      :loading="treeLoading"
      :selected-menu-id="selectedMenuId"
      :filter-active="filterActive"
      :total-count="treeRows.length"
      @open="selectMenu"
      @create-root="startCreateRoot"
      @create-child="startCreateChild"
    />
    <MenuDrawerPanel
      :visible="drawerVisible"
      :icon-preview-url="iconPreviewUrl"
      :icon-uploading="iconUploading"
      :current-detail="currentDetail"
      :editor-mode="editorMode"
      :form="form"
      :function-point-options="functionPointOptions"
      :panel-loading="panelLoading"
      :parent-options="parentOptions"
      :selected-menu="selectedMenu"
      @clear-icon="clearMenuIcon"
      @close="closeDrawer"
      @save="saveMenu"
      @delete="removeMenu"
      @upload-icon="uploadMenuIcon"
    />
  </article>
</template>

<style scoped>
.menus-page {
  display: grid;
  gap: var(--console-page-gap, 18px);
  padding: 4px 0 12px;
  background: var(--console-page-bg, #f6f8f8);
}

.state-text {
  margin: 0;
  padding: var(--console-card-body-y, 18px) var(--console-card-body-x, 18px);
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: var(--console-card-radius, 8px);
  color: var(--console-text, #4a5a70);
  background: var(--console-card-bg, #ffffff);
  box-shadow: var(--console-card-shadow, 0 1px 2px rgba(22, 67, 76, 0.04));
}

.state-error {
  color: var(--console-danger, #b4232f);
}
</style>
