import { createMenu, deleteMenu, listMenuFunctionPoints, listMenus, menuDetail, updateMenu } from '../../../generated/sdk';
import type { FunctionPointOption, MenuDetail, MenuTreeNode, MenuUpsertRequest } from '../../../generated/types';

export async function loadMenuTree(): Promise<MenuTreeNode[]> {
  return listMenus(undefined);
}

export async function loadMenuFunctionPointOptions(): Promise<FunctionPointOption[]> {
  return listMenuFunctionPoints(undefined);
}

export async function loadRegisteredMenuFunctionOptions(): Promise<FunctionPointOption[]> {
  return listMenuFunctionPoints(undefined);
}

export async function loadMenuDetail(menuId: string): Promise<MenuDetail> {
  return menuDetail(menuId, undefined);
}

export async function saveNewMenu(input: MenuUpsertRequest): Promise<MenuDetail> {
  return createMenu(input);
}

export async function saveExistingMenu(menuId: string, input: MenuUpsertRequest): Promise<MenuDetail> {
  return updateMenu(menuId, input);
}

export async function removeMenu(menuId: string): Promise<void> {
  return deleteMenu(menuId, undefined);
}
