export const TOKEN_KEY = 'brick.securityConsole.accessToken';
export const REFRESH_TOKEN_KEY = 'brick.securityConsole.refreshToken';
export const PRINCIPAL_KEY = 'brick.securityConsole.principal';
export const PENDING_MFA_TOKEN_KEY = 'brick.securityConsole.pendingMfa.accessToken';
export const PENDING_MFA_PRINCIPAL_KEY = 'brick.securityConsole.pendingMfa.principal';
export const EXPIRATION_STRATEGY_KEY = 'brick.securityConsole.expirationStrategy';
/**
 * Last successful principal workspace snapshot for soft cold-start skeleton.
 * Keeps menus/permissions under SCREEN_LOCK overlay when AT/RT are dead after reload.
 * Never stores tokens or secrets.
 */
export const SHELL_WORKSPACE_CACHE_KEY = 'brick.securityConsole.shellWorkspaceCache';

export const AuthScreen = {
  FIRST_FACTOR: 'FIRST_FACTOR',
  MFA: 'MFA',
  PASSWORD: 'PASSWORD',
};

/** Terminal recovery after silent refresh fails. Only soft mode is SCREEN_LOCK. */
export const SessionRecovery = {
  NONE: '',
  SCREEN_LOCK: 'SCREEN_LOCK',
};

/** 产品仅两态；历史 VERIFY_PASS 由 normalize 映射为 SCREEN_LOCK。 */
export const EXPIRATION_STRATEGIES = Object.freeze([
  'LOGIN_OUT',
  'SCREEN_LOCK',
]);

export function normalizeExpirationStrategy(value) {
  const normalized = String(value || '').trim().toUpperCase();
  if (normalized === 'SCREEN_LOCK' || normalized === 'VERIFY_PASS') {
    return 'SCREEN_LOCK';
  }
  return 'LOGIN_OUT';
}

export function createInitialAuthState(readJson, storage = localStorage) {
  return {
    token: storage.getItem(TOKEN_KEY) || storage.getItem(PENDING_MFA_TOKEN_KEY) || '',
    refreshToken: storage.getItem(REFRESH_TOKEN_KEY) || '',
    principal: readJson(storage.getItem(PRINCIPAL_KEY)),
    pendingPrincipal: readJson(storage.getItem(PENDING_MFA_PRINCIPAL_KEY)),
    captcha: null,
    mfaPending: Boolean(storage.getItem(PENDING_MFA_TOKEN_KEY)),
    mfaChallenge: null,
    passwordChangeRequired: false,
    passwordLifecycle: null,
    passwordAction: '',
    passwordWarning: null,
    authScreen: AuthScreen.FIRST_FACTOR,
    passwordReminderVisible: false,
    passwordChangeEditorVisible: false,
    /** Runtime expiration strategy from client-meta (non-secret). */
    expirationStrategy: normalizeExpirationStrategy(storage.getItem(EXPIRATION_STRATEGY_KEY)),
    /**
     * Soft suspend after RT failure: SCREEN_LOCK only.
     * Empty string means active/anonymous. Workspace route/drafts stay until clearSession.
     */
    sessionRecovery: SessionRecovery.NONE,
  };
}

export function persistAuthenticatedSession(state, storage = localStorage) {
  storage.setItem(TOKEN_KEY, state.token || '');
  if (state.refreshToken) {
    storage.setItem(REFRESH_TOKEN_KEY, state.refreshToken);
  } else {
    storage.removeItem(REFRESH_TOKEN_KEY);
  }
  storage.setItem(PRINCIPAL_KEY, JSON.stringify(state.principal));
  storage.removeItem(PENDING_MFA_TOKEN_KEY);
  storage.removeItem(PENDING_MFA_PRINCIPAL_KEY);
}

export function persistPendingMfaSession(state, storage = localStorage) {
  storage.removeItem(TOKEN_KEY);
  storage.removeItem(PRINCIPAL_KEY);
  // Pending MFA still carries access token only; RT is not usable until MFA completes.
  storage.setItem(PENDING_MFA_TOKEN_KEY, state.token);
  storage.setItem(PENDING_MFA_PRINCIPAL_KEY, JSON.stringify(state.pendingPrincipal));
  if (state.refreshToken) {
    storage.setItem(REFRESH_TOKEN_KEY, state.refreshToken);
  }
}

export function persistExpirationStrategy(strategy, storage = localStorage) {
  const normalized = normalizeExpirationStrategy(strategy);
  storage.setItem(EXPIRATION_STRATEGY_KEY, normalized);
  return normalized;
}

export function clearStoredSession(storage = localStorage) {
  storage.removeItem(TOKEN_KEY);
  storage.removeItem(REFRESH_TOKEN_KEY);
  storage.removeItem(PRINCIPAL_KEY);
  storage.removeItem(PENDING_MFA_TOKEN_KEY);
  storage.removeItem(PENDING_MFA_PRINCIPAL_KEY);
  clearShellWorkspaceCache(storage);
}

/**
 * Persist non-sensitive shell skeleton after a successful workspace hydrate.
 * @param {{ currentPrincipalWorkspace?: unknown, permissions?: unknown[] } | null | undefined} snapshot
 * @param {Storage} [storage]
 */
export function persistShellWorkspaceCache(snapshot, storage = localStorage) {
  if (!snapshot || typeof snapshot !== 'object') {
    return;
  }
  const workspace = snapshot.currentPrincipalWorkspace;
  if (!workspace || typeof workspace !== 'object') {
    return;
  }
  const permissions = Array.isArray(snapshot.permissions)
    ? snapshot.permissions
    : (Array.isArray(workspace.permissions) ? workspace.permissions : []);
  try {
    storage.setItem(SHELL_WORKSPACE_CACHE_KEY, JSON.stringify({
      currentPrincipalWorkspace: workspace,
      permissions,
      cachedAt: Date.now(),
    }));
  } catch {
    // quota / private mode — soft cold-start falls back to empty menus
  }
}

/**
 * @param {Storage} [storage]
 * @returns {{ currentPrincipalWorkspace: Record<string, unknown>, permissions: unknown[] } | null}
 */
export function readShellWorkspaceCache(storage = localStorage) {
  try {
    const raw = storage.getItem(SHELL_WORKSPACE_CACHE_KEY);
    if (!raw) {
      return null;
    }
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || !parsed.currentPrincipalWorkspace) {
      return null;
    }
    return {
      currentPrincipalWorkspace: parsed.currentPrincipalWorkspace,
      permissions: Array.isArray(parsed.permissions) ? parsed.permissions : [],
    };
  } catch {
    return null;
  }
}

export function clearShellWorkspaceCache(storage = localStorage) {
  try {
    storage.removeItem(SHELL_WORKSPACE_CACHE_KEY);
  } catch {
    // ignore
  }
}

export function clearMfaState(state, storage = localStorage) {
  state.mfaPending = false;
  state.mfaChallenge = null;
  state.pendingPrincipal = null;
  storage.removeItem(PENDING_MFA_TOKEN_KEY);
  storage.removeItem(PENDING_MFA_PRINCIPAL_KEY);
}
