import { formatBrickI18nMessage, normalizeBrickLocale } from '@wildbuck/core-i18n-frontend';
import {
  IAM_AUTH_MESSAGES,
  IAM_AUTH_MESSAGES_ZH_CN,
} from './i18n-messages.js';

/**
 * Resolve flat IAM auth message table for a Buck locale.
 * @param {unknown} locale
 * @returns {Readonly<Record<string, string>>}
 */
export function resolveIamAuthMessages(locale) {
  const normalized = normalizeBrickLocale(locale);
  return IAM_AUTH_MESSAGES[normalized] ?? IAM_AUTH_MESSAGES_ZH_CN;
}

/**
 * Build the nested authExperience object used by IAM auth workspace / view.
 * Call again when appearance.locale changes so login copy switches with the shell.
 * @param {unknown} [locale='zh-CN']
 */
export function createAuthExperience(locale = 'zh-CN') {
  const pack = resolveIamAuthMessages(locale);
  const zh = IAM_AUTH_MESSAGES_ZH_CN;
  const t = (key, params) => {
    const template = pack[key] ?? zh[key] ?? key;
    return formatBrickI18nMessage(template, params);
  };

  return Object.freeze({
    view: Object.freeze({
      title: t('module.iam.auth.view.title'),
      navTitle: t('module.iam.auth.view.navTitle'),
      eyebrow: t('module.iam.auth.view.eyebrow'),
      summary: t('module.iam.auth.view.summary'),
    }),
    controls: Object.freeze({
      loginMethodTitle: t('module.iam.auth.controls.loginMethodTitle'),
      loginMethodValue: t('module.iam.auth.controls.loginMethodValue'),
      loginMethodHint: t('module.iam.auth.controls.loginMethodHint'),
      firstFactorEyebrow: t('module.iam.auth.controls.firstFactorEyebrow'),
      firstFactorSummary: t('module.iam.auth.controls.firstFactorSummary'),
      captchaTitle: t('module.iam.auth.controls.captchaTitle'),
      captchaRefreshButton: t('module.iam.auth.controls.captchaRefreshButton'),
      captchaPlaceholder: t('module.iam.auth.controls.captchaPlaceholder'),
      captchaAlt: t('module.iam.auth.controls.captchaAlt'),
      mfaEyebrow: t('module.iam.auth.controls.mfaEyebrow'),
      mfaStepTitle: t('module.iam.auth.controls.mfaStepTitle'),
      mfaStepSummary: t('module.iam.auth.controls.mfaStepSummary'),
      mfaFirstFactorLabel: t('module.iam.auth.controls.mfaFirstFactorLabel'),
      mfaFirstFactorValue: t('module.iam.auth.controls.mfaFirstFactorValue'),
      mfaSecondFactorLabel: t('module.iam.auth.controls.mfaSecondFactorLabel'),
      mfaSecondFactorValue: t('module.iam.auth.controls.mfaSecondFactorValue'),
      mfaReservedLabel: t('module.iam.auth.controls.mfaReservedLabel'),
      mfaSendButton: t('module.iam.auth.controls.mfaSendButton'),
      mfaCodeLabel: t('module.iam.auth.controls.mfaCodeLabel'),
      mfaCodePlaceholder: t('module.iam.auth.controls.mfaCodePlaceholder'),
      mfaCompleteButton: t('module.iam.auth.controls.mfaCompleteButton'),
      passwordLifecycleEyebrow: t('module.iam.auth.controls.passwordLifecycleEyebrow'),
      passwordLifecycleTitle: t('module.iam.auth.controls.passwordLifecycleTitle'),
      passwordLifecycleSummary: t('module.iam.auth.controls.passwordLifecycleSummary'),
      passwordLifecycleRemindTitle: t('module.iam.auth.controls.passwordLifecycleRemindTitle'),
      passwordLifecycleRemindSummary: t('module.iam.auth.controls.passwordLifecycleRemindSummary'),
      passwordLifecycleSelfServiceTitle: t('module.iam.auth.controls.passwordLifecycleSelfServiceTitle'),
      passwordLifecycleSelfServiceSummary: t('module.iam.auth.controls.passwordLifecycleSelfServiceSummary'),
      passwordLifecycleBlockTitle: t('module.iam.auth.controls.passwordLifecycleBlockTitle'),
      passwordLifecycleBlockSummary: t('module.iam.auth.controls.passwordLifecycleBlockSummary'),
      passwordLifecycleScenarioLabel: t('module.iam.auth.controls.passwordLifecycleScenarioLabel'),
      passwordLifecycleRemindAction: t('module.iam.auth.controls.passwordLifecycleRemindAction'),
      passwordLifecycleBlockAction: t('module.iam.auth.controls.passwordLifecycleBlockAction'),
      passwordLifecycleDismissButton: t('module.iam.auth.controls.passwordLifecycleDismissButton'),
      currentPasswordLabel: t('module.iam.auth.controls.currentPasswordLabel'),
      currentPasswordPlaceholder: t('module.iam.auth.controls.currentPasswordPlaceholder'),
      newPasswordLabel: t('module.iam.auth.controls.newPasswordLabel'),
      newPasswordPlaceholder: t('module.iam.auth.controls.newPasswordPlaceholder'),
      confirmNewPasswordLabel: t('module.iam.auth.controls.confirmNewPasswordLabel'),
      confirmNewPasswordPlaceholder: t('module.iam.auth.controls.confirmNewPasswordPlaceholder'),
      passwordChangeSubmitButton: t('module.iam.auth.controls.passwordChangeSubmitButton'),
      loginSubmitButton: t('module.iam.auth.controls.loginSubmitButton'),
      panelTitleLogin: t('module.iam.auth.controls.panelTitleLogin'),
      panelTitlePassword: t('module.iam.auth.controls.panelTitlePassword'),
      panelDescLogin: t('module.iam.auth.controls.panelDescLogin'),
      panelDescMfaEmail: t('module.iam.auth.controls.panelDescMfaEmail'),
      panelDescMfaSms: t('module.iam.auth.controls.panelDescMfaSms'),
      panelDescMfaGeneric: t('module.iam.auth.controls.panelDescMfaGeneric'),
      panelDescPasswordBlock: t('module.iam.auth.controls.panelDescPasswordBlock'),
      panelDescPasswordRemind: t('module.iam.auth.controls.panelDescPasswordRemind'),
      panelDescPasswordSelfService: t('module.iam.auth.controls.panelDescPasswordSelfService'),
      versionLabel: t('module.iam.auth.controls.versionLabel'),
    }),
    loginModes: Object.freeze({
      'username-password': Object.freeze({
        optionLabel: t('module.iam.auth.loginModes.usernamePassword.optionLabel'),
        title: t('module.iam.auth.loginModes.usernamePassword.title'),
        identityLabel: t('module.iam.auth.loginModes.usernamePassword.identityLabel'),
        identityPlaceholder: t('module.iam.auth.loginModes.usernamePassword.identityPlaceholder'),
        credentialLabel: t('module.iam.auth.loginModes.usernamePassword.credentialLabel'),
        credentialPlaceholder: t('module.iam.auth.loginModes.usernamePassword.credentialPlaceholder'),
        verificationHint: t('module.iam.auth.loginModes.usernamePassword.verificationHint'),
      }),
    }),
    messages: Object.freeze({
      sessionAnonymous: t('module.iam.auth.messages.sessionAnonymous'),
      sessionPendingPrincipal: t('module.iam.auth.messages.sessionPendingPrincipal'),
      bootstrapMfaPending: t('module.iam.auth.messages.bootstrapMfaPending'),
      loginStepPassed: t('module.iam.auth.messages.loginStepPassed'),
      loginSuccessRequirePasswordChange: t('module.iam.auth.messages.loginSuccessRequirePasswordChange'),
      sessionMustChangePassword: t('module.iam.auth.messages.sessionMustChangePassword'),
      mfaCodeSentStatus: t('module.iam.auth.messages.mfaCodeSentStatus'),
      mfaNotRequired: t('module.iam.auth.messages.mfaNotRequired'),
      mfaComplete: t('module.iam.auth.messages.mfaComplete'),
      passwordChangedRelogin: t('module.iam.auth.messages.passwordChangedRelogin'),
      passwordReasonInitialPassword: t('module.iam.auth.messages.passwordReasonInitialPassword'),
      passwordReasonInitialPasswordExpired: t('module.iam.auth.messages.passwordReasonInitialPasswordExpired'),
      passwordReasonPeriodicExpired: t('module.iam.auth.messages.passwordReasonPeriodicExpired'),
      passwordReasonAdminReset: t('module.iam.auth.messages.passwordReasonAdminReset'),
      passwordReasonWeakPassword: t('module.iam.auth.messages.passwordReasonWeakPassword'),
      passwordExpiredFallback: t('module.iam.auth.messages.passwordExpiredFallback'),
      passwordChangeRequiredFallback: t('module.iam.auth.messages.passwordChangeRequiredFallback'),
      passwordNoticeWithDays: t('module.iam.auth.messages.passwordNoticeWithDays'),
      passwordNoticeFallback: t('module.iam.auth.messages.passwordNoticeFallback'),
      passwordWarningGeneric: t('module.iam.auth.messages.passwordWarningGeneric'),
      passwordWarningTemplate: t('module.iam.auth.messages.passwordWarningTemplate'),
      passwordViolationTooShort: t('module.iam.auth.messages.passwordViolationTooShort'),
      passwordViolationTooLong: t('module.iam.auth.messages.passwordViolationTooLong'),
      passwordViolationMissingUppercase: t('module.iam.auth.messages.passwordViolationMissingUppercase'),
      passwordViolationMissingLowercase: t('module.iam.auth.messages.passwordViolationMissingLowercase'),
      passwordViolationMissingDigit: t('module.iam.auth.messages.passwordViolationMissingDigit'),
      passwordViolationMissingSpecial: t('module.iam.auth.messages.passwordViolationMissingSpecial'),
      passwordViolationWeak: t('module.iam.auth.messages.passwordViolationWeak'),
      requireLoginError: t('module.iam.auth.messages.requireLoginError'),
      bootstrapPasswordChangeRequired: t('module.iam.auth.messages.bootstrapPasswordChangeRequired'),
      captchaNotRequired: t('module.iam.auth.messages.captchaNotRequired'),
      captchaLoadingHint: t('module.iam.auth.messages.captchaLoadingHint'),
      passwordConfirmMismatch: t('module.iam.auth.messages.passwordConfirmMismatch'),
      loginFailed: t('module.iam.auth.messages.loginFailed'),
      loggedOut: t('module.iam.auth.messages.loggedOut'),
      sessionExpired: t('module.iam.auth.messages.sessionExpired'),
      sessionLocked: t('module.iam.auth.messages.sessionLocked'),
      sessionResumed: t('module.iam.auth.messages.sessionResumed'),
      sessionUnlockPasswordRequired: t('module.iam.auth.messages.sessionUnlockPasswordRequired'),
      captchaTriggeredHint: t('module.iam.auth.messages.captchaTriggeredHint'),
      mfaChannelHint: t('module.iam.auth.messages.mfaChannelHint'),
      mfaChannelEmail: t('module.iam.auth.messages.mfaChannelEmail'),
      mfaChannelSms: t('module.iam.auth.messages.mfaChannelSms'),
      listJoinSep: t('module.iam.auth.messages.listJoinSep'),
    }),
  });
}

/** Default zh-CN experience for backward-compatible imports. */
export const authExperience = createAuthExperience('zh-CN');
