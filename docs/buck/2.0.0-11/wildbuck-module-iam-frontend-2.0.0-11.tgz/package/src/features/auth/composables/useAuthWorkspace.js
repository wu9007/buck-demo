import { computed } from 'vue';

import { createAuthRequestClient } from '@wildbuck/core-authentication-frontend';
import {
  isBrickSessionRecoveryUiActive,
  setBrickSessionRecoveryUiActive,
} from '@wildbuck/core-ui-frontend/session-recovery-ui';
import {
  readBrickConsoleActiveRouteId,
  writeBrickConsoleActiveRouteId,
} from '@wildbuck/core-ui-frontend/shell-navigation';
import { authExperience as defaultAuthExperience } from '../../../auth-experience.js';
import { resolveBrickLoginDeviceId } from '../lib/brick-login-device.js';
import {
  AuthScreen,
  EXPIRATION_STRATEGY_KEY,
  REFRESH_TOKEN_KEY,
  SessionRecovery,
  TOKEN_KEY,
  clearMfaState,
  clearStoredSession,
  normalizeExpirationStrategy,
  persistAuthenticatedSession,
  persistExpirationStrategy,
  persistPendingMfaSession,
} from '../auth-state.js';

const REFRESH_PATH = '/brick/token/refresh';

export function useAuthWorkspace({
  state,
  showStatus,
  loadAuthenticatedContext,
  /** Optional: restore shell menus from cache when soft-suspend has no live workspace (cold start). */
  onSoftSuspend,
}) {
  const authRequestClient = createAuthRequestClient({
    state,
    // clearSession kept as last-resort fallback only; 401 after refresh uses lifecycle.
    clearSession,
    adoptPasswordChangeRequiredState,
    onStatus: showStatus,
    tryRefresh: trySilentRefresh,
    // Align auth-adjacent 401 with business SDK: strategy branch, not clearSession-only.
    onSessionTerminal: (error) => handleSessionTerminal(error),
  });
  const currentLoginMode = computed(
    () => state.authExperience.loginModes?.[state.loginType] || defaultAuthExperience.loginModes['username-password'],
  );
  const screenTitle = computed(() => {
    if (state.authScreen === AuthScreen.MFA) {
      return state.authExperience.controls.mfaStepTitle;
    }
    if (state.authScreen === AuthScreen.PASSWORD) {
      if (state.passwordChangeRequired) {
        return state.authExperience.controls.passwordLifecycleBlockTitle;
      }
      // Policy remind vs voluntary self-service from avatar menu.
      if (state.passwordLifecycle || state.passwordWarning) {
        return state.authExperience.controls.passwordLifecycleRemindTitle;
      }
      return state.authExperience.controls.passwordLifecycleSelfServiceTitle
        || state.authExperience.controls.passwordLifecycleRemindTitle;
    }
    return currentLoginMode.value.title;
  });
  const canDismissPasswordReminder = computed(
    () => state.passwordReminderVisible && !state.passwordChangeRequired,
  );
  const authAlertText = computed(() => composeAuthSummary());
  const sessionUserName = computed(() => {
    if (state.pendingPrincipal?.username) {
      const template = state.authExperience.messages?.sessionPendingPrincipal
        || defaultAuthExperience.messages.sessionPendingPrincipal
        || '';
      return template.replaceAll('{username}', state.pendingPrincipal.username);
    }
    return state.principal?.username || state.authExperience.messages.sessionAnonymous;
  });
  /**
   * Shell stays mounted while soft-suspended so URL / drafts survive.
   * Active business access still requires a live access token.
   */
  const isAuthenticated = computed(
    () => {
      if (state.sessionRecovery) {
        return Boolean(state.principal)
          && !state.mfaPending
          && !state.passwordChangeRequired
          && !state.passwordReminderVisible;
      }
      return Boolean(state.token)
        && !state.mfaPending
        && !state.passwordChangeRequired
        && !state.passwordReminderVisible;
    },
  );
  const isAuthFocus = computed(() => !isAuthenticated.value);
  /** Soft-suspend active（仅 SCREEN_LOCK 一态）。 */
  const isSessionLocked = computed(() => state.sessionRecovery === SessionRecovery.SCREEN_LOCK);
  const isSessionRecoveryActive = computed(() => Boolean(state.sessionRecovery));

  function applyLoginMode(loginType) {
    state.loginType = loginType || 'username-password';
    state.form.password = '';
    state.form.captchaCode = '';
  }

  async function bootstrapAuthState() {
    await loadCaptcha();
    if (state.mfaPending && state.token) {
      state.authScreen = AuthScreen.MFA;
      state.activeRouteId = 'login';
      showStatus(state.authExperience.messages.bootstrapMfaPending, 'warning');
      return;
    }
    if (state.token) {
      await loadAuthenticatedContext();
    }
  }

  async function login() {
    try {
      const attributes = {
        'Visitor-Terminal': 'BUSINESS',
        deviceId: resolveBrickLoginDeviceId(),
      };
      if (state.captcha?.required) {
        attributes.captchaId = state.captcha.captchaId;
        attributes.validCode = state.form.captchaCode.trim();
      }
      const result = await authRequestClient.request('/brick/login', {
        method: 'POST',
        body: JSON.stringify({
          username: state.form.username.trim(),
          password: state.form.password,
          loginType: state.loginType,
          attributes,
        }),
        anonymous: true,
        transportProtected: true,
      });
      await acceptAuthenticatedSession(result);
    } catch (error) {
      showStatus(error?.message || state.authExperience.messages.loginFailed, 'error');
      await loadCaptcha().catch(() => {});
    }
  }

  async function loadCaptcha() {
    try {
      const username = state.form.username.trim();
      const challengePath = username
        ? `/brick/captcha?username=${encodeURIComponent(username)}`
        : '/brick/captcha';
      const challenge = await authRequestClient.request(challengePath, {
        method: 'GET',
        anonymous: true,
      });
      state.captcha = challenge;
      return challenge;
    } catch {
      state.captcha = null;
      return null;
    }
  }

  async function sendMfaVerificationCode() {
    try {
      requireToken();
      const result = await authRequestClient.request('/brick/mfa/verification-code/send', {
        method: 'POST',
      });
      state.mfaChallenge = result;
      showStatus(
        formatMessage('mfaCodeSentStatus', { channel: describeMfaChannel(result.channel) }),
        'success',
      );
    } catch {
    }
  }

  async function completeMfaVerification() {
    try {
      requireToken();
      const result = await authRequestClient.request('/brick/mfa/verification-code/verify', {
        method: 'POST',
        body: JSON.stringify({ code: state.form.mfaCode.trim() }),
      });
      clearMfaState(state);
      await acceptAuthenticatedSession(result);
      showStatus(state.authExperience.messages.mfaComplete, 'success');
    } catch {
    }
  }

  async function completePasswordChange() {
    try {
      requireToken();
      if (state.form.newPassword !== state.form.confirmNewPassword) {
        showStatus(state.authExperience.messages.passwordConfirmMismatch, 'error');
        return;
      }
      const username = state.form.username.trim();
      const newPassword = state.form.newPassword;
      await authRequestClient.request('/brick/password/change', {
        method: 'POST',
        body: JSON.stringify({
          currentPassword: state.form.currentPassword,
          newPassword,
        }),
      });
      clearSession(state.authExperience.messages.passwordChangedRelogin);
      state.form.username = username;
      state.form.password = newPassword;
      state.form.currentPassword = '';
      state.form.newPassword = '';
      state.form.confirmNewPassword = '';
      await loadCaptcha();
    } catch {
    }
  }

  async function logout() {
    const accessToken = state.token;
    const refreshToken = state.refreshToken;
    if (accessToken || refreshToken) {
      try {
        const logoutResult = await authRequestClient.request('/brick/logout', {
          method: 'POST',
          body: JSON.stringify({
            refreshToken: refreshToken || undefined,
          }),
          // Allow logout even when access token is already dead (RT still revocable).
          anonymous: !accessToken,
        });
        const payload = logoutResult && typeof logoutResult === 'object'
          ? (logoutResult.data && (logoutResult.category || logoutResult.code) ? logoutResult.data : logoutResult)
          : null;
        const federatedLogoutUrl = payload?.federatedLogoutUrl;
        if (typeof federatedLogoutUrl === 'string' && /^https?:\/\//i.test(federatedLogoutUrl)) {
          clearSession(state.authExperience.messages.loggedOut);
          window.location.assign(federatedLogoutUrl);
          return;
        }
      } catch {
      }
    }
    clearSession(state.authExperience.messages.loggedOut);
  }

  async function dismissPasswordReminder() {
    state.passwordReminderVisible = false;
    state.passwordChangeEditorVisible = false;
    state.authScreen = AuthScreen.FIRST_FACTOR;
    // Resolve the first real management route (menus/workspace), never park on the shell placeholder.
    await loadAuthenticatedContext();
  }

  /**
   * Policy/forced password stage on the auth view (not the avatar-menu dialog).
   * Self-service from the topbar uses changeOwnPassword + BrickChangePasswordDialog.
   */
  function openPasswordChangeEditor() {
    state.passwordChangeEditorVisible = true;
    if (state.passwordChangeRequired || state.passwordReminderVisible) {
      state.authScreen = AuthScreen.PASSWORD;
    }
    state.form.currentPassword = '';
    state.form.newPassword = '';
    state.form.confirmNewPassword = '';
  }

  /**
   * Self-service password change while staying in the shell (dialog form).
   * @param {{ currentPassword: string, newPassword: string }} payload
   */
  async function changeOwnPassword(payload = {}) {
    requireToken();
    const currentPassword = String(payload.currentPassword || '');
    const newPassword = String(payload.newPassword || '');
    if (!currentPassword || !newPassword) {
      throw new Error(state.authExperience.messages.passwordConfirmMismatch || 'Invalid password payload');
    }
    const username = String(
      state.form.username || state.principal?.username || state.currentPrincipalWorkspace?.username || '',
    ).trim();
    await authRequestClient.request('/brick/password/change', {
      method: 'POST',
      body: JSON.stringify({
        currentPassword,
        newPassword,
      }),
    });
    clearSession(state.authExperience.messages.passwordChangedRelogin);
    state.form.username = username;
    state.form.password = newPassword;
    state.form.currentPassword = '';
    state.form.newPassword = '';
    state.form.confirmNewPassword = '';
    await loadCaptcha();
  }

  /**
   * @param {object} result login / unlock payload
   * @param {{ preserveRouteId?: string }} [options]
   */
  async function acceptAuthenticatedSession(result, options = {}) {
    state.token = result.accessToken || '';
    state.refreshToken = result.refreshToken || '';
    state.sessionRecovery = SessionRecovery.NONE;
    setBrickSessionRecoveryUiActive(false);
    state.passwordAction = String(result.attributes?.['Password-Lifecycle-Action'] || '').trim();
    state.passwordLifecycle = readPasswordLifecycle(result.attributes);
    state.passwordChangeRequired = result.attributes?.['Password-Change-Required'] === 'true';
    state.passwordWarning = readPasswordWarning(result.attributes);
    if (result.attributes?.['Require-2FA']) {
      state.principal = null;
      state.pendingPrincipal = result.principal;
      state.mfaPending = true;
      state.mfaChallenge = null;
      persistPendingMfaSession(state);
      state.authScreen = AuthScreen.MFA;
      state.activeRouteId = 'login';
      await loadCaptcha();
      showStatus(state.authExperience.messages.loginStepPassed, 'warning');
      return;
    }
    state.principal = result.principal;
    state.pendingPrincipal = null;
    persistAuthenticatedSession(state);
    clearMfaState(state);
    // REMIND lifecycle, or password-policy warning (e.g. weak password), both surface the password stage.
    state.passwordReminderVisible = !state.passwordChangeRequired
      && (
        (state.passwordAction === 'REMIND' && Boolean(state.passwordLifecycle))
        || Boolean(state.passwordWarning)
      );
    state.passwordChangeEditorVisible = state.passwordChangeRequired;
    state.authScreen = state.passwordChangeRequired || state.passwordReminderVisible
      ? AuthScreen.PASSWORD
      : AuthScreen.FIRST_FACTOR;
    if (state.passwordChangeRequired) {
      state.activeRouteId = 'login';
      await loadCaptcha();
      showStatus(state.authExperience.messages.loginSuccessRequirePasswordChange, 'warning');
      return;
    }
    // Unlock/soft recovery passes preserveRouteId so shell does not jump away from open forms.
    await loadAuthenticatedContext({
      preserveRouteId: options.preserveRouteId,
    });
    await loadCaptcha();
    if (state.passwordReminderVisible) {
      // Shell hydration already picked a real management route (path / sessionStorage / first menu).
      showStatus(
        state.passwordLifecycle
          || state.passwordWarning
          || state.authExperience.messages.passwordNoticeFallback,
        'warning',
      );
      return;
    }
    if (!state.activeRouteId || state.activeRouteId === 'login') {
      await loadAuthenticatedContext({
        preserveRouteId: options.preserveRouteId,
      });
    }
  }

  function adoptTokensFromRefresh(result) {
    if (!result?.accessToken) {
      return false;
    }
    state.token = result.accessToken;
    if (result.refreshToken) {
      state.refreshToken = result.refreshToken;
    }
    if (result.principal) {
      state.principal = result.principal;
    }
    state.sessionRecovery = SessionRecovery.NONE;
    setBrickSessionRecoveryUiActive(false);
    persistAuthenticatedSession(state);
    return true;
  }

  /**
   * 联邦登录完成票据兑换后写入会话，复用本地密码登录后的工作区加载。
   */
  async function adoptFederatedLoginResult(result) {
    if (!adoptTokensFromRefresh(result)) {
      throw new Error(state.authExperience?.messages?.loginFailed || '身份源登录失败');
    }
    state.mfaPending = false;
    state.authScreen = AuthScreen.FIRST_FACTOR;
    await loadAuthenticatedContext({});
    return true;
  }

  /**
   * Single-flight is owned by core-api tokenRefresh; this performs one raw refresh call.
   * Uses fetch directly to avoid re-entering configureHttp session recovery.
   */
  async function trySilentRefresh() {
    const refreshToken = state.refreshToken;
    if (!refreshToken) {
      return false;
    }
    try {
      const response = await fetch(REFRESH_PATH, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({ refreshToken }),
      });
      const text = await response.text();
      let body = null;
      if (text) {
        try {
          body = JSON.parse(text);
        } catch {
          body = null;
        }
      }
      // Support both raw DTO and BrickApiResponse envelope.
      const payload = body && typeof body === 'object' && body.data && body.category
        ? body.data
        : body;
      if (!response.ok || !payload?.accessToken) {
        return false;
      }
      return adoptTokensFromRefresh(payload);
    } catch {
      return false;
    }
  }

  /**
   * Terminal path after silent refresh failed (or no RT).
   * LOGIN_OUT revokes then clears workspace; SCREEN_LOCK soft-suspends and keeps route/drafts.
   * Historical VERIFY_PASS is normalized to SCREEN_LOCK before branch.
   */
  async function handleSessionTerminal(error) {
    if (state.sessionRecovery || isBrickSessionRecoveryUiActive()) {
      // Already suspended — do not thrash UI on concurrent 401s.
      return;
    }
    const strategy = resolveActiveExpirationStrategy();
    const message = readTerminalMessage(error, strategy);
    if (strategy === 'SCREEN_LOCK') {
      softSuspend(message);
      return;
    }
    await endSessionSecurely(message);
  }

  /**
   * Prefer stored strategy (client-meta adopt) over stale in-memory default.
   * normalize maps historical VERIFY_PASS → SCREEN_LOCK.
   */
  function resolveActiveExpirationStrategy() {
    let stored = '';
    try {
      stored = localStorage.getItem(EXPIRATION_STRATEGY_KEY) || '';
    } catch {
      stored = '';
    }
    const strategy = normalizeExpirationStrategy(stored || state.expirationStrategy);
    if (state.expirationStrategy !== strategy) {
      state.expirationStrategy = strategy;
    }
    // Rewrite storage when historical VERIFY_PASS was still present so card/runtime stay aligned.
    if (stored && normalizeExpirationStrategy(stored) !== stored) {
      try {
        persistExpirationStrategy(strategy);
      } catch {
        // storage may be unavailable in tests
      }
    }
    return strategy;
  }

  /** Best-effort server revoke then local clear (LOGIN_OUT / unlock exit). */
  async function endSessionSecurely(message) {
    const accessToken = state.token;
    const refreshToken = state.refreshToken;
    if (accessToken || refreshToken) {
      try {
        await fetch('/brick/logout', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json',
            ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
          },
          body: JSON.stringify({
            refreshToken: refreshToken || undefined,
          }),
        });
      } catch {
        // offline / already invalid — still clear local session
      }
    }
    clearSession(message);
  }

  function softSuspend(message) {
    // Drop dead access token so prepareRequest stops sending it; keep principal + route + open forms.
    state.token = '';
    state.refreshToken = '';
    state.sessionRecovery = SessionRecovery.SCREEN_LOCK;
    // Overlay owns UX — suppress page-level load-error toasts while suspended.
    setBrickSessionRecoveryUiActive(true);
    // Pin management route in sessionStorage so hard refresh / unlock stay on the same page.
    const pinnedRouteId = state.activeRouteId && state.activeRouteId !== 'login'
      ? state.activeRouteId
      : readBrickConsoleActiveRouteId();
    if (pinnedRouteId && pinnedRouteId !== 'login') {
      writeBrickConsoleActiveRouteId(pinnedRouteId);
      state.activeRouteId = pinnedRouteId;
    }
    // Clear only AT/RT storage; principal stays for shell identity until unlock or logout.
    try {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(REFRESH_TOKEN_KEY);
    } catch {
      // storage may be unavailable in tests
    }
    // Cold reload with dead tokens: rehydrate last-known menus under the mask (do not change route).
    if (typeof onSoftSuspend === 'function') {
      try {
        onSoftSuspend(pinnedRouteId);
      } catch {
        // cache miss is fine — overlay still blocks actions
      }
    }
    // Do not toast here: global recovery overlay is the single session UI.
    void message;
  }

  /**
   * Re-authenticate with password for soft recovery.
   * Uses /brick/login (new AT/RT). Must not call step-up password verify (needs live Bearer).
   * Must keep activeRouteId so unfinished drawers/forms are not closed or remounted.
   */
  async function unlockWithPassword(password) {
    const username = state.principal?.username || state.form.username?.trim();
    if (!username) {
      throw new Error(state.authExperience.messages.requireLoginError);
    }
    if (password == null || String(password).trim() === '') {
      throw new Error(state.authExperience.messages.sessionUnlockPasswordRequired);
    }
    const attributes = {
      'Visitor-Terminal': 'BUSINESS',
      deviceId: resolveBrickLoginDeviceId(),
    };
    // Capture before login rehydrate; prefer live route then sessionStorage memory.
    const previousRouteId = (state.activeRouteId && state.activeRouteId !== 'login'
      ? state.activeRouteId
      : readBrickConsoleActiveRouteId()) || '';
    if (previousRouteId) {
      writeBrickConsoleActiveRouteId(previousRouteId);
    }
    const result = await authRequestClient.request('/brick/login', {
      method: 'POST',
      body: JSON.stringify({
        username,
        password: String(password),
        loginType: state.loginType || 'username-password',
        attributes,
      }),
      anonymous: true,
      transportProtected: true,
    });
    await acceptAuthenticatedSession(result, { preserveRouteId: previousRouteId });
    if (previousRouteId && !state.mfaPending && !state.passwordChangeRequired) {
      // Pin again after shell rehydrate (path + sessionStorage) so open forms stay mounted.
      state.activeRouteId = previousRouteId;
      writeBrickConsoleActiveRouteId(previousRouteId);
    }
    showStatus(state.authExperience.messages.sessionResumed, 'success');
    return result;
  }

  function adoptExpirationStrategy(strategy) {
    state.expirationStrategy = persistExpirationStrategy(strategy);
    return state.expirationStrategy;
  }

  function requireToken() {
    if (!state.token) {
      throw new Error(state.authExperience.messages.requireLoginError);
    }
  }

  function clearSession(message = state.authExperience.messages.sessionAnonymous) {
    state.token = '';
    state.refreshToken = '';
    state.principal = null;
    state.pendingPrincipal = null;
    state.permissions = [];
    state.currentPrincipalWorkspace = null;
    state.passwordChangeRequired = false;
    state.passwordLifecycle = null;
    state.passwordAction = '';
    state.passwordWarning = null;
    state.passwordReminderVisible = false;
    state.passwordChangeEditorVisible = false;
    state.sessionRecovery = SessionRecovery.NONE;
    setBrickSessionRecoveryUiActive(false);
    state.form.currentPassword = '';
    state.form.newPassword = '';
    state.form.confirmNewPassword = '';
    state.form.mfaCode = '';
    state.authScreen = AuthScreen.FIRST_FACTOR;
    state.activeRouteId = 'login';
    writeBrickConsoleActiveRouteId('');
    clearStoredSession();
    clearMfaState(state);
    showStatus(message, 'info');
  }

  function adoptPasswordChangeRequiredState(error) {
    state.passwordChangeRequired = true;
    state.passwordReminderVisible = false;
    state.passwordChangeEditorVisible = true;
    state.authScreen = AuthScreen.PASSWORD;
    state.activeRouteId = 'login';
    state.sessionRecovery = SessionRecovery.NONE;
    state.passwordLifecycle = readPasswordLifecycle({
      'Password-Change-Required': 'true',
      'Password-Change-Reason': error.headers?.get('Password-Change-Reason') || '',
      'Password-Expired': error.headers?.get('Password-Expired') || '',
    });
  }

  function composeAuthSummary() {
    const parts = [];
    if (state.authScreen === AuthScreen.FIRST_FACTOR) {
      parts.push(state.authExperience.controls.firstFactorSummary);
      if (state.captcha?.required) {
        parts.push(formatMessage('captchaTriggeredHint', {
          captchaTitle: state.authExperience.controls.captchaTitle,
        }));
      }
    }
    if (state.authScreen === AuthScreen.MFA) {
      parts.push(state.authExperience.controls.mfaStepSummary);
      if (state.mfaChallenge?.channel) {
        parts.push(formatMessage('mfaChannelHint', {
          channel: describeMfaChannel(state.mfaChallenge.channel),
        }));
      }
    }
    if (state.authScreen === AuthScreen.PASSWORD) {
      parts.push(
        state.passwordChangeRequired
          ? state.authExperience.controls.passwordLifecycleBlockSummary
          : state.authExperience.controls.passwordLifecycleRemindSummary,
      );
    }
    if (state.passwordLifecycle) {
      parts.push(state.passwordLifecycle);
    }
    if (state.passwordWarning) {
      parts.push(state.passwordWarning);
    }
    return parts.filter(Boolean).join(' ');
  }

  function readPasswordLifecycle(attributes) {
    const changeRequired = attributes?.['Password-Change-Required'] === 'true';
    const reason = String(attributes?.['Password-Change-Reason'] || '').trim();
    const labels = {
      INITIAL_PASSWORD: state.authExperience.messages.passwordReasonInitialPassword,
      INITIAL_PASSWORD_EXPIRED: state.authExperience.messages.passwordReasonInitialPasswordExpired,
      PERIODIC_EXPIRED: state.authExperience.messages.passwordReasonPeriodicExpired,
      ADMIN_RESET: state.authExperience.messages.passwordReasonAdminReset,
      WEAK_PASSWORD: state.authExperience.messages.passwordReasonWeakPassword,
    };
    if (changeRequired && labels[reason]) {
      return labels[reason];
    }
    if (changeRequired && attributes?.['Password-Expired'] === 'true') {
      return state.authExperience.messages.passwordExpiredFallback;
    }
    if (changeRequired) {
      return state.authExperience.messages.passwordChangeRequiredFallback;
    }
    const noticeReason = String(attributes?.['Password-Notice-Reason'] || '').trim();
    if (noticeReason === 'PERIODIC_EXPIRING_SOON') {
      const daysRemaining = String(attributes?.['Password-Notice-Days-Remaining'] || '').trim();
      return daysRemaining
        ? formatMessage('passwordNoticeWithDays', { days: daysRemaining })
        : state.authExperience.messages.passwordNoticeFallback;
    }
    return null;
  }

  function readPasswordWarning(attributes) {
    if (attributes?.['Password-Warning'] !== 'true') {
      return null;
    }
    const violations = String(attributes?.['Password-Violations'] || '')
      .split(',')
      .map((item) => item.trim())
      .filter(Boolean)
      .map(describePasswordViolation);
    if (!violations.length) {
      return state.authExperience.messages.passwordWarningGeneric;
    }
    return formatMessage('passwordWarningTemplate', {
      violations: violations.join(state.authExperience.messages.listJoinSep),
    });
  }

  function describePasswordViolation(code) {
    const labels = {
      'brick.password.too-short': state.authExperience.messages.passwordViolationTooShort,
      'brick.password.too-long': state.authExperience.messages.passwordViolationTooLong,
      'brick.password.missing-uppercase': state.authExperience.messages.passwordViolationMissingUppercase,
      'brick.password.missing-lowercase': state.authExperience.messages.passwordViolationMissingLowercase,
      'brick.password.missing-digit': state.authExperience.messages.passwordViolationMissingDigit,
      'brick.password.missing-special': state.authExperience.messages.passwordViolationMissingSpecial,
      'brick.password.weak': state.authExperience.messages.passwordViolationWeak,
    };
    return labels[code] || code;
  }

  function describeMfaChannel(channel) {
    const normalizedChannel = String(channel || '').trim().toUpperCase();
    if (normalizedChannel === 'EMAIL') {
      return state.authExperience.messages.mfaChannelEmail;
    }
    if (normalizedChannel === 'SMS') {
      return state.authExperience.messages.mfaChannelSms;
    }
    return channel;
  }

  function formatMessage(key, values = {}) {
    const template = state.authExperience.messages?.[key] || defaultAuthExperience.messages[key] || '';
    return Object.entries(values).reduce(
      (message, [field, value]) => message.replaceAll(`{${field}}`, value),
      template,
    );
  }

  function readTerminalMessage(error, strategy = 'LOGIN_OUT') {
    const fixed = strategy === 'SCREEN_LOCK'
      ? (state.authExperience.messages.sessionLocked || state.authExperience.messages.sessionExpired)
      : (state.authExperience.messages.sessionExpired || state.authExperience.messages.sessionAnonymous);

    const payload = (typeof error?.payload === 'object' && error.payload)
      || (typeof error?.body === 'object' && error.body)
      || null;
    const recovery = typeof payload?.recovery === 'string' ? payload.recovery.trim() : '';
    // Only surface server recovery when it is actionable task language (CJK / known i18n),
    // never bare English technical tokens like "at expired" or HTTP status text.
    if (recovery && isUserFacingTerminalCopy(recovery)) {
      return recovery;
    }
    return fixed;
  }

  function isUserFacingTerminalCopy(text) {
    if (!text || /^HTTP\s+\d{3}$/i.test(text)) {
      return false;
    }
    // CJK task language from server i18n.
    if (/[\u3400-\u9FFF]/.test(text)) {
      return true;
    }
    // Short English technical blobs (token codes, raw exception text) stay out of UI.
    if (text.length < 12 || !/\s/.test(text)) {
      return false;
    }
    // Reject obvious non-user technical fragments.
    if (/\b(at|rt|jwt|token|expired|unauthorized|null|undefined)\b/i.test(text)
      && !/\b(please|sign|log|session|password|continue|unlock)\b/i.test(text)) {
      return false;
    }
    return true;
  }

  return {
    currentLoginMode,
    screenTitle,
    canDismissPasswordReminder,
    authAlertText,
    sessionUserName,
    isAuthenticated,
    isAuthFocus,
    isSessionLocked,
    isSessionRecoveryActive,
    bootstrapAuthState,
    applyLoginMode,
    login,
    loadCaptcha,
    sendMfaVerificationCode,
    completeMfaVerification,
    completePasswordChange,
    changeOwnPassword,
    dismissPasswordReminder,
    openPasswordChangeEditor,
    logout,
    clearSession,
    adoptPasswordChangeRequiredState,
    adoptFederatedLoginResult,
    trySilentRefresh,
    handleSessionTerminal,
    unlockWithPassword,
    adoptExpirationStrategy,
    softSuspend,
  };
}
