<script setup>
/**
 * Default IAM auth flow page for upper application shells.
 *
 * Brand/layout: runtime `client-meta.capabilities.loginBrand` (deployment config)
 * with optional prop overrides. Layout uses controlled presets (form + brand positions),
 * not free-form CSS injection.
 *
 * App version: client-meta identity fields / prop override.
 */
import { computed, onMounted, ref, unref, watch } from 'vue';
import {
  formatBrickClientAppVersionLabel,
  loadBrickClientMeta,
} from '@wildbuck/core-client-meta-frontend';
import { AuthScreen } from '../auth-state.js';
import { applyLoginBrandBrowserChrome, normalizeLoginBrand } from '../login-brand.js';

const props = defineProps({
  app: { type: Object, required: true },
  /**
   * Full client-meta loginBrand capability already loaded by the shell bootstrap.
   * When set, first paint uses this brand (layout/logo/colors) — avoids default→brand FOUC.
   */
  initialLoginBrand: { type: Object, default: null },
  /** Fallback product name when loginBrand has no systemName. */
  brandTitle: { type: String, default: '' },
  /** Fallback short mark when loginBrand has no logo/mark. */
  brandMark: { type: String, default: '' },
  /** Fallback description/subtitle. */
  brandSubtitle: { type: String, default: '' },
  primaryButtonType: { type: String, default: 'primary' },
  appVersion: { type: String, default: '' },
  buildId: { type: String, default: '' },
  brickVersion: { type: String, default: '' },
  includeAppCodeInVersion: { type: Boolean, default: false },
  includeBrickVersion: { type: Boolean, default: false },
});

function readAppField(field) {
  return unref(props.app?.[field]);
}

const state = computed(() => props.app.state);
const controls = computed(() => props.app.state.authExperience.controls);
const currentLoginMode = computed(() => {
  const mode = readAppField('currentLoginMode');
  return mode && typeof mode === 'object' ? mode : {};
});
const canDismissPasswordReminder = computed(() => Boolean(readAppField('canDismissPasswordReminder')));

/** Step eyebrow only when flow is multi-step (MFA / password lifecycle). First-factor stays quiet. */
const stageBadge = computed(() => {
  if (state.value.authScreen === AuthScreen.MFA) {
    return controls.value.mfaEyebrow;
  }
  if (state.value.authScreen === AuthScreen.PASSWORD) {
    return controls.value.passwordLifecycleEyebrow;
  }
  return '';
});
const panelTitle = computed(() => {
  if (state.value.authScreen === AuthScreen.MFA) {
    return controls.value.mfaCodePlaceholder;
  }
  if (state.value.authScreen === AuthScreen.PASSWORD) {
    return controls.value.panelTitlePassword;
  }
  // First factor: brand already carries product identity; avoid duplicate marketing copy.
  return '';
});
const panelDescription = computed(() => {
  if (state.value.authScreen === AuthScreen.MFA) {
    const channel = String(state.value.mfaChallenge?.channel || '').trim().toUpperCase();
    if (channel === 'EMAIL') {
      return controls.value.panelDescMfaEmail;
    }
    if (channel === 'SMS') {
      return controls.value.panelDescMfaSms;
    }
    return controls.value.panelDescMfaGeneric;
  }
  if (state.value.authScreen === AuthScreen.PASSWORD) {
    if (state.value.passwordChangeRequired) {
      return controls.value.panelDescPasswordBlock;
    }
    if (state.value.passwordLifecycle || state.value.passwordWarning) {
      return controls.value.panelDescPasswordRemind;
    }
    return controls.value.panelDescPasswordSelfService || controls.value.panelDescPasswordRemind;
  }
  return '';
});
const showPanelCopy = computed(() => Boolean(stageBadge.value || panelTitle.value || panelDescription.value));

const runtimeIdentity = ref({
  appCode: undefined,
  appVersion: undefined,
  buildId: undefined,
  brickVersion: undefined,
});
// Prefer shell-prefetched capability so first paint is the configured brand (no default flash).
const runtimeLoginBrand = ref(normalizeLoginBrand(props.initialLoginBrand));
/** 已启用身份源公开列表（sourceKey/displayName/logo/sourceType）。 */
const enabledIdentitySources = ref([]);
const federatedLoginError = ref('');
const federatedBusy = ref(false);
const federatedBusyLabel = ref('');
const federatedCompleting = ref(false);
/**
 * When the business shell does not pass initialLoginBrand, hold the auth form until
 * client-meta resolves — otherwise operators see default layout then brand (FOUC).
 * Validation shell passes initialLoginBrand after bootstrap; brandReady starts true there.
 */
const brandReady = ref(props.initialLoginBrand != null);

const loginBrand = computed(() => {
  const remote = runtimeLoginBrand.value;
  // Props fill gaps when remote brand disabled or missing fields.
  if (!remote.enabled) {
    const hasPropBrand = Boolean(props.brandTitle || props.brandMark || props.brandSubtitle);
    if (!hasPropBrand) {
      return remote;
    }
    return normalizeLoginBrand({
      enabled: true,
      systemName: props.brandTitle,
      description: props.brandSubtitle,
      brandMark: props.brandMark,
      formPosition: 'CENTER',
      brandPosition: 'ABOVE_FORM',
      backgroundMode: 'NONE',
    });
  }
  return normalizeLoginBrand({
    ...remote,
    systemName: remote.systemName || props.brandTitle || '',
    description: remote.description || props.brandSubtitle || '',
    brandMark: remote.brandMark || props.brandMark || '',
  });
});

watch(
  () => props.initialLoginBrand,
  (capability) => {
    if (capability != null) {
      runtimeLoginBrand.value = normalizeLoginBrand(capability);
      brandReady.value = true;
    }
  },
  { deep: true },
);

const showBrandContent = computed(() => {
  const brand = loginBrand.value;
  return Boolean(brand.systemName || brand.description || brand.logoUrl || brand.brandMark);
});

const brandPosition = computed(() => loginBrand.value.brandPosition);
const formPosition = computed(() => loginBrand.value.formPosition);
const isSplitLayout = computed(() => (
  brandPosition.value === 'LEFT_PANEL' || brandPosition.value === 'RIGHT_PANEL'
));
const brandInFormCard = computed(() => (
  brandPosition.value === 'ABOVE_FORM' || brandPosition.value === 'BELOW_FORM'
));

const shellClass = computed(() => ([
  'auth-shell',
  `auth-form-${formPosition.value.toLowerCase()}`,
  `auth-brand-${brandPosition.value.toLowerCase().replaceAll('_', '-')}`,
  isSplitLayout.value ? 'auth-shell-split' : 'auth-shell-single',
]));

const shellStyle = computed(() => {
  const brand = loginBrand.value;
  const style = {};
  // Empty primaryColor = follow shell/console theme (--primary-button-*, --el-color-primary).
  if (brand.primaryColor) {
    const primary = brand.primaryColor;
    const hover = `color-mix(in srgb, ${primary} 88%, #000)`;
    const active = `color-mix(in srgb, ${primary} 80%, #000)`;
    // Custom auth token + Element Plus button tokens.
    style['--auth-primary'] = primary;
    style['--el-color-primary'] = primary;
    style['--el-button-bg-color'] = primary;
    style['--el-button-border-color'] = primary;
    style['--el-button-hover-bg-color'] = hover;
    style['--el-button-hover-border-color'] = hover;
    style['--el-button-active-bg-color'] = active;
    style['--el-button-active-border-color'] = active;
    // Upper shells (e.g. security-console) map primary buttons via --primary-button-*;
    // inherit onto the button so their higher-specificity rules still resolve to brand.
    style['--primary-button-bg'] = primary;
    style['--primary-button-border'] = primary;
    style['--primary-button-hover'] = hover;
  }
  if (brand.backgroundMode === 'SOLID' && brand.backgroundColor) {
    style.background = brand.backgroundColor;
  } else if (brand.backgroundMode === 'SOFT_GRADIENT') {
    const base = brand.backgroundColor || '#0f172a';
    style.background = `linear-gradient(145deg, ${base} 0%, color-mix(in srgb, ${base} 55%, #1e293b) 48%, #020617 100%)`;
  } else if (brand.backgroundMode === 'IMAGE' && brand.backgroundImageUrl) {
    style.backgroundImage = `linear-gradient(180deg, rgba(15,23,42,0.35), rgba(15,23,42,0.55)), url(${JSON.stringify(brand.backgroundImageUrl).slice(1, -1)})`;
    style.backgroundSize = 'cover';
    style.backgroundPosition = 'center';
    style.backgroundRepeat = 'no-repeat';
  }
  return style;
});

const versionFooterText = computed(() => {
  const propVersion = String(props.appVersion || '').trim();
  const identity = propVersion
    ? {
        appCode: runtimeIdentity.value.appCode,
        appVersion: propVersion,
        buildId: String(props.buildId || '').trim() || runtimeIdentity.value.buildId,
        brickVersion: String(props.brickVersion || '').trim() || runtimeIdentity.value.brickVersion,
      }
    : {
        appCode: runtimeIdentity.value.appCode,
        appVersion: runtimeIdentity.value.appVersion,
        buildId: String(props.buildId || '').trim() || runtimeIdentity.value.buildId,
        brickVersion: String(props.brickVersion || '').trim() || runtimeIdentity.value.brickVersion,
      };
  return formatBrickClientAppVersionLabel(identity, {
    versionLabel: controls.value.versionLabel || '版本',
    includeAppCode: props.includeAppCodeInVersion,
    includeBrickVersion: props.includeBrickVersion,
  });
});

// Do not restore tab/favicon on unmount: deployment brand should stay after login and across logout remounts.
// Restoring would flash the static HTML default ("Brick") between auth ↔ shell transitions.
watch(
  loginBrand,
  (brand) => {
    if (!brandReady.value) {
      return;
    }
    applyLoginBrandBrowserChrome(brand, {
      fallbackTitle: props.brandTitle || '',
    });
  },
  { immediate: true, deep: true },
);

async function loadEnabledIdentitySources() {
  try {
    const response = await fetch('/brick/auth/oauth2/enabled-sources', { method: 'GET' });
    if (!response.ok) {
      enabledIdentitySources.value = [];
      return;
    }
    const body = await response.json();
    const list = Array.isArray(body) ? body : (Array.isArray(body?.data) ? body.data : []);
    enabledIdentitySources.value = list.filter((item) => item && item.sourceKey && item.displayName);
  } catch {
    enabledIdentitySources.value = [];
  }
}

function federatedSourceType(source) {
  return String(source?.sourceType || '').trim().toUpperCase();
}

function federatedPrimaryLabel(source) {
  const type = federatedSourceType(source);
  const name = source?.displayName || '企业身份源';
  if (type === 'DINGTALK') {
    return name.includes('钉钉') ? `${name}扫码登录` : `钉钉扫码 · ${name}`;
  }
  if (type === 'GITHUB') {
    return `使用 ${name} 继续`;
  }
  if (type === 'CAS') {
    return `使用 ${name} 登录`;
  }
  return `使用 ${name} 登录`;
}

function federatedSecondaryLabel(source) {
  const type = federatedSourceType(source);
  if (type === 'DINGTALK') {
    return '打开钉钉扫一扫，安全快捷完成登录';
  }
  if (type === 'GITHUB') {
    return '跳转 GitHub 授权后返回本系统';
  }
  return '跳转企业身份提供商完成认证';
}

function federatedGlyph(source) {
  const type = federatedSourceType(source);
  if (type === 'DINGTALK') return '钉';
  if (type === 'GITHUB') return 'GH';
  if (type === 'CAS') return 'CA';
  if (type === 'OAUTH2') return 'O2';
  const name = String(source?.displayName || '?').trim();
  return name ? name.slice(0, 1) : '企';
}

function federatedButtonClass(source) {
  const type = federatedSourceType(source);
  return [
    'auth-federated-btn',
    type === 'DINGTALK' ? 'auth-federated-btn--dingtalk' : '',
    type === 'GITHUB' ? 'auth-federated-btn--github' : '',
    type && type !== 'DINGTALK' && type !== 'GITHUB' ? 'auth-federated-btn--generic' : '',
  ].filter(Boolean);
}

function startFederatedLogin(source) {
  federatedLoginError.value = '';
  const rawKey = typeof source === 'string' ? source : source?.sourceKey;
  const key = encodeURIComponent(String(rawKey || '').trim());
  if (!key) {
    return;
  }
  const type = typeof source === 'object' ? federatedSourceType(source) : '';
  federatedBusy.value = true;
  federatedBusyLabel.value = type === 'DINGTALK'
    ? '正在打开钉钉扫码…'
    : '正在跳转企业身份源…';
  // 回跳必须落在「匿名可 GET 的 SPA 文档」上，再由前端用 federatedTicket 换 token。
  // 若把当前管理深链（如 /identity-federation/auth-sources）当 returnUrl，未登记 SPA fallback 时会先 401 JSON，
  // complete 永远不执行——用户只看到「未登录或登录已过期」。
  const returnUrl = encodeURIComponent('/');
  const authorizeBase = type === 'CAS'
    ? `/brick/auth/cas/${key}/authorize`
    : `/brick/auth/oauth2/${key}/authorize`;
  const target = `${authorizeBase}?purpose=LOGIN&returnUrl=${returnUrl}`;
  // 先让 busy 态完成一帧绘制，再跳转（避免无反馈闪切）
  requestAnimationFrame(() => {
    window.setTimeout(() => {
      window.location.assign(target);
    }, 80);
  });
}

async function completeFederatedTicketIfPresent() {
  const params = new URLSearchParams(window.location.search || '');
  const ticket = params.get('federatedTicket');
  if (!ticket) {
    return;
  }
  const protocol = params.get('federatedProtocol') === 'cas' ? 'cas' : 'oauth2';
  federatedLoginError.value = '';
  federatedCompleting.value = true;
  federatedBusyLabel.value = '正在完成企业登录…';
  try {
    const response = await fetch(protocol === 'cas' ? '/brick/auth/cas/complete' : '/brick/auth/oauth2/complete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ ticket }),
    });
    const raw = await response.json().catch(() => ({}));
    // 兼容裸 Map 与 BrickApiResponse 信封
    const body = raw && typeof raw === 'object' && raw.data && (raw.category || raw.code)
      ? raw.data
      : raw;
    if (!response.ok || !body?.accessToken) {
      federatedLoginError.value = raw?.recovery || raw?.message || body?.recovery || body?.message
        || '身份源登录失败，请重试或联系管理员。';
      return;
    }
    if (typeof props.app?.adoptFederatedLoginResult === 'function') {
      await props.app.adoptFederatedLoginResult(body);
    } else if (typeof props.app?.adoptLoginResult === 'function') {
      await props.app.adoptLoginResult(body);
    } else {
      // 兼容仅暴露 state 的壳：直接写入 token
      if (props.app?.state) {
        props.app.state.token = body.accessToken;
        props.app.state.principal = body.principal || null;
      }
    }
    params.delete('federatedTicket');
    const next = `${window.location.pathname}${params.toString() ? `?${params}` : ''}${window.location.hash || ''}`;
    window.history.replaceState({}, '', next);
  } catch {
    federatedLoginError.value = '身份源登录完成失败，请重新发起登录。';
  } finally {
    federatedCompleting.value = false;
  }
}

onMounted(() => {
  // Shell bootstrap already applied brand when initialLoginBrand is set; only refresh identity
  // (and brand if shell did not prefetch) so slow networks never paint the unconfigured layout first.
  loadBrickClientMeta()
    .then((meta) => {
      runtimeIdentity.value = {
        appCode: meta.appCode,
        appVersion: meta.appVersion,
        buildId: meta.buildId,
        brickVersion: meta.brickVersion,
      };
      const next = normalizeLoginBrand(meta.capabilities?.loginBrand);
      // Avoid redundant reactive churn when shell already supplied the same brand.
      if (!props.initialLoginBrand || next.enabled) {
        runtimeLoginBrand.value = next;
      }
    })
    .catch(() => {
      // Keep shell-prefetched brand or prop fallbacks.
    })
    .finally(() => {
      brandReady.value = true;
    });
  void loadEnabledIdentitySources();
  void completeFederatedTicketIfPresent();
});
</script>

<template>
  <div
    v-if="!brandReady"
    class="auth-shell auth-shell-brand-loading"
    data-testid="auth-brand-loading"
    aria-busy="true"
  >
    <div class="auth-brand-loading-card" aria-hidden="true" />
  </div>
  <div v-else :class="shellClass" :style="shellStyle" data-testid="auth-shell">
    <div
      v-if="brandPosition === 'TOP_BAR' && showBrandContent"
      class="auth-top-bar"
      data-testid="auth-brand-top-bar"
    >
      <img
        v-if="loginBrand.logoUrl"
        class="auth-logo auth-logo-bar"
        :src="loginBrand.logoUrl"
        alt=""
      >
      <div v-else-if="loginBrand.brandMark" class="shell-brand-mark" aria-hidden="true">
        {{ loginBrand.brandMark }}
      </div>
      <div class="auth-top-bar-copy">
        <strong v-if="loginBrand.systemName">{{ loginBrand.systemName }}</strong>
        <span v-if="loginBrand.description">{{ loginBrand.description }}</span>
      </div>
    </div>

    <div class="auth-stage-frame">
      <aside
        v-if="isSplitLayout && showBrandContent"
        class="auth-brand-panel"
        data-testid="auth-brand-panel"
      >
        <img
          v-if="loginBrand.logoUrl"
          class="auth-logo auth-logo-panel"
          :src="loginBrand.logoUrl"
          alt=""
        >
        <div v-else-if="loginBrand.brandMark" class="shell-brand-mark auth-panel-mark" aria-hidden="true">
          {{ loginBrand.brandMark }}
        </div>
        <h2 v-if="loginBrand.systemName" class="auth-panel-title">{{ loginBrand.systemName }}</h2>
        <p v-if="loginBrand.description" class="auth-panel-desc">{{ loginBrand.description }}</p>
      </aside>

      <section class="auth-stage-layout auth-stage-layout-minimal">
        <el-card shadow="never" class="auth-card-body auth-stage-card auth-stage-card-minimal">
          <div
            v-if="brandInFormCard && brandPosition === 'ABOVE_FORM' && showBrandContent"
            class="auth-brand-strip auth-brand-strip-minimal"
            data-testid="auth-brand-above"
          >
            <img
              v-if="loginBrand.logoUrl"
              class="auth-logo auth-logo-inline"
              :src="loginBrand.logoUrl"
              alt=""
            >
            <div v-else-if="loginBrand.brandMark" class="shell-brand-mark" aria-hidden="true">
              {{ loginBrand.brandMark }}
            </div>
            <div v-if="loginBrand.systemName || loginBrand.description" class="auth-brand-copy auth-brand-copy-minimal">
              <strong v-if="loginBrand.systemName">{{ loginBrand.systemName }}</strong>
              <span v-if="loginBrand.description" class="auth-brand-subtitle">{{ loginBrand.description }}</span>
            </div>
          </div>

          <div v-if="showPanelCopy" class="auth-panel-copy auth-panel-copy-minimal">
            <p v-if="stageBadge" class="auth-panel-kicker">{{ stageBadge }}</p>
            <h1 v-if="panelTitle">{{ panelTitle }}</h1>
            <p v-if="panelDescription">{{ panelDescription }}</p>
          </div>

          <section v-if="state.authScreen === AuthScreen.FIRST_FACTOR">
            <div class="auth-stage-grid auth-stage-grid-form">
              <el-form label-position="top" class="auth-form auth-form-compact" @submit.prevent="app.login">
                <el-form-item :label="currentLoginMode.identityLabel">
                  <el-input
                    v-model="state.form.username"
                    size="large"
                    autocomplete="username"
                    :placeholder="currentLoginMode.identityPlaceholder"
                    @blur="app.loadCaptcha"
                  />
                </el-form-item>

                <el-form-item :label="currentLoginMode.credentialLabel">
                  <el-input
                    v-model="state.form.password"
                    size="large"
                    type="password"
                    show-password
                    autocomplete="current-password"
                    :placeholder="currentLoginMode.credentialPlaceholder"
                  />
                </el-form-item>

                <div v-if="state.captcha?.required" class="captcha-panel">
                  <div class="captcha-panel-header">
                    <strong>{{ controls.captchaTitle }}</strong>
                    <el-button text type="primary" @click="app.loadCaptcha">
                      {{ controls.captchaRefreshButton }}
                    </el-button>
                  </div>
                  <div class="captcha-panel-body">
                    <img
                      v-if="state.captcha?.imageBase64"
                      class="captcha-image"
                      :src="`data:image/png;base64,${state.captcha.imageBase64}`"
                      :alt="controls.captchaAlt"
                    >
                    <el-input
                      v-model="state.form.captchaCode"
                      size="large"
                      :placeholder="controls.captchaPlaceholder"
                    />
                  </div>
                </div>

                <el-button class="auth-submit" :type="primaryButtonType" size="large" native-type="submit">
                  {{ controls.loginSubmitButton }}
                </el-button>
              </el-form>

              <div
                v-if="enabledIdentitySources.length"
                class="auth-federated"
                data-testid="auth-federated-sources"
              >
                <div class="auth-federated-divider" role="separator">
                  <span class="auth-federated-divider-line" aria-hidden="true" />
                  <span class="auth-federated-divider-text">企业登录</span>
                  <span class="auth-federated-divider-line" aria-hidden="true" />
                </div>
                <button
                  v-for="source in enabledIdentitySources"
                  :key="source.sourceKey"
                  type="button"
                  :class="federatedButtonClass(source)"
                  :data-testid="`auth-federated-${source.sourceKey}`"
                  :data-source-type="federatedSourceType(source) || undefined"
                  :disabled="federatedBusy || federatedCompleting"
                  @click="startFederatedLogin(source)"
                >
                  <span
                    class="auth-federated-mark"
                    :class="{ 'auth-federated-mark--logo': Boolean(source.logoContentUrl) }"
                    aria-hidden="true"
                  >
                    <img
                      v-if="source.logoContentUrl"
                      class="auth-federated-logo"
                      :src="source.logoContentUrl"
                      alt=""
                    >
                    <span v-else class="auth-federated-glyph">{{ federatedGlyph(source) }}</span>
                  </span>
                  <span class="auth-federated-copy">
                    <span class="auth-federated-title">{{ federatedPrimaryLabel(source) }}</span>
                    <span class="auth-federated-subtitle">{{ federatedSecondaryLabel(source) }}</span>
                  </span>
                  <span class="auth-federated-chevron" aria-hidden="true">›</span>
                </button>
              </div>
              <p v-if="federatedLoginError" class="auth-federated-error" role="alert">
                {{ federatedLoginError }}
              </p>
              <div
                v-if="federatedBusy || federatedCompleting"
                class="auth-federated-busy"
                data-testid="auth-federated-busy"
                role="status"
                aria-live="polite"
              >
                <span class="auth-federated-busy-spinner" aria-hidden="true" />
                <span>{{ federatedBusyLabel || '处理中…' }}</span>
              </div>
            </div>
          </section>

          <section v-else-if="state.authScreen === AuthScreen.MFA">
            <div class="auth-stage-grid auth-stage-grid-form">
              <el-form label-position="top" class="auth-form auth-form-compact" @submit.prevent="app.completeMfaVerification">
                <el-form-item :label="controls.mfaCodeLabel">
                  <el-input
                    v-model="state.form.mfaCode"
                    size="large"
                    :placeholder="controls.mfaCodePlaceholder"
                  >
                    <template #append>
                      <el-button @click="app.sendMfaVerificationCode">
                        {{ controls.mfaSendButton }}
                      </el-button>
                    </template>
                  </el-input>
                </el-form-item>

                <el-button class="auth-submit" :type="primaryButtonType" size="large" native-type="submit">
                  {{ controls.mfaCompleteButton }}
                </el-button>
              </el-form>
            </div>
          </section>

          <section v-else>
            <div class="auth-stage-grid auth-stage-grid-form password-dialog-card">
              <el-alert
                v-if="state.passwordLifecycle || state.passwordWarning"
                class="auth-inline-alert"
                type="warning"
                :closable="false"
                :title="state.passwordLifecycle || state.passwordWarning"
              />

              <el-form label-position="top" class="auth-form auth-form-compact" @submit.prevent="app.completePasswordChange">
                <el-form-item :label="controls.currentPasswordLabel">
                  <el-input
                    v-model="state.form.currentPassword"
                    type="password"
                    show-password
                    size="large"
                    :placeholder="controls.currentPasswordPlaceholder"
                  />
                </el-form-item>
                <el-form-item :label="controls.newPasswordLabel">
                  <el-input
                    v-model="state.form.newPassword"
                    type="password"
                    show-password
                    size="large"
                    :placeholder="controls.newPasswordPlaceholder"
                  />
                </el-form-item>
                <el-form-item :label="controls.confirmNewPasswordLabel">
                  <el-input
                    v-model="state.form.confirmNewPassword"
                    type="password"
                    show-password
                    size="large"
                    :placeholder="controls.confirmNewPasswordPlaceholder"
                  />
                </el-form-item>

                <div class="auth-actions">
                  <el-button
                    v-if="canDismissPasswordReminder"
                    @click="app.dismissPasswordReminder"
                  >
                    {{ controls.passwordLifecycleDismissButton }}
                  </el-button>
                  <el-button class="auth-submit-inline" :type="primaryButtonType" native-type="submit">
                    {{ controls.passwordChangeSubmitButton }}
                  </el-button>
                </div>
              </el-form>
            </div>
          </section>

          <div
            v-if="brandInFormCard && brandPosition === 'BELOW_FORM' && showBrandContent"
            class="auth-brand-strip auth-brand-below"
            data-testid="auth-brand-below"
          >
            <strong v-if="loginBrand.systemName">{{ loginBrand.systemName }}</strong>
            <span v-if="loginBrand.description">{{ loginBrand.description }}</span>
          </div>

          <p
            v-if="loginBrand.footerText"
            class="auth-brand-footer"
            data-testid="auth-brand-footer"
          >
            {{ loginBrand.footerText }}
          </p>
          <p
            v-if="versionFooterText"
            class="auth-version-footer"
            data-testid="auth-version-footer"
          >
            {{ versionFooterText }}
          </p>
        </el-card>
      </section>
    </div>
  </div>
</template>

<style scoped>
/* 企业 SSO 一等入口：品牌识别 + 主副文案 + busy 态（控制体积，避免玩具感灰边按钮） */
.auth-federated { margin-top: 20px; display: grid; gap: 12px; }
.auth-federated-divider {
  display: grid; grid-template-columns: 1fr auto 1fr; align-items: center; gap: 10px;
}
.auth-federated-divider-line {
  height: 1px; background: linear-gradient(90deg, transparent, #d8e0ea 20%, #d8e0ea 80%, transparent);
}
.auth-federated-divider-text { color: #64748b; font-size: 12px; font-weight: 600; letter-spacing: .06em; }
.auth-federated-btn {
  display: grid; grid-template-columns: auto 1fr auto; align-items: center; gap: 12px;
  width: 100%; min-height: 56px; padding: 10px 14px; border: 1px solid #dbe3ee; border-radius: 12px;
  background: linear-gradient(180deg, #fff, #f8fafc); box-shadow: 0 1px 2px rgba(15, 23, 42, .04);
  cursor: pointer; font: inherit; text-align: left;
  transition: border-color .15s ease, box-shadow .15s ease;
}
.auth-federated-btn:hover:not(:disabled) {
  border-color: #bfdbfe; box-shadow: 0 8px 20px rgba(37, 99, 235, .08);
}
.auth-federated-btn:focus-visible { outline: 2px solid #2563eb; outline-offset: 2px; }
.auth-federated-btn--dingtalk:focus-visible { outline-color: #0089ff; }
.auth-federated-btn:disabled { opacity: .72; cursor: wait; }
.auth-federated-btn--dingtalk {
  border-color: #9fd0ff; background: linear-gradient(180deg, #f3f9ff, #e8f4ff);
}
.auth-federated-btn--dingtalk:hover:not(:disabled) {
  border-color: #0089ff; box-shadow: 0 10px 22px rgba(0, 137, 255, .14);
}
.auth-federated-btn--github { border-color: #d0d7de; background: linear-gradient(180deg, #fff, #f6f8fa); }
.auth-federated-btn--generic { border-color: #c7d2fe; background: linear-gradient(180deg, #f8faff, #eef2ff); }
.auth-federated-mark {
  display: inline-flex; align-items: center; justify-content: center;
  width: 36px; height: 36px; border-radius: 10px; background: #fff;
  border: 1px solid rgba(15, 23, 42, .06); overflow: hidden; flex-shrink: 0;
}
/* 无 logo：品牌色字标；有 logo：白底避免彩标被染没 */
.auth-federated-btn--dingtalk .auth-federated-mark:not(.auth-federated-mark--logo) {
  background: #0089ff; border-color: #0089ff; color: #fff;
}
.auth-federated-btn--github .auth-federated-mark:not(.auth-federated-mark--logo) {
  background: #24292f; border-color: #24292f; color: #fff;
}
.auth-federated-logo { width: 22px; height: 22px; object-fit: contain; }
.auth-federated-glyph { font-size: 13px; font-weight: 700; line-height: 1; }
.auth-federated-copy { display: grid; gap: 2px; min-width: 0; }
.auth-federated-title { color: #0f172a; font-size: 14px; font-weight: 600; line-height: 1.3; }
.auth-federated-subtitle { color: #64748b; font-size: 12px; line-height: 1.35; }
.auth-federated-chevron { color: #94a3b8; font-size: 22px; line-height: 1; }
.auth-federated-btn--dingtalk .auth-federated-chevron { color: #0089ff; }
.auth-federated-error {
  margin: 10px 0 0; padding: 10px 12px; border-radius: 10px;
  background: #fef3f2; border: 1px solid #fecdca; color: #b42318; font-size: 13px; line-height: 1.45;
}
.auth-federated-busy {
  margin-top: 12px; display: inline-flex; align-items: center; justify-content: center; gap: 10px;
  width: 100%; min-height: 40px; padding: 8px 12px; border-radius: 10px;
  background: #f8fafc; border: 1px solid #e2e8f0; color: #334155; font-size: 13px;
}
.auth-federated-busy-spinner {
  width: 14px; height: 14px; border-radius: 50%;
  border: 2px solid #cbd5e1; border-top-color: #2563eb;
  animation: auth-federated-spin .7s linear infinite;
}
@keyframes auth-federated-spin { to { transform: rotate(360deg); } }

.auth-shell-brand-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  box-sizing: border-box;
  background: var(--shell-bg, #f1f5f9);
}

.auth-brand-loading-card {
  width: min(400px, 88vw);
  height: 320px;
  border-radius: 12px;
  background: linear-gradient(90deg, #e2e8f0 25%, #f1f5f9 50%, #e2e8f0 75%);
  background-size: 200% 100%;
  animation: auth-brand-shimmer 1.1s ease-in-out infinite;
}

@keyframes auth-brand-shimmer {
  0% { background-position: 100% 0; }
  100% { background-position: -100% 0; }
}

.auth-shell {
  min-height: 100vh;
  box-sizing: border-box;
  /* Comfortable outer inset so left/right form positions are not glued to the viewport edge */
  padding: 32px clamp(40px, 7vw, 120px);
  background: var(--shell-bg, #f1f5f9);
  --auth-primary: var(--el-color-primary, #2563eb);
}

.auth-shell-single {
  display: flex;
  flex-direction: column;
  align-items: stretch;
  justify-content: center;
}

.auth-form-center .auth-stage-frame {
  justify-content: center;
}

.auth-form-left .auth-stage-frame {
  justify-content: flex-start;
}

.auth-form-right .auth-stage-frame {
  justify-content: flex-end;
}

.auth-shell-single.auth-form-center {
  align-items: center;
}

.auth-shell-single.auth-form-left {
  align-items: flex-start;
}

.auth-shell-single.auth-form-right {
  align-items: flex-end;
}

.auth-stage-frame {
  width: 100%;
  max-width: 1080px;
  margin-left: auto;
  margin-right: auto;
  display: flex;
  gap: 28px;
  align-items: stretch;
}

.auth-shell-single .auth-stage-frame {
  max-width: 440px;
  display: block;
}

/* margin:auto would cancel formPosition left/right; keep soft inset via shell padding */
.auth-shell-single.auth-form-left .auth-stage-frame {
  margin-left: 0;
  margin-right: auto;
}

.auth-shell-single.auth-form-right .auth-stage-frame {
  margin-left: auto;
  margin-right: 0;
}

.auth-shell-single.auth-form-center .auth-stage-frame {
  margin-left: auto;
  margin-right: auto;
}

.auth-shell-split .auth-stage-frame {
  min-height: min(640px, calc(100vh - 64px));
}

.auth-brand-left-panel .auth-stage-frame {
  flex-direction: row;
}

.auth-brand-right-panel .auth-stage-frame {
  flex-direction: row-reverse;
}

.auth-brand-panel {
  flex: 1 1 48%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 12px;
  padding: 36px 32px;
  border-radius: 20px;
  color: #f8fafc;
  background: color-mix(in srgb, var(--auth-primary) 22%, rgba(15, 23, 42, 0.72));
  border: 1px solid rgba(255, 255, 255, 0.12);
  backdrop-filter: blur(8px);
}

.auth-panel-title {
  margin: 0;
  font-size: 28px;
  line-height: 1.25;
  font-weight: 650;
}

.auth-panel-desc {
  margin: 0;
  font-size: 15px;
  line-height: 1.6;
  opacity: 0.9;
}

.auth-stage-layout {
  flex: 0 1 420px;
  width: 100%;
}

.auth-shell-single .auth-stage-layout {
  max-width: 420px;
}

.auth-top-bar {
  width: min(1080px, 100%);
  margin: 0 auto 20px;
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 12px 16px;
  border-radius: 14px;
  background: color-mix(in srgb, #ffffff 88%, transparent);
  border: 1px solid rgba(148, 163, 184, 0.35);
  box-shadow: 0 8px 24px rgba(15, 23, 42, 0.06);
}

.auth-top-bar-copy {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.auth-top-bar-copy strong {
  font-size: 15px;
  color: #0f172a;
}

.auth-top-bar-copy span {
  font-size: 13px;
  color: #64748b;
}

.auth-logo {
  object-fit: contain;
  display: block;
}

.auth-logo-inline {
  width: 40px;
  height: 40px;
  border-radius: 10px;
}

.auth-logo-panel {
  width: 72px;
  height: 72px;
  border-radius: 16px;
  background: rgba(255, 255, 255, 0.12);
  padding: 8px;
}

.auth-logo-bar {
  width: 36px;
  height: 36px;
  border-radius: 8px;
}

.auth-brand-strip {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}

.auth-brand-below {
  margin-top: 16px;
  margin-bottom: 0;
  flex-direction: column;
  align-items: flex-start;
  color: var(--console-text-muted, #64748b);
  font-size: 13px;
}

.auth-brand-copy {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.auth-brand-copy strong {
  font-size: 16px;
  color: var(--console-text, #0f172a);
}

.auth-brand-subtitle {
  font-size: 13px;
  color: var(--console-text-muted, #64748b);
}

.auth-brand-footer {
  margin: 16px 0 0;
  padding-top: 12px;
  border-top: 1px solid var(--console-card-border, var(--el-border-color-lighter, #e2e8f0));
  color: var(--console-text-muted, var(--el-text-color-secondary, #64748b));
  font-size: 12px;
  line-height: 1.5;
  text-align: center;
}

.auth-version-footer {
  margin: 8px 0 0;
  color: var(--console-text-muted, var(--el-text-color-secondary, #64748b));
  font-size: 12px;
  line-height: 1.4;
  letter-spacing: 0.01em;
  font-variant-numeric: tabular-nums;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;
  text-align: center;
  user-select: all;
  word-break: break-all;
}

.auth-brand-footer + .auth-version-footer {
  margin-top: 6px;
  padding-top: 0;
  border-top: 0;
}


.auth-submit {
  width: 100%;
}

/*
 * Force brand primary onto EP primary buttons.
 * Match console-root's :not(.is-plain|:is-link|:is-text) chain so specificity wins when
 * the auth shell is nested under upper-app theme overrides (e.g. security-console).
 */
.auth-shell :deep(.auth-submit.el-button--primary:not(.is-plain):not(.is-link):not(.is-text)),
.auth-shell :deep(.auth-submit-inline.el-button--primary:not(.is-plain):not(.is-link):not(.is-text)) {
  --el-button-bg-color: var(--auth-primary, var(--el-color-primary));
  --el-button-border-color: var(--auth-primary, var(--el-color-primary));
  --el-button-hover-bg-color: color-mix(in srgb, var(--auth-primary, var(--el-color-primary)) 88%, #000);
  --el-button-hover-border-color: color-mix(in srgb, var(--auth-primary, var(--el-color-primary)) 88%, #000);
  --el-button-active-bg-color: color-mix(in srgb, var(--auth-primary, var(--el-color-primary)) 80%, #000);
  --el-button-active-border-color: color-mix(in srgb, var(--auth-primary, var(--el-color-primary)) 80%, #000);
  background-color: var(--el-button-bg-color);
  border-color: var(--el-button-border-color);
}

.auth-shell :deep(.auth-submit.el-button--primary:not(.is-plain):not(.is-link):not(.is-text):hover),
.auth-shell :deep(.auth-submit.el-button--primary:not(.is-plain):not(.is-link):not(.is-text):focus),
.auth-shell :deep(.auth-submit-inline.el-button--primary:not(.is-plain):not(.is-link):not(.is-text):hover),
.auth-shell :deep(.auth-submit-inline.el-button--primary:not(.is-plain):not(.is-link):not(.is-text):focus) {
  background-color: var(--el-button-hover-bg-color);
  border-color: var(--el-button-hover-border-color);
}

@media (max-width: 860px) {
  .auth-shell-split .auth-stage-frame,
  .auth-brand-left-panel .auth-stage-frame,
  .auth-brand-right-panel .auth-stage-frame {
    flex-direction: column;
  }

  .auth-brand-panel {
    min-height: 160px;
  }

  .auth-shell-single.auth-form-left,
  .auth-shell-single.auth-form-right {
    align-items: center;
  }
}
</style>
