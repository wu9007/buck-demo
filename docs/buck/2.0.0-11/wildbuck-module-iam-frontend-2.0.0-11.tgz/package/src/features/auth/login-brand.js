/**
 * Normalize login brand capability from client-meta.
 * Controlled layout presets only — no free-form CSS.
 * Browser chrome (title/favicon) delegates to @wildbuck/core-client-meta-frontend shell brand API
 * so login page and post-login shell share one deployment product identity.
 */

import {
  applyBrickShellBrowserChrome,
  resolveBrickShellBrand,
} from '@wildbuck/core-client-meta-frontend';

const BACKGROUND_MODES = new Set(['NONE', 'SOLID', 'IMAGE', 'SOFT_GRADIENT']);
const FORM_POSITIONS = new Set(['CENTER', 'LEFT', 'RIGHT']);
const BRAND_POSITIONS = new Set([
  'ABOVE_FORM',
  'BELOW_FORM',
  'LEFT_PANEL',
  'RIGHT_PANEL',
  'TOP_BAR',
]);

export function normalizeLoginBrand(raw) {
  if (raw == null || typeof raw !== 'object' || Array.isArray(raw)) {
    return disabledBrand();
  }
  const enabled = Boolean(raw.enabled);
  let formPosition = upper(raw.formPosition, 'CENTER');
  let brandPosition = upper(raw.brandPosition, 'ABOVE_FORM');
  if (!FORM_POSITIONS.has(formPosition)) {
    formPosition = 'CENTER';
  }
  if (!BRAND_POSITIONS.has(brandPosition)) {
    brandPosition = 'ABOVE_FORM';
  }
  if (brandPosition === 'LEFT_PANEL') {
    formPosition = 'RIGHT';
  } else if (brandPosition === 'RIGHT_PANEL') {
    formPosition = 'LEFT';
  }

  let backgroundMode = upper(raw.backgroundMode, 'NONE');
  if (!BACKGROUND_MODES.has(backgroundMode)) {
    backgroundMode = 'NONE';
  }

  const systemName = asText(raw.systemName, 120);
  // Tab title stays aligned with product name; optional browserTitle only fills when name missing.
  const browserTitle = asText(raw.browserTitle, 120) || systemName;

  return {
    enabled,
    systemName,
    description: asText(raw.description, 120),
    logoUrl: asPublicUrl(raw.logoUrl),
    brandMark: asText(raw.brandMark, 8),
    backgroundMode,
    backgroundColor: asColor(raw.backgroundColor),
    backgroundImageUrl: asPublicUrl(raw.backgroundImageUrl),
    formPosition,
    brandPosition,
    primaryColor: asColor(raw.primaryColor),
    footerText: asText(raw.footerText, 255),
    browserTitle,
    layoutTemplate: asText(raw.layoutTemplate, 64),
  };
}

/**
 * Apply browser tab title + favicon from login brand (shared shell-brand API).
 * Returns a restore function for unmount; prefer re-applying product brand after login
 * so the console does not fall back to a host-specific title.
 */
export function applyLoginBrandBrowserChrome(brand, options = {}) {
  const shellBrand = resolveBrickShellBrand(brand, {
    fallbackTitle: options.fallbackTitle,
  });
  return applyBrickShellBrowserChrome(shellBrand, options);
}

function disabledBrand() {
  return {
    enabled: false,
    systemName: '',
    description: '',
    logoUrl: '',
    brandMark: '',
    backgroundMode: 'NONE',
    backgroundColor: '',
    backgroundImageUrl: '',
    formPosition: 'CENTER',
    brandPosition: 'ABOVE_FORM',
    primaryColor: '',
    footerText: '',
    browserTitle: '',
    layoutTemplate: '',
  };
}

function upper(value, fallback) {
  if (value == null || value === '') {
    return fallback;
  }
  return String(value).trim().toUpperCase();
}

function asText(value, max) {
  if (value == null) {
    return '';
  }
  const text = String(value).trim();
  if (!text) {
    return '';
  }
  return text.length > max ? text.slice(0, max) : text;
}

function asColor(value) {
  const text = asText(value, 16);
  if (!text) {
    return '';
  }
  return /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(text) ? text : '';
}

function asPublicUrl(value) {
  const text = asText(value, 512);
  if (!text) {
    return '';
  }
  const lower = text.toLowerCase();
  if (lower.startsWith('javascript:') || lower.startsWith('data:text') || lower.startsWith('vbscript:')) {
    return '';
  }
  if (text.startsWith('/') || lower.startsWith('https://') || lower.startsWith('http://')) {
    return text;
  }
  return '';
}
