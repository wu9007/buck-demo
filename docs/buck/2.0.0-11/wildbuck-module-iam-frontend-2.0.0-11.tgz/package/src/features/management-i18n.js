import { formatBrickI18nMessage, normalizeBrickLocale } from '@wildbuck/core-i18n-frontend';
import {
  useBrickConsoleI18n,
} from '@wildbuck/core-ui-frontend/i18n';
import {
  resolveIamAuthMessages,
} from './auth/auth-experience-factory.js';
import {
  IAM_MANAGEMENT_MESSAGES,
  IAM_MANAGEMENT_MESSAGES_ZH_CN,
} from './management-i18n-messages.js';

/**
 * Resolve flat IAM management (non-auth) message table for a Buck locale.
 * @param {unknown} locale
 * @returns {Readonly<Record<string, string>>}
 */
export function resolveIamManagementMessages(locale) {
  const normalized = normalizeBrickLocale(locale);
  return IAM_MANAGEMENT_MESSAGES[normalized] ?? IAM_MANAGEMENT_MESSAGES_ZH_CN;
}

/**
 * Merge auth + management packs for registerMessages('module-iam', ...).
 * @param {unknown} locale
 * @returns {Readonly<Record<string, string>>}
 */
export function resolveIamModuleMessages(locale) {
  return Object.freeze({
    ...resolveIamAuthMessages(locale),
    ...resolveIamManagementMessages(locale),
  });
}

/**
 * Translate IAM management keys with runtime first, then management pack fallback.
 * @param {unknown} runtime
 * @param {string} key
 * @param {Record<string, unknown>} [params]
 * @param {string} [fallbackLocale]
 */
export function translateIamManagement(runtime, key, params = {}, fallbackLocale = 'zh-CN') {
  const messageKey = String(key ?? '');
  if (!messageKey) {
    return '';
  }
  if (runtime && typeof runtime.t === 'function') {
    const resolved = runtime.t(messageKey, params);
    if (resolved != null && resolved !== '' && resolved !== messageKey) {
      return String(resolved);
    }
  }
  const locale = normalizeBrickLocale(
    typeof runtime?.getLocale === 'function' ? runtime.getLocale() : fallbackLocale,
    fallbackLocale,
  );
  const pack = resolveIamManagementMessages(locale);
  const template = pack[messageKey] ?? IAM_MANAGEMENT_MESSAGES_ZH_CN[messageKey];
  if (typeof template === 'string') {
    return formatBrickI18nMessage(template, params);
  }
  return messageKey;
}

/**
 * Vue inject helper for IAM management SFCs / workspaces.
 * Tracks runtime revision so setLocale / registerMessages re-render templates that call t().
 */
export function useIamI18n() {
  const { i18n, revision, locale, t: consoleT } = useBrickConsoleI18n();

  function t(key, params) {
    void revision.value;
    const fromRuntime = consoleT(key, params);
    if (fromRuntime != null && fromRuntime !== '' && fromRuntime !== key) {
      return fromRuntime;
    }
    return translateIamManagement(i18n, key, params, locale.value);
  }

  return {
    i18n,
    revision,
    locale,
    t,
  };
}

export {
  IAM_MANAGEMENT_MESSAGES,
  IAM_MANAGEMENT_MESSAGES_EN_US,
  IAM_MANAGEMENT_MESSAGES_ZH_CN,
} from './management-i18n-messages.js';
