import { invalidateEmployeeSessions, invalidateSession, listEmployeeSessions, listSessions } from '../../../generated/sdk';
import type {
  InvalidateEmployeeSessionResult,
  InvalidateSessionResult,
  Page,
  SessionSearchRequest,
  SessionSummary,
} from '../../../generated/types';

export async function searchEmployeeSessions(
  employeeId: string,
  input: SessionSearchRequest,
): Promise<Page<SessionSummary>> {
  return listEmployeeSessions(employeeId, input);
}

export async function searchSessions(input: SessionSearchRequest): Promise<Page<SessionSummary>> {
  return listSessions(input);
}

export async function dropSession(sessionId: string): Promise<InvalidateSessionResult> {
  return invalidateSession(sessionId, undefined);
}

export async function dropEmployeeSessions(employeeId: string): Promise<InvalidateEmployeeSessionResult> {
  return invalidateEmployeeSessions(employeeId, undefined);
}
