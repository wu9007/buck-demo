<script setup lang="ts">
import { onMounted } from 'vue';
import { BrickPageHeader } from '@wildbuck/core-ui-frontend/patterns';
import SessionFilterToolbar from '../components/SessionFilterToolbar.vue';
import SessionTablePanel from '../components/SessionTablePanel.vue';
import { useSessionWorkspace } from '../composables/useSessionWorkspace';
import { iamUsageTracker } from '../../../usage-events';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

const {
  actionMessage,
  activeSessionCount,
  applyFilters,
  authenticationModeOptions,
  changePage,
  changePageSize,
  filterActive,
  filters,
  initialize,
  invalidateEmployeeSessionsAction,
  invalidateSessionAction,
  invalidating,
  listError,
  listLoading,
  page,
  pageSize,
  pageSizeOptions,
  pageSummary,
  resetFilters,
  resolveAuthenticationModeLabel,
  resolveSessionStatusLabel,
  rows,
  sessionStatusOptions,
  total,
} = useSessionWorkspace();

onMounted(() => {
  void iamUsageTracker.trackPage('sessions');
  initialize();
});

/** reactive 对象不能用 v-model 整对象赋值，字段级回写 */
function onFilterModelUpdate(next: {
  keyword?: string;
  sessionStatus?: string;
  authenticationMode?: string;
  scope?: 'all' | 'active';
}) {
  filters.keyword = next?.keyword ?? '';
  filters.sessionStatus = next?.sessionStatus ?? '';
  filters.authenticationMode = next?.authenticationMode ?? '';
  filters.scope = next?.scope === 'all' ? 'all' : 'active';
}
</script>

<template>
  <article class="sessions-page" data-testid="sessions-page">
    <BrickPageHeader
      :eyebrow="t('module.iam.sessions.page.eyebrow')"
      :title="t('module.iam.sessions.page.title')"
      :description="t('module.iam.sessions.page.description')"
    />

    <SessionFilterToolbar
      :model-value="filters"
      :authentication-mode-options="authenticationModeOptions"
      :session-status-options="sessionStatusOptions"
      @update:model-value="onFilterModelUpdate"
      @search="applyFilters"
      @reset="resetFilters"
    />

    <p v-if="listError" class="state-text state-error" data-testid="session-list-error" role="alert">
      {{ listError }}
    </p>
    <p
      v-if="actionMessage"
      class="state-text panel-success"
      data-testid="session-action-message"
      role="status"
    >
      {{ actionMessage }}
    </p>

    <SessionTablePanel
      :loading="listLoading"
      :invalidating="invalidating"
      :page="page"
      :page-size="pageSize"
      :page-size-options="pageSizeOptions"
      :page-summary="pageSummary"
      :resolve-authentication-mode-label="resolveAuthenticationModeLabel"
      :resolve-session-status-label="resolveSessionStatusLabel"
      :rows="rows"
      :total="total"
      :active-session-count="activeSessionCount"
      :filter-active="filterActive"
      @invalidate-employee="invalidateEmployeeSessionsAction"
      @invalidate="invalidateSessionAction"
      @update:page="changePage"
      @update:page-size="changePageSize"
    />
  </article>
</template>

<style scoped>
.sessions-page {
  display: grid;
  gap: var(--console-page-gap, 18px);
  padding: 4px 0 12px;
  background: var(--console-page-bg, #f6f8f8);
}

.state-text {
  margin: 0;
  padding: var(--console-card-body-y, 18px) var(--console-card-body-x, 18px);
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: var(--console-card-radius, 8px);
  color: var(--console-text, #4a5a70);
  background: var(--console-card-bg, #ffffff);
  box-shadow: var(--console-card-shadow, 0 1px 2px rgba(22, 67, 76, 0.04));
}

.state-error {
  color: var(--console-danger, #b4232f);
}

.panel-success {
  color: var(--console-primary, #188168);
  background: var(--console-accent-soft, rgba(24, 129, 104, 0.08));
}
</style>
