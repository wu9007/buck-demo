import {
  createOptionRequest,
  loadBrickOptions,
  normalizeOptionItems,
  withAllOption,
} from '@wildbuck/core-option-frontend';
import { isBrickSessionError } from '@wildbuck/core-api-frontend';
import { computed, reactive, ref } from 'vue';
import type { SessionSummary } from '../../../generated/types';
import { dropEmployeeSessions, dropSession, searchSessions } from '../api/session';
import { iamUsageTracker } from '../../../usage-events';
import { useIamI18n } from '../../management-i18n.js';

const DEFAULT_PAGE_SIZE = 20;
const PAGE_SIZE_OPTIONS = [10, 20, 50, 100];
type OptionItem = { label: string; value: string };
const SESSION_STATUS_OPTION_CODE = 'iam_session_status';
const AUTHENTICATION_MODE_OPTION_CODE = 'iam_session_authentication_mode';

export interface SessionFilterState {
  keyword: string;
  sessionStatus: string;
  authenticationMode: string;
  scope: 'all' | 'active';
}

export function useSessionWorkspace() {
  const { t } = useIamI18n();
  const fallbackSessionStatusOptions: OptionItem[] = [
    { label: t('module.iam.sessions.statusOption.all'), value: '' },
    { label: t('module.iam.sessions.statusOption.active'), value: 'ACTIVE' },
    { label: t('module.iam.sessions.statusOption.invalidated'), value: 'INVALIDATED' },
    { label: t('module.iam.sessions.statusOption.loggedOut'), value: 'LOGGED_OUT' },
    { label: t('module.iam.sessions.statusOption.expired'), value: 'EXPIRED' },
  ];
  const fallbackAuthenticationModeOptions: OptionItem[] = [
    { label: t('module.iam.sessions.authModeOption.all'), value: '' },
    { label: t('module.iam.sessions.authModeOption.password'), value: 'username-password' },
    { label: t('module.iam.sessions.authModeOption.sms'), value: 'sms-code' },
    { label: t('module.iam.sessions.authModeOption.smsMfa'), value: 'sms-mfa' },
  ];
  const filters = reactive<SessionFilterState>({
    keyword: '',
    sessionStatus: '',
    authenticationMode: '',
    // 运维默认只看活跃会话，降低误操作面与噪音（仍可通过范围筛选看历史）
    scope: 'active',
  });
  const rows = ref<SessionSummary[]>([]);
  const total = ref(0);
  const page = ref(1);
  const pageSize = ref(DEFAULT_PAGE_SIZE);
  const listLoading = ref(false);
  const listError = ref('');
  const actionMessage = ref('');
  const invalidating = ref(false);
  const sessionStatusOptions = ref<OptionItem[]>([...fallbackSessionStatusOptions]);
  const authenticationModeOptions = ref<OptionItem[]>([...fallbackAuthenticationModeOptions]);

  const sessionStatusLabelMap = computed(() => optionLabelMap(sessionStatusOptions.value));
  const authenticationModeLabelMap = computed(() => optionLabelMap(authenticationModeOptions.value));
  const activeSessionCount = computed(() => rows.value.filter((session) => session.sessionStatus === 'ACTIVE').length);
  /** 是否已应用非默认筛选（列表 meta / 空态） */
  const filterActive = computed(() => (
    Boolean(filters.keyword.trim())
    || Boolean(filters.sessionStatus)
    || Boolean(filters.authenticationMode)
    || filters.scope !== 'active'
  ));
  const pageSummary = computed(() => t('module.iam.sessions.list.loaded', {
    page: page.value,
    count: rows.value.length,
    total: total.value,
  }));
  const hasPreviousPage = computed(() => page.value > 1);
  const hasNextPage = computed(() => page.value * pageSize.value < total.value);

  async function initialize() {
    await loadSessionOptions();
    await loadSessions();
  }

  async function loadSessionOptions() {
    try {
      const options = await loadBrickOptions([
        createOptionRequest(SESSION_STATUS_OPTION_CODE),
        createOptionRequest(AUTHENTICATION_MODE_OPTION_CODE),
      ]);
      sessionStatusOptions.value = withAllOption(
        { label: t('module.iam.sessions.statusOption.all'), value: '' },
        normalizeOptionItems(options[SESSION_STATUS_OPTION_CODE]),
        fallbackSessionStatusOptions,
      );
      authenticationModeOptions.value = withAllOption(
        { label: t('module.iam.sessions.authModeOption.all'), value: '' },
        normalizeOptionItems(options[AUTHENTICATION_MODE_OPTION_CODE]),
        fallbackAuthenticationModeOptions,
      );
    } catch (error) {
      if (isBrickSessionError(error)) {
        return;
      }
      sessionStatusOptions.value = [...fallbackSessionStatusOptions];
      authenticationModeOptions.value = [...fallbackAuthenticationModeOptions];
    }
  }

  async function loadSessions() {
    listLoading.value = true;
    listError.value = '';
    try {
      const result = await searchSessions({
        keyword: filters.keyword.trim() || undefined,
        sessionStatus: filters.sessionStatus || undefined,
        authenticationMode: filters.authenticationMode || undefined,
        includeInactive: filters.scope === 'all',
        page: page.value,
        size: pageSize.value,
      });
      rows.value = result.records;
      total.value = result.total;
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      rows.value = [];
      total.value = 0;
      listError.value = t('module.iam.sessions.status.loadFailed');
      return false;
    } finally {
      listLoading.value = false;
    }
  }

  function assignFilters(next: Partial<SessionFilterState>) {
    filters.keyword = next.keyword ?? '';
    filters.sessionStatus = next.sessionStatus ?? '';
    filters.authenticationMode = next.authenticationMode ?? '';
    filters.scope = next.scope === 'all' ? 'all' : 'active';
  }

  async function applyFilters(nextFilters?: Partial<SessionFilterState>) {
    if (nextFilters) {
      assignFilters(nextFilters);
    }
    page.value = 1;
    actionMessage.value = '';
    listError.value = '';
    const loaded = await loadSessions();
    if (loaded) {
      void iamUsageTracker.trackActionResult('session', 'search', 'SUCCESS');
    } else {
      void iamUsageTracker.trackActionResult('session', 'search', 'FAILURE');
    }
    return loaded;
  }

  async function resetFilters(nextFilters?: Partial<SessionFilterState>) {
    const empty: SessionFilterState = {
      keyword: '',
      sessionStatus: '',
      authenticationMode: '',
      scope: 'active',
    };
    assignFilters(nextFilters ?? empty);
    return applyFilters(nextFilters ?? empty);
  }

  async function previousPage() {
    if (!hasPreviousPage.value) {
      return;
    }
    page.value -= 1;
    await loadSessions();
  }

  async function nextPage() {
    if (!hasNextPage.value) {
      return;
    }
    page.value += 1;
    await loadSessions();
  }

  async function changePage(nextPage: number) {
    if (nextPage < 1 || nextPage === page.value) {
      return;
    }
    page.value = nextPage;
    await loadSessions();
  }

  async function changePageSize(nextSize: number) {
    if (nextSize < 1 || nextSize === pageSize.value) {
      return;
    }
    pageSize.value = nextSize;
    page.value = 1;
    await loadSessions();
  }

  function shortSessionId(sessionId: string) {
    const value = (sessionId || '').trim();
    if (value.length <= 12) {
      return value;
    }
    return `${value.slice(0, 6)}…${value.slice(-4)}`;
  }

  async function invalidateSessionAction(sessionId: string) {
    if (!sessionId || invalidating.value) {
      return;
    }
    invalidating.value = true;
    listError.value = '';
    actionMessage.value = '';
    try {
      const result = await dropSession(sessionId);
      if (result.invalidated) {
        actionMessage.value = t('module.iam.sessions.status.invalidated', {
          sessionId: shortSessionId(result.sessionId || sessionId),
        });
        void iamUsageTracker.trackActionResult('session', 'force-offline', 'SUCCESS');
      } else {
        // 会话已非活跃时仍给明确反馈，避免操作者以为成功结束了还在线的会话
        actionMessage.value = t('module.iam.sessions.status.alreadyInactive', {
          sessionId: shortSessionId(result.sessionId || sessionId),
        });
        void iamUsageTracker.trackActionResult('session', 'force-offline', 'SUCCESS');
      }
      await loadSessions();
    } catch (error) {
      if (isBrickSessionError(error)) {
        return;
      }
      listError.value = t('module.iam.sessions.status.invalidateFailed');
      void iamUsageTracker.trackActionResult('session', 'force-offline', 'FAILURE');
    } finally {
      invalidating.value = false;
    }
  }

  async function invalidateEmployeeSessionsAction(employeeId: string) {
    if (!employeeId || invalidating.value) {
      return;
    }
    invalidating.value = true;
    listError.value = '';
    actionMessage.value = '';
    try {
      const result = await dropEmployeeSessions(employeeId);
      if (result.invalidated) {
        actionMessage.value = t('module.iam.sessions.status.employeeInvalidated');
      } else {
        actionMessage.value = t('module.iam.sessions.status.employeeAlreadyInactive');
      }
      await loadSessions();
      void iamUsageTracker.trackActionResult('session', 'force-offline', 'SUCCESS');
    } catch (error) {
      if (isBrickSessionError(error)) {
        return;
      }
      listError.value = t('module.iam.sessions.status.employeeInvalidateFailed');
      void iamUsageTracker.trackActionResult('session', 'force-offline', 'FAILURE');
    } finally {
      invalidating.value = false;
    }
  }

  function resolveSessionStatusLabel(value?: string | null) {
    return resolveOptionLabel(sessionStatusLabelMap.value, value);
  }

  function resolveAuthenticationModeLabel(value?: string | null) {
    return resolveOptionLabel(authenticationModeLabelMap.value, value);
  }

  return {
    actionMessage,
    activeSessionCount,
    applyFilters,
    authenticationModeOptions,
    changePage,
    changePageSize,
    filterActive,
    filters,
    hasNextPage,
    hasPreviousPage,
    initialize,
    invalidateEmployeeSessionsAction,
    invalidateSessionAction,
    invalidating,
    listError,
    listLoading,
    nextPage,
    page,
    pageSize,
    pageSizeOptions: PAGE_SIZE_OPTIONS,
    pageSummary,
    previousPage,
    resetFilters,
    resolveAuthenticationModeLabel,
    resolveSessionStatusLabel,
    rows,
    sessionStatusOptions,
    total,
  };
}

function optionLabelMap(options: OptionItem[]) {
  return new Map(options.map((option) => [option.value, option.label]));
}

function resolveOptionLabel(labelMap: Map<string, string>, value?: string | null) {
  if (!value || !value.trim()) {
    return '-';
  }
  return labelMap.get(value) || value;
}
