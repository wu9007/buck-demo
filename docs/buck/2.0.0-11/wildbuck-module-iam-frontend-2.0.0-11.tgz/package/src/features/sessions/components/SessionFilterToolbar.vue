<script setup lang="ts">
import { computed, watch } from 'vue';
import { BrickFilterToolbar, useBrickFilterDraft } from '@wildbuck/core-ui-frontend/patterns';
import { buildSessionScopeFilterOptions } from '../../../shared/filter-options';
import type { SessionFilterState } from '../composables/useSessionWorkspace';
import { useIamI18n } from '../../management-i18n.js';

const props = defineProps<{
  authenticationModeOptions: Array<{ label: string; value: string }>;
  /** 已应用的查询条件（只读展示同步；控件绑定 draft） */
  modelValue: SessionFilterState;
  sessionStatusOptions: Array<{ label: string; value: string }>;
}>();

const emit = defineEmits<{
  'update:modelValue': [SessionFilterState];
  search: [SessionFilterState];
  reset: [SessionFilterState];
}>();

const { t } = useIamI18n();
const scopeOptions = computed(() => buildSessionScopeFilterOptions(t));

const defaultFilters = (): SessionFilterState => ({
  keyword: '',
  sessionStatus: '',
  authenticationMode: '',
  scope: 'active',
});

const { draft, resetDraft, replaceDraft, snapshot } = useBrickFilterDraft(defaultFilters);

// 父组件外部改写已应用条件时同步进草稿
watch(
  () => props.modelValue,
  (value) => {
    if (!value) {
      return;
    }
    const current = snapshot();
    if (
      current.keyword !== value.keyword
      || current.sessionStatus !== value.sessionStatus
      || current.authenticationMode !== value.authenticationMode
      || current.scope !== value.scope
    ) {
      replaceDraft({
        keyword: value.keyword ?? '',
        sessionStatus: value.sessionStatus ?? '',
        authenticationMode: value.authenticationMode ?? '',
        scope: value.scope === 'all' ? 'all' : 'active',
      });
    }
  },
  { deep: true, immediate: true },
);

function onSearch() {
  const next = snapshot();
  emit('update:modelValue', next);
  emit('search', next);
}

function onReset() {
  const next = resetDraft();
  emit('update:modelValue', next);
  emit('reset', next);
}
</script>

<template>
  <BrickFilterToolbar data-guide-anchor="filters" field-min-width="180px" data-testid="session-filter-toolbar">
    <el-input
      v-model="draft.keyword"
      :placeholder="t('module.iam.sessions.filter.keyword')"
      clearable
      data-testid="session-filter-keyword"
      @keyup.enter="onSearch"
    />

    <el-select
      v-model="draft.sessionStatus"
      :placeholder="t('module.iam.sessions.filter.status')"
      clearable
      data-testid="session-filter-status"
    >
      <el-option
        v-for="option in sessionStatusOptions"
        :key="option.value || 'all-status'"
        :label="option.label"
        :value="option.value"
      />
    </el-select>

    <el-select
      v-model="draft.authenticationMode"
      :placeholder="t('module.iam.sessions.filter.authMode')"
      clearable
      data-testid="session-filter-auth-mode"
    >
      <el-option
        v-for="option in authenticationModeOptions"
        :key="option.value || 'all-auth'"
        :label="option.label"
        :value="option.value"
      />
    </el-select>

    <el-select
      v-model="draft.scope"
      :placeholder="t('module.iam.sessions.filter.scope')"
      data-testid="session-filter-scope"
    >
      <el-option
        v-for="option in scopeOptions"
        :key="option.value"
        :label="option.label"
        :value="option.value"
      />
    </el-select>

    <template #actions>
      <el-button native-type="button" data-testid="session-filter-reset" @click.prevent="onReset">
        {{ t('module.iam.common.resetFilters') }}
      </el-button>
      <el-button type="primary" native-type="button" data-testid="session-filter-search" @click.prevent="onSearch">
        {{ t('module.iam.sessions.filter.search') }}
      </el-button>
    </template>
  </BrickFilterToolbar>
</template>
