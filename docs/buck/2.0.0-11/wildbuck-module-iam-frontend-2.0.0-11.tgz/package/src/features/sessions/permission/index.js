export const sessionPermissions = {
  list: 'iam:session:view',
  invalidateSingle: 'iam:session:invalidate',
  invalidateUser: 'iam:session:invalidate',
};
