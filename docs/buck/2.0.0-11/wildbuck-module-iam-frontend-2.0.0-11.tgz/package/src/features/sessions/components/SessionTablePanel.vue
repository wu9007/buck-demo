<script setup lang="ts">
import { computed, ref } from 'vue';
import { BrickPaginationBar, BrickRiskConfirm, BrickTableMoreMenu } from '@wildbuck/core-ui-frontend/patterns';
import type { SessionSummary } from '../../../generated/types';
import { BrickTableActions as IamTableActions } from '@wildbuck/core-ui-frontend/patterns';
import { useIamI18n } from '../../management-i18n.js';

const props = defineProps<{
  loading: boolean;
  invalidating?: boolean;
  page: number;
  pageSize: number;
  pageSizeOptions: number[];
  pageSummary: string;
  rows: SessionSummary[];
  resolveAuthenticationModeLabel: (value?: string | null) => string;
  resolveSessionStatusLabel: (value?: string | null) => string;
  total: number;
  activeSessionCount?: number;
  /** 是否处于已应用筛选（空态 / meta） */
  filterActive?: boolean;
}>();

const emit = defineEmits<{
  invalidateEmployee: [employeeId: string];
  invalidate: [sessionId: string];
  'update:page': [value: number];
  'update:pageSize': [value: number];
}>();

const { t } = useIamI18n();

const riskEmployeeVisible = ref(false);
const pendingEmployeeId = ref('');
const riskSessionVisible = ref(false);
const pendingSessionId = ref('');
const pendingSessionLabel = ref('');

const emptyText = computed(() => {
  if (props.loading) {
    return t('module.iam.sessions.list.loading');
  }
  if (props.filterActive) {
    return t('module.iam.sessions.list.emptyFiltered');
  }
  return t('module.iam.sessions.list.empty');
});

const headerMeta = computed(() => {
  if (props.filterActive) {
    return t('module.iam.sessions.list.filteredMeta', {
      visible: props.rows.length,
      total: props.total,
      active: props.activeSessionCount ?? props.rows.filter((row) => row.sessionStatus === 'ACTIVE').length,
    });
  }
  return t('module.iam.sessions.list.totalMeta', {
    total: props.total,
    active: props.activeSessionCount ?? props.rows.filter((row) => row.sessionStatus === 'ACTIVE').length,
  });
});

function tagType(status: string) {
  if (status === 'ACTIVE') {
    return 'success';
  }
  if (status === 'INVALIDATED') {
    return 'warning';
  }
  if (status === 'EXPIRED') {
    return 'info';
  }
  return 'info';
}

function formatDateTime(value?: string | null) {
  return value || '-';
}

function formatSessionActivity(row: SessionSummary) {
  return formatDateTime(row.lastRefreshedAt || row.loggedInAt);
}

function formatVisitorTerminal(value?: string | null) {
  const text = (value || '').trim();
  return text || t('module.iam.sessions.column.terminalUnknown');
}

function openInvalidateEmployee(employeeId: string) {
  if (!employeeId || props.invalidating) {
    return;
  }
  pendingEmployeeId.value = employeeId;
  riskEmployeeVisible.value = true;
}

function openInvalidateSession(row: SessionSummary) {
  if (!row?.sessionId || row.sessionStatus !== 'ACTIVE' || props.invalidating) {
    return;
  }
  pendingSessionId.value = row.sessionId;
  const principal = row.employeeName || row.username || row.sessionId;
  const ip = row.remoteAddress || t('module.iam.sessions.column.clientIpUnknown');
  pendingSessionLabel.value = t('module.iam.sessions.action.confirmSessionTarget', {
    principal,
    ip,
  });
  riskSessionVisible.value = true;
}

function onMoreCommand(command: string, row: SessionSummary) {
  if (command === 'invalidateEmployee' && row.employeeId) {
    openInvalidateEmployee(row.employeeId);
  }
}

function confirmInvalidateEmployee() {
  if (pendingEmployeeId.value) {
    emit('invalidateEmployee', pendingEmployeeId.value);
  }
  pendingEmployeeId.value = '';
  riskEmployeeVisible.value = false;
}

function confirmInvalidateSession() {
  if (pendingSessionId.value) {
    emit('invalidate', pendingSessionId.value);
  }
  pendingSessionId.value = '';
  pendingSessionLabel.value = '';
  riskSessionVisible.value = false;
}

function cancelInvalidateSession() {
  pendingSessionId.value = '';
  pendingSessionLabel.value = '';
}
</script>

<template>
  <el-card shadow="never" class="session-table-panel" data-guide-anchor="list" data-testid="session-table-panel">
    <template #header>
      <div class="session-table-panel__header">
        <div>
          <h2>{{ t('module.iam.sessions.list.title') }}</h2>
          <p>{{ t('module.iam.sessions.list.subtitle') }}</p>
        </div>
        <span class="session-table-panel__meta" data-testid="session-list-meta">{{ headerMeta }}</span>
      </div>
    </template>

    <el-table
      v-if="rows.length > 0 || loading"
      :data="rows"
      row-key="sessionId"
      :empty-text="emptyText"
      v-loading="loading || invalidating"
      data-testid="session-table"
    >
      <el-table-column prop="employeeName" :label="t('module.iam.sessions.column.principal')" min-width="150">
        <template #default="{ row }">
          {{ row.employeeName || row.username || '-' }}
        </template>
      </el-table-column>
      <el-table-column prop="username" :label="t('module.iam.employees.roles.usernameLabel')" min-width="130" />
      <el-table-column :label="t('module.iam.sessions.filter.status')" width="100">
        <template #default="{ row }">
          <el-tag :type="tagType(row.sessionStatus)" effect="plain">
            {{ resolveSessionStatusLabel(row.sessionStatus) }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="authenticationMode" :label="t('module.iam.sessions.filter.authMode')" min-width="120">
        <template #default="{ row }">
          {{ resolveAuthenticationModeLabel(row.authenticationMode) }}
        </template>
      </el-table-column>
      <el-table-column :label="t('module.iam.sessions.column.terminal')" min-width="120">
        <template #default="{ row }">
          <span :title="row.visitorTerminal || undefined">{{ formatVisitorTerminal(row.visitorTerminal) }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="remoteAddress" :label="t('module.iam.sessions.column.clientIp')" min-width="120">
        <template #default="{ row }">
          {{ row.remoteAddress || t('module.iam.sessions.column.clientIpUnknown') }}
        </template>
      </el-table-column>
      <el-table-column :label="t('module.iam.sessions.column.loggedInAt')" min-width="160">
        <template #default="{ row }">
          {{ formatDateTime(row.loggedInAt) }}
        </template>
      </el-table-column>
      <el-table-column :label="t('module.iam.sessions.column.activityAt')" min-width="160">
        <template #default="{ row }">
          {{ formatSessionActivity(row) }}
        </template>
      </el-table-column>
      <el-table-column :label="t('module.iam.sessions.column.expiresAt')" min-width="160">
        <template #default="{ row }">
          {{ formatDateTime(row.accessTokenExpiresAt) }}
        </template>
      </el-table-column>
      <!-- 主动作短文案 + 更多菜单，避免双长链挤压操作列；单条结束也走风险确认 -->
      <el-table-column :label="t('module.iam.common.actions')" width="132" fixed="right">
        <template #default="{ row }">
          <IamTableActions @click.stop>
            <el-button
              link
              type="danger"
              data-testid="session-invalidate"
              :disabled="row.sessionStatus !== 'ACTIVE' || Boolean(invalidating)"
              @click.stop="openInvalidateSession(row)"
            >{{ t('module.iam.sessions.action.invalidate') }}</el-button>
            <BrickTableMoreMenu
              v-if="row.employeeId"
              data-testid="session-row-more"
              @command="(command) => onMoreCommand(String(command), row)"
            >
              <el-dropdown-item
                command="invalidateEmployee"
                :disabled="Boolean(invalidating)"
              >
                {{ t('module.iam.sessions.action.invalidateEmployee') }}
              </el-dropdown-item>
            </BrickTableMoreMenu>
          </IamTableActions>
        </template>
      </el-table-column>
    </el-table>

    <p v-else class="session-table-panel__empty" data-testid="session-list-empty">{{ emptyText }}</p>

    <BrickPaginationBar
      v-if="rows.length > 0 || total > 0"
      :page="page"
      :page-size="pageSize"
      :page-sizes="pageSizeOptions"
      :summary="pageSummary"
      :total="total"
      @update:page="$emit('update:page', $event)"
      @update:page-size="$emit('update:pageSize', $event)"
    />

    <BrickRiskConfirm
      v-model="riskSessionVisible"
      :title="t('module.iam.sessions.action.confirmSessionTitle')"
      :description="pendingSessionLabel || t('module.iam.sessions.action.confirmSessionDescription')"
      :impact="[
        t('module.iam.sessions.action.confirmSessionImpact1'),
        t('module.iam.sessions.action.confirmSessionImpact2'),
      ]"
      :confirm-text="t('module.iam.sessions.action.confirmSession')"
      data-testid="session-invalidate-confirm"
      @confirm="confirmInvalidateSession"
      @cancel="cancelInvalidateSession"
    />

    <BrickRiskConfirm
      v-model="riskEmployeeVisible"
      :title="t('module.iam.sessions.action.confirmEmployeeTitle')"
      :description="t('module.iam.sessions.action.confirmEmployeeDescription')"
      :impact="[
        t('module.iam.sessions.action.confirmEmployeeImpact1'),
        t('module.iam.sessions.action.confirmEmployeeImpact2'),
      ]"
      :confirm-text="t('module.iam.sessions.action.confirmEmployee')"
      data-testid="session-invalidate-employee-confirm"
      @confirm="confirmInvalidateEmployee"
      @cancel="pendingEmployeeId = ''"
    />
  </el-card>
</template>

<style scoped>
/* 会话列表不复用 list-panel.css 全量 import，避免 scoped 多份拷贝撑破 app.css 预算 */
.session-table-panel {
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: var(--console-card-radius, 8px);
  background: var(--console-card-bg, #ffffff);
  box-shadow: var(--console-card-shadow, 0 1px 2px rgba(15, 23, 42, 0.04));
}

.session-table-panel :deep(.el-card__header) {
  padding: var(--console-card-header-y, 14px) var(--console-card-header-x, 16px);
  border-bottom-color: var(--console-card-border, #e6ebf2);
}

.session-table-panel :deep(.el-card__body) {
  padding: 0;
}

.session-table-panel__header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
}

.session-table-panel__header h2,
.session-table-panel__header p {
  margin: 0;
}

.session-table-panel__header h2 {
  color: var(--console-title, #172033);
  font-size: 16px;
  font-weight: 600;
  line-height: 1.3;
}

.session-table-panel__header p {
  margin-top: 4px;
  color: var(--console-muted, #7e8ba0);
  font-size: 12px;
  line-height: 1.5;
}

.session-table-panel__meta {
  flex: 0 0 auto;
  color: var(--console-muted, #7e8ba0);
  font-size: 12px;
  font-weight: 600;
  white-space: nowrap;
}

.session-table-panel__empty {
  margin: 0;
  padding: 40px 16px;
  color: var(--console-muted, #7e8ba0);
  font-size: 13px;
  line-height: 1.6;
  text-align: center;
}
</style>
