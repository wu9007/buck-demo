import { sessionPermissions } from './permission/index.js';
import { sessionRoutes } from './routes/index.js';

export const sessionsFeature = {
  featureKey: 'sessions',
  routes: sessionRoutes,
  permissions: sessionPermissions,
};
