<script setup lang="ts">
import { computed } from 'vue';
import { BrickConsoleDrawer } from '@wildbuck/core-ui-frontend/shell';
import type { RoleAuthorizationDetail, RoleDetail, RoleSummary, UpdateRoleRequest } from '../../../generated/types';
import RoleAuthorizationCard from './RoleAuthorizationCard.vue';
import RoleDetailCard from './RoleDetailCard.vue';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

const props = defineProps<{
  activeTab: string;
  authorizationDetail: RoleAuthorizationDetail | null;
  canSaveAuthorization: boolean;
  currentDetail: RoleDetail | null;
  editorMode: 'edit' | 'create';
  form: UpdateRoleRequest;
  panelLoading: boolean;
  permissionDraft: string[];
  selectedRole: RoleSummary | null;
  visible: boolean;
}>();

defineEmits<{
  close: [];
  delete: [];
  save: [];
  saveAuthorization: [];
  'update:activeTab': [value: string];
  'update:permissionDraft': [value: string[]];
}>();

const drawerEyebrow = computed(() => (
  props.editorMode === 'create'
    ? t('module.iam.roles.page.create')
    : t('module.iam.roles.drawer.detailTitle')
));

const drawerTitle = computed(() => (
  props.form.roleName
  || props.selectedRole?.roleName
  || t('module.iam.roles.drawer.unnamed')
));

const drawerDescription = computed(() => {
  const id = props.currentDetail?.roleId
    || props.selectedRole?.roleId
    || t('module.iam.roles.drawer.createIdHint');
  const status = props.form.enabled
    ? t('module.iam.common.roleEnabledHint')
    : t('module.iam.common.roleDisabledHint');
  return `${id} · ${status}`;
});
</script>

<template>
  <BrickConsoleDrawer
    :model-value="visible"
    size="56%"
    :destroy-on-close="false"
    class="role-drawer"
    :eyebrow="drawerEyebrow"
    :title="drawerTitle"
    :description="drawerDescription"
    @close="$emit('close')"
  >
    <p v-if="panelLoading" class="role-drawer__state" data-testid="role-drawer-loading">
      {{ t('module.iam.roles.drawer.loading') }}
    </p>

    <el-tabs
      v-else
      :model-value="activeTab"
      class="role-drawer__tabs"
      data-testid="role-drawer-tabs"
      @update:model-value="$emit('update:activeTab', $event)"
    >
      <el-tab-pane :label="t('module.iam.roles.drawer.tab.detail')" name="detail">
        <RoleDetailCard
          :current-detail="currentDetail"
          :editor-mode="editorMode"
          :form="form"
          :selected-role="selectedRole"
          @delete="$emit('delete')"
          @save="$emit('save')"
        />
      </el-tab-pane>

      <el-tab-pane :label="t('module.iam.roles.drawer.tab.grant')" name="authorization" :disabled="editorMode === 'create'">
        <RoleAuthorizationCard
          :authorization-detail="authorizationDetail"
          :can-save-authorization="canSaveAuthorization"
          :permission-draft="permissionDraft"
          :selected-role="selectedRole"
          @save="$emit('saveAuthorization')"
          @update:permission-draft="$emit('update:permissionDraft', $event)"
        />
      </el-tab-pane>
    </el-tabs>
  </BrickConsoleDrawer>
</template>

<style scoped>
/* Formal underline tabs; no nested panel chrome around the tab strip. */
.role-drawer__tabs :deep(.el-tabs__header) {
  margin: 0 0 18px;
}

.role-drawer__tabs :deep(.el-tabs__nav-wrap::after) {
  height: 1px;
  background-color: var(--console-card-border, #e2e8f0);
}

.role-drawer__tabs :deep(.el-tabs__item) {
  height: 40px;
  padding: 0 16px;
  color: var(--console-text, #41516a);
  font-size: 13px;
  font-weight: 500;
}

.role-drawer__tabs :deep(.el-tabs__item.is-active) {
  color: var(--console-title, #172033);
  font-weight: 600;
}

.role-drawer__tabs :deep(.el-tabs__active-bar) {
  height: 2px;
  background-color: var(--console-primary, #2563eb);
}

.role-drawer__tabs :deep(.el-tabs__content) {
  overflow: visible;
}

.role-drawer__tabs :deep(.el-tab-pane) {
  display: grid;
  gap: 0;
}

.role-drawer__state {
  margin: 0;
  padding: var(--console-drawer-padding, 18px) 4px;
  color: var(--console-text, #41516a);
  font-size: 13px;
}
</style>
