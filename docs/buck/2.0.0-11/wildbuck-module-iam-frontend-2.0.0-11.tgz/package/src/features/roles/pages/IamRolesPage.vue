<script setup lang="ts">
import { onMounted } from 'vue';
import { BrickListPageActions, BrickPageHeader } from '@wildbuck/core-ui-frontend/patterns';
import RoleDrawerPanel from '../components/RoleDrawerPanel.vue';
import RoleExclusionPanel from '../components/RoleExclusionPanel.vue';
import RoleFilterToolbar from '../components/RoleFilterToolbar.vue';
import RoleTablePanel from '../components/RoleTablePanel.vue';
import { useRoleExclusionWorkspace } from '../composables/useRoleExclusionWorkspace';
import { useRoleWorkspace } from '../composables/useRoleWorkspace';
import { iamUsageTracker } from '../../../usage-events';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

const {
  activeTab,
  authorizationDetail,
  canSaveAuthorization,
  changePage,
  changePageSize,
  closeDrawer,
  currentDetail,
  deleteSelectedRole,
  drawerVisible,
  editorMode,
  filterActive,
  filters,
  form,
  initialize,
  listError,
  listLoading,
  openRole,
  pageSummary,
  page,
  pageSize,
  pageSizeOptions,
  panelLoading,
  permissionDraft,
  resetFilters,
  roleMetrics,
  roles,
  selectedRole,
  selectedRoleId,
  startCreateRole,
  submitAuthorizations,
  submitRoleForm,
  submitSearch,
  updateActiveTab,
} = useRoleWorkspace();

/** reactive 对象不能用 v-model 整对象赋值，字段级回写 */
function onFilterModelUpdate(next: { keyword?: string; enabled?: string }) {
  filters.keyword = next?.keyword ?? '';
  filters.enabled = next?.enabled ?? 'all';
}

const {
  canCreate: canCreateExclusion,
  cancelConflictConfirm,
  closeDrawer: closeExclusionDrawer,
  confirmCreateDespiteConflicts,
  conflictConfirmVisible,
  createPair,
  deletePair,
  deletingId: exclusionDeletingId,
  drawerVisible: exclusionDrawerVisible,
  form: exclusionForm,
  formEpoch: exclusionFormEpoch,
  listError: exclusionListError,
  listLoading: exclusionListLoading,
  openDrawer: openExclusionDrawer,
  pairs,
  reloadPairs,
  roleOptions,
  saving: exclusionSaving,
} = useRoleExclusionWorkspace();

onMounted(() => {
  void iamUsageTracker.trackPage('roles');
  void initialize();
});
</script>

<template>
  <article class="roles-page">
    <BrickPageHeader
      :eyebrow="t('module.iam.roles.page.eyebrow')"
      :title="t('module.iam.roles.page.title')"
      :description="t('module.iam.roles.page.description')"
    >
      <template #actions>
        <BrickListPageActions>
          <template #extra>
            <el-button type="primary" plain data-guide-anchor="role-exclusion-action" @click="openExclusionDrawer">
              {{ t('module.iam.roles.exclusion.open') }}
            </el-button>
          </template>
          <template #primary>
            <el-button type="primary" data-guide-anchor="primary-action" @click="startCreateRole">
              {{ t('module.iam.roles.page.create') }}
            </el-button>
          </template>
        </BrickListPageActions>
      </template>
    </BrickPageHeader>

    <RoleFilterToolbar
      :model-value="filters"
      @update:model-value="onFilterModelUpdate"
      @search="submitSearch"
      @reset="resetFilters"
    />

    <p v-if="listError" class="state-text state-error">{{ listError }}</p>

    <RoleTablePanel
      :rows="roles"
      :loading="listLoading"
      :page="page"
      :page-size="pageSize"
      :page-size-options="pageSizeOptions"
      :selected-role-id="selectedRoleId"
      :page-summary="pageSummary"
      :total="roleMetrics.total"
      :filter-active="filterActive"
      @create="startCreateRole"
      @open="openRole"
      @update:page="changePage"
      @update:page-size="changePageSize"
    />

    <RoleExclusionPanel
      :visible="exclusionDrawerVisible"
      :pairs="pairs"
      :role-options="roleOptions"
      :form="exclusionForm"
      :form-epoch="exclusionFormEpoch"
      :list-loading="exclusionListLoading"
      :list-error="exclusionListError"
      :saving="exclusionSaving"
      :deleting-id="exclusionDeletingId"
      :can-create="canCreateExclusion"
      :conflict-confirm-visible="conflictConfirmVisible"
      @close="closeExclusionDrawer"
      @create="createPair"
      @delete="deletePair"
      @reload="() => reloadPairs({ clearOnError: false })"
      @confirm-conflict="confirmCreateDespiteConflicts"
      @cancel-conflict="cancelConflictConfirm"
    />

    <RoleDrawerPanel
      :visible="drawerVisible"
      :active-tab="activeTab"
      :current-detail="currentDetail"
      :editor-mode="editorMode"
      :form="form"
      :selected-role="selectedRole"
      :panel-loading="panelLoading"
      :authorization-detail="authorizationDetail"
      :permission-draft="permissionDraft"
      :can-save-authorization="canSaveAuthorization"
      @close="closeDrawer"
      @update:active-tab="updateActiveTab"
      @save="submitRoleForm"
      @delete="deleteSelectedRole"
      @save-authorization="submitAuthorizations"
      @update:permission-draft="permissionDraft = $event"
    />
  </article>
</template>

<style scoped>
.roles-page {
  display: grid;
  gap: var(--console-page-gap, 18px);
  padding: 4px 0 12px;
  background: var(--console-page-bg, #f6f8f8);
}

.state-text {
  margin: 0;
  padding: var(--console-card-body-y, 18px) var(--console-card-body-x, 18px);
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: var(--console-card-radius, 8px);
  color: var(--console-text, #4a5a70);
  background: var(--console-card-bg, #ffffff);
  box-shadow: var(--console-card-shadow, 0 1px 2px rgba(22, 67, 76, 0.04));
}

.state-error {
  color: var(--console-danger, #b4232f);
}
</style>
