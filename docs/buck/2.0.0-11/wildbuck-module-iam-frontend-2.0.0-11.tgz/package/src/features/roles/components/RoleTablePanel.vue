<script setup lang="ts">
import { computed } from 'vue';
import { BrickPaginationBar } from '@wildbuck/core-ui-frontend/patterns';
import type { RoleSummary } from '../../../generated/types';
import { BrickTableActions as IamTableActions } from '@wildbuck/core-ui-frontend/patterns';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

const props = defineProps<{
  loading: boolean;
  page: number;
  pageSize: number;
  pageSizeOptions: number[];
  pageSummary: string;
  rows: RoleSummary[];
  selectedRoleId: string;
  total: number;
  /** 是否处于已应用筛选（空态 / meta） */
  filterActive?: boolean;
}>();

const emit = defineEmits<{
  create: [];
  open: [roleId: string];
  'update:page': [value: number];
  'update:pageSize': [value: number];
}>();

const emptyText = computed(() => {
  if (props.loading) {
    return t('module.iam.roles.list.loading');
  }
  if (props.filterActive) {
    return t('module.iam.roles.list.emptyFiltered');
  }
  return t('module.iam.roles.list.empty');
});

const headerMeta = computed(() => {
  if (props.filterActive) {
    return t('module.iam.roles.list.filteredMeta', {
      visible: props.rows.length,
      total: props.total,
    });
  }
  return t('module.iam.roles.list.totalMeta', { total: props.total });
});

function onRowClick(row: RoleSummary) {
  emit('open', row.roleId);
}
</script>

<template>
  <el-card shadow="never" class="iam-list-panel role-table-panel" data-guide-anchor="list">
    <template #header>
      <div class="iam-list-panel__header">
        <div>
          <h2>{{ t('module.iam.roles.list.title') }}</h2>
          <p>{{ t('module.iam.roles.list.subtitle') }}</p>
        </div>
        <span class="iam-list-panel__meta" data-testid="role-list-meta">{{ headerMeta }}</span>
      </div>
    </template>

    <el-table
      v-if="rows.length > 0 || loading"
      :data="rows"
      row-key="roleId"
      :highlight-current-row="true"
      :current-row-key="selectedRoleId"
      :empty-text="emptyText"
      v-loading="loading"
      @row-click="onRowClick"
    >
      <el-table-column :label="t('module.iam.roles.column.name')" min-width="220">
        <template #default="{ row }">
          <div class="iam-list-name">
            <div class="iam-list-name__copy">
              <!-- 列表只展示角色名称；roleId 为系统标识，不向操作者暴露 -->
              <strong>{{ row.roleName }}</strong>
            </div>
          </div>
        </template>
      </el-table-column>
      <el-table-column :label="t('module.iam.common.enabledState')" width="120">
        <template #default="{ row }">
          <el-tag :type="row.enabled ? 'success' : 'warning'" effect="plain">
            {{ row.enabled ? t('module.iam.common.enabled') : t('module.iam.common.disabled') }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column :label="t('module.iam.common.actions')" width="120" fixed="right">
        <template #default="{ row }">
          <IamTableActions @click.stop>
            <el-button
              link
              type="primary"
              data-testid="role-open-detail"
              @click.stop="$emit('open', row.roleId)"
            >{{ t('module.iam.common.viewDetail') }}</el-button>
          </IamTableActions>
        </template>
      </el-table-column>
    </el-table>

    <p v-else class="iam-list-empty" data-testid="role-list-empty">{{ emptyText }}</p>

    <BrickPaginationBar
      v-if="rows.length > 0 || total > 0"
      :page="page"
      :page-size="pageSize"
      :page-sizes="pageSizeOptions"
      :summary="pageSummary"
      :total="total"
      @update:page="$emit('update:page', $event)"
      @update:page-size="$emit('update:pageSize', $event)"
    />
  </el-card>
</template>

<style scoped>
@import "@wildbuck/core-ui-frontend/list-panel.css";
</style>
