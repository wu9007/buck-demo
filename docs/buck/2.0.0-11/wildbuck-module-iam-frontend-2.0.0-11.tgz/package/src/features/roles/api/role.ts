import {
  assignRoleAuthorizations,
  createRole,
  createRoleExclusionPair,
  deleteRole,
  deleteRoleExclusionPair,
  listRoleExclusionPairs,
  listRoles,
  roleAuthorizationDetail,
  roleDetail,
  updateRole,
} from '../../../generated/sdk';
import type {
  AssignRoleAuthorizationsRequest,
  CreateRoleExclusionPairRequest,
  Page,
  RoleAuthorizationAssignment,
  RoleAuthorizationDetail,
  RoleDetail,
  RoleExclusionPairSummary,
  RoleSearchRequest,
  RoleSummary,
  UpdateRoleRequest,
} from '../../../generated/types';

export async function searchRoles(input: RoleSearchRequest): Promise<Page<RoleSummary>> {
  return listRoles(input);
}

export async function loadRoleDetail(roleId: string): Promise<RoleDetail> {
  return roleDetail(roleId, undefined);
}

export async function saveNewRole(input: UpdateRoleRequest): Promise<RoleDetail> {
  return createRole(input);
}

export async function saveRole(roleId: string, input: UpdateRoleRequest): Promise<RoleDetail> {
  return updateRole(roleId, input);
}

export async function removeRole(roleId: string): Promise<void> {
  return deleteRole(roleId, undefined);
}

export async function loadRoleAuthorizationDetail(roleId: string): Promise<RoleAuthorizationDetail> {
  return roleAuthorizationDetail(roleId, undefined);
}

export async function saveRoleAuthorizations(
  roleId: string,
  input: AssignRoleAuthorizationsRequest,
): Promise<RoleAuthorizationAssignment> {
  return assignRoleAuthorizations(roleId, input);
}

export async function loadRoleExclusionPairs(): Promise<RoleExclusionPairSummary[]> {
  return listRoleExclusionPairs(undefined);
}

export async function saveNewRoleExclusionPair(
  input: CreateRoleExclusionPairRequest,
): Promise<RoleExclusionPairSummary> {
  return createRoleExclusionPair({
    roleIdA: input.roleIdA,
    roleIdB: input.roleIdB,
    remark: input.remark,
    confirmExistingConflicts: input.confirmExistingConflicts ?? false,
  });
}

export async function removeRoleExclusionPair(exclusionPairId: string): Promise<void> {
  return deleteRoleExclusionPair(exclusionPairId, undefined);
}
