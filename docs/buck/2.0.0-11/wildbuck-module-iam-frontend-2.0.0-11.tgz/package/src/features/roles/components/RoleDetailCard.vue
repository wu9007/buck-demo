<script setup lang="ts">
import { ref } from 'vue';
import { validateBrickRequiredFields } from '@wildbuck/core-ui-frontend';
import { BrickActionBar, BrickRiskConfirm } from '@wildbuck/core-ui-frontend/patterns';
import type { RoleDetail, RoleSummary, UpdateRoleRequest } from '../../../generated/types';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

const props = defineProps<{
  currentDetail: RoleDetail | null;
  editorMode: 'edit' | 'create';
  form: UpdateRoleRequest;
  selectedRole: RoleSummary | null;
}>();

const emit = defineEmits<{
  delete: [];
  save: [];
}>();

const roleNameInputRef = ref();

function handleSubmit() {
  const result = validateBrickRequiredFields([
    {
      label: t('module.iam.roles.column.name'),
      value: props.form.roleName,
      focusTarget: roleNameInputRef.value,
    },
  ]);
  if (!result.ok) {
    return;
  }
  emit('save');
}
</script>

<template>
  <!-- Flat drawer body: no nested card chrome inside BrickConsoleDrawer. -->
  <section class="role-editor">
    <el-form class="role-editor__form brick-required-form" label-position="top" @submit.prevent="handleSubmit">
      <el-form-item :label="t('module.iam.roles.detail.nameRequired')" required>
        <el-input ref="roleNameInputRef" v-model.trim="form.roleName" :aria-label="t('module.iam.roles.column.name')" />
      </el-form-item>
      <el-form-item :label="t('module.iam.roles.detail.remarkOptional')">
        <el-input
          v-model.trim="form.remark"
          type="textarea"
          :rows="3"
          :aria-label="t('module.iam.roles.detail.remark')"
        />
      </el-form-item>
      <el-form-item class="role-editor__enabled" :label="t('module.iam.common.enabledRequired')" required>
        <div class="role-editor__enabled-row">
          <el-switch
            v-model="form.enabled"
            :aria-label="t('module.iam.common.enabledState')"
          />
          <span class="role-editor__enabled-hint">{{ t('module.iam.roles.detail.enabledHint') }}</span>
        </div>
      </el-form-item>
      <p v-if="editorMode === 'edit'" class="role-editor__meta">
        {{ currentDetail?.roleId || selectedRole?.roleId }}
      </p>
      <BrickActionBar class="role-editor__actions">
        <template #primary>
          <el-button type="primary" native-type="submit">{{ t('module.iam.roles.detail.save') }}</el-button>
        </template>
        <template #danger>
          <BrickRiskConfirm
            v-if="editorMode === 'edit'"
            :title="t('module.iam.roles.detail.deleteTitle')"
            :description="t('module.iam.roles.detail.deleteDescription')"
            :impact="[t('module.iam.roles.detail.deleteImpact1'), t('module.iam.roles.detail.deleteImpact2')]"
            :confirm-text="t('module.iam.roles.detail.deleteTitle')"
            @confirm="$emit('delete')"
          >
            <template #trigger>
              <el-button type="danger" plain>{{ t('module.iam.roles.detail.delete') }}</el-button>
            </template>
          </BrickRiskConfirm>
        </template>
      </BrickActionBar>
    </el-form>
  </section>
</template>

<style scoped>
.role-editor {
  display: grid;
  gap: 0;
}

.role-editor__form {
  display: grid;
  gap: 16px;
  max-width: 560px;
}

.role-editor__form :deep(.el-form-item) {
  margin-bottom: 0;
}

.role-editor__form :deep(.el-form-item__label) {
  color: var(--console-muted, #64748b);
  font-size: 12px;
  font-weight: 600;
  line-height: 1.4;
  letter-spacing: 0.02em;
}

.role-editor__enabled-row {
  display: flex;
  align-items: center;
  gap: 12px;
  min-height: 32px;
}

.role-editor__enabled-hint {
  color: var(--console-text, #41516a);
  font-size: 13px;
  line-height: 1.5;
}

.role-editor__meta {
  margin: 0;
  color: var(--console-muted, #64748b);
  font-size: 12px;
  font-family: "SFMono-Regular", "Cascadia Code", ui-monospace, monospace;
  line-height: 1.5;
  word-break: break-all;
}

.role-editor__actions {
  margin-top: 4px;
  padding-top: 8px;
  border-top: 1px solid var(--console-card-border, #e2e8f0);
}
</style>
