<script setup lang="ts">
import { computed } from 'vue';
import type { RoleAuthorizationDetail, RoleAuthorizationMenuNode, RoleSummary } from '../../../generated/types';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

const props = defineProps<{
  authorizationDetail: RoleAuthorizationDetail | null;
  canSaveAuthorization: boolean;
  permissionDraft: string[];
  selectedRole: RoleSummary | null;
}>();

const emit = defineEmits<{
  save: [];
  'update:permissionDraft': [value: string[]];
}>();

const permissionIdsModel = computed({
  get: () => props.permissionDraft,
  set: (value: string[]) => emit('update:permissionDraft', value),
});

const menuTree = computed<RoleAuthorizationMenuNode[]>(() => props.authorizationDetail?.menus || []);

const treeProps = {
  children: 'children',
  label: 'menuName',
};
</script>

<template>
  <section class="role-grant">
    <header class="role-grant__header">
      <div class="role-grant__copy">
        <h3 class="role-grant__title">{{ t('module.iam.roles.grant.menuActionsTitle') }}</h3>
        <p class="role-grant__hint">
          <template v-if="selectedRole">{{ t('module.iam.roles.grant.configuring', { name: selectedRole.roleName }) }} · </template>
          {{ t('module.iam.roles.grant.menuActionsHint') }}
        </p>
      </div>
      <el-button type="primary" :disabled="!canSaveAuthorization" @click="$emit('save')">
        {{ t('module.iam.roles.grant.save') }}
      </el-button>
    </header>

    <div v-if="authorizationDetail && selectedRole" class="role-grant__body">
      <el-tree
        class="role-grant__tree"
        :data="menuTree"
        :props="treeProps"
        node-key="menuId"
        :default-expand-all="false"
        :expand-on-click-node="false"
        :auto-expand-parent="false"
        :empty-text="t('module.iam.roles.grant.noMenus')"
      >
        <template #default="{ data }">
          <div class="role-grant-node" :class="{ disabled: !data.enabled }">
            <div class="role-grant-node__header">
              <span class="role-grant-node__title">{{ data.menuName }}</span>
              <span class="role-grant-node__meta">{{ data.routePath || data.menuCode }}</span>
            </div>

            <el-checkbox-group
              v-if="data.actions.length"
              v-model="permissionIdsModel"
              class="role-grant-node__actions"
            >
              <label
                v-for="action in data.actions"
                :key="action.permissionId"
                class="role-grant-action"
                :class="{ disabled: !action.enabled }"
              >
                <el-checkbox
                  :value="action.permissionId"
                  :disabled="!action.enabled"
                >
                  {{ action.permissionName }}
                </el-checkbox>
                <em>{{ action.permissionCode }}</em>
              </label>
            </el-checkbox-group>
          </div>
        </template>
      </el-tree>
    </div>

    <p v-else class="role-grant__empty">{{ t('module.iam.roles.grant.saveFirst') }}</p>
  </section>
</template>

<style scoped>
.role-grant {
  display: grid;
  gap: 14px;
}

.role-grant__header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  padding-bottom: 12px;
  border-bottom: 1px solid var(--console-card-border, #e2e8f0);
}

.role-grant__copy {
  display: grid;
  gap: 4px;
  min-width: 0;
}

.role-grant__title {
  margin: 0;
  color: var(--console-title, #172033);
  font-size: 14px;
  font-weight: 600;
  line-height: 1.4;
}

.role-grant__hint {
  margin: 0;
  color: var(--console-muted, #64748b);
  font-size: 12px;
  line-height: 1.55;
}

.role-grant__body {
  min-width: 0;
}

.role-grant__tree {
  background: transparent;
  --el-tree-node-hover-bg-color: color-mix(in srgb, var(--console-primary, #2563eb) 6%, transparent);
}

.role-grant__tree :deep(.el-tree-node__content) {
  height: auto;
  min-height: 0;
  align-items: flex-start;
  padding-block: 8px;
  border-bottom: 1px solid var(--console-card-border, #e2e8f0);
}

.role-grant__tree :deep(.el-tree-node:last-child > .el-tree-node__content) {
  border-bottom: 0;
}

.role-grant__tree :deep(.el-tree-node__expand-icon) {
  color: var(--console-muted, #64748b);
  font-size: 14px;
  margin-top: 4px;
}

.role-grant__tree :deep(.el-tree-node__children) {
  overflow: visible;
}

.role-grant-node {
  display: grid;
  gap: 8px;
  width: 100%;
  padding: 2px 0 4px;
}

.role-grant-node.disabled,
.role-grant-action.disabled {
  opacity: 0.56;
}

.role-grant-node__header {
  display: grid;
  gap: 2px;
}

.role-grant-node__title {
  color: var(--console-title, #172033);
  font-size: 13px;
  font-weight: 600;
  line-height: 1.4;
}

.role-grant-node__meta {
  color: var(--console-muted, #64748b);
  font-size: 12px;
  line-height: 1.45;
  word-break: break-all;
}

.role-grant-node__actions {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 6px 12px;
}

.role-grant-action {
  display: grid;
  gap: 2px;
  min-width: 0;
  padding: 4px 0;
}

.role-grant-action :deep(.el-checkbox) {
  margin-right: 0;
  color: var(--console-title, #172033);
  font-weight: 500;
}

.role-grant-action :deep(.el-checkbox__label) {
  white-space: normal;
}

.role-grant-action em {
  color: var(--console-muted, #64748b);
  font-size: 11px;
  font-style: normal;
  word-break: break-all;
  padding-left: 22px;
}

.role-grant__empty {
  margin: 0;
  padding: 20px 0;
  color: var(--console-text, #41516a);
  font-size: 13px;
  line-height: 1.6;
}

@media (max-width: 760px) {
  .role-grant__header {
    flex-direction: column;
    align-items: stretch;
  }

  .role-grant-node__actions {
    grid-template-columns: 1fr;
  }
}
</style>
