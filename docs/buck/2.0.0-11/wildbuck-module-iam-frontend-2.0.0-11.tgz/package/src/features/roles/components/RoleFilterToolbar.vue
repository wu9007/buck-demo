<script setup lang="ts">
import { computed, watch } from 'vue';
import { BrickFilterToolbar, useBrickFilterDraft } from '@wildbuck/core-ui-frontend/patterns';
import { buildEnabledStateFilterOptions } from '../../../shared/filter-options';
import { useIamI18n } from '../../management-i18n.js';

export type RoleListFilters = {
  keyword: string;
  enabled: string;
};

const props = defineProps<{
  /** 已应用的查询条件；控件只绑定 draft */
  modelValue: RoleListFilters;
}>();

const emit = defineEmits<{
  'update:modelValue': [RoleListFilters];
  search: [RoleListFilters];
  reset: [RoleListFilters];
}>();

const { t } = useIamI18n();
const enabledOptions = computed(() => buildEnabledStateFilterOptions(t));

const defaultFilters = (): RoleListFilters => ({
  keyword: '',
  enabled: 'all',
});

const { draft, resetDraft, replaceDraft, snapshot } = useBrickFilterDraft(defaultFilters);

watch(
  () => props.modelValue,
  (value) => {
    if (!value) {
      return;
    }
    const current = snapshot();
    if (current.keyword !== value.keyword || current.enabled !== value.enabled) {
      replaceDraft({
        keyword: value.keyword ?? '',
        enabled: value.enabled ?? 'all',
      });
    }
  },
  { deep: true, immediate: true },
);

function onSearch() {
  const next = snapshot();
  emit('update:modelValue', next);
  emit('search', next);
}

function onReset() {
  const next = resetDraft();
  emit('update:modelValue', next);
  emit('reset', next);
}
</script>

<template>
  <BrickFilterToolbar data-guide-anchor="filters" field-min-width="180px" data-testid="role-filter-toolbar">
    <el-input
      v-model="draft.keyword"
      :placeholder="t('module.iam.roles.filter.keyword')"
      clearable
      data-testid="role-filter-keyword"
      @keyup.enter="onSearch"
    />

    <el-select
      v-model="draft.enabled"
      :placeholder="t('module.iam.common.enabledState')"
      data-testid="role-filter-enabled"
    >
      <el-option
        v-for="option in enabledOptions"
        :key="option.value"
        :label="option.label"
        :value="option.value"
      />
    </el-select>

    <template #actions>
      <el-button native-type="button" data-testid="role-filter-reset" @click.prevent="onReset">
        {{ t('module.iam.common.resetFilters') }}
      </el-button>
      <el-button type="primary" native-type="button" data-testid="role-filter-search" @click.prevent="onSearch">
        {{ t('module.iam.roles.filter.search') }}
      </el-button>
    </template>
  </BrickFilterToolbar>
</template>
