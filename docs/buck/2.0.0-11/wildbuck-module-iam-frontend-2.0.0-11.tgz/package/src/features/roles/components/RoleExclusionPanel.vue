<script setup lang="ts">
import { computed } from 'vue';
import { BrickConsoleDrawer } from '@wildbuck/core-ui-frontend/shell';
import { BrickActionBar, BrickEmptyState, BrickRiskConfirm } from '@wildbuck/core-ui-frontend/patterns';
import type { RoleExclusionPairSummary, RoleSummary } from '../../../generated/types';
import { BrickTableActions as IamTableActions } from '@wildbuck/core-ui-frontend/patterns';
import { useIamI18n } from '../../management-i18n.js';

const { t } = useIamI18n();

const props = defineProps<{
  canCreate: boolean;
  conflictConfirmVisible: boolean;
  deletingId: string;
  form: {
    roleIdA: string;
    roleIdB: string;
    remark: string;
  };
  /** Changes after successful create to remount the form and clear residual validation UI. */
  formEpoch?: number;
  listError: string;
  listLoading: boolean;
  pairs: RoleExclusionPairSummary[];
  roleOptions: RoleSummary[];
  saving: boolean;
  visible: boolean;
}>();

const emit = defineEmits<{
  cancelConflict: [];
  close: [];
  confirmConflict: [];
  create: [];
  delete: [exclusionPairId: string];
  reload: [];
}>();

const enabledRoles = computed(() =>
  (props.roleOptions || []).filter((role) => role.enabled !== false),
);

function roleLabel(role: RoleSummary) {
  return role.roleName || role.roleId;
}

function submitCreate() {
  if (props.saving || !props.canCreate) {
    return;
  }
  emit('create');
}
</script>

<template>
  <BrickConsoleDrawer
    :model-value="visible"
    size="56%"
    :destroy-on-close="false"
    class="role-exclusion-drawer"
    :eyebrow="t('module.iam.roles.exclusion.drawerEyebrow')"
    :title="t('module.iam.roles.exclusion.title')"
    :description="t('module.iam.roles.exclusion.drawerDescription', { count: pairs.length })"
    @close="$emit('close')"
  >
    <p v-if="listLoading && pairs.length === 0" class="role-exclusion-drawer__state">
      {{ t('module.iam.roles.exclusion.loading') }}
    </p>

    <template v-else>
      <!-- Flat body inside BrickConsoleDrawer: same card grammar as EmployeeRoleCard / formal detail cards -->
      <section class="console-detail-card">
        <div class="console-detail-card__header">
          <div>
            <h2>{{ t('module.iam.roles.exclusion.formTitle') }}</h2>
            <p>{{ t('module.iam.roles.exclusion.formSubtitle') }}</p>
          </div>
          <span class="console-summary-chip">
            {{ t('module.iam.roles.exclusion.count', { count: pairs.length }) }}
          </span>
        </div>

        <el-form
          :key="`role-exclusion-form-${props.formEpoch || 0}`"
          class="console-detail-form brick-required-form"
          label-position="top"
          @submit.prevent="submitCreate"
        >
          <el-form-item :label="t('module.iam.roles.exclusion.roleA')" required>
            <el-select
              v-model="form.roleIdA"
              filterable
              clearable
              :disabled="saving"
              :placeholder="t('module.iam.roles.exclusion.rolePlaceholder')"
              :aria-label="t('module.iam.roles.exclusion.roleA')"
            >
              <el-option
                v-for="role in enabledRoles"
                :key="`a-${role.roleId}`"
                :label="roleLabel(role)"
                :value="role.roleId"
                :disabled="role.roleId === form.roleIdB"
              />
            </el-select>
          </el-form-item>

          <el-form-item :label="t('module.iam.roles.exclusion.roleB')" required>
            <el-select
              v-model="form.roleIdB"
              filterable
              clearable
              :disabled="saving"
              :placeholder="t('module.iam.roles.exclusion.rolePlaceholder')"
              :aria-label="t('module.iam.roles.exclusion.roleB')"
            >
              <el-option
                v-for="role in enabledRoles"
                :key="`b-${role.roleId}`"
                :label="roleLabel(role)"
                :value="role.roleId"
                :disabled="role.roleId === form.roleIdA"
              />
            </el-select>
          </el-form-item>

          <el-form-item class="console-detail-form__full" :label="t('module.iam.roles.exclusion.remarkOptional')">
            <el-input
              v-model.trim="form.remark"
              :disabled="saving"
              maxlength="100"
              :placeholder="t('module.iam.roles.exclusion.remarkPlaceholder')"
              :aria-label="t('module.iam.roles.exclusion.remarkOptional')"
            />
          </el-form-item>

          <BrickActionBar class="console-detail-form__full">
            <template #primary>
              <el-button type="primary" native-type="submit" :loading="saving" :disabled="!canCreate">
                {{ t('module.iam.roles.exclusion.create') }}
              </el-button>
              <el-button plain :loading="listLoading" :disabled="saving" @click="$emit('reload')">
                {{ t('module.iam.roles.exclusion.reload') }}
              </el-button>
            </template>
          </BrickActionBar>
        </el-form>
      </section>

      <p v-if="listError" class="role-exclusion-drawer__error" role="alert">{{ listError }}</p>

      <section class="console-detail-card role-exclusion-drawer__list-card">
        <div class="console-detail-card__header">
          <div>
            <h2>{{ t('module.iam.roles.exclusion.listTitle') }}</h2>
            <p>{{ t('module.iam.roles.exclusion.listSubtitle') }}</p>
          </div>
        </div>

        <div v-if="pairs.length === 0 && !listLoading" class="role-exclusion-drawer__empty-wrap">
          <BrickEmptyState
            compact
            :title="t('module.iam.roles.exclusion.empty')"
            :description="t('module.iam.roles.exclusion.emptyHint')"
          />
        </div>

        <el-table
          v-else
          :data="pairs"
          row-key="exclusionPairId"
          v-loading="listLoading"
          class="role-exclusion-drawer__table"
        >
          <el-table-column :label="t('module.iam.roles.exclusion.column.roleLow')" min-width="160">
            <template #default="{ row }">
              <div class="role-exclusion-drawer__role-cell">
                <span class="role-exclusion-drawer__role-name">{{ row.roleNameLow || row.roleIdLow }}</span>
                <span class="role-exclusion-drawer__role-id">{{ row.roleIdLow }}</span>
              </div>
            </template>
          </el-table-column>
          <el-table-column :label="t('module.iam.roles.exclusion.column.roleHigh')" min-width="160">
            <template #default="{ row }">
              <div class="role-exclusion-drawer__role-cell">
                <span class="role-exclusion-drawer__role-name">{{ row.roleNameHigh || row.roleIdHigh }}</span>
                <span class="role-exclusion-drawer__role-id">{{ row.roleIdHigh }}</span>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="remark" :label="t('module.iam.roles.exclusion.column.remark')" min-width="140">
            <template #default="{ row }">
              {{ row.remark || t('module.iam.common.notFilled') }}
            </template>
          </el-table-column>
          <el-table-column :label="t('module.iam.common.actions')" width="120" fixed="right">
            <template #default="{ row }">
              <IamTableActions>
                <BrickRiskConfirm
                  :title="t('module.iam.roles.exclusion.deleteTitle')"
                  :description="t('module.iam.roles.exclusion.deleteDescription')"
                  :confirm-text="t('module.iam.common.confirmDelete')"
                  @confirm="$emit('delete', row.exclusionPairId)"
                >
                  <template #trigger>
                    <el-button
                      link
                      type="danger"
                      :loading="deletingId === row.exclusionPairId"
                      :disabled="Boolean(deletingId) && deletingId !== row.exclusionPairId"
                    >
                      {{ t('module.iam.common.delete') }}
                    </el-button>
                  </template>
                </BrickRiskConfirm>
              </IamTableActions>
            </template>
          </el-table-column>
        </el-table>
      </section>
    </template>

    <BrickRiskConfirm
      :model-value="conflictConfirmVisible"
      :title="t('module.iam.roles.exclusion.conflictTitle')"
      :description="t('module.iam.roles.exclusion.conflictDescription')"
      :impact="[t('module.iam.roles.exclusion.conflictImpact1'), t('module.iam.roles.exclusion.conflictImpact2')]"
      :confirm-text="t('module.iam.roles.exclusion.conflictConfirm')"
      @confirm="$emit('confirmConflict')"
      @cancel="$emit('cancelConflict')"
      @update:model-value="(v) => !v && $emit('cancelConflict')"
    />
  </BrickConsoleDrawer>
</template>

<style scoped>
@import "../../../shared/detail-form.css";

.role-exclusion-drawer__state {
  margin: 0;
  padding: 4px 0;
  color: var(--console-text, #41516a);
  font-size: 13px;
}

.role-exclusion-drawer__list-card {
  margin-top: 16px;
}

.role-exclusion-drawer__error {
  margin: 12px 0 0;
  color: var(--console-danger, #b4232f);
  font-size: 13px;
}

.role-exclusion-drawer__empty-wrap {
  padding: 8px 18px 20px;
}

.role-exclusion-drawer__table {
  width: 100%;
}

.role-exclusion-drawer__table :deep(.el-table__inner-wrapper::before) {
  display: none;
}

.role-exclusion-drawer__table :deep(.el-table__header th) {
  color: var(--console-muted, #7e8ba0);
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 0.04em;
  background: var(--console-card-bg, #ffffff);
}

.role-exclusion-drawer__role-cell {
  display: grid;
  gap: 2px;
  min-width: 0;
}

.role-exclusion-drawer__role-name {
  color: var(--console-title, #172033);
  font-size: 13px;
  font-weight: 600;
  line-height: 1.4;
}

.role-exclusion-drawer__role-id {
  color: var(--console-muted, #64748b);
  font-size: 12px;
  font-family: "SFMono-Regular", "Cascadia Code", ui-monospace, monospace;
  line-height: 1.4;
  word-break: break-all;
}
</style>
