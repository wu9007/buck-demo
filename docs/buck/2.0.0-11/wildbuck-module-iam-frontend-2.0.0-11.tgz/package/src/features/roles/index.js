import { rolePermissions } from './permission/index.js';
import { roleRoutes } from './routes/index.js';

export const rolesFeature = {
  featureKey: 'roles',
  routes: roleRoutes,
  permissions: rolePermissions,
};
