import { computed, reactive, ref } from 'vue';
import { isBrickSessionError } from '@wildbuck/core-api-frontend';
import { showBrickStatus } from '@wildbuck/core-ui-frontend';
import {
  loadRoleAuthorizationWorkspace,
  saveRoleAuthorizationWorkspace,
} from '../../../role-authorization-workspace.js';
import type {
  RoleAuthorizationDetail,
  RoleDetail,
  RoleSummary,
  UpdateRoleRequest,
} from '../../../generated/types';
import {
  loadRoleDetail,
  removeRole,
  saveNewRole,
  saveRole,
  searchRoles,
} from '../api/role';
import { resolveRoleErrorMessage } from '../lib/role-errors';
import { useIamI18n } from '../../management-i18n.js';
import {
  iamUsageTracker,
  resolveIamStatusAction,
} from '../../../usage-events';

type EditorMode = 'edit' | 'create';
type RoleDrawerTab = 'detail' | 'authorization';

export function useRoleWorkspace() {
  const { t } = useIamI18n();
  const roles = ref<RoleSummary[]>([]);
  const total = ref(0);
  const page = ref(1);
  const pageSize = ref(20);
  const pageSizeOptions = [10, 20, 50, 100];
  const listLoading = ref(true);
  const detailLoading = ref(false);
  const authorizationLoading = ref(false);
  const roleSaving = ref(false);
  const authorizationSaving = ref(false);
  const listError = ref('');
  const selectedRoleId = ref('');
  const editorMode = ref<EditorMode>('edit');
  const drawerVisible = ref(false);
  const activeTab = ref<RoleDrawerTab>('detail');
  const currentDetail = ref<RoleDetail | null>(null);
  const authorizationDetail = ref<RoleAuthorizationDetail | null>(null);
  const permissionDraft = ref<string[]>([]);

  /** 已应用筛选（仅查询/重置时更新；输入草稿在 FilterToolbar 内） */
  const filters = reactive({
    keyword: '',
    enabled: 'all',
  });

  const form = reactive<UpdateRoleRequest>({
    roleName: '',
    remark: '',
    enabled: true,
  });

  const selectedRole = computed(() => {
    const listedRole = roles.value.find((role) => role.roleId === selectedRoleId.value);
    if (listedRole) {
      return listedRole;
    }
    if (currentDetail.value && currentDetail.value.roleId === selectedRoleId.value) {
      return {
        enabled: currentDetail.value.enabled,
        roleId: currentDetail.value.roleId,
        roleName: currentDetail.value.roleName,
      };
    }
    return null;
  });
  const filterActive = computed(() => (
    Boolean(filters.keyword.trim())
    || filters.enabled !== 'all'
  ));
  const roleMetrics = computed(() => ({
    total: total.value || roles.value.length,
    enabled: roles.value.filter((role) => role.enabled).length,
    disabled: roles.value.filter((role) => !role.enabled).length,
  }));
  const canSaveAuthorization = computed(() => editorMode.value === 'edit' && Boolean(selectedRoleId.value));
  const pageSummary = computed(() => t('module.iam.roles.list.loaded', { count: roles.value.length, total: total.value }));
  const hasPreviousPage = computed(() => page.value > 1);
  const hasNextPage = computed(() => page.value * pageSize.value < total.value);
  const panelLoading = computed(() => detailLoading.value || authorizationLoading.value);

  async function initialize() {
    const routeIntent = consumeManagementRouteIntent('iam.roles.list');
    const preferredRoleId = routeIntent?.roleId;
    await reloadRoles(preferredRoleId);
    if (preferredRoleId && roles.value.some((role) => role.roleId === preferredRoleId)) {
      await openRole(preferredRoleId);
    }
  }

  async function reloadRoles(preferredRoleId?: string) {
    listLoading.value = true;
    listError.value = '';
    try {
      const response = await searchRoles({
        keyword: filters.keyword.trim() || undefined,
        enabled: filters.enabled === 'all' ? undefined : filters.enabled === 'enabled',
        page: page.value,
        size: pageSize.value,
      });
      roles.value = response.records || [];
      total.value = response.total || 0;
      if (preferredRoleId && roles.value.some((role) => role.roleId === preferredRoleId)) {
        selectedRoleId.value = preferredRoleId;
      } else if (!roles.value.some((role) => role.roleId === selectedRoleId.value)) {
        selectedRoleId.value = roles.value[0]?.roleId || '';
      }
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      roles.value = [];
      total.value = 0;
      selectedRoleId.value = '';
      listError.value = resolveRoleErrorMessage(error);
      return false;
    } finally {
      listLoading.value = false;
    }
  }

  function assignFilters(next?: { keyword?: string; enabled?: string }) {
    filters.keyword = next?.keyword ?? '';
    filters.enabled = next?.enabled ?? 'all';
  }

  async function submitSearch(next?: { keyword?: string; enabled?: string }) {
    if (next) {
      assignFilters(next);
    }
    page.value = 1;
    const loaded = await reloadRoles();
    await reloadDrawerSelection();
    if (loaded) {
      void iamUsageTracker.trackActionResult('role', 'search', 'SUCCESS');
    } else {
      void iamUsageTracker.trackActionResult('role', 'search', 'FAILURE');
    }
    return loaded;
  }

  async function resetFilters(next?: { keyword?: string; enabled?: string }) {
    assignFilters(next ?? { keyword: '', enabled: 'all' });
    return submitSearch({ keyword: filters.keyword, enabled: filters.enabled });
  }

  async function goToPreviousPage() {
    if (!hasPreviousPage.value) {
      return;
    }
    page.value -= 1;
    await reloadRoles();
    await reloadDrawerSelection();
  }

  async function goToNextPage() {
    if (!hasNextPage.value) {
      return;
    }
    page.value += 1;
    await reloadRoles();
    await reloadDrawerSelection();
  }

  async function changePage(nextPage: number) {
    if (nextPage < 1 || nextPage === page.value) {
      return;
    }
    page.value = nextPage;
    await reloadRoles();
    await reloadDrawerSelection();
  }

  async function changePageSize(nextSize: number) {
    if (nextSize < 1 || nextSize === pageSize.value) {
      return;
    }
    pageSize.value = nextSize;
    page.value = 1;
    await reloadRoles();
    await reloadDrawerSelection();
  }

  async function openRole(roleId: string, options: { trackEnter?: boolean } = {}) {
    if (!roleId) {
      return false;
    }
    const shouldTrackEnter = options.trackEnter ?? true;
    selectedRoleId.value = roleId;
    editorMode.value = 'edit';
    drawerVisible.value = true;
    activeTab.value = 'detail';
    try {
      await Promise.all([loadDetail(roleId), loadAuthorization(roleId)]);
      if (shouldTrackEnter) {
        void iamUsageTracker.trackOpen('role', 'open-detail');
      }
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      showBrickStatus(resolveRoleErrorMessage(error), 'error');
      if (shouldTrackEnter) {
        void iamUsageTracker.trackOpen('role', 'open-detail', 'FAILURE');
      }
      return false;
    }
  }

  function closeDrawer() {
    drawerVisible.value = false;
    activeTab.value = 'detail';
  }

  function startCreateRole() {
    editorMode.value = 'create';
    drawerVisible.value = true;
    activeTab.value = 'detail';
    selectedRoleId.value = '';
    currentDetail.value = null;
    authorizationDetail.value = null;
    permissionDraft.value = [];
    fillForm({
      roleName: '',
      remark: '',
      enabled: true,
    });
    void iamUsageTracker.trackOpen('role', 'open-create');
  }

  async function submitRoleForm() {
    roleSaving.value = true;
    const wasCreating = editorMode.value === 'create';
    const actionCode = wasCreating
      ? 'create'
      : resolveIamStatusAction(currentDetail.value?.enabled, Boolean(form.enabled));
    try {
      const payload = normalizeForm();
      const detail = wasCreating
        ? await saveNewRole(payload)
        : await saveRole(selectedRoleId.value, payload);
      await reloadRoles(detail.roleId);
      await openRole(detail.roleId, { trackEnter: false });
      if (wasCreating) {
        updateActiveTab('authorization');
      }
      showBrickStatus(t('module.iam.roles.status.saved', { name: detail.roleName }), 'success');
      void iamUsageTracker.trackActionResult('role', actionCode, 'SUCCESS');
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      showBrickStatus(resolveRoleErrorMessage(error), 'error');
      void iamUsageTracker.trackActionResult('role', actionCode, 'FAILURE');
      return false;
    } finally {
      roleSaving.value = false;
    }
  }

  async function deleteSelectedRole() {
    if (editorMode.value !== 'edit' || !selectedRoleId.value) {
      return false;
    }
    try {
      const roleName = currentDetail.value?.roleName || selectedRole.value?.roleName || selectedRoleId.value;
      await removeRole(selectedRoleId.value);
      currentDetail.value = null;
      authorizationDetail.value = null;
      permissionDraft.value = [];
      selectedRoleId.value = '';
      closeDrawer();
      await reloadRoles();
      showBrickStatus(t('module.iam.roles.status.deleted', { name: roleName }), 'success');
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      showBrickStatus(resolveRoleErrorMessage(error), 'error');
      return false;
    }
  }

  async function submitAuthorizations() {
    if (!selectedRoleId.value || editorMode.value !== 'edit') {
      return;
    }
    authorizationSaving.value = true;
    try {
      const result = await saveRoleAuthorizationWorkspace(selectedRoleId.value, {
        permissionIds: [...permissionDraft.value],
      });
      await loadAuthorization(selectedRoleId.value);
      showBrickStatus(
        result.sessionsInvalidated
          ? t('module.iam.roles.status.grantUpdatedInvalidated')
          : t('module.iam.roles.status.grantUpdated'),
        'success',
      );
      void iamUsageTracker.trackActionResult('roleAuthorization', 'authorize', 'SUCCESS');
    } catch (error) {
      if (isBrickSessionError(error)) {
        return;
      }
      showBrickStatus(resolveRoleErrorMessage(error), 'error');
      void iamUsageTracker.trackActionResult('roleAuthorization', 'authorize', 'FAILURE');
    } finally {
      authorizationSaving.value = false;
    }
  }

  function updateActiveTab(tab: string) {
    activeTab.value = tab === 'authorization' ? 'authorization' : 'detail';
    if (activeTab.value === 'authorization' && editorMode.value === 'edit' && selectedRoleId.value) {
      void iamUsageTracker.trackOpen('roleAuthorization', 'enter');
    }
  }

  function fillForm(detail: Pick<RoleDetail, 'roleName' | 'remark' | 'enabled'>) {
    form.roleName = detail.roleName;
    form.remark = detail.remark || '';
    form.enabled = detail.enabled;
  }

  async function loadDetail(roleId: string) {
    detailLoading.value = true;
    try {
      const detail = await loadRoleDetail(roleId);
      currentDetail.value = detail;
      fillForm(detail);
    } finally {
      detailLoading.value = false;
    }
  }

  async function loadAuthorization(roleId: string) {
    authorizationLoading.value = true;
    try {
      const detail = await loadRoleAuthorizationWorkspace(roleId);
      authorizationDetail.value = detail;
      permissionDraft.value = [...(detail.assignedPermissionIds || [])];
    } finally {
      authorizationLoading.value = false;
    }
  }

  async function reloadDrawerSelection() {
    if (!drawerVisible.value || editorMode.value !== 'edit') {
      return;
    }
    if (!selectedRoleId.value || !roles.value.some((role) => role.roleId === selectedRoleId.value)) {
      closeDrawer();
      return;
    }
    await openRole(selectedRoleId.value, { trackEnter: false });
  }

  function normalizeForm(): UpdateRoleRequest {
    return {
      roleName: form.roleName.trim(),
      remark: form.remark.trim() || undefined,
      enabled: Boolean(form.enabled),
    };
  }

  return {
    activeTab,
    authorizationDetail,
    authorizationSaving,
    canSaveAuthorization,
    changePage,
    changePageSize,
    closeDrawer,
    currentDetail,
    deleteSelectedRole,
    drawerVisible,
    filterActive,
    editorMode,
    roles,
    filters,
    form,
    goToNextPage,
    goToPreviousPage,
    hasNextPage,
    hasPreviousPage,
    initialize,
    listError,
    listLoading,
    openRole,
    pageSummary,
    page,
    pageSize,
    pageSizeOptions,
    panelLoading,
    permissionDraft,
    resetFilters,
    roleMetrics,
    roleSaving,
    selectedRole,
    selectedRoleId,
    startCreateRole,
    submitAuthorizations,
    submitRoleForm,
    submitSearch,
    updateActiveTab,
  };
}

function consumeManagementRouteIntent(routeId: string): Record<string, string> | null {
  if (typeof window === 'undefined') {
    return null;
  }
  const raw = window.sessionStorage.getItem('brick.management.intent');
  if (!raw) {
    return null;
  }
  try {
    const intent = JSON.parse(raw);
    if (intent?.routeId !== routeId || !intent.selection || typeof intent.selection !== 'object') {
      return null;
    }
    window.sessionStorage.removeItem('brick.management.intent');
    return intent.selection as Record<string, string>;
  } catch {
    return null;
  }
}
