export const rolePermissions = {
  list: 'iam:role:list',
  edit: 'iam:role:edit',
  grant: 'iam:role:grant',
};
