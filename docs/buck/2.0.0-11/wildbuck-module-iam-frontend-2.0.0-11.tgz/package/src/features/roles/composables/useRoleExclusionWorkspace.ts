import { computed, reactive, ref } from 'vue';
import { isBrickSessionError, readBrickBusinessError } from '@wildbuck/core-api-frontend';
import { showBrickStatus } from '@wildbuck/core-ui-frontend';
import type { RoleExclusionPairSummary, RoleSummary } from '../../../generated/types';
import {
  loadRoleExclusionPairs,
  removeRoleExclusionPair,
  saveNewRoleExclusionPair,
  searchRoles,
} from '../api/role';
import { resolveRoleErrorMessage } from '../lib/role-errors';
import { useIamI18n } from '../../management-i18n.js';
import { iamUsageTracker } from '../../../usage-events';

function orderRoleIds(roleIdA: string, roleIdB: string): [string, string] {
  return roleIdA <= roleIdB ? [roleIdA, roleIdB] : [roleIdB, roleIdA];
}

export function useRoleExclusionWorkspace() {
  const { t } = useIamI18n();
  const pairs = ref<RoleExclusionPairSummary[]>([]);
  const roleOptions = ref<RoleSummary[]>([]);
  const listLoading = ref(false);
  const saving = ref(false);
  const deletingId = ref('');
  const listError = ref('');
  const drawerVisible = ref(false);
  const conflictConfirmVisible = ref(false);
  /** Bumps after successful create so the form remounts and drops Element Plus required errors. */
  const formEpoch = ref(0);
  const form = reactive({
    roleIdA: '',
    roleIdB: '',
    remark: '',
  });

  let createInFlight = false;
  let deleteInFlightId = '';
  let openDrawerInFlight: Promise<void> | null = null;

  const pairCount = computed(() => pairs.value.length);
  const canCreate = computed(
    () =>
      Boolean(form.roleIdA) &&
      Boolean(form.roleIdB) &&
      form.roleIdA !== form.roleIdB &&
      !saving.value &&
      !createInFlight,
  );

  /**
   * Always refresh pairs and role options when opening the drawer.
   * Page-level role create does not share this workspace; a one-shot load leaves new roles out of the select.
   */
  async function openDrawer() {
    drawerVisible.value = true;
    if (openDrawerInFlight) {
      await openDrawerInFlight;
      return;
    }
    openDrawerInFlight = initialize().finally(() => {
      openDrawerInFlight = null;
    });
    await openDrawerInFlight;
  }

  function closeDrawer() {
    drawerVisible.value = false;
    conflictConfirmVisible.value = false;
  }

  async function initialize() {
    await Promise.all([reloadPairs(), reloadRoleOptions()]);
  }

  async function reloadPairs(options: { clearOnError?: boolean } = {}) {
    const clearOnError = options.clearOnError !== false;
    listLoading.value = true;
    listError.value = '';
    try {
      const next = (await loadRoleExclusionPairs()) || [];
      pairs.value = Array.isArray(next) ? next : [];
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      if (clearOnError) {
        pairs.value = [];
        listError.value = resolveRoleErrorMessage(error);
      } else if (pairs.value.length === 0) {
        listError.value = resolveRoleErrorMessage(error);
      }
      return false;
    } finally {
      listLoading.value = false;
    }
  }

  async function reloadRoleOptions() {
    try {
      const response = await searchRoles({ page: 1, size: 200 });
      roleOptions.value = response.records || [];
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      roleOptions.value = [];
      return false;
    }
  }

  function resetForm() {
    form.roleIdA = '';
    form.roleIdB = '';
    form.remark = '';
  }

  function hasLocalPair(roleIdA: string, roleIdB: string) {
    const [low, high] = orderRoleIds(roleIdA, roleIdB);
    return pairs.value.some((pair) => pair.roleIdLow === low && pair.roleIdHigh === high);
  }

  function upsertLocalPair(created: RoleExclusionPairSummary) {
    if (!created?.exclusionPairId) {
      return;
    }
    const others = pairs.value.filter((pair) => pair.exclusionPairId !== created.exclusionPairId);
    pairs.value = [created, ...others];
  }

  async function createPair(options: { confirmExistingConflicts?: boolean } = {}) {
    if (createInFlight || saving.value) {
      return false;
    }
    if (!form.roleIdA || !form.roleIdB) {
      showBrickStatus(t('module.iam.roles.exclusion.needTwoRoles'), 'warning');
      return false;
    }
    if (form.roleIdA === form.roleIdB) {
      showBrickStatus(t('module.iam.roles.exclusion.sameRole'), 'warning');
      return false;
    }
    if (hasLocalPair(form.roleIdA, form.roleIdB)) {
      showBrickStatus(t('module.iam.roles.exclusion.alreadyExists'), 'warning');
      return false;
    }

    createInFlight = true;
    saving.value = true;
    listError.value = '';
    try {
      const created = await saveNewRoleExclusionPair({
        roleIdA: form.roleIdA,
        roleIdB: form.roleIdB,
        remark: form.remark.trim() || undefined,
        confirmExistingConflicts: options.confirmExistingConflicts === true,
      });
      if (created?.exclusionPairId) {
        upsertLocalPair(created);
      } else {
        await reloadPairs({ clearOnError: false });
      }
      resetForm();
      formEpoch.value += 1;
      conflictConfirmVisible.value = false;
      const affected = Number(created?.affectedPrincipalCount || 0);
      // Keep success tone even when dual-hold accounts remain: rule is saved; copy explains residual risk.
      if (affected > 0) {
        showBrickStatus(t('module.iam.roles.exclusion.status.createdWithConflicts', { count: affected }), 'success');
      } else {
        showBrickStatus(t('module.iam.roles.exclusion.status.created'), 'success');
      }
      void iamUsageTracker.trackActionResult('roleExclusion', 'create', 'SUCCESS');
      void reloadPairs({ clearOnError: false });
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      const code = readBrickBusinessError(error).code;
      if (code === 'IAM_ROLE_EXCLUSION_EXISTING_ASSIGNMENTS' && options.confirmExistingConflicts !== true) {
        conflictConfirmVisible.value = true;
        return false;
      }
      showBrickStatus(resolveRoleErrorMessage(error), 'error');
      void iamUsageTracker.trackActionResult('roleExclusion', 'create', 'FAILURE');
      return false;
    } finally {
      createInFlight = false;
      saving.value = false;
    }
  }

  async function confirmCreateDespiteConflicts() {
    conflictConfirmVisible.value = false;
    return createPair({ confirmExistingConflicts: true });
  }

  function cancelConflictConfirm() {
    conflictConfirmVisible.value = false;
  }

  async function deletePair(exclusionPairId: string) {
    if (!exclusionPairId || deleteInFlightId === exclusionPairId) {
      return false;
    }
    deleteInFlightId = exclusionPairId;
    deletingId.value = exclusionPairId;
    listError.value = '';
    try {
      await removeRoleExclusionPair(exclusionPairId);
      pairs.value = pairs.value.filter((pair) => pair.exclusionPairId !== exclusionPairId);
      showBrickStatus(t('module.iam.roles.exclusion.status.deleted'), 'success');
      void iamUsageTracker.trackActionResult('roleExclusion', 'delete', 'SUCCESS');
      void reloadPairs({ clearOnError: false });
      return true;
    } catch (error) {
      if (isBrickSessionError(error)) {
        return false;
      }
      showBrickStatus(resolveRoleErrorMessage(error), 'error');
      void iamUsageTracker.trackActionResult('roleExclusion', 'delete', 'FAILURE');
      return false;
    } finally {
      deleteInFlightId = '';
      deletingId.value = '';
    }
  }

  return {
    canCreate,
    cancelConflictConfirm,
    closeDrawer,
    confirmCreateDespiteConflicts,
    conflictConfirmVisible,
    createPair,
    deletePair,
    deletingId,
    drawerVisible,
    form,
    formEpoch,
    initialize,
    listError,
    listLoading,
    openDrawer,
    pairCount,
    pairs,
    reloadPairs,
    reloadRoleOptions,
    resetForm,
    roleOptions,
    saving,
  };
}
