export const currentPrincipalPermissions = {
  detail: 'authenticated',
  navigation: 'authenticated',
};
