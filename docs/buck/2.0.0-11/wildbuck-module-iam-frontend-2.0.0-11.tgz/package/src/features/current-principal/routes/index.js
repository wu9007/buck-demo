/** No console page for current principal; shell uses workspace API for menu/permission projection. */
export const currentPrincipalRoutes = [];
