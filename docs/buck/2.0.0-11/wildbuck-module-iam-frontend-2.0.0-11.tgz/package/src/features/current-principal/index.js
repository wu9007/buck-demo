import { currentPrincipalPermissions } from './permission/index.js';
import { currentPrincipalRoutes } from './routes/index.js';

/**
 * Current-principal feature owns workspace projection (permissions/menus), not a management page.
 * Page route intentionally empty — shell consumes current-principal-workspace helpers.
 */
export const currentPrincipalFeature = {
  featureKey: 'current-principal',
  routes: currentPrincipalRoutes,
  permissions: currentPrincipalPermissions,
};
