import type { BrickFrontendModuleExperienceDefinition } from './index.js';

export declare const authExperience: BrickFrontendModuleExperienceDefinition;
export declare function createAuthExperience(locale?: string): BrickFrontendModuleExperienceDefinition;
export declare function resolveIamAuthMessages(locale?: string): Readonly<Record<string, string>>;
export declare function resolveIamManagementMessages(locale?: string): Readonly<Record<string, string>>;
export declare function resolveIamModuleMessages(locale?: string): Readonly<Record<string, string>>;
