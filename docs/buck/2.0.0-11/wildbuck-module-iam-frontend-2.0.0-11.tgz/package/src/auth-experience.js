export {
  authExperience,
  createAuthExperience,
  resolveIamAuthMessages,
} from './features/auth/auth-experience-factory.js';

export {
  resolveIamManagementMessages,
  resolveIamModuleMessages,
} from './features/management-i18n.js';
