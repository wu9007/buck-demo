export { useAuthWorkspace } from './features/auth/composables/useAuthWorkspace.js';
