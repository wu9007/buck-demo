export { default } from './features/auth/components/IamAuthFlowView.vue';
