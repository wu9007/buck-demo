import { request as brickRequest, requestBlob } from '@wildbuck/core-api-frontend';
import {
  buildBrickConsoleNavigationGroupsFromMenus,
  mergeBrickConsoleRoutesWithMenus,
} from '@wildbuck/core-ui-frontend/shell-navigation';

const DEFAULT_IMAGE_OBJECT_URL_CACHE = new Map();
const MISSING_IMAGE_RESOURCE_STORAGE_KEY = 'brick.iam.missing-image-resource-ids';

export async function loadCurrentPrincipalWorkspace() {
  return brickRequest('/iam/current-principal/workspace', {
    method: 'POST',
    body: JSON.stringify(null),
  });
}

/**
 * Load image blob as object URL for shell avatar / menu icons.
 * Soft-fails on 404 (orphan metadata after tmp wipe) and remembers missing ids
 * in sessionStorage so full page refresh does not re-hit the same broken content.
 */
export async function loadIamImageResourceObjectUrl(resourceId, options = {}) {
  const normalized = normalizeResourceId(resourceId);
  if (!normalized) {
    return '';
  }
  if (isKnownMissingImageResourceId(normalized, options)) {
    return '';
  }
  try {
    const requestBlobFn = typeof options.requestBlob === 'function' ? options.requestBlob : requestBlob;
    const blob = await requestBlobFn(`/file-resources/${encodeURIComponent(normalized)}/content`);
    const createObjectURL = options.createObjectURL || globalThis.URL?.createObjectURL?.bind(globalThis.URL);
    rememberMissingImageResourceId(normalized, false, options);
    return typeof createObjectURL === 'function' ? createObjectURL(blob) : '';
  } catch {
    // 元数据在、磁盘丢失或 404：壳层用默认图标，并负向缓存避免每次刷新再打 404
    rememberMissingImageResourceId(normalized, true, options);
    return '';
  }
}

export async function loadCurrentPrincipalShellVisuals(workspace = null, options = {}) {
  const imageUrls = await loadCurrentPrincipalImageResourceUrls(workspace, options);
  const avatarResourceId = resolveCurrentPrincipalAvatarResourceId(workspace);
  return {
    principalAvatarUrl: avatarResourceId ? imageUrls[avatarResourceId] || '' : '',
    menuIconUrls: Object.fromEntries(
      Object.entries(imageUrls).filter(([resourceId]) => resourceId !== avatarResourceId)
    ),
  };
}

export function mergeCurrentPrincipalMenusIntoRoutes(routes = [], workspace = null, options = {}) {
  return mergeBrickConsoleRoutesWithMenus(routes, toShellMenus(workspace, options));
}

export function buildCurrentPrincipalNavigationGroups(routes = [], workspace = null, options = {}) {
  const mergedRoutes = mergeCurrentPrincipalMenusIntoRoutes(routes, workspace, options);
  return buildBrickConsoleNavigationGroupsFromMenus(mergedRoutes, toShellMenus(workspace, options), {
    permissions: options.permissions || [],
    useMergedRoutes: true,
  });
}

export function resolveCurrentPrincipalAvatarResourceId(workspace = null) {
  return normalizeResourceId(workspace?.avatarResourceId);
}

function normalizeResourceId(value) {
  return normalizeText(value);
}

function normalizeText(value) {
  return typeof value === 'string' && value.trim() ? value.trim() : '';
}

function toShellMenus(workspace, options = {}) {
  const menuIconUrls = options.menuIconUrls || {};
  return (workspace?.navigationMenus || []).map((menu) => toShellMenuNode(menu, menuIconUrls));
}

async function loadCurrentPrincipalImageResourceUrls(workspace = null, options = {}) {
  const cache = options.cache instanceof Map ? options.cache : DEFAULT_IMAGE_OBJECT_URL_CACHE;
  const loadImageResourceObjectUrl = options.loadImageResourceObjectUrl
    || ((resourceId) => loadIamImageResourceObjectUrl(resourceId, options));
  const resourceIds = collectCurrentPrincipalImageResourceIds(workspace);
  const loadedEntries = await Promise.all(resourceIds.map(async (resourceId) => {
    if (cache.has(resourceId)) {
      return [resourceId, cache.get(resourceId)];
    }
    try {
      const imageResourceUrl = await loadImageResourceObjectUrl(resourceId);
      // 成功与失败都缓存，避免同一缺失资源反复打 404
      cache.set(resourceId, imageResourceUrl || '');
      return [resourceId, imageResourceUrl || ''];
    } catch {
      cache.set(resourceId, '');
      return [resourceId, ''];
    }
  }));
  return Object.fromEntries(loadedEntries.filter(([, imageResourceUrl]) => Boolean(imageResourceUrl)));
}

function collectCurrentPrincipalImageResourceIds(workspace) {
  const resourceIds = new Set();
  if (workspace?.avatarResourceId) {
    resourceIds.add(workspace.avatarResourceId);
  }
  for (const functionPoint of workspace?.functionPoints || []) {
    collectMenuImageResourceIds(functionPoint.menus || [], resourceIds);
  }
  collectMenuImageResourceIds(workspace?.navigationMenus || [], resourceIds);
  return [...resourceIds].map((resourceId) => normalizeResourceId(resourceId)).filter(Boolean);
}

function collectMenuImageResourceIds(menus, resourceIds) {
  for (const menu of menus || []) {
    if (menu?.iconResourceId) {
      resourceIds.add(menu.iconResourceId);
    }
    collectMenuImageResourceIds(menu?.children || [], resourceIds);
  }
}

function toShellMenuNode(menu, menuIconUrls) {
  const iconResourceId = normalizeResourceId(menu?.iconResourceId);
  return {
    id: normalizeText(menu?.menuId),
    code: normalizeText(menu?.menuCode),
    title: normalizeText(menu?.menuName),
    path: normalizeText(menu?.routePath),
    iconName: normalizeText(menu?.icon),
    iconResourceId,
    // Missing blob stays empty; shell falls back to iconName / line icon.
    iconUrl: iconResourceId ? menuIconUrls[iconResourceId] || '' : '',
    order: Number.isFinite(menu?.sortNo) ? menu.sortNo : 0,
    sortNo: Number.isFinite(menu?.sortNo) ? menu.sortNo : 0,
    children: (menu?.children || []).map((child) => toShellMenuNode(child, menuIconUrls)),
  };
}

function isKnownMissingImageResourceId(resourceId, options = {}) {
  const storage = resolveSessionStorage(options);
  if (!storage) {
    return false;
  }
  try {
    const raw = storage.getItem(MISSING_IMAGE_RESOURCE_STORAGE_KEY);
    if (!raw) {
      return false;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.includes(resourceId);
  } catch {
    return false;
  }
}

function rememberMissingImageResourceId(resourceId, missing, options = {}) {
  const storage = resolveSessionStorage(options);
  if (!storage) {
    return;
  }
  try {
    const raw = storage.getItem(MISSING_IMAGE_RESOURCE_STORAGE_KEY);
    const current = raw ? JSON.parse(raw) : [];
    const list = Array.isArray(current) ? current.filter((item) => typeof item === 'string') : [];
    const next = new Set(list);
    if (missing) {
      next.add(resourceId);
    } else {
      next.delete(resourceId);
    }
    storage.setItem(MISSING_IMAGE_RESOURCE_STORAGE_KEY, JSON.stringify([...next]));
  } catch {
    // sessionStorage may be unavailable (privacy mode / quota); memory cache still applies.
  }
}

function resolveSessionStorage(options = {}) {
  if (options.sessionStorage) {
    return options.sessionStorage;
  }
  if (typeof globalThis !== 'undefined' && globalThis.sessionStorage) {
    return globalThis.sessionStorage;
  }
  return null;
}
