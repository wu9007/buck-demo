import { request as brickRequest } from '@wildbuck/core-api-frontend';

export async function loadRoleAuthorizationWorkspace(roleId) {
  return brickRequest(`/iam/roles/${encodeURIComponent(roleId)}/authorizations/detail`, {
    method: 'POST',
    body: JSON.stringify(null),
  });
}

export async function saveRoleAuthorizationWorkspace(roleId, input) {
  return brickRequest(`/iam/roles/${encodeURIComponent(roleId)}/authorizations`, {
    method: 'PUT',
    body: JSON.stringify(input),
  });
}
