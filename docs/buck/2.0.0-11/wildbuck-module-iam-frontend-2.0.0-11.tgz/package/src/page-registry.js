import { iamRoutes } from './routes/index.js';

export const brickRouteComponentLoaders = {
  'iam.employees.list': () => import('./features/employees/pages/IamEmployeesPage.vue'),
  'iam.menus.list': () => import('./features/menus/pages/IamMenusPage.vue'),
  'iam.organizations.list': () => import('./features/organizations/pages/IamOrganizationsPage.vue'),
  'iam.roles.list': () => import('./features/roles/pages/IamRolesPage.vue'),
  'iam.sessions.list': () => import('./features/sessions/pages/IamSessionsPage.vue'),
};

export function validateIamPageRegistry({
  routes = iamRoutes,
  loaders = brickRouteComponentLoaders,
  grantedPermissions,
} = {}) {
  const normalizedRoutes = Array.isArray(routes) ? routes : [];
  const normalizedLoaders = loaders && typeof loaders === 'object' ? loaders : {};
  const routeIds = normalizedRoutes.map((route) => route?.id).filter(Boolean).sort();
  const loaderIds = Object.keys(normalizedLoaders).filter((routeId) => typeof normalizedLoaders[routeId] === 'function').sort();
  const routeIdSet = new Set(routeIds);
  const loaderIdSet = new Set(loaderIds);
  const granted = Array.isArray(grantedPermissions) ? new Set(grantedPermissions) : null;

  const missingLoaderRouteIds = routeIds.filter((routeId) => !loaderIdSet.has(routeId));
  const orphanLoaderRouteIds = loaderIds.filter((routeId) => !routeIdSet.has(routeId));
  const missingPermissionRouteIds = granted == null
    ? []
    : normalizedRoutes
      .filter((route) => route?.permission && route.permission !== 'authenticated' && !granted.has(route.permission))
      .map((route) => route.id)
      .sort();
  const messages = [
    ...missingLoaderRouteIds.map((routeId) => `IAM route ${routeId} has no page-registry loader.`),
    ...orphanLoaderRouteIds.map((routeId) => `IAM page-registry loader ${routeId} has no matching route metadata.`),
    ...missingPermissionRouteIds.map((routeId) => `Current principal lacks permission for IAM route ${routeId}.`),
  ];

  return Object.freeze({
    ok: messages.length === 0,
    routeIds: Object.freeze(routeIds),
    loaderIds: Object.freeze(loaderIds),
    missingLoaderRouteIds: Object.freeze(missingLoaderRouteIds),
    orphanLoaderRouteIds: Object.freeze(orphanLoaderRouteIds),
    missingPermissionRouteIds: Object.freeze(missingPermissionRouteIds),
    messages: Object.freeze(messages),
  });
}
