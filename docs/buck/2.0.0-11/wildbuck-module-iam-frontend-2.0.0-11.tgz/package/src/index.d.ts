export interface BrickFrontendRouteRecord {
  id: string;
  featureKey: string;
  path: string;
  title: string;
  abbr?: string;
  iconName?: string;
  iconText?: string;
  eyebrow?: string;
  summary?: string;
  messages?: Record<string, string>;
  permission: string;
  component: () => Promise<unknown>;
}

export interface BrickFrontendModuleMeta {
  displayName: string;
}

export interface BrickFrontendModuleExperienceDefinition {
  view?: Record<string, string>;
  loginModes?: Record<string, Record<string, string>>;
  messages?: Record<string, string>;
}

export interface BrickFrontendFeatureDefinition {
  featureKey: string;
  routes: BrickFrontendRouteRecord[];
  permissions: Record<string, string>;
}

export declare const iamFeatureRegistry: {
  currentPrincipal: BrickFrontendFeatureDefinition;
  roles: BrickFrontendFeatureDefinition;
  sessions: BrickFrontendFeatureDefinition;
  employees: BrickFrontendFeatureDefinition;
  organizations: BrickFrontendFeatureDefinition;
  menus: BrickFrontendFeatureDefinition;
};

export declare const iamPermissionMap: {
  currentPrincipal: Record<string, string>;
  roles: Record<string, string>;
  sessions: Record<string, string>;
  employees: Record<string, string>;
  organizations: Record<string, string>;
  menus: Record<string, string>;
};
export declare const iamExperiences: {
  auth: BrickFrontendModuleExperienceDefinition;
};

export declare const iamRoutes: BrickFrontendRouteRecord[];
export declare const brickModuleKey: string;
export declare const brickModuleMeta: BrickFrontendModuleMeta;
export declare const brickModuleExperiences: {
  auth: BrickFrontendModuleExperienceDefinition;
};
export declare const brickFeatureRegistry: {
  currentPrincipal: BrickFrontendFeatureDefinition;
  roles: BrickFrontendFeatureDefinition;
  sessions: BrickFrontendFeatureDefinition;
  employees: BrickFrontendFeatureDefinition;
  organizations: BrickFrontendFeatureDefinition;
  menus: BrickFrontendFeatureDefinition;
};
export declare const brickPermissionMap: {
  currentPrincipal: Record<string, string>;
  roles: Record<string, string>;
  sessions: Record<string, string>;
  employees: Record<string, string>;
  organizations: Record<string, string>;
  menus: Record<string, string>;
};
export declare const brickRoutes: BrickFrontendRouteRecord[];

export type IamUsageEventPageKey =
  | 'currentPrincipal'
  | 'employees'
  | 'organizations'
  | 'roles'
  | 'menus'
  | 'sessions';
export type IamUsageEventFeatureKey =
  | 'currentPrincipal'
  | 'employee'
  | 'employeeAvatar'
  | 'employeeRole'
  | 'employeeSecurity'
  | 'employeeSession'
  | 'organization'
  | 'role'
  | 'roleAuthorization'
  | 'roleExclusion'
  | 'menu'
  | 'session';
export type IamUsageEventActionCode =
  | 'view'
  | 'search'
  | 'open-detail'
  | 'open-create'
  | 'create'
  | 'update'
  | 'enable'
  | 'disable'
  | 'delete'
  | 'upload-avatar'
  | 'reset-password'
  | 'unlock'
  | 'save-roles'
  | 'force-offline'
  | 'authorize'
  | 'enter';
export interface IamUsageEventEntry {
  featureCode: string;
  pageCode: string;
  routeName: string;
}
export declare const IAM_USAGE_EVENT_MODULE_CODE: 'iam';
export declare const iamUsageEventMatrix: Readonly<{
  pages: Record<IamUsageEventPageKey, Readonly<IamUsageEventEntry>>;
  features: Record<IamUsageEventFeatureKey, Readonly<IamUsageEventEntry>>;
}>;
export declare const iamUsageTracker: import('@wildbuck/core-usage-event-frontend').BrickModuleUsageTracker;
export declare function resolveIamStatusAction(
  previousEnabled: boolean | undefined,
  nextEnabled: boolean,
): 'enable' | 'disable' | 'update';
