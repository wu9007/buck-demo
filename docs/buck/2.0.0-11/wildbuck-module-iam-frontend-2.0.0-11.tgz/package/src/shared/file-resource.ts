import { request as brickRequest, requestBlob as brickRequestBlob } from '@wildbuck/core-api-frontend';

export type ImageResourceCategory = 'EMPLOYEE_AVATAR' | 'MENU_ICON' | 'APPLICATION_LOGO';

export interface ImageUploadResponse {
  resourceId: string;
  contentUrl: string;
}

export async function uploadImageResource(file: File, category: ImageResourceCategory): Promise<ImageUploadResponse> {
  const body = new FormData();
  body.append('file', file);
  return brickRequest<ImageUploadResponse>(`/file-resources/images?category=${encodeURIComponent(category)}`, {
    method: 'POST',
    body,
  });
}

export async function loadImageResourceBlob(resourceId: string): Promise<Blob> {
  return brickRequestBlob(`/file-resources/${encodeURIComponent(resourceId)}/content`);
}
