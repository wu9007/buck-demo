export type ConsoleFilterOption<TValue extends string = string> = Readonly<{
  label: string;
  value: TValue;
}>;

export type EnabledStateFilterValue = 'all' | 'enabled' | 'disabled';
export type BooleanStateFilterValue = 'all' | 'true' | 'false';
export type FunctionPointFilterValue = 'all' | 'none';
export type OrganizationLevelFilterValue = 'all' | '1' | '2' | '3+';
export type SessionScopeFilterValue = 'all' | 'active';

type Translate = (key: string, params?: Record<string, unknown>) => string;

export function buildEnabledStateFilterOptions(
  t: Translate,
): ReadonlyArray<ConsoleFilterOption<EnabledStateFilterValue>> {
  return Object.freeze([
    { label: t('module.iam.common.filter.allStates'), value: 'all' },
    { label: t('module.iam.common.filter.enabledOnly'), value: 'enabled' },
    { label: t('module.iam.common.filter.disabledOnly'), value: 'disabled' },
  ]);
}

export function buildEmployeeEnabledFilterOptions(
  t: Translate,
): ReadonlyArray<ConsoleFilterOption<BooleanStateFilterValue>> {
  return Object.freeze([
    { label: t('module.iam.common.filter.allStates'), value: 'all' },
    { label: t('module.iam.common.filter.enabledTrue'), value: 'true' },
    { label: t('module.iam.common.filter.enabledFalse'), value: 'false' },
  ]);
}

export function buildFunctionPointFilterOptions(
  t: Translate,
): ReadonlyArray<ConsoleFilterOption<FunctionPointFilterValue>> {
  return Object.freeze([
    { label: t('module.iam.common.filter.allFunctions'), value: 'all' },
    { label: t('module.iam.common.filter.unassignedFunction'), value: 'none' },
  ]);
}

export function buildOrganizationLevelFilterOptions(
  t: Translate,
): ReadonlyArray<ConsoleFilterOption<OrganizationLevelFilterValue>> {
  return Object.freeze([
    { label: t('module.iam.common.filter.allLevels'), value: 'all' },
    { label: t('module.iam.common.filter.level1'), value: '1' },
    { label: t('module.iam.common.filter.level2'), value: '2' },
    { label: t('module.iam.common.filter.level3Plus'), value: '3+' },
  ]);
}

export function buildSessionScopeFilterOptions(
  t: Translate,
): ReadonlyArray<ConsoleFilterOption<SessionScopeFilterValue>> {
  return Object.freeze([
    { label: t('module.iam.common.filter.allSessions'), value: 'all' },
    { label: t('module.iam.common.filter.activeSessionsOnly'), value: 'active' },
  ]);
}
