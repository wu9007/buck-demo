function repeatMask(length: number) {
  return '*'.repeat(Math.max(length, 1));
}

export function maskPhoneNumber(value?: string | null, emptyText = '-') {
  const source = String(value ?? '').trim();
  if (!source) {
    return emptyText;
  }
  if (source.length <= 4) {
    return `${source.slice(0, 1)}${repeatMask(source.length - 1)}`;
  }
  if (source.length <= 7) {
    return `${source.slice(0, 2)}${repeatMask(source.length - 3)}${source.slice(-1)}`;
  }
  return `${source.slice(0, 3)}${repeatMask(source.length - 7)}${source.slice(-4)}`;
}

export function maskEmail(value?: string | null, emptyText = '-') {
  const source = String(value ?? '').trim();
  if (!source) {
    return emptyText;
  }
  const atIndex = source.indexOf('@');
  if (atIndex <= 0) {
    if (source.length <= 2) {
      return `${source.slice(0, 1)}${repeatMask(source.length - 1)}`;
    }
    return `${source.slice(0, 1)}${repeatMask(source.length - 2)}${source.slice(-1)}`;
  }
  const local = source.slice(0, atIndex);
  const domain = source.slice(atIndex);
  if (local.length <= 2) {
    return `${local.slice(0, 1)}${repeatMask(local.length - 1)}${domain}`;
  }
  return `${local.slice(0, 1)}${repeatMask(local.length - 2)}${local.slice(-1)}${domain}`;
}

export function maskIdCardNumber(value?: string | null, emptyText = '-') {
  const source = String(value ?? '').trim();
  if (!source) {
    return emptyText;
  }
  if (source.length <= 8) {
    return `${source.slice(0, 2)}${repeatMask(source.length - 4)}${source.slice(-2)}`;
  }
  return `${source.slice(0, 6)}${repeatMask(source.length - 10)}${source.slice(-4)}`;
}
