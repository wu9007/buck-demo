import { request as brickRequest } from '@wildbuck/core-api-frontend';

/**
 * IAM 模块统一 step-up 验密。敏感操作前调用；不回传密码明文。
 */
export async function verifyIamStepUpPassword(password, failedMessage = '密码校验失败，请重试。') {
  try {
    return await brickRequest('/brick/session/verify-password', {
      method: 'POST',
      body: JSON.stringify({ password }),
    });
  } catch (error) {
    const message = error?.payload?.message
      || error?.payload?.recovery
      || error?.message
      || failedMessage;
    throw new Error(message);
  }
}
