import type { CurrentPrincipalWorkspace } from './generated/types';
import type { BrickConsoleRoute, BrickConsoleRouteGroup } from '@wildbuck/core-ui-frontend/shell-navigation';

export interface CurrentPrincipalShellWorkspace extends CurrentPrincipalWorkspace {
  employeeName?: string;
  avatarResourceId?: string;
}

export interface CurrentPrincipalShellRoute {
  id?: string;
  title?: string;
  path?: string;
  group?: string;
  order?: number;
  iconName?: string;
  iconResourceId?: string;
  iconUrl?: string;
  iconText?: string;
  abbr?: string;
  shortTitle?: string;
  collapsedTitle?: string;
  searchKeywords?: string[];
  keywords?: string[];
}

export interface CurrentPrincipalShellVisuals {
  principalAvatarUrl: string;
  menuIconUrls: Record<string, string>;
}

export declare function loadCurrentPrincipalWorkspace(): Promise<CurrentPrincipalWorkspace>;
export declare function resolveCurrentPrincipalAvatarResourceId(
  workspace?: CurrentPrincipalShellWorkspace | null
): string;
export declare function loadIamImageResourceObjectUrl(
  resourceId: string | undefined,
  options?: { createObjectURL?: (blob: Blob) => string }
): Promise<string>;
export declare function loadCurrentPrincipalShellVisuals(
  workspace?: CurrentPrincipalShellWorkspace | null,
  options?: {
    cache?: Map<string, string>;
    createObjectURL?: (blob: Blob) => string;
    loadImageResourceObjectUrl?: (resourceId: string) => Promise<string>;
  }
): Promise<CurrentPrincipalShellVisuals>;
export declare function mergeCurrentPrincipalMenusIntoRoutes<T extends CurrentPrincipalShellRoute>(
  routes?: T[],
  workspace?: CurrentPrincipalShellWorkspace | null,
  options?: { menuIconUrls?: Record<string, string> }
): T[];
export declare function buildCurrentPrincipalNavigationGroups<T extends BrickConsoleRoute>(
  routes?: T[],
  workspace?: CurrentPrincipalShellWorkspace | null,
  options?: { menuIconUrls?: Record<string, string>; permissions?: string[] }
): BrickConsoleRouteGroup[];
