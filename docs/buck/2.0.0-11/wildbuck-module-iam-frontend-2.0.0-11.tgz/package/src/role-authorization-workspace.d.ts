import type {
  AssignRoleAuthorizationsRequest,
  RoleAuthorizationAssignment,
  RoleAuthorizationDetail,
} from './generated/types';

export declare function loadRoleAuthorizationWorkspace(roleId: string): Promise<RoleAuthorizationDetail>;
export declare function saveRoleAuthorizationWorkspace(
  roleId: string,
  input: AssignRoleAuthorizationsRequest,
): Promise<RoleAuthorizationAssignment>;
