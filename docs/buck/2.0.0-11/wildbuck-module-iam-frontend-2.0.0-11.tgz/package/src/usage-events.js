import { createModuleUsageTracker } from '@wildbuck/core-usage-event-frontend';

export const IAM_USAGE_EVENT_MODULE_CODE = 'iam';

export const iamUsageEventMatrix = deepFreeze({
  pages: {
    employees: {
      featureCode: 'employee',
      pageCode: 'employee-page',
      routeName: 'iam.employees.list',
    },
    organizations: {
      featureCode: 'organization',
      pageCode: 'organization-page',
      routeName: 'iam.organizations.list',
    },
    roles: {
      featureCode: 'role',
      pageCode: 'role-page',
      routeName: 'iam.roles.list',
    },
    menus: {
      featureCode: 'menu',
      pageCode: 'menu-page',
      routeName: 'iam.menus.list',
    },
    sessions: {
      featureCode: 'session',
      pageCode: 'session-page',
      routeName: 'iam.sessions.list',
    },
  },
  features: {
    employee: {
      featureCode: 'employee',
      pageCode: 'employee-page',
      routeName: 'iam.employees.list',
    },
    employeeAvatar: {
      featureCode: 'employee-avatar',
      pageCode: 'employee-page',
      routeName: 'iam.employees.list',
    },
    employeeRole: {
      featureCode: 'employee-role',
      pageCode: 'employee-page',
      routeName: 'iam.employees.list',
    },
    employeeSecurity: {
      featureCode: 'employee-security',
      pageCode: 'employee-page',
      routeName: 'iam.employees.list',
    },
    organization: {
      featureCode: 'organization',
      pageCode: 'organization-page',
      routeName: 'iam.organizations.list',
    },
    role: {
      featureCode: 'role',
      pageCode: 'role-page',
      routeName: 'iam.roles.list',
    },
    roleAuthorization: {
      featureCode: 'role-authorization',
      pageCode: 'role-authorization-page',
      routeName: 'iam.roles.list',
    },
    roleExclusion: {
      featureCode: 'role-exclusion',
      pageCode: 'role-page',
      routeName: 'iam.roles.list',
    },
    menu: {
      featureCode: 'menu',
      pageCode: 'menu-page',
      routeName: 'iam.menus.list',
    },
    session: {
      featureCode: 'session',
      pageCode: 'session-page',
      routeName: 'iam.sessions.list',
    },
  },
});

export const iamUsageTracker = createModuleUsageTracker(
  IAM_USAGE_EVENT_MODULE_CODE,
  iamUsageEventMatrix,
);

export function resolveIamStatusAction(previousEnabled, nextEnabled) {
  if (previousEnabled === false && nextEnabled === true) {
    return 'enable';
  }
  if (previousEnabled === true && nextEnabled === false) {
    return 'disable';
  }
  return 'update';
}

function deepFreeze(value) {
  if (value == null || typeof value !== 'object') {
    return value;
  }
  for (const child of Object.values(value)) {
    deepFreeze(child);
  }
  return Object.freeze(value);
}
