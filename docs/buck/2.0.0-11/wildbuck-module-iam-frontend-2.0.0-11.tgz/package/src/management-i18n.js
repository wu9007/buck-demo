export {
  IAM_MANAGEMENT_MESSAGES,
  IAM_MANAGEMENT_MESSAGES_EN_US,
  IAM_MANAGEMENT_MESSAGES_ZH_CN,
  resolveIamManagementMessages,
  resolveIamModuleMessages,
  translateIamManagement,
  useIamI18n,
} from './features/management-i18n.js';
