import { authExperience } from './auth-experience.js';
import { currentPrincipalFeature } from './features/current-principal/index.js';
import { employeesFeature } from './features/employees/index.js';
import { menusFeature } from './features/menus/index.js';
import { organizationsFeature } from './features/organizations/index.js';
import { rolesFeature } from './features/roles/index.js';
import { sessionsFeature } from './features/sessions/index.js';
import { iamRoutes } from './routes/index.js';

export const iamFeatureRegistry = {
  currentPrincipal: currentPrincipalFeature,
  roles: rolesFeature,
  sessions: sessionsFeature,
  employees: employeesFeature,
  organizations: organizationsFeature,
  menus: menusFeature,
};

export const iamPermissionMap = {
  currentPrincipal: currentPrincipalFeature.permissions,
  roles: rolesFeature.permissions,
  sessions: sessionsFeature.permissions,
  employees: employeesFeature.permissions,
  organizations: organizationsFeature.permissions,
  menus: menusFeature.permissions,
};

export const iamExperiences = {
  auth: authExperience,
};

export const brickModuleKey = 'iam';
export const brickModuleMeta = {
  displayName: '系统管理',
};
export const brickModuleExperiences = iamExperiences;
export const brickFeatureRegistry = iamFeatureRegistry;
export const brickPermissionMap = iamPermissionMap;
export const brickRoutes = iamRoutes;

export { iamRoutes };
export {
  IAM_USAGE_EVENT_MODULE_CODE,
  iamUsageEventMatrix,
  iamUsageTracker,
  resolveIamStatusAction,
} from './usage-events.js';
