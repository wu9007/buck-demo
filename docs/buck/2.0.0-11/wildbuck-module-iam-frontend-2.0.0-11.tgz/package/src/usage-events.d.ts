export type IamUsageEventPageKey =
  | 'employees'
  | 'organizations'
  | 'roles'
  | 'menus'
  | 'sessions';

export type IamUsageEventFeatureKey =
  | 'employee'
  | 'employeeAvatar'
  | 'employeeRole'
  | 'employeeSecurity'
  | 'employeeSession'
  | 'organization'
  | 'role'
  | 'roleAuthorization'
  | 'roleExclusion'
  | 'menu'
  | 'session';

export type IamUsageEventActionCode =
  | 'view'
  | 'search'
  | 'open-detail'
  | 'open-create'
  | 'create'
  | 'update'
  | 'enable'
  | 'disable'
  | 'delete'
  | 'upload-avatar'
  | 'reset-password'
  | 'unlock'
  | 'save-roles'
  | 'force-offline'
  | 'authorize'
  | 'enter';

export interface IamUsageEventEntry {
  featureCode: string;
  pageCode: string;
  routeName: string;
}

export declare const IAM_USAGE_EVENT_MODULE_CODE: 'iam';
export declare const iamUsageEventMatrix: Readonly<{
  pages: Record<IamUsageEventPageKey, Readonly<IamUsageEventEntry>>;
  features: Record<IamUsageEventFeatureKey, Readonly<IamUsageEventEntry>>;
}>;
export declare const iamUsageTracker: import('@wildbuck/core-usage-event-frontend').BrickModuleUsageTracker;
export declare function resolveIamStatusAction(
  previousEnabled: boolean | undefined,
  nextEnabled: boolean,
): 'enable' | 'disable' | 'update';
