import type { ComputedRef } from 'vue';

/**
 * Auth workspace for shell assembly. Computed fields stay as ComputedRef.
 * Hold the return value with shallowRef or a plain object literal when
 * passing to IamAuthFlowView; do not nest into a deep ref() object that
 * auto-unwraps nested refs (that used to blank the login page).
 */
export interface BrickAuthWorkspace {
  /** Active login mode labels/placeholders; keep as ComputedRef when assembling app. */
  currentLoginMode: ComputedRef<Record<string, any>>;
  screenTitle: ComputedRef<string>;
  canDismissPasswordReminder: ComputedRef<boolean>;
  authAlertText: ComputedRef<string>;
  sessionUserName: ComputedRef<string>;
  isAuthenticated: ComputedRef<boolean>;
  isAuthFocus: ComputedRef<boolean>;
  /** Soft-suspend (SCREEN_LOCK) active. */
  isSessionLocked: ComputedRef<boolean>;
  isSessionRecoveryActive: ComputedRef<boolean>;
  bootstrapAuthState: () => Promise<void>;
  applyLoginMode: (loginType?: string) => void;
  login: () => Promise<void>;
  loadCaptcha: () => Promise<any>;
  sendMfaVerificationCode: () => Promise<void>;
  completeMfaVerification: () => Promise<void>;
  completePasswordChange: () => Promise<void>;
  /** Self-service dialog path (shell avatar menu); does not leave the console. */
  changeOwnPassword: (payload: { currentPassword: string; newPassword: string }) => Promise<void>;
  dismissPasswordReminder: () => void;
  openPasswordChangeEditor: () => void;
  logout: () => Promise<void>;
  clearSession: (message?: string) => void;
  adoptPasswordChangeRequiredState: (error: any) => void;
  /** Silent RT refresh; used by configureHttp tokenRefresh. */
  trySilentRefresh: () => Promise<boolean>;
  /** After refresh fails: branch LOGIN_OUT vs SCREEN_LOCK soft-suspend. */
  handleSessionTerminal: (error: any) => void;
  /** Soft unlock via login re-auth (not step-up verify-password). */
  unlockWithPassword: (password: string) => Promise<any>;
  adoptExpirationStrategy: (strategy: unknown) => string;
  softSuspend: (message?: string) => void;
}

export declare function useAuthWorkspace(options: {
  state: Record<string, any>;
  showStatus: (message: string, type?: string) => void;
  /** Shell rehydrate; pass preserveRouteId on unlock so open forms stay mounted. */
  loadAuthenticatedContext: (options?: { preserveRouteId?: string }) => Promise<void>;
  /** Soft cold-start menu skeleton; optional preserveRouteId pins the current page. */
  onSoftSuspend?: (preserveRouteId?: string) => void;
}): BrickAuthWorkspace;
