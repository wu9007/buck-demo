export declare const TOKEN_KEY: string;
export declare const REFRESH_TOKEN_KEY: string;
export declare const PRINCIPAL_KEY: string;
export declare const PENDING_MFA_TOKEN_KEY: string;
export declare const PENDING_MFA_PRINCIPAL_KEY: string;
export declare const EXPIRATION_STRATEGY_KEY: string;
export declare const SHELL_WORKSPACE_CACHE_KEY: string;

export declare const AuthScreen: {
  FIRST_FACTOR: string;
  MFA: string;
  PASSWORD: string;
};

export declare const SessionRecovery: {
  NONE: string;
  SCREEN_LOCK: string;
};

export declare const EXPIRATION_STRATEGIES: readonly string[];

export declare function normalizeExpirationStrategy(value: unknown): 'LOGIN_OUT' | 'SCREEN_LOCK';

export declare function createInitialAuthState(
  readJson: (text: string | null) => unknown,
  storage?: Storage,
): Record<string, unknown>;

export declare function persistAuthenticatedSession(
  state: Record<string, any>,
  storage?: Storage,
): void;

export declare function persistPendingMfaSession(
  state: Record<string, any>,
  storage?: Storage,
): void;

export declare function persistExpirationStrategy(
  strategy: unknown,
  storage?: Storage,
): 'LOGIN_OUT' | 'SCREEN_LOCK';

export declare function clearStoredSession(storage?: Storage): void;

export declare function persistShellWorkspaceCache(
  snapshot: { currentPrincipalWorkspace?: unknown; permissions?: unknown[] } | null | undefined,
  storage?: Storage,
): void;

export declare function readShellWorkspaceCache(
  storage?: Storage,
): { currentPrincipalWorkspace: Record<string, unknown>; permissions: unknown[] } | null;

export declare function clearShellWorkspaceCache(storage?: Storage): void;

export declare function clearMfaState(
  state: Record<string, any>,
  storage?: Storage,
): void;
