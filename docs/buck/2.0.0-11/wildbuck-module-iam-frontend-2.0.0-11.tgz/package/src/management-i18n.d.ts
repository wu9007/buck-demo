import type { ComputedRef, Ref } from 'vue';

export declare const IAM_MANAGEMENT_MESSAGES_ZH_CN: Readonly<Record<string, string>>;
export declare const IAM_MANAGEMENT_MESSAGES_EN_US: Readonly<Record<string, string>>;
export declare const IAM_MANAGEMENT_MESSAGES: Readonly<Record<string, Readonly<Record<string, string>>>>;

export declare function resolveIamManagementMessages(locale?: string): Readonly<Record<string, string>>;
export declare function resolveIamModuleMessages(locale?: string): Readonly<Record<string, string>>;
export declare function translateIamManagement(
  runtime: unknown,
  key: string,
  params?: Record<string, unknown>,
  fallbackLocale?: string,
): string;

export declare function useIamI18n(): {
  t: (key: string, params?: Record<string, unknown>) => string;
  i18n: unknown;
  locale: ComputedRef<string>;
  revision: Ref<number>;
};
