export declare const brickRouteComponentLoaders: Record<string, () => Promise<unknown>>;

export interface IamPageRegistryValidationOptions {
  routes?: Array<{
    id?: string;
    permission?: string;
  }>;
  loaders?: Record<string, unknown>;
  grantedPermissions?: string[];
}

export interface IamPageRegistryValidationResult {
  ok: boolean;
  routeIds: readonly string[];
  loaderIds: readonly string[];
  missingLoaderRouteIds: readonly string[];
  orphanLoaderRouteIds: readonly string[];
  missingPermissionRouteIds: readonly string[];
  messages: readonly string[];
}

export declare function validateIamPageRegistry(options?: IamPageRegistryValidationOptions): IamPageRegistryValidationResult;
