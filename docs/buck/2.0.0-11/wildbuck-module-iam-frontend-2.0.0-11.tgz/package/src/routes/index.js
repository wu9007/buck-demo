import { employeeRoutes } from '../features/employees/routes/index.js';
import { menuRoutes } from '../features/menus/routes/index.js';
import { organizationRoutes } from '../features/organizations/routes/index.js';
import { roleRoutes } from '../features/roles/routes/index.js';
import { sessionRoutes } from '../features/sessions/routes/index.js';

export const iamRoutes = [
  ...organizationRoutes,
  ...employeeRoutes,
  ...roleRoutes,
  ...menuRoutes,
  ...sessionRoutes,
];
