# @wildbuck/core-option-frontend

`@wildbuck/core-option-frontend` 是 `core:option` 的前端入口，用于从后端 `BrickOptionProvider` 加载下拉、单选、多选和标签选项。

业务页面不要硬编码稳定业务状态、字典或枚举选项。先在后端功能点 `provider` 中实现 `BrickOptionProvider`，再在前端调用：

```js
import { createOptionRequest, loadBrickOptions } from '@wildbuck/core-option-frontend';

// 在会话 / access token 就绪后调用；未登录时 POST /brick/options/list 默认 401 是预期行为。
const options = await loadBrickOptions([
  createOptionRequest('face_archive_status')
]);

statusOptions.value = options.face_archive_status || [];
```

## 鉴权说明

- `POST /brick/options/list` **默认需要认证**。公开 `client-meta` 可访问，**不**表示 options 可匿名。
- 壳启动时先恢复会话，再批量 `loadBrickOptions`；不要在 token 未就绪时狂刷字典，也不要为消 401 在前端写死枚举。
- 开发 open-mode 下若业务坚持匿名拉字典，须由业务 `BrickAuthorizationRuleContributor` **显式**放行，并评估字典泄露面；框架不提供默认匿名 options。
- 时序总览见 `docs/architecture/delivery/business-frontend-ui-reference.md`「壳启动时序：client-meta 与 options 鉴权」。

本包只封装 `/brick/options/list` 协议，不定义页面控件和视觉样式。
