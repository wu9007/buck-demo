export interface BrickOptionRequest {
  name: string;
  values?: unknown[];
  extension?: Record<string, unknown>;
}

export interface BrickOption {
  value: unknown;
  label: unknown;
  description?: string;
  disabled?: boolean;
  hidden?: boolean;
  children?: BrickOption[];
  [key: string]: unknown;
}

export interface LoadBrickOptionsOptions {
  path?: string;
  requestClient?: (path: string, init: RequestInit) => Promise<Record<string, BrickOption[]>>;
}

export declare function createOptionRequest(
  name: string,
  options?: Pick<BrickOptionRequest, 'values' | 'extension'>,
): BrickOptionRequest;

export declare function loadBrickOptions(
  optionRequests: Array<string | BrickOptionRequest>,
  options?: LoadBrickOptionsOptions,
): Promise<Record<string, BrickOption[]>>;

export interface BrickOptionItem {
  label: string;
  value: string;
}

export declare function normalizeOptionItems(options: unknown): BrickOptionItem[];

export declare function withAllOption<T extends BrickOptionItem>(
  allOption: T,
  loadedOptions: T[],
  fallbackOptions: T[],
): T[];
