import { request } from '@wildbuck/core-api-frontend';

export function createOptionRequest(name, options = {}) {
  const request = {
    name: requiredText(name, 'name'),
  };
  if (Array.isArray(options.values) && options.values.length > 0) {
    request.values = options.values;
  }
  if (options.extension != null) {
    request.extension = options.extension;
  }
  return request;
}

export async function loadBrickOptions(optionRequests, options = {}) {
  const requests = normalizeRequests(optionRequests);
  if (requests.length === 0) {
    return {};
  }
  const requestClient = options.requestClient ?? request;
  return requestClient(options.path ?? '/brick/options/list', {
    method: 'POST',
    body: JSON.stringify(requests),
  });
}

/**
 * Normalize option API / provider rows to { label, value } pairs.
 * @param {unknown} options
 * @returns {Array<{ label: string, value: string }>}
 */
export function normalizeOptionItems(options) {
  if (!Array.isArray(options)) {
    return [];
  }
  return options
    .map((option) => {
      if (option == null || typeof option !== 'object') {
        return null;
      }
      const value = String(option.value ?? '').trim();
      const label = String(option.label ?? '').trim();
      return value && label ? { label, value } : null;
    })
    .filter(Boolean);
}

/**
 * Prepend an "all" sentinel when loaded options exist; otherwise keep fallback list.
 * @template {{ label: string, value: string }} T
 * @param {T} allOption
 * @param {T[]} loadedOptions
 * @param {T[]} fallbackOptions
 * @returns {T[]}
 */
export function withAllOption(allOption, loadedOptions, fallbackOptions) {
  return Array.isArray(loadedOptions) && loadedOptions.length > 0
    ? [allOption, ...loadedOptions]
    : [...(fallbackOptions || [])];
}

function normalizeRequests(optionRequests) {
  if (!Array.isArray(optionRequests)) {
    throw new TypeError('optionRequests must be an array');
  }
  return optionRequests.map((item) => {
    if (typeof item === 'string') {
      return createOptionRequest(item);
    }
    if (item == null || typeof item !== 'object') {
      throw new TypeError('option request must be a string or object');
    }
    return createOptionRequest(item.name, {
      values: item.values,
      extension: item.extension,
    });
  });
}

function requiredText(value, name) {
  const text = String(value ?? '').trim();
  if (!text) {
    throw new TypeError(`Buck option ${name} must not be blank`);
  }
  return text;
}
