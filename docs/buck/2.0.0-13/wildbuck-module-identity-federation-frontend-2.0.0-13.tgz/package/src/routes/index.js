import { authsourceRoutes } from '../features/authsource/routes/index.js';
import { identitysyncRoutes } from '../features/identitysync/routes/index.js';
import { identitylinkRoutes } from '../features/identitylink/routes/index.js';

export const identityFederationRoutes = [
  ...authsourceRoutes,
  ...identitysyncRoutes,
  ...identitylinkRoutes,
];

export default function registerIdentityFederationRoutes() {
  return identityFederationRoutes.map((route) => ({
    path: route.path,
    name: route.id,
    component: route.component,
  }));
}
