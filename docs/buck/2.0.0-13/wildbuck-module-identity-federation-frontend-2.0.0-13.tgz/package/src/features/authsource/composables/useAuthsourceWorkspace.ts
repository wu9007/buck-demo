import { computed, onBeforeUnmount, reactive, ref } from 'vue';
import {
  createSource,
  loadIdentitySourceDetail,
  previewCallback,
  removeSource,
  searchIdentitySources,
  startTestConnection,
  updateSource,
} from '../api/authsource';
import {
  DEFAULT_OAUTH2_SCOPE,
  defaultScopeForType,
  DINGTALK_OAUTH2_PRESET,
  GITHUB_OAUTH2_PRESET,
  IDENTITY_SOURCE_TYPES,
  isCasSourceType,
  isDingTalkSourceType,
  isGithubSourceType,
  isPresetSourceType,
  CAS_PRESET,
  looksLikeGithubEndpoints,
  resolveAuthsourceError,
  resolveFederationTestError,
  statusBadge,
  TEST_CONNECTION_POLL_MS,
  TEST_CONNECTION_TIMEOUT_MS,
  VERIFICATION_STATUS_LABELS,
} from '../lib/authsource-errors.js';
import { authsourcePermissions } from '../permission/index.js';
import { loadImageResourceBlob, uploadImageResource } from '../../../shared/file-resource';
import type { IdentitySourceDetail } from '../../../generated/types';

/** 与后端 IdentitySourceService 默认路径保持一致。 */
export function deriveDefaultOAuth2Endpoints(issuerUrl: string) {
  const base = (issuerUrl || '').trim().replace(/\/+$/, '');
  if (!base) {
    return {
      authorizationEndpoint: '',
      tokenEndpoint: '',
      userInfoEndpoint: '',
    };
  }
  return {
    authorizationEndpoint: `${base}/oauth2/authorize`,
    tokenEndpoint: `${base}/oauth2/token`,
    userInfoEndpoint: `${base}/oauth2/userinfo`,
  };
}

function emptyForm() {
  return {
    sourceType: 'OAUTH2',
    sourceKey: '',
    displayName: '',
    logoResourceId: '',
    remark: '',
    issuerUrl: '',
    authorizationEndpoint: '',
    tokenEndpoint: '',
    userInfoEndpoint: '',
    clientId: '',
    clientSecret: '',
    scope: DEFAULT_OAUTH2_SCOPE,
    // 默认当前页 origin；真机扫码/隧道时改为公网基址
    callbackPublicBaseUrl:
      typeof window !== 'undefined' && window.location?.origin
        ? window.location.origin
        : '',
    casPreset: 'STANDARD',
    casLoginPath: '',
    casValidatePath: '',
    casLogoutPath: '',
    casAppId: '',
    casResponseFormat: '',
  };
}

function applyCasPresetToForm(formState: ReturnType<typeof emptyForm>, preset = formState.casPreset) {
  formState.sourceType = 'CAS';
  const key = preset === 'HAINAN' ? 'HAINAN' : 'STANDARD';
  formState.casPreset = key;
  const defaults = CAS_PRESET[key];
  formState.casLoginPath = defaults.loginPath;
  formState.casValidatePath = defaults.validatePath;
  formState.casLogoutPath = defaults.logoutPath;
  formState.casResponseFormat = defaults.responseFormat;
}

function applyGithubPresetToForm(formState: ReturnType<typeof emptyForm>) {
  formState.sourceType = 'GITHUB';
  formState.issuerUrl = GITHUB_OAUTH2_PRESET.issuerUrl;
  formState.authorizationEndpoint = GITHUB_OAUTH2_PRESET.authorizationEndpoint;
  formState.tokenEndpoint = GITHUB_OAUTH2_PRESET.tokenEndpoint;
  formState.userInfoEndpoint = GITHUB_OAUTH2_PRESET.userInfoEndpoint;
  formState.scope = GITHUB_OAUTH2_PRESET.scope;
}

function applyDingTalkPresetToForm(formState: ReturnType<typeof emptyForm>) {
  formState.sourceType = 'DINGTALK';
  // issuerUrl 保留用户填写的 CorpId
  formState.authorizationEndpoint = DINGTALK_OAUTH2_PRESET.authorizationEndpoint;
  formState.tokenEndpoint = DINGTALK_OAUTH2_PRESET.tokenEndpoint;
  formState.userInfoEndpoint = DINGTALK_OAUTH2_PRESET.userInfoEndpoint;
  formState.scope = DINGTALK_OAUTH2_PRESET.scope;
}

function normalizeComparable(value: string | null | undefined) {
  return (value || '').trim();
}

function endpointsMatchDefaults(formState: ReturnType<typeof emptyForm>) {
  const defaults = deriveDefaultOAuth2Endpoints(formState.issuerUrl);
  if (!defaults.authorizationEndpoint) {
    return !normalizeComparable(formState.authorizationEndpoint)
      && !normalizeComparable(formState.tokenEndpoint)
      && !normalizeComparable(formState.userInfoEndpoint);
  }
  return normalizeComparable(formState.authorizationEndpoint) === defaults.authorizationEndpoint
    && normalizeComparable(formState.tokenEndpoint) === defaults.tokenEndpoint
    && normalizeComparable(formState.userInfoEndpoint) === defaults.userInfoEndpoint;
}

/**
 * 高级区是否偏离产品默认。
 * 主路径只关心「能连上」；图标/端点/备注 是低频项（账号关联已收口到身份同步）。
 * 编辑时若已自定义，默认展开高级区，避免用户看不到自己改过的配置。
 */
export function formHasAdvancedCustom(formState: ReturnType<typeof emptyForm>) {
  const logo = Boolean(normalizeComparable(formState.logoResourceId));
  const remark = Boolean(normalizeComparable(formState.remark));
  if (isGithubSourceType(formState.sourceType) || isDingTalkSourceType(formState.sourceType) || isCasSourceType(formState.sourceType)) {
    return logo || remark;
  }
  const expectedScope = defaultScopeForType(formState.sourceType);
  const scopeCustom = Boolean(normalizeComparable(formState.scope))
    && normalizeComparable(formState.scope) !== normalizeComparable(expectedScope);
  // 有 issuer 时按默认路径推导；只有手填偏离默认才算自定义
  const endpointsCustom = Boolean(
    normalizeComparable(formState.authorizationEndpoint)
    || normalizeComparable(formState.tokenEndpoint)
    || normalizeComparable(formState.userInfoEndpoint)
  ) && !endpointsMatchDefaults(formState);
  return logo || remark || scopeCustom || endpointsCustom;
}

/** Critical OAuth fields: changing any forces re-verification + new Secret on server. */
function isCriticalConfigChanged(
  before: IdentitySourceDetail | null,
  formState: ReturnType<typeof emptyForm>
) {
  if (!before) {
    return false;
  }
  return normalizeComparable(before.issuerUrl) !== normalizeComparable(formState.issuerUrl)
    || normalizeComparable(before.authorizationEndpoint) !== normalizeComparable(formState.authorizationEndpoint)
    || normalizeComparable(before.tokenEndpoint) !== normalizeComparable(formState.tokenEndpoint)
    || normalizeComparable(before.userInfoEndpoint) !== normalizeComparable(formState.userInfoEndpoint)
    || normalizeComparable(before.clientId) !== normalizeComparable(formState.clientId)
    || normalizeComparable(before.callbackPublicBaseUrl) !== normalizeComparable(formState.callbackPublicBaseUrl);
}

/**
 * 端点解析：GitHub 固定预设；OAuth2 以服务地址推导默认值，
 * 表单里若已手填高级端点则优先用表单（与高级折叠开关无关，避免收起后丢自定义）。
 */
function resolvePayloadEndpoints(formState: ReturnType<typeof emptyForm>) {
  if (isGithubSourceType(formState.sourceType)) {
    return {
      issuerUrl: GITHUB_OAUTH2_PRESET.issuerUrl,
      authorizationEndpoint: GITHUB_OAUTH2_PRESET.authorizationEndpoint,
      tokenEndpoint: GITHUB_OAUTH2_PRESET.tokenEndpoint,
      userInfoEndpoint: GITHUB_OAUTH2_PRESET.userInfoEndpoint,
    };
  }
  if (isDingTalkSourceType(formState.sourceType)) {
    return {
      issuerUrl: formState.issuerUrl.trim() || undefined,
      authorizationEndpoint: DINGTALK_OAUTH2_PRESET.authorizationEndpoint,
      tokenEndpoint: DINGTALK_OAUTH2_PRESET.tokenEndpoint,
      userInfoEndpoint: DINGTALK_OAUTH2_PRESET.userInfoEndpoint,
    };
  }
  const derived = deriveDefaultOAuth2Endpoints(formState.issuerUrl);
  return {
    issuerUrl: formState.issuerUrl.trim() || undefined,
    authorizationEndpoint: formState.authorizationEndpoint.trim() || derived.authorizationEndpoint || undefined,
    tokenEndpoint: formState.tokenEndpoint.trim() || derived.tokenEndpoint || undefined,
    userInfoEndpoint: formState.userInfoEndpoint.trim() || derived.userInfoEndpoint || undefined,
  };
}



export function useAuthsourceWorkspace() {
  const rows = ref<any[]>([]);
  const total = ref(0);
  const page = ref(1);
  const pageSize = ref(20);
  const listLoading = ref(false);
  const listError = ref('');
  const actionMessage = ref('');
  const actionWarning = ref('');
  const actionError = ref('');
  const keyword = ref('');
  const typePickerOpen = ref(false);
  const editorOpen = ref(false);
  const editorMode = ref<'create' | 'edit'>('create');
  const saving = ref(false);
  const testing = ref(false);
  const current = ref<IdentitySourceDetail | null>(null);
  const form = reactive(emptyForm());
  const advancedOpen = ref(false);
  const logoPreviewUrl = ref('');
  const logoUploading = ref(false);
  let localLogoPreviewUrl = '';
  const callbackPreview = ref<{
    callbackUrl?: string | null;
    warningMessage?: string | null;
    publicBaseUrlConfigured?: boolean;
    localhostWarning?: boolean;
  } | null>(null);
  const formError = ref('');
  let testPopup: Window | null = null;
  let testTimer: ReturnType<typeof setTimeout> | null = null;
  let testPollTimer: ReturnType<typeof setInterval> | null = null;
  /** When true, popup.closed is intentional (cancel / success cleanup) — skip closed error. */
  let testClosedIntentionally = false;

  const empty = computed(() => !listLoading.value && rows.value.length === 0 && !listError.value);

  async function refreshList() {
    listLoading.value = true;
    listError.value = '';
    try {
      const result = await searchIdentitySources({
        keyword: keyword.value.trim() || undefined,
        page: page.value,
        size: pageSize.value,
      });
      rows.value = result?.records || result?.items || [];
      total.value = Number(result?.total || 0);
    } catch (error) {
      listError.value = resolveAuthsourceError(error, '加载身份源列表失败。');
      rows.value = [];
      total.value = 0;
    } finally {
      listLoading.value = false;
    }
  }

  function openTypePicker() {
    typePickerOpen.value = true;
  }

  function closeTypePicker() {
    typePickerOpen.value = false;
  }

  function revokeLocalLogoPreview() {
    if (localLogoPreviewUrl) {
      URL.revokeObjectURL(localLogoPreviewUrl);
      localLogoPreviewUrl = '';
    }
  }

  async function refreshLogoPreview(resourceId?: string | null) {
    revokeLocalLogoPreview();
    logoPreviewUrl.value = '';
    const id = (resourceId || '').trim();
    if (!id) {
      return;
    }
    try {
      const blob = await loadImageResourceBlob(id);
      localLogoPreviewUrl = URL.createObjectURL(blob);
      logoPreviewUrl.value = localLogoPreviewUrl;
    } catch {
      logoPreviewUrl.value = '';
    }
  }

  async function uploadLogo(file: File) {
    logoUploading.value = true;
    formError.value = '';
    try {
      const uploaded = await uploadImageResource(file, 'APPLICATION_LOGO');
      form.logoResourceId = uploaded.resourceId;
      await refreshLogoPreview(uploaded.resourceId);
    } catch (error) {
      formError.value = resolveAuthsourceError(error, 'Logo 上传失败。');
    } finally {
      logoUploading.value = false;
    }
  }

  function clearLogo() {
    form.logoResourceId = '';
    revokeLocalLogoPreview();
    logoPreviewUrl.value = '';
  }

  function applyIssuerDefaultsToForm() {
    if (isGithubSourceType(form.sourceType)) {
      applyGithubPresetToForm(form);
      return;
    }
    if (isDingTalkSourceType(form.sourceType)) {
      applyDingTalkPresetToForm(form);
      return;
    }
    const derived = deriveDefaultOAuth2Endpoints(form.issuerUrl);
    form.authorizationEndpoint = derived.authorizationEndpoint;
    form.tokenEndpoint = derived.tokenEndpoint;
    form.userInfoEndpoint = derived.userInfoEndpoint;
  }

  function onIssuerBlur() {
    if (isGithubSourceType(form.sourceType) || isDingTalkSourceType(form.sourceType)) {
      return;
    }
    // 高级区收起时：服务地址变更自动填默认端点，降低主路径心智负担
    // 高级区展开时：尊重用户手填，不覆盖
    if (!advancedOpen.value) {
      applyIssuerDefaultsToForm();
    }
  }

  /** 仅切换显隐；绝不在收起时回写默认端点（防止误点折叠丢失手填）。 */
  function toggleAdvanced() {
    advancedOpen.value = !advancedOpen.value;
  }

  function setAdvancedOpen(open: boolean) {
    advancedOpen.value = open;
  }

  function selectType(type: string) {
    const meta = IDENTITY_SOURCE_TYPES.find((item) => item.type === type);
    if (!meta?.available) {
      return;
    }
    closeTypePicker();
    editorMode.value = 'create';
    current.value = null;
    Object.assign(form, emptyForm());
    form.sourceType = type;
    if (isGithubSourceType(type)) {
      applyGithubPresetToForm(form);
      form.displayName = form.displayName || 'GitHub';
    } else if (isDingTalkSourceType(type)) {
      applyDingTalkPresetToForm(form);
      form.displayName = form.displayName || '钉钉';
    } else if (isCasSourceType(type)) {
      applyCasPresetToForm(form, 'STANDARD');
      form.displayName = form.displayName || 'CAS';
    } else {
      form.scope = defaultScopeForType(type);
    }
    advancedOpen.value = false;
    clearLogo();
    callbackPreview.value = null;
    formError.value = '';
    actionError.value = '';
    editorOpen.value = true;
  }

  function applyDetailToEditor(detail: IdentitySourceDetail) {
    current.value = detail;
    editorMode.value = 'edit';
    let sourceType = (detail as { sourceType?: string }).sourceType || 'OAUTH2';
    const githubLegacy = looksLikeGithubEndpoints({
      authorizationEndpoint: detail.authorizationEndpoint,
      tokenEndpoint: detail.tokenEndpoint,
      userInfoEndpoint: detail.userInfoEndpoint,
    });
    if (githubLegacy) {
      sourceType = 'GITHUB';
    }
    Object.assign(form, {
      sourceType,
      sourceKey: detail.sourceKey || '',
      displayName: detail.displayName || '',
      logoResourceId: detail.logoResourceId || '',
      remark: detail.remark || '',
      issuerUrl: detail.issuerUrl || '',
      authorizationEndpoint: detail.authorizationEndpoint || '',
      tokenEndpoint: detail.tokenEndpoint || '',
      userInfoEndpoint: detail.userInfoEndpoint || '',
      clientId: detail.clientId || '',
      clientSecret: '',
      scope: detail.scope || defaultScopeForType(sourceType),
      callbackPublicBaseUrl: detail.callbackPublicBaseUrl || '',
      casPreset: detail.casPreset || 'STANDARD',
      casLoginPath: detail.casLoginPath || '',
      casValidatePath: detail.casValidatePath || '',
      casLogoutPath: detail.casLogoutPath || '',
      casAppId: detail.casAppId || '',
      casResponseFormat: detail.casResponseFormat || '',
    });
    if (isGithubSourceType(sourceType)) {
      applyGithubPresetToForm(form);
    } else if (isDingTalkSourceType(sourceType)) {
      applyDingTalkPresetToForm(form);
    } else if (isCasSourceType(sourceType) && !form.casLoginPath) {
      applyCasPresetToForm(form, form.casPreset);
    }
    // 已自定义高级项时展开，避免编辑态「看不见自己的配置」
    advancedOpen.value = formHasAdvancedCustom(form);
    callbackPreview.value = {
      callbackUrl: detail.callbackUrl,
      warningMessage: detail.callbackWarning,
      publicBaseUrlConfigured: Boolean(detail.callbackUrl),
      localhostWarning: Boolean(detail.callbackWarning?.includes('localhost')),
    };
    editorOpen.value = true;
    void refreshLogoPreview(detail.logoResourceId);
  }

  async function openEdit(identitySourceId: string) {
    formError.value = '';
    actionError.value = '';
    try {
      applyDetailToEditor(await loadIdentitySourceDetail(identitySourceId));
    } catch (error) {
      actionError.value = resolveAuthsourceError(error, '加载身份源详情失败。');
    }
  }

  /** Refresh list (and open editor form if drawer already open) after test-connection. */
  async function refreshEditorAfterTest() {
    await refreshList();
    if (!editorOpen.value || !current.value?.identitySourceId) {
      return;
    }
    try {
      const detail = await loadIdentitySourceDetail(current.value.identitySourceId);
      // 抽屉已打开时刷新表单与状态，不强制改 editorOpen。
      current.value = detail;
      const sourceType = (detail as { sourceType?: string }).sourceType || form.sourceType || 'OAUTH2';
      Object.assign(form, {
        sourceType,
        sourceKey: detail.sourceKey || '',
        displayName: detail.displayName || '',
        logoResourceId: detail.logoResourceId || '',
        remark: detail.remark || '',
        issuerUrl: detail.issuerUrl || '',
        authorizationEndpoint: detail.authorizationEndpoint || '',
        tokenEndpoint: detail.tokenEndpoint || '',
        userInfoEndpoint: detail.userInfoEndpoint || '',
        clientId: detail.clientId || '',
        clientSecret: '',
        scope: detail.scope || defaultScopeForType(sourceType),
        callbackPublicBaseUrl: detail.callbackPublicBaseUrl || form.callbackPublicBaseUrl,
        casPreset: detail.casPreset || form.casPreset || 'STANDARD',
        casLoginPath: detail.casLoginPath || '',
        casValidatePath: detail.casValidatePath || '',
        casLogoutPath: detail.casLogoutPath || '',
        casAppId: detail.casAppId || '',
        casResponseFormat: detail.casResponseFormat || '',
      });
      if (isGithubSourceType(sourceType)) {
        applyGithubPresetToForm(form);
      } else if (isDingTalkSourceType(sourceType)) {
        applyDingTalkPresetToForm(form);
      }
      void refreshLogoPreview(detail.logoResourceId);
    } catch {
      // keep existing form
    }
  }

  function closeEditor() {
    if (testing.value) {
      cancelTestConnection();
    }
    editorOpen.value = false;
    formError.value = '';
    actionWarning.value = '';
    advancedOpen.value = false;
    clearLogo();
  }

  async function refreshCallbackPreview() {
    const sourceKey = form.sourceKey.trim().toLowerCase();
    const callbackPublicBaseUrl = form.callbackPublicBaseUrl.trim().replace(/\/+$/, '');
    if (!/^[a-z0-9][a-z0-9_-]{1,63}$/.test(sourceKey) || !callbackPublicBaseUrl) {
      callbackPreview.value = callbackPublicBaseUrl
        ? null
        : {
            callbackUrl: null,
            warningMessage: '请填写回调公网基址（浏览器与 IdP 可访问，无尾斜杠）。',
            publicBaseUrlConfigured: false,
            localhostWarning: false,
          };
      return;
    }
    try {
      callbackPreview.value = await previewCallback({
        sourceKey,
        callbackPublicBaseUrl,
        sourceType: form.sourceType,
      });
    } catch (error) {
      callbackPreview.value = {
        callbackUrl: null,
        warningMessage: resolveAuthsourceError(error, '无法预览回调 URL。'),
        publicBaseUrlConfigured: false,
        localhostWarning: false,
      };
    }
  }

  function applySaveFeedback(
    detail: IdentitySourceDetail | null | undefined,
    options: {
      criticalChanged?: boolean;
      secretRotated?: boolean;
    } = {}
  ) {
    actionWarning.value = '';
    const { criticalChanged, secretRotated } = options;
    if (criticalChanged || secretRotated) {
      actionMessage.value = '已保存，请重新测试连接。';
    } else {
      actionMessage.value = '已保存。';
    }
    // 保存后软探测服务地址：仅不可达时提示；可达不打扰。
    if (detail && detail.issuerReachable === false) {
      actionWarning.value = detail.issuerReachabilityMessage
        || '服务地址当前不通，已保存；请检查地址或网络后再试「测试连接」。';
    }
  }

  async function save() {
    saving.value = true;
    formError.value = '';
    actionMessage.value = '';
    actionWarning.value = '';
    actionError.value = '';
    try {
      const callbackPublicBaseUrl = form.callbackPublicBaseUrl.trim().replace(/\/+$/, '');
      if (!callbackPublicBaseUrl) {
        formError.value = '请填写回调公网基址（须与 IdP 登记域名一致）。';
        return;
      }
      const github = isGithubSourceType(form.sourceType);
      const dingtalk = isDingTalkSourceType(form.sourceType);
      const cas = isCasSourceType(form.sourceType);
      if (cas) {
        if (!form.issuerUrl.trim()) {
          formError.value = '请填写 CAS 服务地址。';
          return;
        }
        if (form.casPreset === 'HAINAN' && !form.casAppId.trim()) {
          formError.value = '海南预设需要填写 appId（应用通信 ID）。';
          return;
        }
        applyCasPresetToForm(form, form.casPreset || 'STANDARD');
        const casPayload = {
          sourceType: 'CAS',
          sourceKey: form.sourceKey.trim().toLowerCase(),
          displayName: form.displayName.trim(),
          logoResourceId: form.logoResourceId.trim() || undefined,
          remark: form.remark.trim() || undefined,
          issuerUrl: form.issuerUrl.trim(),
          callbackPublicBaseUrl,
          casPreset: form.casPreset,
          casLoginPath: form.casLoginPath || undefined,
          casValidatePath: form.casValidatePath || undefined,
          casLogoutPath: form.casLogoutPath || undefined,
          casAppId: form.casAppId.trim() || undefined,
          casResponseFormat: form.casResponseFormat || undefined,
        };
        if (editorMode.value === 'create') {
          const created = await createSource(casPayload);
          current.value = created;
          editorMode.value = 'edit';
          applySaveFeedback(created);
        } else if (current.value?.identitySourceId) {
          const updated = await updateSource(current.value.identitySourceId, casPayload);
          current.value = updated;
          applySaveFeedback(updated);
        }
        await refreshList();
        return;
      }
      if (github) {
        applyGithubPresetToForm(form);
      } else if (dingtalk) {
        applyDingTalkPresetToForm(form);
        if (!form.issuerUrl.trim()) {
          formError.value = '请填写 CorpId。';
          return;
        }
      } else if (!form.issuerUrl.trim()) {
        formError.value = '请填写服务地址。';
        return;
      }
      // 折叠高级不丢手填端点；空字段回落到服务地址默认路径。
      if (!github && !dingtalk && !form.authorizationEndpoint.trim() && form.issuerUrl.trim()) {
        applyIssuerDefaultsToForm();
      }
      const endpoints = resolvePayloadEndpoints(form);
      const defaultScope = defaultScopeForType(form.sourceType);
      const scopeValue = github
        ? GITHUB_OAUTH2_PRESET.scope
        : dingtalk
          ? DINGTALK_OAUTH2_PRESET.scope
          : (form.scope.trim() || defaultScope);
      if (editorMode.value === 'create') {
        if (!form.clientSecret.trim()) {
          formError.value = dingtalk ? '新建时必须填写 AppSecret。' : '新建时必须填写 Client Secret。';
          return;
        }
        const created = await createSource({
          sourceType: form.sourceType || 'OAUTH2',
          sourceKey: form.sourceKey.trim().toLowerCase(),
          displayName: form.displayName.trim(),
          logoResourceId: form.logoResourceId.trim() || undefined,
          remark: form.remark.trim() || undefined,
          issuerUrl: endpoints.issuerUrl,
          authorizationEndpoint: endpoints.authorizationEndpoint,
          tokenEndpoint: endpoints.tokenEndpoint,
          userInfoEndpoint: endpoints.userInfoEndpoint,
          clientId: form.clientId.trim(),
          clientSecret: form.clientSecret,
          scope: scopeValue,
          callbackPublicBaseUrl,
        });
        current.value = created;
        editorMode.value = 'edit';
        form.clientSecret = '';
        applySaveFeedback(created);
      } else if (current.value?.identitySourceId) {
        const secretRotated = Boolean(form.clientSecret.trim());
        const criticalChanged = isCriticalConfigChanged(current.value, form);
        // 已配置密钥时可留空；仅「从未配置」时前端也会被后端 400 拦住。
        const updated = await updateSource(current.value.identitySourceId, {
          displayName: form.displayName.trim(),
          logoResourceId: form.logoResourceId.trim() || undefined,
          remark: form.remark.trim() || undefined,
          issuerUrl: endpoints.issuerUrl,
          authorizationEndpoint: endpoints.authorizationEndpoint,
          tokenEndpoint: endpoints.tokenEndpoint,
          userInfoEndpoint: endpoints.userInfoEndpoint,
          clientId: form.clientId.trim(),
          clientSecret: form.clientSecret.trim() || undefined,
          scope: scopeValue,
          callbackPublicBaseUrl,
        });
        current.value = updated;
        form.clientSecret = '';
        applySaveFeedback(updated, {
          criticalChanged,
          secretRotated,
        });
      }
      await refreshList();
    } catch (error) {
      formError.value = resolveAuthsourceError(error, '保存失败。');
    } finally {
      saving.value = false;
    }
  }

  function finishTestWithError(category: string, serverMessage = '', options: { refresh?: boolean } = {}) {
    if (!testing.value) {
      return;
    }
    testClosedIntentionally = true;
    testing.value = false;
    actionError.value = resolveFederationTestError(category, serverMessage);
    actionMessage.value = '';
    cleanupTestPopup();
    if (options.refresh === false) {
      return;
    }
    void refreshEditorAfterTest();
  }

  function onTestMessage(event: MessageEvent) {
    // 回调常落在身份源公网基址（如隧道域名），管理页可能在 localhost；不能按 origin 过滤。
    // 仅接受结构固定的试连结果消息。
    const data = event.data;
    if (!data || data.type !== 'BRICK_AUTHSOURCE_TEST_RESULT') {
      return;
    }
    if (!testing.value && !testPopup) {
      return;
    }
    testClosedIntentionally = true;
    testing.value = false;
    if (data.success) {
      actionMessage.value = data.subject
        ? `测试连接成功。已读取外部主体 ${data.subject}${data.email ? `（${data.email}）` : ''}，可以启用。`
        : '测试连接成功，可以启用。';
      actionError.value = '';
      cleanupTestPopup();
    } else {
      const category = typeof data.errorCategory === 'string' ? data.errorCategory : 'UNKNOWN';
      actionError.value = resolveFederationTestError(category, data.message || '');
      actionMessage.value = '';
      cleanupTestPopup();
    }
    void refreshEditorAfterTest();
  }

  function clearTestWatchers() {
    window.removeEventListener('message', onTestMessage);
    if (testTimer) {
      clearTimeout(testTimer);
      testTimer = null;
    }
    if (testPollTimer) {
      clearInterval(testPollTimer);
      testPollTimer = null;
    }
  }

  function cleanupTestPopup() {
    clearTestWatchers();
    if (testPopup && !testPopup.closed) {
      try {
        testPopup.close();
      } catch {
        // ignore cross-origin close failures
      }
    }
    testPopup = null;
    testClosedIntentionally = false;
  }

  function cancelTestConnection() {
    if (!testing.value && !testPopup) {
      return;
    }
    testClosedIntentionally = true;
    testing.value = false;
    actionError.value = resolveFederationTestError('CANCELLED');
    actionMessage.value = '';
    cleanupTestPopup();
  }

  /**
   * 发起测试连接。可从编辑抽屉或列表行调用；列表传入 identitySourceId。
   * 注意：Vue @click="fn" 会传入 MouseEvent，必须忽略非字符串参数。
   */
  async function testConnection(identitySourceId?: string | Event) {
    const rawId = typeof identitySourceId === 'string' ? identitySourceId : '';
    const targetId = (rawId || current.value?.identitySourceId || '').trim();
    if (!targetId) {
      formError.value = '请先保存草稿后再测试连接。';
      actionError.value = '请先保存草稿后再测试连接。';
      return;
    }
    if (testing.value) {
      return;
    }
    testing.value = true;
    formError.value = '';
    actionError.value = '';
    actionMessage.value = '正在快速检测服务连通…';
    actionWarning.value = '';
    testClosedIntentionally = false;
    try {
      // 探测通过后打开本系统授权页（钉钉为品牌化内嵌扫码；其它 IdP 再跳转）。
      const result = await startTestConnection(targetId);
      cleanupTestPopup();
      testClosedIntentionally = false;
      window.addEventListener('message', onTestMessage);
      const width = 520;
      const height = 760;
      const left = Math.max(0, Math.round((window.screen.width - width) / 2));
      const top = Math.max(0, Math.round((window.screen.height - height) / 2));
      const authorizeUrl = String(result?.authorizationUrl || '').trim();
      if (!authorizeUrl) {
        testing.value = false;
        actionMessage.value = '';
        actionError.value = '无法发起测试连接：缺少授权地址。';
        clearTestWatchers();
        return;
      }
      testPopup = window.open(
        authorizeUrl,
        'brick-authsource-test',
        `popup=yes,width=${width},height=${height},left=${left},top=${top},noopener=no`
      );
      if (!testPopup) {
        testing.value = false;
        actionMessage.value = '';
        actionError.value = resolveFederationTestError('POPUP_BLOCKED');
        clearTestWatchers();
        return;
      }
      actionMessage.value = '请在弹出窗口完成扫码或授权；成功或失败结果会回到本页显示。';
      testTimer = setTimeout(() => {
        finishTestWithError('TIMEOUT', '', { refresh: false });
      }, TEST_CONNECTION_TIMEOUT_MS);
      testPollTimer = setInterval(() => {
        if (!testPopup || testClosedIntentionally || !testing.value) {
          return;
        }
        let closed = false;
        try {
          closed = testPopup.closed;
        } catch {
          closed = true;
        }
        if (closed) {
          // User closed IdP tab (e.g. chrome-error / unreachable) without postMessage.
          finishTestWithError('POPUP_CLOSED');
        }
      }, TEST_CONNECTION_POLL_MS);
    } catch (error) {
      testing.value = false;
      actionMessage.value = '';
      actionError.value = resolveAuthsourceError(error, '无法发起测试连接。');
      cleanupTestPopup();
    }
  }

  const riskConfirmOpen = ref(false);
  const riskAction = ref<'delete' | null>(null);
  const riskTargetId = ref('');
  const riskTargetName = ref('');

  const riskTitle = computed(() => {
    if (riskAction.value === 'delete') return '删除身份源';
    return '确认操作';
  });
  const riskDescription = computed(() => {
    if (riskAction.value === 'delete') {
      return `删除「${riskTargetName.value || '该身份源'}」将移除配置与相关登录绑定。登录入口请在「登录安全」管理。`;
    }
    return '';
  });
  const riskImpact = computed(() => {
    if (riskAction.value === 'delete') {
      return ['删除身份源配置', '清理相关登录绑定', '不自动删除已同步员工主数据'];
    }
    return [];
  });
  const riskConfirmText = computed(() => {
    if (riskAction.value === 'delete') return '确认删除';
    return '确认';
  });

  function openDeleteConfirm(row: { identitySourceId: string; displayName?: string; loginEntryEnabled?: boolean }) {
    if (row.loginEntryEnabled) {
      actionError.value = '请先在「登录安全 → 登录方式」关闭该身份源登录入口，再删除。';
      return;
    }
    riskAction.value = 'delete';
    riskTargetId.value = row.identitySourceId;
    riskTargetName.value = row.displayName || '';
    riskConfirmOpen.value = true;
  }

  function cancelRiskConfirm() {
    riskConfirmOpen.value = false;
    riskAction.value = null;
    riskTargetId.value = '';
    riskTargetName.value = '';
  }

  async function confirmRiskAction() {
    const action = riskAction.value;
    const id = riskTargetId.value;
    cancelRiskConfirm();
    if (!action || !id) {
      return;
    }
    if (action === 'delete') {
      try {
        await removeSource(id);
        actionMessage.value = '已删除。';
        if (current.value?.identitySourceId === id) {
          closeEditor();
          current.value = null;
        }
        await refreshList();
      } catch (error) {
        actionError.value = resolveAuthsourceError(error, '删除失败。');
      }
    }
  }

  function fillDefaultScope() {
    form.scope = defaultScopeForType(form.sourceType);
  }

  function initialize() {
    void refreshList();
  }

  const defaultScope = computed(() => defaultScopeForType(form.sourceType));
  const isGithubType = computed(() => isGithubSourceType(form.sourceType));
  const isDingTalkType = computed(() => isDingTalkSourceType(form.sourceType));
  const isCasType = computed(() => isCasSourceType(form.sourceType));
  const isPresetType = computed(() => isPresetSourceType(form.sourceType));

  onBeforeUnmount(() => {
    cleanupTestPopup();
    revokeLocalLogoPreview();
  });

  return {
    rows,
    total,
    page,
    pageSize,
    listLoading,
    listError,
    actionMessage,
    actionWarning,
    actionError,
    keyword,
    empty,
    typePickerOpen,
    editorOpen,
    editorMode,
    saving,
    testing,
    current,
    form,
    advancedOpen,
    logoPreviewUrl,
    logoUploading,
    callbackPreview,
    formError,
    types: IDENTITY_SOURCE_TYPES,
    permissions: authsourcePermissions,
    verificationLabels: VERIFICATION_STATUS_LABELS,
    defaultScope,
    isGithubType,
    isDingTalkType,
    isCasType,
    applyCasPresetToForm: (preset: string) => applyCasPresetToForm(form, preset),
    isPresetType,
    statusBadge,
    initialize,
    refreshList,
    openTypePicker,
    closeTypePicker,
    selectType,
    openEdit,
    closeEditor,
    refreshCallbackPreview,
    save,
    testConnection,
    cancelTestConnection,
    riskConfirmOpen,
    riskTitle,
    riskDescription,
    riskImpact,
    riskConfirmText,
    openDeleteConfirm,
    cancelRiskConfirm,
    confirmRiskAction,
    fillDefaultScope,
    uploadLogo,
    clearLogo,
    onIssuerBlur,
    toggleAdvanced,
    setAdvancedOpen,
    formHasAdvancedCustom: () => formHasAdvancedCustom(form),
    applyIssuerDefaultsToForm,
    changePage(next: number) {
      page.value = next;
      void refreshList();
    },
  };
}
