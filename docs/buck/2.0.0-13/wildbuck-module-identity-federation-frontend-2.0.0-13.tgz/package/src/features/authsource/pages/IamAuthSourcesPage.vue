<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue';
import {
  BrickListPageActions,
  BrickPageHeader,
  BrickRiskConfirm,
  BrickSettingsDrawer,
} from '@wildbuck/core-ui-frontend/patterns';
import {
  BrickImageUploadField,
  BrickManagedSecretInput,
  BrickReadonlyCopyInput,
  resolveBrickManagedSecretField,
} from '@wildbuck/core-ui-frontend/fields';
import '@wildbuck/core-ui-frontend/settings-page.css';
import { useAuthsourceWorkspace } from '../composables/useAuthsourceWorkspace';
import { stashIdentitySyncDeepLinkSourceId } from '../../identitysync/lib/identitysync-deeplink';
import { identityFederationUsageTracker } from '../../../usage-events.js';
import { useIdentityFederationI18n } from '../../../i18n.js';
import '@wildbuck/core-ui-frontend/list-panel.css';

const { t } = useIdentityFederationI18n();

const {
  rows,
  total,
  listLoading,
  listError,
  actionMessage,
  actionWarning,
  actionError,
  keyword,
  empty,
  typePickerOpen,
  editorOpen,
  editorMode,
  saving,
  testing,
  current,
  form,
  advancedOpen,
  logoPreviewUrl,
  logoUploading,
  callbackPreview,
  formError,
  types,

  defaultScope,
  isGithubType,
  isDingTalkType,
  isCasType,
  applyCasPresetToForm,
  isPresetType,
  statusBadge,
  initialize,
  refreshList,
  openTypePicker,
  closeTypePicker,
  selectType,
  openEdit,
  closeEditor,
  refreshCallbackPreview,
  save,
  testConnection,
  cancelTestConnection,
  riskConfirmOpen,
  riskTitle,
  riskDescription,
  riskImpact,
  riskConfirmText,
  openDeleteConfirm,
  cancelRiskConfirm,
  confirmRiskAction,
  fillDefaultScope,
  uploadLogo,
  clearLogo,
  onIssuerBlur,
  toggleAdvanced,
  formHasAdvancedCustom,
} = useAuthsourceWorkspace();

const secretConfigured = computed(
  () => Boolean(current.value?.secretConfigured) && editorMode.value === 'edit'
);

/** 复用 core-ui 托管密钥字段文案：必填/选填、placeholder、hint 统一。 */
const secretField = computed(() => resolveBrickManagedSecretField({
  label: secretFieldLabelOverride.value,
  configured: secretConfigured.value,
  value: form.clientSecret,
  requiredText: t('module.identity-federation.common.required'),
  optionalText: t('module.identity-federation.common.optional'),
  unconfiguredPlaceholder: isDingTalkType.value
    ? t('module.identity-federation.authsource.form.appSecretPlaceholder')
    : t('module.identity-federation.authsource.form.clientSecretPlaceholder'),
  configuredPlaceholder: t('module.identity-federation.authsource.form.secretKeepPlaceholder'),
  unconfiguredHint: t('module.identity-federation.authsource.form.secretUnconfiguredHint'),
  configuredHint: t('module.identity-federation.authsource.form.secretConfiguredHint'),
}));

const editorTitle = computed(() => (
  editorMode.value === 'create'
    ? t('module.identity-federation.authsource.editor.createTitle')
    : t('module.identity-federation.authsource.editor.editTitle')
));
/** 主路径一句话：先完成连接，再测再启。 */
const editorDescription = computed(() => {
  if (isGithubType.value) {
    return t('module.identity-federation.authsource.editor.descGithub');
  }
  if (isDingTalkType.value) {
    return t('module.identity-federation.authsource.editor.descDingTalk');
  }
  if (isCasType.value) {
    return t('module.identity-federation.authsource.editor.descCas');
  }
  return t('module.identity-federation.authsource.editor.descOAuth2');
});

const serviceUrlHint = computed(() => (
  isCasType.value
    ? t('module.identity-federation.authsource.form.serviceUrlHintCas')
    : t('module.identity-federation.authsource.form.serviceUrlHint')
));

const clientIdLabel = computed(() => (
  isDingTalkType.value
    ? t('module.identity-federation.authsource.form.appKeyRequired')
    : t('module.identity-federation.authsource.form.clientIdRequired')
));
const secretFieldLabelOverride = computed(() => (
  isDingTalkType.value
    ? 'AppSecret'
    : t('module.identity-federation.authsource.form.clientSecret')
));

function resolveStatusBadge(row: unknown) {
  return statusBadge(row, t);
}

const typeScenarioKey: Record<string, string> = {
  OAUTH2: 'module.identity-federation.authsource.type.oauth2.scenario',
  GITHUB: 'module.identity-federation.authsource.type.github.scenario',
  DINGTALK: 'module.identity-federation.authsource.type.dingtalk.scenario',
  CAS: 'module.identity-federation.authsource.type.cas.scenario',
  AD_LDAP: 'module.identity-federation.authsource.type.ad.scenario',
  WECOM: 'module.identity-federation.authsource.type.wecom.scenario',
};

const typeTitleKey: Record<string, string> = {
  DINGTALK: 'module.identity-federation.authsource.type.dingtalk',
  WECOM: 'module.identity-federation.authsource.type.wecom',
};

const localizedTypes = computed(() => types.map((item) => ({
  ...item,
  title: typeTitleKey[item.type] ? t(typeTitleKey[item.type]) : item.title,
  scenario: typeScenarioKey[item.type] ? t(typeScenarioKey[item.type]) : item.scenario,
  badge: item.available
    ? t('module.identity-federation.authsource.type.badge.available')
    : t('module.identity-federation.authsource.type.badge.soon'),
})));


const callbackTargetLabel = computed(() => {
  if (isDingTalkType.value) {
    return t('module.identity-federation.authsource.form.targetDingTalk');
  }
  if (isGithubType.value) {
    return t('module.identity-federation.authsource.form.targetGithub');
  }
  if (isCasType.value) {
    return t('module.identity-federation.authsource.form.targetCas');
  }
  return t('module.identity-federation.authsource.form.targetIdp');
});

const callbackBaseHelp = computed(() => (
  isCasType.value
    ? t('module.identity-federation.authsource.form.callbackBaseHelpCas', { target: callbackTargetLabel.value })
    : t('module.identity-federation.authsource.form.callbackBaseHelp', { target: callbackTargetLabel.value })
));

const callbackCopyTargetLabel = computed(() => {
  if (isDingTalkType.value) {
    return t('module.identity-federation.authsource.form.targetDingTalkCallback');
  }
  if (isGithubType.value) {
    return t('module.identity-federation.authsource.form.targetGithub');
  }
  return t('module.identity-federation.authsource.form.targetIdp');
});

const callbackUrl = computed(
  () => callbackPreview.value?.callbackUrl || current.value?.callbackUrl || ''
);

const callbackWarning = computed(
  () => callbackPreview.value?.warningMessage || current.value?.callbackWarning || ''
);

const statusAlert = computed(() => formError.value || actionError.value || '');
const statusOk = computed(() => actionMessage.value || '');
const statusWarn = computed(() => actionWarning.value || '');


/**
 * 高级参数：单一状态源 advancedOpen（workspace）。
 * 新建默认收起；编辑若已自定义则自动展开（产品：不藏用户已有配置）。
 * 业界对照：Auth0 Advanced Settings 收起、Authing 登录模式/账号关联次级、Okta 凭据优先。
 */
const advancedHasCustom = computed(() => formHasAdvancedCustom());

const advancedToggleLabel = computed(() => {
  if (advancedOpen.value) {
    return t('module.identity-federation.authsource.form.advancedCollapse');
  }
  return advancedHasCustom.value
    ? t('module.identity-federation.authsource.form.advancedExpandCustom')
    : t('module.identity-federation.authsource.form.advancedExpand');
});

function onEditorOpenChange(open: boolean) {
  if (!open) {
    closeEditor();
  }
}

/** 深链到身份同步中心并打开对应钉钉任务（登录配置与同步任务分离） */
function openDirectorySyncFromEditor() {
  const id = current.value?.identitySourceId;
  if (!id) {
    return;
  }
  stashIdentitySyncDeepLinkSourceId(id);
  window.location.assign('/identity-federation/identity-sync');
}

onMounted(() => {
  void identityFederationUsageTracker.trackPage('authsource');
  initialize();
});

watch(
  () => [form.sourceKey, form.callbackPublicBaseUrl, form.sourceType] as const,
  () => {
    void refreshCallbackPreview();
  }
);
</script>

<template>
  <article class="authsource-page" data-testid="authsource-page">
    <BrickPageHeader
      :eyebrow="t('module.identity-federation.common.systemAdmin')"
      :title="t('module.identity-federation.authsource.page.title')"
      :description="t('module.identity-federation.authsource.page.description')"
    >
      <template #actions>
        <BrickListPageActions>
          <template #primary>
            <el-button type="primary" data-testid="authsource-create" @click="openTypePicker">
              {{ t('module.identity-federation.authsource.action.create') }}
            </el-button>
          </template>
        </BrickListPageActions>
      </template>
    </BrickPageHeader>

    <div class="authsource-toolbar">
      <el-input
        v-model="keyword"
        clearable
        :placeholder="t('module.identity-federation.authsource.filter.searchPlaceholder')"
        style="max-width: 280px"
        @keyup.enter="refreshList"
      />
      <el-button @click="refreshList">{{ t('module.identity-federation.authsource.filter.query') }}</el-button>
    </div>

    <el-alert
      v-if="listError"
      class="authsource-alert"
      type="error"
      :closable="false"
      show-icon
      :title="listError"
    />
    <el-alert
      v-if="statusOk && !editorOpen"
      class="authsource-alert"
      type="success"
      :closable="false"
      show-icon
      :title="statusOk"
    />
    <el-alert
      v-if="actionError && !editorOpen"
      class="authsource-alert"
      type="error"
      :closable="false"
      show-icon
      :title="actionError"
    />
    <el-alert
      v-if="statusWarn && !editorOpen"
      class="authsource-alert"
      type="warning"
      :closable="false"
      show-icon
      :title="statusWarn"
    />

    <el-card class="iam-list-panel" shadow="never">
      <el-table
        v-loading="listLoading || testing"
        :data="rows"
        stripe
        :empty-text="t('module.identity-federation.authsource.table.empty')"
      >
        <el-table-column prop="displayName" :label="t('module.identity-federation.authsource.table.name')" min-width="140" />
        <el-table-column prop="sourceKey" :label="t('module.identity-federation.authsource.table.sourceKey')" min-width="120">
          <template #default="{ row }">
            <code class="authsource-code">{{ row.sourceKey }}</code>
          </template>
        </el-table-column>
        <el-table-column prop="sourceType" :label="t('module.identity-federation.authsource.table.type')" width="110">
          <template #default="{ row }">
            {{ localizedTypes.find((item) => item.type === row.sourceType)?.title || row.sourceType }}
          </template>
        </el-table-column>
        <el-table-column :label="t('module.identity-federation.authsource.table.status')" min-width="150">
          <template #default="{ row }">
            <el-tag
              size="small"
              effect="plain"
              :type="resolveStatusBadge(row).tone === 'success' ? 'success' : resolveStatusBadge(row).tone === 'danger' ? 'danger' : 'info'"
            >
              {{ resolveStatusBadge(row).text }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column :label="t('module.identity-federation.authsource.table.actions')" width="220" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="openEdit(row.identitySourceId)">{{ t('module.identity-federation.authsource.action.edit') }}</el-button>
            <el-button
              link
              type="primary"
              :disabled="testing || !row.secretConfigured"
              data-testid="authsource-list-test"
              @click="testConnection(row.identitySourceId)"
            >
              {{ t('module.identity-federation.common.testShort') }}
            </el-button>
            <el-button
              link
              type="danger"
              :disabled="row.loginEntryEnabled"
              :title="row.loginEntryEnabled ? t('module.identity-federation.authsource.loginEntry.closeFirst') : undefined"
              @click="openDeleteConfirm(row)"
            >
              {{ t('module.identity-federation.authsource.action.delete') }}
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <div v-if="!empty && total > 0" class="authsource-footer">{{ t('module.identity-federation.common.totalCount', { total }) }}</div>
    </el-card>

    <!-- 类型选择：保留完整卡片信息，帮助用户理解各类型场景 -->
    <el-dialog
      v-model="typePickerOpen"
      :title="t('module.identity-federation.authsource.form.type')"
      width="640px"
      destroy-on-close
      data-testid="authsource-type-picker"
      @close="closeTypePicker"
    >
      <p class="type-picker-hint">
        {{ t('module.identity-federation.authsource.form.typeHint') }}
      </p>
      <div class="type-grid">
        <button
          v-for="item in localizedTypes"
          :key="item.type"
          type="button"
          class="type-card"
          :class="{ disabled: !item.available, available: item.available }"
          :disabled="!item.available"
          :data-testid="`authsource-type-${item.type}`"
          @click="selectType(item.type)"
        >
          <div class="type-card__head">
            <strong class="type-card__title">{{ item.title }}</strong>
            <el-tag
              size="small"
              :type="item.available ? 'success' : 'info'"
              effect="plain"
            >
              {{ item.badge }}
            </el-tag>
          </div>
          <p class="type-card__scenario">{{ item.scenario }}</p>
        </button>
      </div>
    </el-dialog>

    <!--
      人用主路径（X/业界调研：Auth0 Advanced 收起、Authing 连接主字段、Okta 凭据优先）：
      名称 + 标识 +（OAuth2 服务地址）+ Client ID/Secret + 回调 → 保存 → 测试 → 启用。
      图标 / 账号关联 / 协议端点 / 备注 → 高级参数，默认收起；已自定义时编辑自动展开。
    -->
    <BrickSettingsDrawer
      :model-value="editorOpen"
      :title="editorTitle"
      :description="editorDescription"
      :saving="saving"
      :save-text="t('module.identity-federation.common.save')"
      :cancel-text="t('module.identity-federation.common.cancel')"
      width="min(520px, 94vw)"
      data-testid="authsource-editor"
      @update:model-value="onEditorOpenChange"
      @save="save"
    >
      <template #secondary>
        <el-button
          v-if="editorMode === 'edit' && !testing"
          :disabled="saving || !current?.secretConfigured"
          data-testid="authsource-test"
          @click="() => testConnection()"
        >
          {{ t('module.identity-federation.authsource.action.test') }}
        </el-button>
        <el-button
          v-if="editorMode === 'edit' && testing"
          data-testid="authsource-test-cancel"
          @click="cancelTestConnection"
        >
          {{ t('module.identity-federation.authsource.action.cancelTest') }}
        </el-button>
        <el-alert
          v-if="editorMode === 'edit' && current?.verificationStatus === 'VERIFIED' && !current?.loginEntryEnabled"
          type="info"
          :closable="false"
          show-icon
          class="authsource-login-hint"
          :title="t('module.identity-federation.authsource.loginEntry.hint')"
        />
      </template>

      <el-alert
        v-if="statusAlert"
        class="authsource-alert"
        type="error"
        :closable="false"
        show-icon
        :title="statusAlert"
      />
      <el-alert
        v-if="statusOk"
        class="authsource-alert"
        type="success"
        :closable="false"
        show-icon
        :title="statusOk"
      />
      <el-alert
        v-if="statusWarn"
        class="authsource-alert"
        type="warning"
        :closable="false"
        show-icon
        :title="statusWarn"
        data-testid="authsource-service-warning"
      />
      <el-form
        
        label-position="top"
        class="authsource-form setting-form brick-required-form"
        @submit.prevent="save"
      >
        <!-- 主路径：连接必需，单列线性扫视 -->
        <el-form-item :label="t('module.identity-federation.authsource.form.displayName')" class="setting-form__full" required>
          <el-input
            v-model="form.displayName"
            maxlength="100"
            :placeholder="t('module.identity-federation.authsource.form.displayNameHint')"
            data-testid="authsource-display-name"
          />
        </el-form-item>

        <el-form-item :label="t('module.identity-federation.authsource.form.sourceKey')" class="setting-form__full" required>
          <el-input
            v-model="form.sourceKey"
            :disabled="editorMode === 'edit'"
            :placeholder="t('module.identity-federation.authsource.form.sourceKeyPlaceholder')"
            data-testid="authsource-source-key"
            @blur="refreshCallbackPreview"
          />
          <small class="field-hint">{{ t('module.identity-federation.authsource.form.sourceKeyHint') }}</small>
        </el-form-item>

        <el-form-item
          v-if="isDingTalkType"
          :label="t('module.identity-federation.authsource.form.corpId')"
          class="setting-form__full"
          required
        >
          <el-input
            v-model="form.issuerUrl"
            :placeholder="t('module.identity-federation.authsource.form.corpIdPlaceholder')"
            data-testid="authsource-corpid"
          />
          <small class="field-hint">{{ t('module.identity-federation.authsource.form.corpIdHint') }}</small>
        </el-form-item>

        <el-form-item
          v-else-if="!isGithubType"
          :label="t('module.identity-federation.authsource.form.serviceUrl')"
          class="setting-form__full"
          required
        >
          <el-input
            v-model="form.issuerUrl"
            placeholder="https://idp.example.com"
            data-testid="authsource-issuer-url"
            @blur="onIssuerBlur"
          />
          <small class="field-hint">{{ serviceUrlHint }}</small>
        </el-form-item>

        <p v-else class="github-preset-note setting-form__full" data-testid="authsource-github-preset-note">
          {{ t('module.identity-federation.authsource.form.githubBuiltin') }}
        </p>

        <p
          v-if="isDingTalkType"
          class="github-preset-note setting-form__full"
          data-testid="authsource-dingtalk-preset-note"
        >
          {{ t('module.identity-federation.authsource.form.dingtalkBuiltin') }}
        </p>

        <div
          v-if="isDingTalkType && editorMode === 'edit' && current?.identitySourceId"
          class="setting-form__full authsource-sync-entry"
          data-testid="authsource-directory-sync-entry"
        >
          <div class="authsource-sync-entry__text">
            <strong>{{ t('module.identity-federation.authsource.form.syncSection') }}</strong>
            <span class="field-hint">{{ t('module.identity-federation.authsource.form.syncSectionHint') }}</span>
          </div>
          <el-button
            type="primary"
            plain
            data-testid="authsource-open-directory-sync"
            @click="openDirectorySyncFromEditor"
          >
            {{ t('module.identity-federation.authsource.action.openSync') }}
          </el-button>
        </div>

        <template v-if="isCasType">
          <el-form-item label="CAS 预设" class="setting-form__full" required>
            <el-select
              v-model="form.casPreset"
              data-testid="authsource-cas-preset"
              @change="applyCasPresetToForm(form.casPreset)"
            >
              <el-option label="标准 CAS（Apereo）" value="STANDARD" />
              <el-option label="海南门户（类 CAS JSON）" value="HAINAN" />
            </el-select>
            <small class="field-hint">厂商门户只改预设，不要新增身份源类型。</small>
          </el-form-item>
          <el-form-item v-if="form.casPreset === 'HAINAN'" label="appId" class="setting-form__full" required>
            <el-input v-model="form.casAppId" placeholder="门户应用通信 ID" data-testid="authsource-cas-app-id" />
          </el-form-item>
          <el-form-item label="验票路径" class="setting-form__full">
            <el-input v-model="form.casValidatePath" data-testid="authsource-cas-validate-path" />
          </el-form-item>
          <el-form-item label="登录路径" class="setting-form__full">
            <el-input v-model="form.casLoginPath" data-testid="authsource-cas-login-path" />
          </el-form-item>
          <el-form-item label="登出路径" class="setting-form__full">
            <el-input v-model="form.casLogoutPath" data-testid="authsource-cas-logout-path" />
          </el-form-item>
        </template>

        <el-form-item v-if="!isCasType" :label="clientIdLabel" class="setting-form__full" required>
          <el-input
            v-model="form.clientId"
            autocomplete="off"
            :placeholder="isDingTalkType ? t('module.identity-federation.authsource.form.clientIdPlaceholderDing') : t('module.identity-federation.authsource.form.clientIdPlaceholderOAuth')"
            data-testid="authsource-client-id"
          />
        </el-form-item>

        <el-form-item
          v-if="!isCasType"
          :label="secretField.labelText"
          class="setting-form__full"
          :required="secretField.required"
        >
          <BrickManagedSecretInput
            v-model="form.clientSecret"
            aria-label="Client Secret"
            :configured="secretConfigured"
            :configured-tag-text="secretField.configuredTagText"
            :unconfigured-placeholder="secretField.placeholder"
            :configured-placeholder="secretField.placeholder"
            :unconfigured-hint="secretField.hint"
            :configured-hint="secretField.hint"
            autocomplete="new-password"
          />
        </el-form-item>

        <el-form-item :label="t('module.identity-federation.authsource.form.callbackBase')" class="setting-form__full" required>
          <el-input
            v-model="form.callbackPublicBaseUrl"
            :placeholder="t('module.identity-federation.authsource.form.callbackBaseHint')"
            data-testid="authsource-callback-base"
            autocomplete="off"
          />
          <small class="field-hint">
            {{ callbackBaseHelp }}
          </small>
        </el-form-item>

        <el-form-item
          v-if="callbackUrl || editorMode === 'create'"
          :label="t('module.identity-federation.authsource.form.callbackUrl')"
          class="setting-form__full"
        >
          <BrickReadonlyCopyInput
            :model-value="callbackUrl || t('module.identity-federation.authsource.form.callbackUrlHint')"
            :copyable="Boolean(callbackUrl)"
            :disabled="!callbackUrl"
            :copy-button-text="t('module.identity-federation.common.copy')"
            :placeholder="t('module.identity-federation.authsource.form.callbackUrlHint')"
          />
          <small v-if="callbackWarning" class="field-hint field-hint--warn">{{ callbackWarning }}</small>
          <small v-else class="field-hint">
            {{ t('module.identity-federation.authsource.form.callbackCopyTo', { target: callbackCopyTargetLabel }) }}
          </small>
        </el-form-item>

        <!-- 高级参数：低频项折叠，降低新建心智负担 -->
        <div class="setting-form__full authsource-advanced" data-testid="authsource-advanced-panel">
          <button
            type="button"
            class="advanced-toggle"
            data-testid="authsource-advanced-toggle"
            :aria-expanded="advancedOpen"
            @click="toggleAdvanced"
          >
            <span>{{ advancedToggleLabel }}</span>
            <span class="advanced-toggle__chevron" :data-open="String(advancedOpen)">▾</span>
          </button>

          <div v-if="advancedOpen" class="advanced-body" data-testid="authsource-advanced-body">
            <p class="advanced-lead">
              {{ isPresetType ? t('module.identity-federation.authsource.form.advancedHint') : t('module.identity-federation.authsource.form.advancedHintWithEndpoints') }}
            </p>

            <div class="advanced-section" data-testid="authsource-advanced-display">
              <h4 class="advanced-section__title">{{ t('module.identity-federation.authsource.form.loginDisplay') }}</h4>
              <el-form-item :label="t('module.identity-federation.authsource.form.loginIcon')">
                <BrickImageUploadField
                  label=""
                  description=""
                  :preview-url="logoPreviewUrl"
                  preview-alt="Logo"
                  fallback-text="Logo"
                  :uploading="logoUploading"
                  :clear-disabled="!form.logoResourceId"
                  :upload-text="t('module.identity-federation.common.upload')"
                  :clear-text="t('module.identity-federation.common.clear')"
                  :resource-hint="t('module.identity-federation.authsource.form.resourceHint')"
                  :preview-size="56"
                  @upload="uploadLogo"
                  @clear="clearLogo"
                />
              </el-form-item>
            </div>

            <div v-if="!isPresetType && !isCasType" class="advanced-section" data-testid="authsource-advanced-protocol">
              <h4 class="advanced-section__title">{{ t('module.identity-federation.authsource.form.advancedEndpoints') }}</h4>
              <el-form-item :label="t('module.identity-federation.authsource.form.authorizeEndpoint')">
                <el-input
                  v-model="form.authorizationEndpoint"
                  :placeholder="t('module.identity-federation.authsource.form.authorizePlaceholder')"
                  data-testid="authsource-authorization-endpoint"
                />
              </el-form-item>
              <el-form-item :label="t('module.identity-federation.authsource.form.tokenEndpoint')">
                <el-input
                  v-model="form.tokenEndpoint"
                  :placeholder="t('module.identity-federation.authsource.form.tokenPlaceholder')"
                  data-testid="authsource-token-endpoint"
                />
              </el-form-item>
              <el-form-item :label="t('module.identity-federation.authsource.form.userInfoEndpoint')">
                <el-input
                  v-model="form.userInfoEndpoint"
                  :placeholder="t('module.identity-federation.authsource.form.userInfoPlaceholder')"
                  data-testid="authsource-userinfo-endpoint"
                />
              </el-form-item>
              <el-form-item :label="t('module.identity-federation.authsource.form.scope')">
                <div class="scope-row">
                  <el-input v-model="form.scope" :placeholder="defaultScope" data-testid="authsource-scope" />
                  <el-button @click="fillDefaultScope">{{ t('module.identity-federation.authsource.form.restoreDefaults') }}</el-button>
                </div>
              </el-form-item>
            </div>

            <div class="advanced-section" data-testid="authsource-advanced-remark">
              <h4 class="advanced-section__title">{{ t('module.identity-federation.authsource.form.remark') }}</h4>
              <el-form-item :label="t('module.identity-federation.authsource.form.remark')">
                <el-input
                  v-model="form.remark"
                  type="textarea"
                  :rows="2"
                  maxlength="500"
                  :placeholder="t('module.identity-federation.authsource.form.remarkPlaceholder')"
                />
              </el-form-item>
            </div>
          </div>
        </div>
      </el-form>
    </BrickSettingsDrawer>

    <BrickRiskConfirm
      v-model="riskConfirmOpen"
      :title="riskTitle"
      :description="riskDescription"
      :impact="riskImpact"
      :confirm-text="riskConfirmText"
      data-testid="authsource-risk-confirm"
      @confirm="confirmRiskAction"
      @cancel="cancelRiskConfirm"
    />
  </article>
</template>

<style scoped>
.authsource-page {
  display: grid;
  gap: 16px;
}


.authsource-toolbar {
  display: flex;
  gap: 8px;
  align-items: center;
  flex-wrap: wrap;
}

.authsource-alert {
  margin: 0;
}

.authsource-footer {
  padding: 12px 16px;
  color: var(--console-text-secondary, #5b6b7c);
  font-size: 13px;
}

.authsource-code {
  font-size: 12px;
}

.authsource-alert + .authsource-alert,
.authsource-alert + .authsource-form {
  margin-top: 14px;
}

/* 主路径单列：身份源配置是线性任务，双列会抬高扫视成本 */
.authsource-form.setting-form {
  grid-template-columns: minmax(0, 1fr);
}

.field-hint {
  display: block;
  margin-top: 6px;
  color: var(--console-text, #4a5a70);
  font-size: 12px;
  line-height: 1.5;
}

.field-hint--warn {
  color: var(--console-warning, #b76c00);
}

.scope-row {
  display: flex;
  gap: 8px;
  width: 100%;
  align-items: center;
}

.scope-row :deep(.el-input) {
  flex: 1;
}

.authsource-advanced {
  margin-top: 8px;
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: 10px;
  overflow: hidden;
  background: var(--console-card-bg);
}

.advanced-toggle {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  min-height: 44px;
  padding: 0 14px;
  border: 0;
  background: var(--console-soft-bg, var(--console-block-bg, var(--console-card-bg)));
  color: var(--console-title, #172033);
  font: inherit;
  font-size: 13px;
  font-weight: 650;
  cursor: pointer;
  text-align: left;
}

.advanced-toggle:hover {
  background: color-mix(in srgb, var(--console-primary) 8%, var(--console-soft-bg, var(--console-block-bg)));
}

.advanced-toggle__chevron {
  color: var(--console-text-secondary, #5b6b7c);
  transition: transform 0.15s ease;
}

.advanced-toggle__chevron[data-open='true'] {
  transform: rotate(180deg);
}

.advanced-body {
  display: grid;
  gap: 4px;
  padding: 12px 14px 14px;
  border-top: 1px solid var(--console-card-border, #e6ebf2);
}

.advanced-lead {
  margin: 0 0 12px;
  color: var(--console-text-secondary, #5b6b7c);
  font-size: 12px;
  line-height: 1.5;
}

.advanced-section {
  display: grid;
  gap: 2px;
  padding-top: 4px;
}

.advanced-section + .advanced-section {
  margin-top: 8px;
  padding-top: 12px;
  border-top: 1px dashed var(--console-card-border, #e6ebf2);
}

.advanced-section__title {
  margin: 0 0 8px;
  font-size: 12px;
  font-weight: 650;
  letter-spacing: 0.02em;
  color: var(--console-text-secondary, #5b6b7c);
}

.github-preset-note {
  margin: 0 0 4px;
  padding: 10px 12px;
  border-radius: 8px;
  background: color-mix(in srgb, var(--console-primary) 10%, var(--console-block-bg, var(--console-card-bg)));
  color: var(--console-text, #4a5a70);
  font-size: 12px;
  line-height: 1.5;
}

.authsource-sync-entry {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin: 4px 0 12px;
  padding: 12px;
  border-radius: 8px;
  border: 1px solid var(--console-card-border, #e6ebf2);
  background: var(--console-soft-bg, #f7f9fc);
}

.authsource-sync-entry__text {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.authsource-sync-entry__text strong {
  font-size: 13px;
}

.authsource-sync-entry .field-hint {
  margin-top: 0;
}

.type-picker-hint {
  margin: 0 0 16px;
  font-size: 13px;
  line-height: 1.5;
  color: var(--console-text-secondary, #5b6b7c);
}

.type-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}

.type-card {
  display: flex;
  flex-direction: column;
  align-items: stretch;
  gap: 10px;
  min-height: 108px;
  padding: 16px;
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: 10px;
  background: var(--console-card-bg);
  color: var(--console-text);
  cursor: pointer;
  text-align: left;
  font: inherit;
  transition: border-color 0.15s ease, box-shadow 0.15s ease;
}

.type-card.available:hover {
  border-color: var(--console-primary);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--console-primary) 18%, transparent);
}

.type-card.disabled {
  opacity: 0.62;
  cursor: not-allowed;
  background: var(--console-block-bg, var(--console-card-bg));
}

.type-card__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.type-card__title {
  font-size: 15px;
  color: var(--console-title, #172033);
}

.type-card__scenario {
  margin: 0;
  font-size: 13px;
  line-height: 1.5;
  color: var(--console-text-secondary, #5b6b7c);
}

.scope-row :deep(.el-input) {
  flex: 1;
}
</style>
