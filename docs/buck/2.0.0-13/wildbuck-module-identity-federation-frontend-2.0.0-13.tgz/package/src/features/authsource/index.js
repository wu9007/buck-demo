import { authsourcePermissions } from './permission/index.js';
import { authsourceRoutes } from './routes/index.js';

export const authsourceFeature = {
  featureKey: 'authsource',
  permissions: authsourcePermissions,
  routes: authsourceRoutes,
};

export { authsourcePermissions, authsourceRoutes };
