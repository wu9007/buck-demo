export const authsourceRoutes = [
  {
    id: 'identity-federation.authsource.list',
    featureKey: 'authsource',
    path: '/identity-federation/auth-sources',
    title: '身份源',
    abbr: '源',
    eyebrow: '系统管理 / 身份源',
    summary: '接入企业 OAuth2 身份源，完成回调配置、测试连接后启用联邦登录。',
    guide: {
      title: '身份源接入任务路径',
      steps: [
        {
          anchor: 'list',
          title: '选择类型并填写配置',
          body: '新建时先选 OAuth2.0；把回调 URL 原样配置到 IdP。',
        },
        {
          anchor: 'list',
          title: '保存草稿后测试连接',
          body: '测试通过才会变为已验证；未验证不能启用。',
        },
        {
          anchor: 'list',
          title: '启用后出现在登录页',
          body: '启用后业务用户可点「使用 XX 登录」；本地密码登录仍可用。',
        },
      ],
    },
    permission: 'identity-federation:authsource:view',
    component: () => import('../pages/IamAuthSourcesPage.vue'),
  },
];
