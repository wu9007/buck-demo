import {
  createIdentitySource,
  deleteIdentitySource,
  identitySourceDetail,
  listIdentitySources,
  previewIdentitySourceCallback,
  startIdentitySourceTestConnection,
  updateIdentitySource,
} from '../../../generated/sdk';
import type {
  CreateIdentitySourceRequest,
  IdentitySourceCallbackPreviewRequest,
  IdentitySourceSearchRequest,
  UpdateIdentitySourceRequest,
} from '../../../generated/types';

export function searchIdentitySources(request: IdentitySourceSearchRequest = {}) {
  return listIdentitySources(request);
}

export function loadIdentitySourceDetail(identitySourceId: string) {
  return identitySourceDetail(identitySourceId, undefined as void);
}

export function previewCallback(request: IdentitySourceCallbackPreviewRequest) {
  return previewIdentitySourceCallback(request);
}

export function createSource(request: CreateIdentitySourceRequest) {
  return createIdentitySource(request);
}

export function updateSource(identitySourceId: string, request: UpdateIdentitySourceRequest) {
  return updateIdentitySource(identitySourceId, request);
}

export function removeSource(identitySourceId: string) {
  return deleteIdentitySource(identitySourceId, undefined as void);
}

export function startTestConnection(identitySourceId: string) {
  return startIdentitySourceTestConnection(identitySourceId, undefined as void);
}
