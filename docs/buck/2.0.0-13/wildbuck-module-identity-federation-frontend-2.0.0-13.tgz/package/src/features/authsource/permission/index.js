export const authsourcePermissions = {
  list: 'identity-federation:authsource:view',
  edit: 'identity-federation:authsource:edit',
  test: 'identity-federation:authsource:test',
};
