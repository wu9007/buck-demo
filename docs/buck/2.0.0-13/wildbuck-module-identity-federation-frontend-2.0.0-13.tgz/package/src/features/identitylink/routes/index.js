export const identitylinkRoutes = [
  {
    id: 'identity-federation.identity-link',
    featureKey: 'identitylink',
    path: '/identity-federation/identity-link',
    title: '身份关联',
    abbr: '联',
    eyebrow: '系统管理 / 身份关联',
    summary: '将同步暂存的上游身份与本地员工绑定，供扫码登录使用。',
    guide: {
      title: '身份关联',
      steps: [
        {
          anchor: 'list',
          title: '选择身份源',
          body: '先选上游身份源，查看暂存待关联人员。',
        },
        {
          anchor: 'list',
          title: '手工或一键关联',
          body: '手工选本地员工，或按手机/邮箱唯一命中一键绑定。',
        },
        {
          anchor: 'list',
          title: '解除与登录',
          body: '绑定写入登录关系后即可扫码登录；可随时解除。',
        },
      ],
    },
    permission: 'identity-federation:identity-link:view',
    component: () => import('../pages/IamIdentityLinkPage.vue'),
  },
];
