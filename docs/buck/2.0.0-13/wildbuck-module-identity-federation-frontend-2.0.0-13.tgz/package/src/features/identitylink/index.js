import { identitylinkPermissions } from './permission/index.js';
import { identitylinkRoutes } from './routes/index.js';

export const identitylinkFeature = {
  featureKey: 'identitylink',
  permissions: identitylinkPermissions,
  routes: identitylinkRoutes,
};

export { identitylinkPermissions, identitylinkRoutes };
