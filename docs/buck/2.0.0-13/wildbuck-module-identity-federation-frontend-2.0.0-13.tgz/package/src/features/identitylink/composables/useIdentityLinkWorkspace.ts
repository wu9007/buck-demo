import { computed, reactive, ref } from 'vue';
import {
  attributeLink,
  manualLink,
  searchCandidates,
  searchEmployees,
  searchSources,
  unlink,
} from '../api/identitylink';
import { resolveIdentityLinkError } from '../lib/identitylink-errors';
import type {
  IdentityLinkCandidate,
  IdentityLinkCandidateSearchRequest,
  IdentitySourceSummary,
} from '../../../generated/types';
import type { EmployeeSummary } from '../../../api/iam-master-data';

export type IdentityLinkFilters = {
  identitySourceId: string;
  keyword: string;
  linkStatus: string;
};

const PAGE_SIZE_OPTIONS = [10, 20, 50];

export function useIdentityLinkWorkspace(options: { t?: (key: string, params?: Record<string, unknown>) => string } = {}) {
  const t = typeof options.t === 'function' ? options.t : (key: string) => key;
  const listLoading = ref(false);
  const linking = ref(false);
  const listError = ref('');
  const actionMessage = ref('');
  const sources = ref<IdentitySourceSummary[]>([]);
  const candidates = ref<IdentityLinkCandidate[]>([]);
  const total = ref(0);
  const pendingCount = ref(0);
  const linkedCount = ref(0);
  const page = ref(1);
  const pageSize = ref(20);

  const filters = reactive<IdentityLinkFilters>({
    identitySourceId: '',
    keyword: '',
    linkStatus: '',
  });

  const manualVisible = ref(false);
  const manualRow = ref<IdentityLinkCandidate | null>(null);
  /** 本地员工远程下拉：keyword 仅作 remote 查询，不在表单上单独展示输入框。 */
  const employeeKeyword = ref('');
  const employeeOptions = ref<EmployeeSummary[]>([]);
  const employeeSearchLoading = ref(false);
  const selectedEmployeeId = ref('');

  const sourceOptions = computed(() =>
    sources.value.map((item) => ({
      value: item.identitySourceId,
      label: `${item.displayName}（${item.sourceKey}）`,
    })),
  );

  const linkStatusOptions = computed(() => [
    { value: 'PENDING', label: t('module.identity-federation.identitylink.filter.pending') },
    { value: 'LINKED', label: t('module.identity-federation.identitylink.filter.linked') },
  ]);

  const filterActive = computed(
    () => Boolean(filters.keyword.trim() || filters.linkStatus),
  );

  const pageSummary = computed(() => {
    const params = {
      total: total.value,
      pending: pendingCount.value,
      linked: linkedCount.value,
    };
    if (filterActive.value) {
      return t('module.identity-federation.identitylink.summary.filtered', params);
    }
    return t('module.identity-federation.identitylink.summary.total', params);
  });

  const pageSizeOptions = PAGE_SIZE_OPTIONS;

  async function loadSources() {
    const pageRes = await searchSources({ page: 1, size: 100 });
    sources.value = pageRes.records || [];
    if (!filters.identitySourceId && sources.value.length) {
      filters.identitySourceId = sources.value[0].identitySourceId;
    }
  }

  async function refreshStats() {
    if (!filters.identitySourceId) {
      pendingCount.value = 0;
      linkedCount.value = 0;
      return;
    }
    try {
      const [pending, linked] = await Promise.all([
        searchCandidates(filters.identitySourceId, { linkStatus: 'PENDING', page: 1, size: 1 }),
        searchCandidates(filters.identitySourceId, { linkStatus: 'LINKED', page: 1, size: 1 }),
      ]);
      pendingCount.value = pending.total || 0;
      linkedCount.value = linked.total || 0;
    } catch {
      // stats are best-effort
    }
  }

  async function reloadList() {
    if (!filters.identitySourceId) {
      candidates.value = [];
      total.value = 0;
      pendingCount.value = 0;
      linkedCount.value = 0;
      return;
    }
    listLoading.value = true;
    listError.value = '';
    try {
      const res = await searchCandidates(filters.identitySourceId, {
        keyword: filters.keyword || undefined,
        linkStatus: filters.linkStatus || undefined,
        page: page.value,
        size: pageSize.value,
      });
      candidates.value = res.records || [];
      total.value = res.total || 0;
      await refreshStats();
    } catch (e: unknown) {
      listError.value = resolveIdentityLinkError(e, t('module.identity-federation.error.listFailed'));
    } finally {
      listLoading.value = false;
    }
  }

  async function initialize() {
    listError.value = '';
    try {
      await loadSources();
      await reloadList();
    } catch (e: unknown) {
      listError.value = resolveIdentityLinkError(e, t('module.identity-federation.error.initFailed'));
    }
  }

  function applyFilters(next: IdentityLinkFilters) {
    filters.identitySourceId = next.identitySourceId;
    filters.keyword = next.keyword ?? '';
    filters.linkStatus = next.linkStatus ?? '';
    page.value = 1;
    void reloadList();
  }

  function resetFilters(next: IdentityLinkFilters) {
    filters.identitySourceId = next.identitySourceId || filters.identitySourceId;
    filters.keyword = '';
    filters.linkStatus = '';
    page.value = 1;
    void reloadList();
  }

  function changePage(next: number) {
    page.value = next;
    void reloadList();
  }

  function changePageSize(next: number) {
    pageSize.value = next;
    page.value = 1;
    void reloadList();
  }

  async function openManual(row: IdentityLinkCandidate) {
    manualRow.value = row;
    selectedEmployeeId.value = '';
    // 勿用上游显示名预填：同名同步员工会误导成「只能选上游同名账号」。
    employeeKeyword.value = '';
    employeeOptions.value = [];
    manualVisible.value = true;
    await searchEmployeeOptions('');
  }

  /**
   * 远程搜索本地员工（el-select remote-method）。
   * 打开弹窗时 keyword 为空，加载首屏列表；输入后再按姓名/登录名筛选。
   */
  async function searchEmployeeOptions(keyword: string = '') {
    employeeKeyword.value = typeof keyword === 'string' ? keyword : '';
    employeeSearchLoading.value = true;
    try {
      const res = await searchEmployees({
        keyword: employeeKeyword.value.trim() || undefined,
        page: 1,
        size: 30,
      });
      employeeOptions.value = res.records || [];
    } catch {
      employeeOptions.value = [];
    } finally {
      employeeSearchLoading.value = false;
    }
  }

  async function submitManualLink() {
    if (!manualRow.value || !selectedEmployeeId.value || !filters.identitySourceId) {
      return false;
    }
    linking.value = true;
    listError.value = '';
    actionMessage.value = '';
    try {
      const result = await manualLink(filters.identitySourceId, {
        externalUserId: manualRow.value.externalUserId,
        employeeId: selectedEmployeeId.value,
      });
      actionMessage.value = result.message || t('module.identity-federation.identitylink.msg.bound');
      manualVisible.value = false;
      await reloadList();
      return true;
    } catch (e: unknown) {
      listError.value = resolveIdentityLinkError(e, t('module.identity-federation.identitylink.action.bind'));
      return false;
    } finally {
      linking.value = false;
    }
  }

  async function submitAttributeLink(matchKey: 'PHONE' | 'EMAIL') {
    if (!filters.identitySourceId) {
      return false;
    }
    linking.value = true;
    listError.value = '';
    actionMessage.value = '';
    try {
      const result = await attributeLink(filters.identitySourceId, { matchKey, dryRun: false });
      actionMessage.value = t('module.identity-federation.identitylink.msg.attributeResult', {
        linkCount: result.linkCount,
        skipCount: result.skipCount,
        failCount: result.failCount,
      });
      await reloadList();
      return true;
    } catch (e: unknown) {
      listError.value = resolveIdentityLinkError(e, t('module.identity-federation.identitylink.action.linkPhone'));
      return false;
    } finally {
      linking.value = false;
    }
  }

  async function submitUnlink(row: IdentityLinkCandidate) {
    if (!filters.identitySourceId) {
      return false;
    }
    linking.value = true;
    listError.value = '';
    actionMessage.value = '';
    try {
      const result = await unlink(filters.identitySourceId, { externalUserId: row.externalUserId });
      actionMessage.value = result.message || t('module.identity-federation.identitylink.msg.unbound');
      await reloadList();
      return true;
    } catch (e: unknown) {
      listError.value = resolveIdentityLinkError(e, t('module.identity-federation.identitylink.action.unbind'));
      return false;
    } finally {
      linking.value = false;
    }
  }

  return {
    actionMessage,
    applyFilters,
    candidates,
    changePage,
    changePageSize,
    employeeKeyword,
    employeeOptions,
    employeeSearchLoading,
    filterActive,
    filters,
    initialize,
    linkStatusOptions,
    linking,
    listError,
    listLoading,
    loadSources,
    manualRow,
    manualVisible,
    openManual,
    page,
    pageSize,
    pageSizeOptions,
    pageSummary,
    pendingCount,
    reloadList,
    resetFilters,
    searchEmployeeOptions,
    selectedEmployeeId,
    sourceOptions,
    sources,
    submitAttributeLink,
    submitManualLink,
    submitUnlink,
    total,
  };
}
