<script setup lang="ts">
import { watch } from 'vue';
import { BrickFilterToolbar, useBrickFilterDraft } from '@wildbuck/core-ui-frontend/patterns';
import type { IdentityLinkFilters } from '../composables/useIdentityLinkWorkspace';
import { useIdentityFederationI18n } from '../../../i18n.js';

const { t } = useIdentityFederationI18n();

const props = defineProps<{
  modelValue: IdentityLinkFilters;
  sourceOptions: Array<{ label: string; value: string }>;
  linkStatusOptions: Array<{ label: string; value: string }>;
}>();

const emit = defineEmits<{
  'update:modelValue': [IdentityLinkFilters];
  search: [IdentityLinkFilters];
  reset: [IdentityLinkFilters];
}>();

const defaultFilters = (): IdentityLinkFilters => ({
  identitySourceId: props.modelValue?.identitySourceId || '',
  keyword: '',
  linkStatus: '',
});

const { draft, resetDraft, replaceDraft, snapshot } = useBrickFilterDraft(defaultFilters);

watch(
  () => props.modelValue,
  (value) => {
    if (!value) {
      return;
    }
    const current = snapshot();
    if (
      current.identitySourceId !== value.identitySourceId
      || current.keyword !== value.keyword
      || current.linkStatus !== value.linkStatus
    ) {
      replaceDraft({
        identitySourceId: value.identitySourceId ?? '',
        keyword: value.keyword ?? '',
        linkStatus: value.linkStatus ?? '',
      });
    }
  },
  { deep: true, immediate: true },
);

function onSearch() {
  const next = snapshot();
  emit('update:modelValue', next);
  emit('search', next);
}

function onReset() {
  const next = resetDraft();
  // keep current source when clearing keyword/status
  next.identitySourceId = props.modelValue.identitySourceId || next.identitySourceId;
  replaceDraft(next);
  emit('update:modelValue', next);
  emit('reset', next);
}
</script>

<template>
  <BrickFilterToolbar data-guide-anchor="filters" field-min-width="180px" data-testid="identity-link-filter-toolbar">
    <el-select
      v-model="draft.identitySourceId"
      filterable
      :placeholder="t('module.identity-federation.identitylink.filter.source')"
      data-testid="identity-link-source"
    >
      <el-option
        v-for="option in sourceOptions"
        :key="option.value"
        :label="option.label"
        :value="option.value"
      />
    </el-select>

    <el-select
      v-model="draft.linkStatus"
      clearable
      :placeholder="t('module.identity-federation.identitylink.filter.status')"
      data-testid="identity-link-status"
    >
      <el-option
        v-for="option in linkStatusOptions"
        :key="option.value"
        :label="option.label"
        :value="option.value"
      />
    </el-select>

    <el-input
      v-model="draft.keyword"
      clearable
      :placeholder="t('module.identity-federation.identitylink.filter.keyword')"
      data-testid="identity-link-keyword"
      @keyup.enter="onSearch"
    />

    <template #actions>
      <el-button native-type="button" data-testid="identity-link-filter-reset" @click.prevent="onReset">
        {{ t('module.identity-federation.identitylink.filter.reset') }}
      </el-button>
      <el-button type="primary" native-type="button" data-testid="identity-link-search" @click.prevent="onSearch">
        {{ t('module.identity-federation.identitylink.filter.query') }}
      </el-button>
    </template>
  </BrickFilterToolbar>
</template>
