<script setup lang="ts">
/**
 * 身份关联：复用 IAM 正式列表页骨架
 * BrickPageHeader + BrickFilterToolbar + iam-list-panel 表 + BrickPaginationBar + BrickRiskConfirm
 */
import { computed, onMounted, ref } from 'vue';
import {
  BrickListPageActions,
  BrickPageHeader,
  BrickRiskConfirm,
} from '@wildbuck/core-ui-frontend/patterns';
import IdentityLinkFilterToolbar from '../components/IdentityLinkFilterToolbar.vue';
import IdentityLinkTablePanel from '../components/IdentityLinkTablePanel.vue';
import { useIdentityLinkWorkspace } from '../composables/useIdentityLinkWorkspace';
import { identityFederationUsageTracker } from '../../../usage-events.js';
import { useIdentityFederationI18n } from '../../../i18n.js';

const { t } = useIdentityFederationI18n();

const {
  actionMessage,
  applyFilters,
  candidates,
  changePage,
  changePageSize,
  employeeOptions,
  employeeSearchLoading,
  filterActive,
  filters,
  initialize,
  linkStatusOptions,
  linking,
  listError,
  listLoading,
  manualRow,
  manualVisible,
  openManual,
  page,
  pageSize,
  pageSizeOptions,
  pageSummary,
  pendingCount,
  resetFilters,
  searchEmployeeOptions,
  selectedEmployeeId,
  sourceOptions,
  submitAttributeLink,
  submitManualLink,
  submitUnlink,
  total,
} = useIdentityLinkWorkspace({ t });

const applyVisible = ref(false);
const applyMatchKey = ref<'PHONE' | 'EMAIL'>('PHONE');

const applyTitle = computed(() =>
  applyMatchKey.value === 'PHONE'
    ? t('module.identity-federation.identitylink.apply.phoneTitle')
    : t('module.identity-federation.identitylink.apply.emailTitle'),
);
const applyDescription = computed(() =>
  applyMatchKey.value === 'PHONE'
    ? t('module.identity-federation.identitylink.apply.phoneDesc')
    : t('module.identity-federation.identitylink.apply.emailDesc'),
);

function onFilterModelUpdate(next: {
  identitySourceId?: string;
  keyword?: string;
  linkStatus?: string;
}) {
  filters.identitySourceId = next?.identitySourceId ?? filters.identitySourceId;
  filters.keyword = next?.keyword ?? '';
  filters.linkStatus = next?.linkStatus ?? '';
}

function requestApply(matchKey: 'PHONE' | 'EMAIL') {
  applyMatchKey.value = matchKey;
  applyVisible.value = true;
}

async function confirmApply() {
  applyVisible.value = false;
  const ok = await submitAttributeLink(applyMatchKey.value);
  void identityFederationUsageTracker.trackActionResult('identitylink', 'attribute-link', ok ? 'SUCCESS' : 'FAILURE');
}

async function onManualConfirm() {
  const ok = await submitManualLink();
  void identityFederationUsageTracker.trackActionResult('identitylink', 'manual-link', ok ? 'SUCCESS' : 'FAILURE');
}

async function onUnlink(row: Parameters<typeof submitUnlink>[0]) {
  const ok = await submitUnlink(row);
  void identityFederationUsageTracker.trackActionResult('identitylink', 'unlink', ok ? 'SUCCESS' : 'FAILURE');
}

function goIdentitySync() {
  window.location.assign('/identity-federation/identity-sync');
}

onMounted(() => {
  void identityFederationUsageTracker.trackPage('identitylink');
  void initialize();
});
</script>

<template>
  <article class="identity-link-page" data-testid="identity-link-page">
    <BrickPageHeader
      :eyebrow="t('module.identity-federation.identitylink.page.eyebrow')"
      :title="t('module.identity-federation.identitylink.page.title')"
      :description="t('module.identity-federation.identitylink.page.description')"
    >
      <template #actions>
        <BrickListPageActions>
          <template #extra>
            <el-button
              type="primary"
              plain
              :loading="linking"
              :disabled="pendingCount === 0"
              data-testid="identity-link-email-apply"
              @click="requestApply('EMAIL')"
            >
              {{ t('module.identity-federation.identitylink.action.linkEmail') }}
            </el-button>
          </template>
          <template #primary>
            <el-button
              type="primary"
              :loading="linking"
              :disabled="pendingCount === 0"
              data-testid="identity-link-phone-apply"
              @click="requestApply('PHONE')"
            >
              {{ t('module.identity-federation.identitylink.action.linkPhone') }}
            </el-button>
          </template>
        </BrickListPageActions>
      </template>
    </BrickPageHeader>

    <IdentityLinkFilterToolbar
      :model-value="filters"
      :source-options="sourceOptions"
      :link-status-options="linkStatusOptions"
      @update:model-value="onFilterModelUpdate"
      @search="applyFilters"
      @reset="resetFilters"
    />

    <p v-if="listError" class="state-text state-error" data-testid="identity-link-error" role="alert">
      {{ listError }}
    </p>
    <p
      v-if="actionMessage"
      class="state-text panel-success"
      data-testid="identity-link-action-message"
      role="status"
    >
      {{ actionMessage }}
    </p>

    <IdentityLinkTablePanel
      :rows="candidates"
      :loading="listLoading"
      :linking="linking"
      :page="page"
      :page-size="pageSize"
      :page-size-options="pageSizeOptions"
      :page-summary="pageSummary"
      :total="total"
      :filter-active="filterActive"
      :has-source="Boolean(filters.identitySourceId)"
      @bind="openManual"
      @unlink="onUnlink"
      @go-sync="goIdentitySync"
      @update:page="changePage"
      @update:page-size="changePageSize"
    />

    <el-dialog
      v-model="manualVisible"
      :title="t('module.identity-federation.identitylink.dialog.title')"
      width="480px"
      destroy-on-close
      data-testid="identity-link-manual-dialog"
    >
      <!-- 上游身份只读说明：不是表单字段，避免与「本地员工」下拉并列成两套输入 -->
      <div v-if="manualRow" class="dialog-upstream" data-testid="identity-link-upstream-summary">
        <div class="dialog-upstream-label">{{ t('module.identity-federation.identitylink.dialog.upstreamLabel') }}</div>
        <div class="dialog-upstream-value">
          {{ manualRow.displayName || manualRow.externalUserId }}
          <span v-if="manualRow.mobile"> · {{ manualRow.mobile }}</span>
          <span v-if="manualRow.email"> · {{ manualRow.email }}</span>
        </div>
      </div>
      <el-form label-position="top">
        <el-form-item :label="t('module.identity-federation.identitylink.dialog.localEmployee')" required>
          <el-select
            v-model="selectedEmployeeId"
            filterable
            remote
            clearable
            reserve-keyword
            style="width: 100%"
            data-testid="identity-link-employee"
            :placeholder="t('module.identity-federation.identitylink.dialog.localEmployeePlaceholder')"
            :remote-method="searchEmployeeOptions"
            :loading="employeeSearchLoading"
          >
            <el-option
              v-for="item in employeeOptions"
              :key="item.employeeId"
              :label="`${item.employeeName || item.username}（${item.username || item.employeeId}）`"
              :value="item.employeeId"
            />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="manualVisible = false">{{ t('module.identity-federation.identitylink.action.cancel') }}</el-button>
        <el-button type="primary" :loading="linking" :disabled="!selectedEmployeeId" @click="onManualConfirm">
          {{ t('module.identity-federation.identitylink.action.confirmBind') }}
        </el-button>
      </template>
    </el-dialog>

    <BrickRiskConfirm
      v-model="applyVisible"
      :title="applyTitle"
      :description="applyDescription"
      :impact="[
        t('module.identity-federation.identitylink.apply.impactUnique'),
        t('module.identity-federation.identitylink.apply.impactSkip'),
      ]"
      :confirm-text="t('module.identity-federation.identitylink.action.confirmRun')"
      data-testid="identity-link-apply-confirm"
      @confirm="confirmApply"
    />
  </article>
</template>

<style scoped>
.identity-link-page {
  display: grid;
  gap: var(--console-page-gap, 18px);
  padding: 4px 0 12px;
  background: var(--console-page-bg);
}

.state-text {
  margin: 0;
  padding: var(--console-card-body-y, 18px) var(--console-card-body-x, 18px);
  border: 1px solid var(--console-card-border);
  border-radius: var(--console-card-radius, 8px);
  color: var(--console-text);
  background: var(--console-card-bg);
  box-shadow: var(--console-card-shadow, 0 1px 2px rgba(22, 67, 76, 0.04));
}

.state-error {
  color: var(--console-danger, #b4232f);
}

.panel-success {
  color: var(--console-primary, #188168);
  background: var(--console-accent-soft, rgba(24, 129, 104, 0.08));
}

.dialog-upstream {
  margin: 0 0 16px;
  padding: 10px 12px;
  border: 1px solid var(--console-card-border, var(--console-block-border));
  border-radius: var(--console-block-radius, 8px);
  /* Surfaces come from documentElement-projected --console-* (teleported dialogs inherit). */
  background: var(--console-block-bg, var(--console-card-bg));
  color: var(--console-text);
}

.dialog-upstream-label {
  margin-bottom: 4px;
  color: var(--console-muted);
  font-size: 12px;
}

.dialog-upstream-value {
  color: var(--console-title, var(--console-text));
  font-size: 14px;
  font-weight: 600;
}
</style>
