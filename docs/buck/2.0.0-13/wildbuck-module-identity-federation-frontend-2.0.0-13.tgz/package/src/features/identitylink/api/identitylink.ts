import {
  attributeIdentityLink,
  listIdentitySources,
  manualIdentityLink,
  searchIdentityLinkCandidates,
  unlinkIdentityLink,
} from '../../../generated/sdk';
import type {
  IdentityLinkAttributeRequest,
  IdentityLinkCandidateSearchRequest,
  IdentityLinkManualRequest,
  IdentityLinkUnlinkRequest,
  IdentitySourceSearchRequest,
} from '../../../generated/types';
import { searchEmployees as searchIamEmployees } from '../../../api/iam-master-data';
import type { EmployeeSearchRequest } from '../../../api/iam-master-data';

export function searchSources(request: IdentitySourceSearchRequest = { page: 1, size: 50 }) {
  return listIdentitySources(request);
}

export function searchCandidates(identitySourceId: string, request: IdentityLinkCandidateSearchRequest = {}) {
  return searchIdentityLinkCandidates(identitySourceId, request);
}

export function manualLink(identitySourceId: string, request: IdentityLinkManualRequest) {
  return manualIdentityLink(identitySourceId, request);
}

export function attributeLink(identitySourceId: string, request: IdentityLinkAttributeRequest) {
  return attributeIdentityLink(identitySourceId, request);
}

export function unlink(identitySourceId: string, request: IdentityLinkUnlinkRequest) {
  return unlinkIdentityLink(identitySourceId, request);
}

export function searchEmployees(request: EmployeeSearchRequest) {
  return searchIamEmployees(request);
}
