<script setup lang="ts">
import { computed, ref } from 'vue';
import { BrickPaginationBar, BrickRiskConfirm } from '@wildbuck/core-ui-frontend/patterns';
import type { IdentityLinkCandidate } from '../../../generated/types';
import { BrickTableActions as IamTableActions } from '@wildbuck/core-ui-frontend/patterns';
import { useIdentityFederationI18n } from '../../../i18n.js';

const { t } = useIdentityFederationI18n();

const props = defineProps<{
  rows: IdentityLinkCandidate[];
  loading: boolean;
  linking?: boolean;
  page: number;
  pageSize: number;
  pageSizeOptions: number[];
  pageSummary: string;
  total: number;
  filterActive?: boolean;
  hasSource?: boolean;
}>();

const emit = defineEmits<{
  bind: [row: IdentityLinkCandidate];
  unlink: [row: IdentityLinkCandidate];
  goSync: [];
  'update:page': [value: number];
  'update:pageSize': [value: number];
}>();

const unlinkVisible = ref(false);
const pendingUnlink = ref<IdentityLinkCandidate | null>(null);

const emptyText = computed(() => {
  if (props.loading) {
    return t('module.identity-federation.identitylink.empty.needSync');
  }
  if (!props.hasSource) {
    return t('module.identity-federation.identitylink.empty.noSource');
  }
  if (props.filterActive) {
    return t('module.identity-federation.identitylink.empty.filtered');
  }
  return t('module.identity-federation.identitylink.empty.needSync');
});

const headerMeta = computed(() => props.pageSummary);

const unlinkDescription = computed(() => {
  const name = pendingUnlink.value?.displayName
    || pendingUnlink.value?.externalUserId
    || t('module.identity-federation.identitylink.unlink.fallbackName');
  return t('module.identity-federation.identitylink.unlink.description', { name });
});

function displayText(value?: string | null) {
  const text = (value || '').trim();
  return text || '—';
}

function contactText(row: IdentityLinkCandidate) {
  const parts = [row.mobile, row.email].map((item) => (item || '').trim()).filter(Boolean);
  return parts.length ? parts.join(' · ') : '—';
}

function openUnlink(row: IdentityLinkCandidate) {
  pendingUnlink.value = row;
  unlinkVisible.value = true;
}

function confirmUnlink() {
  if (pendingUnlink.value) {
    emit('unlink', pendingUnlink.value);
  }
  pendingUnlink.value = null;
  unlinkVisible.value = false;
}
</script>

<template>
  <el-card shadow="never" class="iam-list-panel identity-link-table-panel" data-guide-anchor="list" data-testid="identity-link-table-panel">
    <template #header>
      <div class="iam-list-panel__header">
        <div>
          <h2>{{ t('module.identity-federation.identitylink.table.title') }}</h2>
          <p>{{ t('module.identity-federation.identitylink.route.summary') }}</p>
        </div>
        <span class="iam-list-panel__meta" data-testid="identity-link-list-meta">{{ headerMeta }}</span>
      </div>
    </template>

    <el-table
      v-if="rows.length > 0 || loading"
      v-loading="loading || linking"
      :data="rows"
      row-key="externalUserId"
      :empty-text="emptyText"
      data-testid="identity-link-table"
    >
      <el-table-column :label="t('module.identity-federation.identitylink.table.upstream')" min-width="160">
        <template #default="{ row }">
          <div class="iam-list-name">
            <div class="iam-list-name__copy">
              <strong>{{ displayText(row.displayName) }}</strong>
            </div>
          </div>
        </template>
      </el-table-column>
      <el-table-column :label="t('module.identity-federation.identitylink.table.contact')" min-width="180">
        <template #default="{ row }">{{ contactText(row) }}</template>
      </el-table-column>
      <el-table-column :label="t('module.identity-federation.identitylink.table.status')" width="100">
        <template #default="{ row }">
          <el-tag :type="row.linkStatus === 'LINKED' ? 'success' : 'warning'" effect="plain" size="small">
            {{
              row.linkStatus === 'LINKED'
                ? t('module.identity-federation.identitylink.filter.linked')
                : t('module.identity-federation.identitylink.filter.pending')
            }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column :label="t('module.identity-federation.identitylink.table.local')" min-width="160">
        <template #default="{ row }">
          <template v-if="row.linkStatus === 'LINKED'">
            {{ displayText(row.employeeName) }}
            <span v-if="row.username" class="identity-link-sub">（{{ row.username }}）</span>
          </template>
          <template v-else>—</template>
        </template>
      </el-table-column>
      <el-table-column :label="t('module.identity-federation.identitylink.table.actions')" width="120" fixed="right">
        <template #default="{ row }">
          <IamTableActions>
            <el-button
              v-if="row.linkable"
              link
              type="primary"
              data-testid="identity-link-manual"
              :disabled="Boolean(linking)"
              @click="emit('bind', row)"
            >
              {{ t('module.identity-federation.identitylink.action.bind') }}
            </el-button>
            <el-button
              v-if="row.unlinkable"
              link
              type="danger"
              data-testid="identity-link-unlink"
              :disabled="Boolean(linking)"
              @click="openUnlink(row)"
            >
              {{ t('module.identity-federation.common.unlinkShort') }}
            </el-button>
          </IamTableActions>
        </template>
      </el-table-column>
    </el-table>

    <div v-else class="identity-link-table-panel__empty" data-testid="identity-link-list-empty">
      <p>{{ emptyText }}</p>
      <el-button
        v-if="hasSource && !filterActive"
        type="primary"
        plain
        data-testid="identity-link-go-sync"
        @click="emit('goSync')"
      >
        {{ t('module.identity-federation.identitylink.action.openSync') }}
      </el-button>
    </div>

    <BrickPaginationBar
      v-if="rows.length > 0 || total > 0"
      :page="page"
      :page-size="pageSize"
      :page-sizes="pageSizeOptions"
      :summary="pageSummary"
      :total="total"
      @update:page="$emit('update:page', $event)"
      @update:page-size="$emit('update:pageSize', $event)"
    />

    <BrickRiskConfirm
      v-model="unlinkVisible"
      :title="t('module.identity-federation.identitylink.action.unbind')"
      :description="unlinkDescription"
      :impact="[
        t('module.identity-federation.identitylink.unlink.impact1'),
        t('module.identity-federation.identitylink.unlink.impact2'),
      ]"
      :confirm-text="t('module.identity-federation.identitylink.action.confirmUnbind')"
      data-testid="identity-link-unlink-confirm"
      @confirm="confirmUnlink"
      @cancel="pendingUnlink = null"
    />
  </el-card>
</template>

<style scoped>
@import "@wildbuck/core-ui-frontend/list-panel.css";

.identity-link-sub {
  color: var(--console-muted, #7e8ba0);
  font-size: 12px;
}

.identity-link-table-panel__empty {
  display: grid;
  gap: 12px;
  justify-items: start;
  padding: var(--console-card-body-y, 18px) var(--console-card-body-x, 18px);
  color: var(--console-muted, #7e8ba0);
  font-size: 13px;
}

.identity-link-table-panel__empty p {
  margin: 0;
}
</style>
