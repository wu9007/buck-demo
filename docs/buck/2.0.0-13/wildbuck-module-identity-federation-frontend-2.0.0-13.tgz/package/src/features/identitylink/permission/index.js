export const identitylinkPermissions = {
  view: 'identity-federation:identity-link:view',
  manage: 'identity-federation:identity-link:manage',
};
