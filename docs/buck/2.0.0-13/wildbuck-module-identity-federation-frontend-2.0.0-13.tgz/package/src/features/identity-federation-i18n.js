import { formatBrickI18nMessage, normalizeBrickLocale } from '@wildbuck/core-i18n-frontend';
import { useBrickConsoleI18n } from '@wildbuck/core-ui-frontend/i18n';
import {
  IDENTITY_FEDERATION_MESSAGES,
  IDENTITY_FEDERATION_MESSAGES_EN_US,
  IDENTITY_FEDERATION_MESSAGES_ZH_CN,
} from './identity-federation-i18n-messages.js';

/**
 * @param {unknown} locale
 * @returns {Readonly<Record<string, string>>}
 */
export function resolveIdentityFederationMessages(locale) {
  const normalized = normalizeBrickLocale(locale);
  return IDENTITY_FEDERATION_MESSAGES[normalized] ?? IDENTITY_FEDERATION_MESSAGES_ZH_CN;
}

/**
 * @param {unknown} runtime
 * @param {string} key
 * @param {Record<string, unknown>} [params]
 * @param {string} [fallbackLocale]
 */
export function translateIdentityFederation(runtime, key, params = {}, fallbackLocale = 'zh-CN') {
  const messageKey = String(key ?? '');
  if (!messageKey) {
    return '';
  }
  if (runtime && typeof runtime.t === 'function') {
    const resolved = runtime.t(messageKey, params);
    if (resolved != null && resolved !== '' && resolved !== messageKey) {
      return String(resolved);
    }
  }
  const locale = normalizeBrickLocale(
    typeof runtime?.getLocale === 'function' ? runtime.getLocale() : fallbackLocale,
    fallbackLocale,
  );
  const pack = resolveIdentityFederationMessages(locale);
  const template = pack[messageKey] ?? IDENTITY_FEDERATION_MESSAGES_ZH_CN[messageKey];
  if (typeof template === 'string') {
    return formatBrickI18nMessage(template, params);
  }
  return messageKey;
}

/**
 * Vue inject helper for identity-federation SFCs.
 * Tracks runtime revision so setLocale / registerMessages re-render templates that call t().
 */
export function useIdentityFederationI18n() {
  const { i18n, revision, locale, t: consoleT } = useBrickConsoleI18n();

  function t(key, params) {
    void revision.value;
    const fromRuntime = consoleT(key, params);
    if (fromRuntime != null && fromRuntime !== '' && fromRuntime !== key) {
      return fromRuntime;
    }
    return translateIdentityFederation(i18n, key, params, locale.value);
  }

  return {
    i18n,
    revision,
    locale,
    t,
  };
}

export {
  IDENTITY_FEDERATION_MESSAGES,
  IDENTITY_FEDERATION_MESSAGES_EN_US,
  IDENTITY_FEDERATION_MESSAGES_ZH_CN,
};
