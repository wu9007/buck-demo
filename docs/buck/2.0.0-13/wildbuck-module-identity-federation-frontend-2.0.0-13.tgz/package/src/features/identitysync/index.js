import { identitysyncPermissions } from './permission/index.js';
import { identitysyncRoutes } from './routes/index.js';

export const identitysyncFeature = {
  featureKey: 'identitysync',
  permissions: identitysyncPermissions,
  routes: identitysyncRoutes,
};

export { identitysyncPermissions, identitysyncRoutes };
