import {
  applyIdentitySync,
  checkIdentitySyncPrerequisites,
  disableIdentitySync,
  identitySyncPolicyDetail,
  identitySyncRunDetail,
  listIdentitySyncRuns,
  previewIdentitySync,
  updateIdentitySyncPolicy,
} from '../../../generated/sdk';
import type {
  IdentitySyncApplyRequest,
  IdentitySyncPreviewRequest,
  IdentitySyncRunSearchRequest,
  UpdateIdentitySyncPolicyRequest,
} from '../../../generated/types';

export function loadSyncPolicy(identitySourceId: string) {
  return identitySyncPolicyDetail(identitySourceId, undefined as void);
}

export function saveSyncPolicy(identitySourceId: string, request: UpdateIdentitySyncPolicyRequest) {
  return updateIdentitySyncPolicy(identitySourceId, request);
}

export function checkSyncPrerequisites(identitySourceId: string) {
  return checkIdentitySyncPrerequisites(identitySourceId, undefined as void);
}

export function previewSync(identitySourceId: string, request: IdentitySyncPreviewRequest = {}) {
  return previewIdentitySync(identitySourceId, request);
}

export function applySync(identitySourceId: string, request: IdentitySyncApplyRequest) {
  return applyIdentitySync(identitySourceId, request);
}

export function searchSyncRuns(identitySourceId: string, request: IdentitySyncRunSearchRequest = {}) {
  return listIdentitySyncRuns(identitySourceId, request);
}

export function loadSyncRun(identitySourceId: string, runId: string) {
  return identitySyncRunDetail(identitySourceId, runId, undefined as void);
}

export function disableSync(identitySourceId: string) {
  return disableIdentitySync(identitySourceId, undefined as void);
}
