<script setup lang="ts">
/**
 * 上游同步任务工作台（生产形态）
 * 流水线：上游通讯录 → 暂存表 → 按策略写入本系统主数据
 * - 配置：挂载组织 / 人员落库策略 / 时机
 * - 结果：预览与确认应用（部门挂到挂载点下；员工 CREATE 或 PENDING_LINK 待身份关联）
 * - 历史：同步运行记录
 */
import { computed, onMounted, reactive, ref, watch } from 'vue';
import {
  loadSyncPolicy,
  previewSync,
  applySync,
  saveSyncPolicy,
  searchSyncRuns,
} from '../api/identitysync';
import { resolveIdentitySyncError } from '../lib/identitysync-errors';
import { listOrganizations } from '../../../api/iam-master-data';
import type {
  IdentitySyncPolicyDetail,
  IdentitySyncRunDetail,
  IdentitySyncRunSummary,
} from '../../../generated/types';
import type { OrganizationTreeNode } from '../../../api/iam-master-data';
import { useIdentityFederationI18n } from '../../../i18n.js';

const { t } = useIdentityFederationI18n();

const props = withDefaults(
  defineProps<{
    identitySourceId: string;
    sourceDisplayName?: string;
    sourceType?: string;
    autoPreview?: boolean;
    initialTab?: 'config' | 'result' | 'history';
  }>(),
  {
    autoPreview: false,
    initialTab: 'config',
    sourceType: '',
  }
);

const emit = defineEmits<{ saved: [] }>();

const activeTab = ref<'config' | 'result' | 'history'>(props.initialTab || 'config');
const loading = ref(false);
const saving = ref(false);
const running = ref(false);
const historyLoading = ref(false);
const error = ref('');
const policy = ref<IdentitySyncPolicyDetail | null>(null);
const lastRun = ref<IdentitySyncRunDetail | null>(null);
const history = ref<IdentitySyncRunSummary[]>([]);
const applyConfirm = ref(false);
const orgOptions = ref<{ value: string; label: string }[]>([]);

const form = reactive({
  mountOrganizationId: 'org-root',
  missingUserPolicy: 'CREATE',
  displayNameConflict: 'FIRST_ONLY',
  leavePolicy: 'DISABLE_ACCOUNT',
  rootExternalDeptId: '1',
  scheduleMode: 'MANUAL' as 'MANUAL' | 'INTERVAL',
  scheduleIntervalMinutes: 60 as number,
});

const isDingTalk = computed(() => String(props.sourceType || policy.value?.sourceType || '').toUpperCase() === 'DINGTALK');

function flattenOrgs(nodes: OrganizationTreeNode[], prefix = ''): { value: string; label: string }[] {
  const out: { value: string; label: string }[] = [];
  for (const n of nodes || []) {
    const id = (n as any).organizationId || (n as any).id;
    const name = (n as any).organizationName || (n as any).name || id;
    const label = prefix ? `${prefix} / ${name}` : name;
    if (id) out.push({ value: id, label });
    const children = (n as any).children as OrganizationTreeNode[] | undefined;
    if (children?.length) out.push(...flattenOrgs(children, label));
  }
  return out;
}

function validateForm(): string {
  if (!String(form.mountOrganizationId || '').trim()) return t('module.identity-federation.identitysync.panel.mountOrgRequired');
  return '';
}

function policyPayload() {
  return {
    enabled: true,
    missingUserPolicy: form.missingUserPolicy,
    displayNameConflict: form.displayNameConflict,
    leavePolicy: form.leavePolicy,
    rootExternalDeptId: form.rootExternalDeptId,
    mountOrganizationId: form.mountOrganizationId,
    scheduleMode: form.scheduleMode,
    scheduleIntervalMinutes:
      form.scheduleMode === 'INTERVAL' ? Number(form.scheduleIntervalMinutes) || 60 : undefined,
  };
}

async function refresh() {
  if (!props.identitySourceId) return;
  loading.value = true;
  error.value = '';
  applyConfirm.value = false;
  try {
    const [p, orgs] = await Promise.all([
      loadSyncPolicy(props.identitySourceId),
      listOrganizations(),
    ]);
    policy.value = p;
    orgOptions.value = flattenOrgs(orgs || []);
    form.mountOrganizationId = p.mountOrganizationId || 'org-root';
    form.missingUserPolicy =
      p.missingUserPolicy === 'EXISTING_ONLY' ? 'EXISTING_ONLY' : 'CREATE';
    form.displayNameConflict = p.displayNameConflict || 'FIRST_ONLY';
    form.leavePolicy = p.leavePolicy || 'DISABLE_ACCOUNT';
    form.rootExternalDeptId = p.rootExternalDeptId || '1';
    form.scheduleMode = p.scheduleMode === 'INTERVAL' ? 'INTERVAL' : 'MANUAL';
    form.scheduleIntervalMinutes = p.scheduleIntervalMinutes || 60;
  } catch (e: unknown) {
    error.value = resolveIdentitySyncError(e, t('module.identity-federation.error.loadFailed'));
  } finally {
    loading.value = false;
  }
}

async function loadHistory() {
  if (!props.identitySourceId) return;
  historyLoading.value = true;
  try {
    const page = await searchSyncRuns(props.identitySourceId, { page: 1, size: 20 });
    history.value = page.records || [];
  } catch (e: unknown) {
    error.value = resolveIdentitySyncError(e, t('module.identity-federation.error.historyFailed'));
  } finally {
    historyLoading.value = false;
  }
}

async function onSave() {
  const msg = validateForm();
  if (msg) {
    error.value = msg;
    return;
  }
  saving.value = true;
  error.value = '';
  try {
    policy.value = await saveSyncPolicy(props.identitySourceId, policyPayload());
    emit('saved');
  } catch (e: unknown) {
    error.value = resolveIdentitySyncError(e, t('module.identity-federation.error.saveFailed'));
  } finally {
    saving.value = false;
  }
}

async function onPreview() {
  const msg = validateForm();
  if (msg) {
    error.value = msg;
    activeTab.value = 'config';
    return;
  }
  running.value = true;
  error.value = '';
  applyConfirm.value = false;
  activeTab.value = 'result';
  try {
    policy.value = await saveSyncPolicy(props.identitySourceId, policyPayload());
    lastRun.value = await previewSync(props.identitySourceId, {
      rootExternalDeptId: form.rootExternalDeptId,
    });
    if (lastRun.value.status === 'FAILED') {
      error.value = lastRun.value.errorMessage || t('module.identity-federation.error.previewFailed');
    } else if (lastRun.value.zeroResult) {
      error.value = t('module.identity-federation.identitysync.panel.zeroData');
    }
    await loadHistory();
  } catch (e: unknown) {
    error.value = resolveIdentitySyncError(e, t('module.identity-federation.error.previewFailed'));
  } finally {
    running.value = false;
  }
}

async function onApply() {
  if (!canApply.value || !lastRun.value) {
    error.value = t('module.identity-federation.identitysync.panel.previewFirst');
    activeTab.value = 'result';
    return;
  }
  if (!applyConfirm.value) {
    error.value = t('module.identity-federation.identitysync.panel.confirmWrite');
    return;
  }
  running.value = true;
  error.value = '';
  activeTab.value = 'result';
  try {
    lastRun.value = await applySync(props.identitySourceId, {
      confirm: true,
      previewRunId: lastRun.value.runId,
    });
    if (lastRun.value.status === 'FAILED') {
      error.value = lastRun.value.errorMessage || t('module.identity-federation.error.applyFailed');
    } else {
      emit('saved');
    }
    await loadHistory();
  } catch (e: unknown) {
    error.value = resolveIdentitySyncError(e, t('module.identity-federation.error.applyFailed'));
  } finally {
    running.value = false;
  }
}

const canApply = computed(() => {
  const r = lastRun.value;
  if (!r || r.mode !== 'PREVIEW') return false;
  if (r.status === 'FAILED' || r.zeroResult) return false;
  return r.status === 'SUCCEEDED';
});

/** 预览结果里待属性关联（不写员工表）的样例数 */
const pendingLinkCount = computed(() =>
  (lastRun.value?.samples || []).filter((s) => s.action === 'PENDING_LINK').length
);

const mountOrgLabel = computed(() => {
  const hit = orgOptions.value.find((o) => o.value === form.mountOrganizationId);
  return hit?.label || form.mountOrganizationId || '—';
});

const pipelineSummary = computed(() => {
  if (form.missingUserPolicy === 'EXISTING_ONLY') {
    return t('module.identity-federation.identitysync.panel.stageHint');
  }
  return t('module.identity-federation.identitysync.panel.createHint');
});

const runStatusLabel = computed(() => {
  const s = lastRun.value?.status;
  if (s === 'SUCCEEDED') return t('module.identity-federation.identitysync.health.ok');
  if (s === 'FAILED') return t('module.identity-federation.identitysync.health.failed');
  if (s === 'ZERO_RESULT') return t('module.identity-federation.identitysync.health.zeroCount');
  if (s === 'RUNNING') return t('module.identity-federation.identitysync.health.runningAlt');
  return s || '';
});

const permissionApplyUrl = computed(() => {
  for (const s of lastRun.value?.samples || []) {
    const detail = s.detail || '';
    const m = detail.match(/https:\/\/open-dev\.dingtalk\.com\/[^\s,\]\"']+/);
    if (m) return m[0];
  }
  return '';
});

function statusLabel(s?: string) {
  if (s === 'SUCCEEDED') return t('module.identity-federation.identitysync.health.ok');
  if (s === 'FAILED') return t('module.identity-federation.identitysync.health.failed');
  if (s === 'ZERO_RESULT') return t('module.identity-federation.identitysync.health.zeroCount');
  if (s === 'RUNNING') return t('module.identity-federation.identitysync.health.runningAlt');
  return s || '—';
}

function actionLabel(action?: string) {
  const map: Record<string, string> = {
    CREATE: t('module.identity-federation.identitysync.panel.changeCreate'),
    UPDATE: t('module.identity-federation.identitysync.panel.changeUpdate'),
    LINK: t('module.identity-federation.identitysync.panel.changeLink'),
    PENDING_LINK: t('module.identity-federation.identitysync.panel.changePendingLink'),
    MOUNT: t('module.identity-federation.identitysync.panel.changeMount'),
    DISABLE: t('module.identity-federation.identitysync.panel.changeDisable'),
    SKIP: t('module.identity-federation.identitysync.panel.changeSkip'),
    FAIL: t('module.identity-federation.identitysync.panel.changeFail'),
  };
  return map[action || ''] || action || '—';
}

function formatTime(v?: string) {
  if (!v) return '—';
  return String(v).replace('T', ' ').slice(0, 19);
}

async function bootstrap() {
  activeTab.value = props.initialTab || 'config';
  await refresh();
  await loadHistory();
  if (props.autoPreview && !error.value) {
    await onPreview();
  }
}

watch(
  () => props.identitySourceId,
  () => {
    void bootstrap();
  }
);

watch(
  () => props.initialTab,
  (t) => {
    if (t) activeTab.value = t;
  }
);

watch(
  () => props.autoPreview,
  (v) => {
    if (v && !loading.value && policy.value) {
      void onPreview();
    }
  }
);

onMounted(() => {
  void bootstrap();
});
</script>

<template>
  <div v-loading="loading" class="task-workbench" data-testid="identity-sync-panel">
    <el-alert
      v-if="error"
      type="error"
      :closable="false"
      :title="error"
      class="mb"
      data-testid="identity-sync-error"
    />

    <el-tabs v-model="activeTab" class="tabs" data-testid="identity-sync-tabs">
      <el-tab-pane :label="t('module.identity-federation.identitysync.panel.tab.config')" name="config">
        <el-form label-position="top" class="form" @submit.prevent="onSave">
          <div class="pipeline-strip" data-testid="sync-pipeline-strip">
            <div class="pipeline-title">{{ t('module.identity-federation.identitysync.panel.pipeline') }}</div>
            <ol class="pipeline-steps">
              <li>{{ t('module.identity-federation.identitysync.panel.pipelinePull') }}</li>
              <li>{{ t('module.identity-federation.identitysync.panel.pipelineStage') }}</li>
              <li>{{ t('module.identity-federation.identitysync.panel.pipelineApply') }}</li>
            </ol>
            <div class="pipeline-hint">
              {{ t('module.identity-federation.identitysync.panel.pipelineOrgHint') }}
              {{ pipelineSummary }}
            </div>
          </div>

          <div v-if="isDingTalk" class="builtin-api" data-testid="dingtalk-builtin-api">
            <div class="builtin-title">{{ t('module.identity-federation.identitysync.panel.dingtalkTitle') }}</div>
            <div class="builtin-body">{{ t('module.identity-federation.identitysync.panel.dingtalkBody') }}</div>
          </div>
          <el-alert
            v-else
            type="warning"
            :closable="false"
            :title="t('module.identity-federation.identitysync.panel.unsupported')"
            class="mb"
          />

          <el-form-item :label="t('module.identity-federation.identitysync.panel.mountOrg')" required>
            <el-select
              v-model="form.mountOrganizationId"
              filterable
              style="width: 100%"
              data-testid="sync-mount-org"
            >
              <el-option
                v-for="o in orgOptions"
                :key="o.value"
                :label="o.label"
                :value="o.value"
              />
            </el-select>
            <div class="field-hint">
              {{ t('module.identity-federation.identitysync.panel.mountOrgHint', { mount: mountOrgLabel }) }}
            </div>
          </el-form-item>

          <el-form-item :label="t('module.identity-federation.identitysync.panel.userPolicy')" required>
            <el-radio-group v-model="form.missingUserPolicy" data-testid="sync-missing-policy">
              <el-radio-button value="CREATE">{{ t('module.identity-federation.identitysync.panel.userPolicyCreate') }}</el-radio-button>
              <el-radio-button value="EXISTING_ONLY">{{ t('module.identity-federation.identitysync.panel.userPolicyStage') }}</el-radio-button>
            </el-radio-group>
            <div class="field-hint">
              <template v-if="form.missingUserPolicy === 'CREATE'">
                {{ t('module.identity-federation.identitysync.panel.createHint') }}
              </template>
              <template v-else>
                {{ t('module.identity-federation.identitysync.panel.stageHint') }}
              </template>
            </div>
          </el-form-item>

          <el-form-item :label="t('module.identity-federation.identitysync.panel.scheduleMode')" required>
            <el-radio-group v-model="form.scheduleMode" data-testid="sync-timing">
              <el-radio-button value="MANUAL">{{ t('module.identity-federation.identitysync.schedule.manual') }}</el-radio-button>
              <el-radio-button value="INTERVAL">{{ t('module.identity-federation.identitysync.schedule.interval') }}</el-radio-button>
            </el-radio-group>
            <div class="field-hint">
              {{ t('module.identity-federation.identitysync.panel.scheduleHint') }}
            </div>
          </el-form-item>

          <el-form-item v-if="form.scheduleMode === 'INTERVAL'" :label="t('module.identity-federation.identitysync.panel.scheduleInterval')" required>
            <el-select
              v-model="form.scheduleIntervalMinutes"
              style="width: 220px"
              data-testid="sync-interval"
            >
              <el-option :value="15" :label="t('module.identity-federation.identitysync.panel.interval15')" />
              <el-option :value="30" :label="t('module.identity-federation.identitysync.panel.interval30')" />
              <el-option :value="60" :label="t('module.identity-federation.identitysync.panel.interval60')" />
              <el-option :value="360" :label="t('module.identity-federation.identitysync.panel.interval360')" />
              <el-option :value="1440" :label="t('module.identity-federation.identitysync.panel.interval1440')" />
            </el-select>
            <div v-if="policy?.nextScheduledAt" class="field-hint" data-testid="sync-next-run">
              {{ t('module.identity-federation.identitysync.panel.nextRun', { time: formatTime(policy.nextScheduledAt) }) }}
            </div>
            <div v-else class="field-hint">{{ t('module.identity-federation.identitysync.panel.scheduleAfterSave') }}</div>
          </el-form-item>

          <div class="actions">
            <el-button type="primary" :loading="saving" data-testid="sync-save" @click="onSave">
              {{ t('module.identity-federation.identitysync.action.saveTask') }}
            </el-button>
            <el-button :loading="running" data-testid="identity-sync-preview" @click="onPreview">
              {{ t('module.identity-federation.identitysync.panel.preview') }}
            </el-button>
          </div>
        </el-form>
      </el-tab-pane>

      <el-tab-pane :label="t('module.identity-federation.identitysync.panel.tab.result')" name="result">
        <div v-loading="running" class="result-pane" data-testid="last-sync-run">
          <div v-if="!lastRun" class="empty">{{ t('module.identity-federation.identitysync.panel.neverRun') }}</div>
          <template v-else>
            <div class="result-head">
              <span class="result-status" :data-status="lastRun.status">{{ runStatusLabel }}</span>
              <span class="result-mode">{{ lastRun.mode === 'APPLY' ? t('module.identity-federation.identitysync.panel.modeApplyMaster') : t('module.identity-federation.identitysync.panel.modePreviewStaged') }}</span>
              <span class="result-time">{{ formatTime(lastRun.finishedAt || lastRun.startedAt) }}</span>
            </div>
            <div class="result-counts">
              {{ t('module.identity-federation.identitysync.panel.resultCounts', {
                dept: lastRun.departmentCount,
                user: lastRun.userCount,
                orgCreate: lastRun.orgCreateCount,
                create: lastRun.createCount,
                update: lastRun.updateCount,
                skip: lastRun.skipCount,
                fail: lastRun.failCount,
              }) }}
            </div>
            <div v-if="pendingLinkCount > 0" class="pending-box" data-testid="pending-link-hint">
              {{ t('module.identity-federation.identitysync.panel.pendingLinkHint', { count: pendingLinkCount }) }}
            </div>

            <div v-if="lastRun.status === 'FAILED'" class="fail-box" data-testid="identity-sync-fail-detail">
              <div v-if="lastRun.errorMessage" class="fail-msg">{{ lastRun.errorMessage }}</div>
              <div v-if="lastRun.errorRecovery" class="fail-recovery">{{ lastRun.errorRecovery }}</div>
              <ul v-if="lastRun.checklist?.length" class="fail-list">
                <li v-for="(c, i) in lastRun.checklist" :key="i">{{ c }}</li>
              </ul>
              <div v-if="lastRun.samples?.length" class="fail-samples">
                <div v-for="(s, i) in lastRun.samples.slice(0, 4)" :key="i" class="fail-sample">
                  {{ s.detail || s.displayName || s.action }}
                </div>
              </div>
              <a
                v-if="permissionApplyUrl"
                class="fail-link"
                :href="permissionApplyUrl"
                target="_blank"
                rel="noopener noreferrer"
                data-testid="dingtalk-permission-apply-link"
              >
                {{ t('module.identity-federation.identitysync.panel.openDingPerm') }}
              </a>
            </div>

            <div v-else-if="lastRun.checklist?.length" class="checklist-box" data-testid="sync-checklist">
              <div class="sample-title">{{ t('module.identity-federation.identitysync.panel.execNotes') }}</div>
              <ul class="checklist">
                <li v-for="(c, i) in lastRun.checklist" :key="i">{{ c }}</li>
              </ul>
            </div>

            <div v-if="lastRun.samples?.length && lastRun.status !== 'FAILED'" class="sample-box">
              <div class="sample-title">{{ t('module.identity-federation.identitysync.panel.sample') }}</div>
              <div v-for="(s, i) in lastRun.samples.slice(0, 12)" :key="i" class="sample-row">
                <span class="sample-tag" :data-action="s.action">{{ actionLabel(s.action) }}</span>
                <span>{{ s.displayName || s.externalId || s.kind }}</span>
                <span class="sample-detail">{{ s.detail }}</span>
              </div>
            </div>

            <div v-if="canApply" class="apply-row">
              <el-checkbox v-model="applyConfirm" data-testid="identity-sync-confirm">
                {{ t('module.identity-federation.identitysync.panel.applyConfirm', { mount: mountOrgLabel }) }}
              </el-checkbox>
              <el-button
                type="primary"
                :loading="running"
                :disabled="!applyConfirm"
                data-testid="identity-sync-apply"
                @click="onApply"
              >
                {{ t('module.identity-federation.identitysync.panel.apply') }}
              </el-button>
            </div>
          </template>
        </div>
      </el-tab-pane>

      <el-tab-pane :label="t('module.identity-federation.identitysync.panel.tab.history')" name="history">
        <div v-loading="historyLoading" class="history-pane" data-testid="identity-sync-history">
          <div v-if="!history.length" class="empty">{{ t('module.identity-federation.identitysync.panel.historyEmpty') }}</div>
          <div v-else class="history-list">
            <div v-for="h in history" :key="h.runId" class="history-item">
              <div class="history-top">
                <span class="result-status" :data-status="h.status">{{ statusLabel(h.status) }}</span>
                <span class="result-mode">{{ h.mode === 'APPLY' ? t('module.identity-federation.identitysync.panel.mode.apply') : t('module.identity-federation.identitysync.panel.mode.preview') }}</span>
                <span class="result-time">{{ formatTime(h.finishedAt || h.startedAt) }}</span>
              </div>
              <div class="history-counts">
                {{ t('module.identity-federation.identitysync.panel.historyCounts', {
                  dept: h.departmentCount,
                  user: h.userCount,
                  create: h.createCount + h.orgCreateCount,
                  fail: h.failCount,
                }) }}
              </div>
              <div v-if="h.errorMessage" class="history-err">{{ h.errorMessage }}</div>
            </div>
          </div>
        </div>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<style scoped>
.task-workbench {
  padding-top: 0;
  color: var(--console-text);
}
.mb {
  margin-bottom: 12px;
}
.tabs :deep(.el-tabs__header) {
  margin-bottom: 14px;
}
.form :deep(.el-form-item) {
  margin-bottom: 16px;
}
.form :deep(.el-form-item__label) {
  font-weight: 500;
  color: var(--console-text);
}
.field-hint {
  margin-top: 6px;
  font-size: 12px;
  line-height: 1.45;
  color: var(--console-muted);
}
.pipeline-strip {
  margin-bottom: 16px;
  padding: 12px 14px;
  border-radius: 8px;
  background: var(--console-block-bg, var(--console-card-bg));
  border: 1px solid var(--console-card-border, var(--console-block-border));
}
.pipeline-title {
  font-weight: 600;
  font-size: 13px;
  color: var(--console-title, var(--console-text));
  margin-bottom: 6px;
}
.pipeline-steps {
  margin: 0 0 8px;
  padding-left: 18px;
  font-size: 12px;
  color: var(--console-text);
  line-height: 1.55;
}
.pipeline-hint {
  font-size: 12px;
  line-height: 1.5;
  color: var(--console-muted);
}
.pending-box {
  margin-top: 10px;
  padding: 10px 12px;
  border-radius: 8px;
  background: color-mix(in srgb, var(--console-warning) 16%, var(--console-block-bg, var(--console-card-bg)));
  border: 1px solid color-mix(in srgb, var(--console-warning) 40%, var(--console-card-border));
  color: var(--console-warning);
  font-size: 12px;
  line-height: 1.45;
}
.checklist-box {
  margin-top: 12px;
  border: 1px solid var(--console-card-border);
  border-radius: 8px;
  padding: 10px 12px;
  background: var(--console-card-bg);
}
.checklist {
  margin: 0;
  padding-left: 18px;
  font-size: 12px;
  line-height: 1.55;
  color: var(--console-text);
}
.sample-tag[data-action='PENDING_LINK'] {
  color: var(--console-warning);
}
.sample-tag[data-action='MOUNT'] {
  color: var(--console-primary);
}
.sample-tag[data-action='CREATE'] {
  color: var(--console-success);
}
.sample-tag[data-action='FAIL'] {
  color: var(--console-danger);
}
.builtin-api {
  margin-bottom: 16px;
  padding: 12px 14px;
  border-radius: 8px;
  background: color-mix(in srgb, var(--console-primary) 12%, var(--console-block-bg, var(--console-card-bg)));
  border: 1px solid color-mix(in srgb, var(--console-primary) 35%, var(--console-card-border));
}
.builtin-title {
  font-weight: 600;
  font-size: 13px;
  color: var(--console-title, var(--console-primary));
  margin-bottom: 4px;
}
.builtin-body {
  font-size: 12px;
  color: var(--console-text);
  line-height: 1.45;
}
.actions {
  display: flex;
  gap: 8px;
  margin-top: 4px;
}
.empty {
  padding: 28px 8px;
  text-align: center;
  color: var(--console-muted);
  font-size: 13px;
}
.result-pane,
.history-pane {
  min-height: 160px;
}
.result-head,
.history-top {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
  flex-wrap: wrap;
}
.result-status {
  display: inline-flex;
  align-items: center;
  height: 22px;
  padding: 0 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 600;
  background: var(--console-block-bg);
  color: var(--console-text);
}
.result-status[data-status='SUCCEEDED'] {
  background: color-mix(in srgb, var(--console-success) 22%, var(--console-block-bg));
  color: var(--console-success);
}
.result-status[data-status='FAILED'] {
  background: color-mix(in srgb, var(--console-danger) 22%, var(--console-block-bg));
  color: var(--console-danger);
}
.result-status[data-status='ZERO_RESULT'] {
  background: color-mix(in srgb, var(--console-warning) 22%, var(--console-block-bg));
  color: var(--console-warning);
}
.result-mode,
.result-time {
  font-size: 12px;
  color: var(--console-muted);
}
.result-counts,
.history-counts {
  font-size: 13px;
  line-height: 1.5;
  color: var(--console-text);
}
.fail-box {
  margin-top: 12px;
  padding: 12px;
  border-radius: 8px;
  background: color-mix(in srgb, var(--console-danger) 14%, var(--console-block-bg, var(--console-card-bg)));
  border: 1px solid color-mix(in srgb, var(--console-danger) 40%, var(--console-card-border));
  color: var(--console-danger);
}
.fail-msg {
  font-weight: 600;
  margin-bottom: 6px;
}
.fail-recovery {
  margin-bottom: 8px;
  line-height: 1.45;
  color: var(--console-text);
}
.fail-list {
  margin: 0 0 8px;
  padding-left: 18px;
  color: var(--console-text);
}
.fail-samples,
.fail-sample {
  font-size: 12px;
  word-break: break-all;
}
.fail-link {
  display: inline-block;
  margin-top: 10px;
  color: var(--console-primary);
  font-weight: 600;
  text-decoration: none;
}
.fail-link:hover {
  text-decoration: underline;
}
.sample-box {
  margin-top: 12px;
  border: 1px solid var(--console-card-border);
  border-radius: 8px;
  padding: 10px 12px;
  background: var(--console-card-bg);
}
.sample-title {
  font-weight: 600;
  font-size: 13px;
  margin-bottom: 8px;
  color: var(--console-title, var(--console-text));
}
.sample-row {
  display: grid;
  grid-template-columns: 64px 1fr;
  gap: 6px 10px;
  font-size: 12px;
  padding: 4px 0;
  border-top: 1px solid var(--console-card-border);
  color: var(--console-text);
}
.sample-tag {
  color: var(--console-primary);
  font-weight: 600;
}
.sample-detail {
  grid-column: 1 / -1;
  color: var(--console-muted);
}
.apply-row {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-top: 14px;
  flex-wrap: wrap;
}
.history-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.history-item {
  border: 1px solid var(--console-card-border);
  border-radius: 8px;
  padding: 10px 12px;
  background: var(--console-block-bg, var(--console-card-bg));
}
.history-err {
  margin-top: 6px;
  font-size: 12px;
  color: var(--console-danger);
}
</style>
