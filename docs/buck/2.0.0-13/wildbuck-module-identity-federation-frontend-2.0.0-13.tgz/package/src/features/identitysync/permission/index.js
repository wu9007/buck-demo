export const identitysyncPermissions = {
  view: 'identity-federation:identity-sync:view',
  execute: 'identity-federation:identity-sync:execute',
  configure: 'identity-federation:identity-sync:configure',
};
