<script setup lang="ts">
/**
 * 身份同步中心（生产任务画布）
 *
 * 对标 Authing 同步中心运营心智：
 * - 三列拓扑：上游 → 本系统主数据 → 下游
 * - 画布说明与任务卡分层，标签不压卡片
 * - 空态连线几何中心对齐；任务卡黄金比例 + 图标操作
 */
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { Delete, Plus, VideoPlay } from '@element-plus/icons-vue';
import { BrickPageHeader, BrickRiskConfirm } from '@wildbuck/core-ui-frontend/patterns';
import { BrickConsoleDrawer } from '@wildbuck/core-ui-frontend/shell';
import { listIdentitySources } from '../../../generated/sdk';
import type {
  IdentitySourceSummary,
  IdentitySyncPolicyDetail,
  IdentitySyncRunSummary,
} from '../../../generated/types';
import { disableSync, loadSyncPolicy, searchSyncRuns } from '../api/identitysync';
import IdentitySyncPanel from '../components/IdentitySyncPanel.vue';
import { resolveIdentitySyncError } from '../lib/identitysync-errors';
import { consumeIdentitySyncDeepLinkSourceId } from '../lib/identitysync-deeplink';
import { useIdentityFederationI18n } from '../../../i18n.js';

const { t } = useIdentityFederationI18n();

type RunHealth = 'never' | 'ok' | 'failed' | 'zero' | 'running';

type UpstreamNode = {
  identitySourceId: string;
  displayName: string;
  sourceType: string;
  lastRunLabel: string;
  health: RunHealth;
  healthLabel: string;
  lastError?: string;
  deptCount?: number;
  userCount?: number;
  secretConfigured: boolean;
  supported: boolean;
  /** MANUAL | INTERVAL */
  scheduleMode: string;
};

type FlowWire = {
  id: string;
  d: string;
  active: boolean;
  kind: 'up' | 'down';
};

type Pt = { x: number; y: number; halfW: number; halfH: number };

const TYPE_LABEL: Record<string, string> = {
  DINGTALK: '钉',
  OAUTH2: 'O2',
  CAS: 'CA',
  GITHUB: 'GH',
  AD_LDAP: 'AD',
  WECOM: '企',
};

const TYPE_NAME: Record<string, string> = {
  DINGTALK: '钉钉',
  OAUTH2: 'OAuth2',
  GITHUB: 'GitHub',
  AD_LDAP: 'AD/LDAP',
  WECOM: '企业微信',
};

const loading = ref(false);
const listError = ref('');
const allSources = ref<IdentitySourceSummary[]>([]);
const upstreamNodes = ref<UpstreamNode[]>([]);

const pickerOpen = ref(false);
const taskOpen = ref(false);
const activeSourceId = ref<string | null>(null);
const activeSourceName = ref('');
const activeSourceType = ref('');
const isNewTask = ref(false);
const autoPreview = ref(false);
const initialTab = ref<'config' | 'result' | 'history'>('config');
const deletingId = ref<string | null>(null);
const runningId = ref<string | null>(null);
const riskDeleteOpen = ref(false);
const pendingDelete = ref<UpstreamNode | null>(null);

const stageRef = ref<HTMLElement | null>(null);
const hubRef = ref<HTMLElement | null>(null);
const upNodeRefs = ref<Record<string, HTMLElement | null>>({});
const upPlusRef = ref<HTMLElement | null>(null);
const downPlusRef = ref<HTMLElement | null>(null);
const wires = ref<FlowWire[]>([]);

const sourceCandidates = computed(() => {
  const onGraph = new Set(upstreamNodes.value.map((n) => n.identitySourceId));
  return allSources.value.filter((s) => !onGraph.has(s.identitySourceId));
});

const taskCountLabel = computed(() => {
  const n = upstreamNodes.value.length;
  if (n === 0) return t('module.identity-federation.identitysync.empty.noTasks');
  const failed = upstreamNodes.value.filter((x) => x.health === 'failed').length;
  if (failed > 0) {
    return t('module.identity-federation.identitysync.tasks.summaryFailed', { n, failed });
  }
  return t('module.identity-federation.identitysync.tasks.summaryOk', { n });
});

function typeKey(raw?: string) {
  return String(raw || '').toUpperCase();
}

function typeAbbr(raw?: string) {
  const k = typeKey(raw);
  return TYPE_LABEL[k] || (k ? k.slice(0, 2) : '?');
}

function typeDisplayName(raw?: string) {
  const k = typeKey(raw);
  return TYPE_NAME[k] || raw || t('module.identity-federation.menu.authsource');
}

function healthFromRun(top?: IdentitySyncRunSummary | null): {
  health: RunHealth;
  healthLabel: string;
  lastError?: string;
} {
  if (!top) {
    return {
      health: 'never',
      healthLabel: t('module.identity-federation.identitysync.health.never'),
    };
  }
  if (top.status === 'FAILED') {
    return {
      health: 'failed',
      healthLabel: t('module.identity-federation.identitysync.health.failed'),
      lastError: top.errorMessage || t('module.identity-federation.identitysync.health.lastFailed'),
    };
  }
  if (top.status === 'ZERO_RESULT' || top.zeroResult) {
    return {
      health: 'zero',
      healthLabel: t('module.identity-federation.identitysync.health.zeroCount'),
    };
  }
  if (top.status === 'RUNNING') {
    return {
      health: 'running',
      healthLabel: t('module.identity-federation.identitysync.health.runningAlt'),
    };
  }
  if (top.status === 'SUCCEEDED') {
    return {
      health: 'ok',
      healthLabel: t('module.identity-federation.identitysync.health.okAlt'),
    };
  }
  return {
    health: 'never',
    healthLabel: top.status || t('module.identity-federation.identitysync.health.never'),
  };
}

function setUpNodeRef(id: string, el: unknown) {
  if (el && (el as HTMLElement).getBoundingClientRect) {
    upNodeRefs.value[id] = el as HTMLElement;
  } else {
    delete upNodeRefs.value[id];
  }
}

function centerOf(el: HTMLElement | null, stage: HTMLElement): Pt | null {
  if (!el) return null;
  const c = stage.getBoundingClientRect();
  const r = el.getBoundingClientRect();
  return {
    x: r.left - c.left + r.width / 2,
    y: r.top - c.top + r.height / 2,
    halfW: r.width / 2,
    halfH: r.height / 2,
  };
}

/** 水平中心出线 → 对方中心入线；同高时为直线，否则正交折线 */
function orthogonalPath(from: Pt, to: Pt, pad = 6): string {
  const x1 = from.x + from.halfW + pad;
  const y1 = from.y;
  const x2 = to.x - to.halfW - pad;
  const y2 = to.y;
  if (Math.abs(y1 - y2) < 2) {
    return `M ${x1.toFixed(1)} ${y1.toFixed(1)} L ${x2.toFixed(1)} ${y2.toFixed(1)}`;
  }
  const midX = (x1 + x2) / 2;
  return `M ${x1.toFixed(1)} ${y1.toFixed(1)} L ${midX.toFixed(1)} ${y1.toFixed(1)} L ${midX.toFixed(1)} ${y2.toFixed(1)} L ${x2.toFixed(1)} ${y2.toFixed(1)}`;
}

function recomputeWires() {
  const stage = stageRef.value;
  const hub = hubRef.value;
  if (!stage || !hub) {
    wires.value = [];
    return;
  }
  const hubPt = centerOf(hub, stage);
  if (!hubPt) {
    wires.value = [];
    return;
  }
  const next: FlowWire[] = [];
  for (const node of upstreamNodes.value) {
    const el = upNodeRefs.value[node.identitySourceId];
    const pt = centerOf(el, stage);
    if (!pt) continue;
    next.push({
      id: `up-${node.identitySourceId}`,
      d: orthogonalPath(pt, hubPt),
      active: true,
      kind: 'up',
    });
  }
  if (!upstreamNodes.value.length) {
    const plusPt = centerOf(upPlusRef.value, stage);
    if (plusPt) {
      next.push({
        id: 'up-plus',
        d: orthogonalPath(plusPt, hubPt),
        active: false,
        kind: 'up',
      });
    }
  }
  const downPt = centerOf(downPlusRef.value, stage);
  if (downPt) {
    next.push({
      id: 'down-plus',
      d: orthogonalPath(hubPt, downPt),
      active: false,
      kind: 'down',
    });
  }
  wires.value = next;
}

let resizeObserver: ResizeObserver | null = null;

function scheduleWireUpdate() {
  void nextTick(() => {
    requestAnimationFrame(() => recomputeWires());
  });
}

async function initialize() {
  loading.value = true;
  listError.value = '';
  try {
    const page = await listIdentitySources({ page: 1, size: 100, keyword: '', empty: true });
    allSources.value = page.records || [];
    await rebuildUpstreamNodes();
    openDeepLinkedSource();
    scheduleWireUpdate();
  } catch (e: unknown) {
    listError.value = resolveIdentitySyncError(e, t('module.identity-federation.error.loadFailed'));
  } finally {
    loading.value = false;
    scheduleWireUpdate();
  }
}

function openDeepLinkedSource() {
  const sourceId = consumeIdentitySyncDeepLinkSourceId();
  if (!sourceId) return;
  const src = allSources.value.find((s) => s.identitySourceId === sourceId);
  if (!src) return;
  openTask(
    src.identitySourceId,
    src.displayName || typeDisplayName(src.sourceType),
    typeKey(src.sourceType),
    !upstreamNodes.value.some((n) => n.identitySourceId === sourceId),
    false,
    'config'
  );
}

async function rebuildUpstreamNodes() {
  const nodes: UpstreamNode[] = [];
  for (const src of allSources.value) {
    try {
      const policy: IdentitySyncPolicyDetail = await loadSyncPolicy(src.identitySourceId);
      if (!policy.policyId || policy.enabled === false) continue;
      let lastRunLabel = '—';
      let top: IdentitySyncRunSummary | undefined;
      try {
        const runs = await searchSyncRuns(src.identitySourceId, { page: 1, size: 1 });
        top = runs.records?.[0];
        if (top?.startedAt) {
          lastRunLabel = String(top.startedAt).replace('T', ' ').slice(0, 19);
        } else if (policy.lastAppliedAt) {
          lastRunLabel = String(policy.lastAppliedAt).replace('T', ' ').slice(0, 19);
        }
      } catch {
        /* ignore */
      }
      const h = healthFromRun(top);
      nodes.push({
        identitySourceId: src.identitySourceId,
        displayName: src.displayName || policy.sourceDisplayName || typeDisplayName(src.sourceType),
        sourceType: typeKey(src.sourceType || policy.sourceType),
        lastRunLabel,
        health: h.health,
        healthLabel: h.healthLabel,
        lastError: h.lastError,
        deptCount: top?.departmentCount,
        userCount: top?.userCount,
        secretConfigured: !!policy.secretConfigured,
        supported: !!policy.supported,
        scheduleMode: policy.scheduleMode === 'INTERVAL' ? 'INTERVAL' : 'MANUAL',
      });
    } catch {
      /* skip */
    }
  }
  upstreamNodes.value = nodes;
  scheduleWireUpdate();
}

function openPicker() {
  pickerOpen.value = true;
}

function selectIdentitySource(src: IdentitySourceSummary) {
  pickerOpen.value = false;
  openTask(
    src.identitySourceId,
    src.displayName || typeDisplayName(src.sourceType),
    typeKey(src.sourceType),
    true,
    false,
    'config'
  );
}

function openUpstreamTask(node: UpstreamNode) {
  openTask(node.identitySourceId, node.displayName, node.sourceType, false, false, 'config');
}

function runUpstream(node: UpstreamNode, ev: Event) {
  ev.stopPropagation();
  runningId.value = node.identitySourceId;
  openTask(node.identitySourceId, node.displayName, node.sourceType, false, true, 'result');
  window.setTimeout(() => {
    if (runningId.value === node.identitySourceId) runningId.value = null;
  }, 1500);
}

function openTask(
  id: string,
  name: string,
  sourceType: string,
  isNew: boolean,
  preview: boolean,
  tab: 'config' | 'result' | 'history'
) {
  activeSourceId.value = id;
  activeSourceName.value = name;
  activeSourceType.value = sourceType;
  isNewTask.value = isNew;
  autoPreview.value = preview;
  initialTab.value = tab;
  taskOpen.value = true;
}

async function onTaskSaved() {
  await rebuildUpstreamNodes();
  isNewTask.value = false;
  if (!autoPreview.value) {
    taskOpen.value = false;
  }
  scheduleWireUpdate();
}

async function onTaskDrawerClosed() {
  activeSourceId.value = null;
  activeSourceName.value = '';
  activeSourceType.value = '';
  autoPreview.value = false;
  runningId.value = null;
  initialTab.value = 'config';
  await rebuildUpstreamNodes();
  scheduleWireUpdate();
}

function askRemoveUpstream(node: UpstreamNode, ev: Event) {
  ev.stopPropagation();
  pendingDelete.value = node;
  riskDeleteOpen.value = true;
}

function cancelRemoveUpstream() {
  pendingDelete.value = null;
  riskDeleteOpen.value = false;
}

async function confirmRemoveUpstream() {
  const node = pendingDelete.value;
  riskDeleteOpen.value = false;
  pendingDelete.value = null;
  if (!node) return;
  deletingId.value = node.identitySourceId;
  listError.value = '';
  try {
    await disableSync(node.identitySourceId);
    await rebuildUpstreamNodes();
    if (activeSourceId.value === node.identitySourceId) {
      taskOpen.value = false;
    }
  } catch (e: unknown) {
    listError.value = resolveIdentitySyncError(e, t('module.identity-federation.error.deleteFailed'));
  } finally {
    deletingId.value = null;
    scheduleWireUpdate();
  }
}

const taskTitle = computed(() =>
  isNewTask.value
    ? t('module.identity-federation.identitysync.action.newTask')
    : t('module.identity-federation.identitysync.action.taskTitle', {
        name: activeSourceName.value || t('module.identity-federation.identitysync.label.upstream'),
      })
);

watch(upstreamNodes, () => scheduleWireUpdate(), { deep: true });
watch([pickerOpen, taskOpen], () => scheduleWireUpdate());

onMounted(() => {
  void initialize();
  window.addEventListener('resize', scheduleWireUpdate);
  resizeObserver = new ResizeObserver(() => scheduleWireUpdate());
  void nextTick(() => {
    if (stageRef.value) resizeObserver?.observe(stageRef.value);
  });
});

onBeforeUnmount(() => {
  window.removeEventListener('resize', scheduleWireUpdate);
  resizeObserver?.disconnect();
  resizeObserver = null;
});
</script>

<template>
  <div class="sync-center" data-testid="identity-sync-center" data-guide-anchor="topology">
    <BrickPageHeader :title="t('module.identity-federation.identitysync.page.title')" :description="taskCountLabel" />
    <p v-if="listError" class="page-error">{{ listError }}</p>

    <div v-loading="loading" class="sync-canvas" data-testid="identity-sync-topology">
      <!-- 列标题独立在画布顶栏，绝不叠在任务卡上 -->
      <div class="canvas-header" aria-hidden="true">
        <span class="lane-title">{{ t('module.identity-federation.identitysync.lane.upstream') }}</span>
        <span class="lane-title">{{ t('module.identity-federation.identitysync.lane.hub') }}</span>
        <span class="lane-title">{{ t('module.identity-federation.identitysync.lane.downstream') }}</span>
      </div>

      <div ref="stageRef" class="canvas-stage">
        <svg class="flow-svg" data-testid="flow-wires" aria-hidden="true">
          <defs>
            <marker
              id="flow-arrow-active"
              viewBox="0 0 12 12"
              refX="10"
              refY="6"
              markerWidth="9"
              markerHeight="9"
              orient="auto"
              markerUnits="userSpaceOnUse"
            >
              <path d="M 0 1.5 L 10 6 L 0 10.5 z" fill="#3b82f6" />
            </marker>
            <marker
              id="flow-arrow-muted"
              viewBox="0 0 12 12"
              refX="10"
              refY="6"
              markerWidth="8"
              markerHeight="8"
              orient="auto"
              markerUnits="userSpaceOnUse"
            >
              <path d="M 0 1.5 L 10 6 L 0 10.5 z" fill="#cbd5e1" />
            </marker>
          </defs>
          <path
            v-for="w in wires"
            :key="w.id"
            :d="w.d"
            class="flow-line"
            :class="{ active: w.active, muted: !w.active }"
            fill="none"
            :marker-end="w.active ? 'url(#flow-arrow-active)' : 'url(#flow-arrow-muted)'"
            :data-testid="w.kind === 'up' ? 'upstream-hub-wire' : 'hub-downstream-wire'"
          />
        </svg>

        <!--
          三列同高：空态只有 + 与 hub 共中心线（直线虚线）。
          有任务时任务卡组垂直居中对齐 hub，添加钮沉底不参与居中，避免「卡+加号」把连线折成折线。
        -->
        <div class="lane lane-up" :data-mode="upstreamNodes.length ? 'tasks' : 'empty'">
          <div class="lane-rail">
            <div v-if="upstreamNodes.length" class="task-stack">
              <div
                v-for="node in upstreamNodes"
                :key="node.identitySourceId"
                :ref="(el) => setUpNodeRef(node.identitySourceId, el)"
                class="node-wrap"
              >
                <div
                  class="node-card upstream"
                  :data-health="node.health"
                  data-testid="upstream-task-card"
                >
                  <!-- 紧凑横卡；操作图标叠在卡内右上角，不占整行 -->
                  <button type="button" class="node-body" @click="openUpstreamTask(node)">
                    <div class="node-icon" :data-type="node.sourceType">{{ typeAbbr(node.sourceType) }}</div>
                    <div class="node-meta">
                      <div class="node-title-row">
                        <span class="node-name" :title="node.displayName">{{ node.displayName }}</span>
                        <span class="health-pill" :data-health="node.health">{{ node.healthLabel }}</span>
                      </div>
                      <div class="node-sub">
                        {{ typeDisplayName(node.sourceType) }} ·
                        {{ node.scheduleMode === 'INTERVAL' ? t('module.identity-federation.common.scheduled') : t('module.identity-federation.common.manual') }}
                      </div>
                      <div class="node-sub muted">{{ t('module.identity-federation.common.recent', { time: node.lastRunLabel }) }}</div>
                      <div
                        v-if="node.deptCount != null || node.userCount != null"
                        class="node-sub muted"
                      >
                        {{ t('module.identity-federation.identitysync.label.deptUser', { dept: node.deptCount ?? 0, user: node.userCount ?? 0 }) }}
                      </div>
                      <div v-if="node.health === 'failed' && node.lastError" class="node-err" :title="node.lastError">
                        {{ node.lastError }}
                      </div>
                      <div v-else-if="!node.supported" class="node-warn">{{ t('module.identity-federation.identitysync.panel.capabilityNotReady') }}</div>
                      <div v-else-if="!node.secretConfigured" class="node-warn">{{ t('module.identity-federation.identitysync.panel.secretMissing') }}</div>
                    </div>
                  </button>
                  <div class="node-actions" @click.stop>
                    <button
                      type="button"
                      class="icon-btn primary"
                      data-testid="upstream-task-run"
                      :title="t('module.identity-federation.identitysync.action.run')"
                      :aria-label="t('module.identity-federation.identitysync.action.run')"
                      :disabled="runningId === node.identitySourceId || deletingId === node.identitySourceId"
                      @click="runUpstream(node, $event)"
                    >
                      <el-icon :size="15"><VideoPlay /></el-icon>
                    </button>
                    <button
                      type="button"
                      class="icon-btn danger"
                      data-testid="upstream-task-delete"
                      :title="t('module.identity-federation.identitysync.action.deleteTask')"
                      :aria-label="t('module.identity-federation.identitysync.action.deleteUpstreamTask')"
                      :disabled="deletingId === node.identitySourceId"
                      @click="askRemoveUpstream(node, $event)"
                    >
                      <el-icon :size="14"><Delete /></el-icon>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <button
              ref="upPlusRef"
              type="button"
              class="node-plus"
              :class="{ 'node-plus--dock': upstreamNodes.length > 0 }"
              data-testid="upstream-add"
              :aria-label="t('module.identity-federation.identitysync.action.addUpstreamSource')"
              :title="t('module.identity-federation.identitysync.action.addUpstreamSource')"
              @click="openPicker"
            >
              <el-icon :size="22"><Plus /></el-icon>
            </button>
          </div>
        </div>

        <div class="lane lane-hub">
          <div class="lane-rail">
            <div ref="hubRef" class="node-card hub" data-testid="hub-card">
              <div class="hub-glyph" aria-hidden="true">
                <span class="hub-glyph-window">
                  <i /><i /><i />
                </span>
                <span class="hub-glyph-folder" />
              </div>
              <div class="hub-text">
                <div class="node-name">{{ t('module.identity-federation.identitysync.label.identityMasterData') }}</div>
                <div class="node-sub">{{ t('module.identity-federation.identitysync.lane.hubSub') }}</div>
              </div>
            </div>
          </div>
        </div>

        <div class="lane lane-down" data-mode="empty">
          <div class="lane-rail">
            <button
              ref="downPlusRef"
              type="button"
              class="node-plus muted"
              data-testid="downstream-add"
              disabled
              :aria-label="t('module.identity-federation.identitysync.lane.downHint')"
              :title="t('module.identity-federation.identitysync.lane.downHint')"
            >
              <el-icon :size="22"><Plus /></el-icon>
            </button>
          </div>
        </div>
      </div>

      <div class="canvas-footer">
        <span class="foot-hint">{{ upstreamNodes.length ? t('module.identity-federation.identitysync.footer.clickCard') : t('module.identity-federation.identitysync.footer.addSource') }}</span>
        <span class="foot-hint">{{ t('module.identity-federation.identitysync.footer.hubWrite') }}</span>
        <span class="foot-hint">{{ t('module.identity-federation.identitysync.lane.downSoon') }}</span>
      </div>
    </div>

    <BrickConsoleDrawer
      v-model="pickerOpen"
      :title="t('module.identity-federation.identitysync.action.pickSource')"
      :eyebrow="t('module.identity-federation.identitysync.picker.eyebrow')"
      :description="t('module.identity-federation.identitysync.action.pickSourceHint')"
      size="440px"
      destroy-on-close
    >
      <div class="picker" data-testid="upstream-source-picker">
        <button
          v-for="src in sourceCandidates"
          :key="src.identitySourceId"
          type="button"
          class="picker-item"
          data-testid="upstream-source-item"
          @click="selectIdentitySource(src)"
        >
          <span class="picker-icon">{{ typeAbbr(src.sourceType) }}</span>
          <span class="picker-text">
            <span class="picker-name">{{ src.displayName }}</span>
            <span class="picker-type">{{ typeDisplayName(src.sourceType) }} · {{ src.loginEntryEnabled ? t('module.identity-federation.authsource.status.loginEntryOn') : t('module.identity-federation.authsource.status.loginEntryOff') }}</span>
          </span>
        </button>
        <div v-if="!sourceCandidates.length" class="picker-empty">
          {{ allSources.length ? t('module.identity-federation.identitysync.empty.allOnGraph') : t('module.identity-federation.identitysync.picker.noSources') }}
        </div>
      </div>
    </BrickConsoleDrawer>

    <BrickConsoleDrawer
      v-model="taskOpen"
      :title="taskTitle"
      :eyebrow="t('module.identity-federation.identitysync.drawer.eyebrow')"
      :description="activeSourceName ? `${typeDisplayName(activeSourceType)} · ${activeSourceName}` : t('module.identity-federation.identitysync.drawer.taskPanel')"
      size="520px"
      destroy-on-close
      @closed="onTaskDrawerClosed"
    >
      <IdentitySyncPanel
        v-if="activeSourceId"
        :identity-source-id="activeSourceId"
        :source-display-name="activeSourceName"
        :source-type="activeSourceType"
        :auto-preview="autoPreview"
        :initial-tab="initialTab"
        @saved="onTaskSaved"
      />
    </BrickConsoleDrawer>

    <BrickRiskConfirm
      v-model="riskDeleteOpen"
      :title="t('module.identity-federation.identitysync.action.deleteUpstreamTask')"
      :description="pendingDelete ? t('module.identity-federation.identitysync.delete.desc', { name: pendingDelete.displayName }) : ''"
      :impact="[
        t('module.identity-federation.identitysync.delete.impact1'),
        t('module.identity-federation.identitysync.delete.impact2'),
        t('module.identity-federation.identitysync.delete.impact3'),
      ]"
      :confirm-text="t('module.identity-federation.identitysync.action.deleteTask')"
      @confirm="confirmRemoveUpstream"
      @cancel="cancelRemoveUpstream"
    />
  </div>
</template>

<style scoped>
.sync-center {
  padding: 4px 0 24px;
}
.page-error {
  color: var(--console-danger, var(--el-color-danger));
  margin: 0 0 12px;
  font-size: 13px;
}

/* Canvas surfaces: only --console-* / accent tokens (no hard light paints). */
.sync-canvas {
  display: flex;
  flex-direction: column;
  border-radius: 14px;
  background:
    radial-gradient(
      1200px 420px at 50% 40%,
      color-mix(in srgb, var(--console-primary, #2563eb) 10%, transparent),
      transparent 70%
    ),
    var(--console-card-bg, var(--console-page-bg));
  border: 1px solid var(--console-card-border, var(--console-block-border));
  overflow: hidden;
}

.canvas-header,
.canvas-footer {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  align-items: center;
  padding: 14px 20px;
  flex-shrink: 0;
}
.canvas-header {
  border-bottom: 1px solid var(--console-card-border, var(--console-block-border));
  background: color-mix(in srgb, var(--console-block-bg, var(--console-card-bg)) 88%, transparent);
}
.canvas-footer {
  border-top: 1px solid var(--console-card-border, var(--console-block-border));
  background: color-mix(in srgb, var(--console-block-bg, var(--console-card-bg)) 70%, transparent);
}
.lane-title {
  text-align: center;
  font-size: 12px;
  font-weight: 600;
  color: var(--console-muted, var(--console-text));
  letter-spacing: 0.04em;
}
.foot-hint {
  text-align: center;
  font-size: 12px;
  color: var(--console-muted, var(--console-text));
  line-height: 1.4;
}

.canvas-stage {
  position: relative;
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  align-items: center;
  min-height: 420px;
  padding: 28px 24px;
}

.flow-svg {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 0;
}
.flow-line {
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.flow-line.active {
  stroke: var(--console-primary, #2563eb);
  stroke-dasharray: none;
}
.flow-line.muted {
  stroke: color-mix(in srgb, var(--console-muted, #94a3b8) 55%, var(--console-card-border));
  stroke-dasharray: 7 6;
  opacity: 0.95;
}

.lane {
  position: relative;
  z-index: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 320px;
  min-width: 0;
}
.lane-rail {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 14px;
  width: 100%;
  min-height: 280px;
}
.lane-up[data-mode='tasks'] .lane-rail {
  justify-content: center;
}
.lane-up[data-mode='tasks'] .task-stack {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 14px;
}
.lane-up[data-mode='tasks'] .node-plus--dock {
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
}

.node-wrap {
  width: 100%;
  max-width: 268px;
  display: flex;
  justify-content: center;
}

.node-card.upstream {
  position: relative;
  display: block;
  width: 268px;
  min-height: 96px;
  max-height: calc(268px / 1.618);
  border-radius: 12px;
  border: 1px solid color-mix(in srgb, var(--console-primary) 28%, var(--console-card-border));
  background: var(--console-card-bg);
  box-shadow: var(--console-card-shadow, 0 1px 2px color-mix(in srgb, var(--console-title) 8%, transparent));
  overflow: hidden;
  transition: box-shadow 0.15s ease, border-color 0.15s ease;
  color: var(--console-text);
}
.node-card.upstream:hover {
  border-color: color-mix(in srgb, var(--console-primary) 55%, var(--console-card-border));
  box-shadow: 0 2px 4px color-mix(in srgb, var(--console-title) 10%, transparent),
    0 12px 28px color-mix(in srgb, var(--console-primary) 12%, transparent);
}
.node-card.upstream[data-health='failed'] {
  border-color: color-mix(in srgb, var(--console-danger) 45%, var(--console-card-border));
}
.node-card.upstream[data-health='ok'] {
  border-color: color-mix(in srgb, var(--console-success) 45%, var(--console-card-border));
}

.node-card.hub {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 10px;
  width: 168px;
  height: 168px;
  padding: 16px 14px;
  border-radius: 16px;
  border: 1px solid color-mix(in srgb, var(--console-primary) 35%, var(--console-card-border));
  background: var(--console-card-bg);
  box-shadow: var(--console-card-shadow, 0 2px 6px color-mix(in srgb, var(--console-primary) 12%, transparent));
  text-align: center;
  color: var(--console-text);
}

.node-body {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  box-sizing: border-box;
  width: 100%;
  min-height: 96px;
  padding: 12px 68px 12px 12px;
  border: none;
  background: transparent;
  cursor: pointer;
  text-align: left;
  color: inherit;
}
.node-body:hover {
  background: color-mix(in srgb, var(--console-primary) 8%, transparent);
}

.node-icon {
  width: 40px;
  height: 40px;
  border-radius: 10px;
  background: linear-gradient(
    145deg,
    var(--console-primary),
    color-mix(in srgb, var(--console-primary) 70%, #0f172a)
  );
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 13px;
  flex-shrink: 0;
  box-shadow: 0 2px 6px color-mix(in srgb, var(--console-primary) 30%, transparent);
}
.node-icon[data-type='DINGTALK'] {
  background: linear-gradient(145deg, #38bdf8, #0284c7);
}
.node-icon[data-type='GITHUB'] {
  background: linear-gradient(145deg, #64748b, #0f172a);
}

.node-meta {
  min-width: 0;
  flex: 1;
  overflow: hidden;
}
.node-title-row {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}
.node-name {
  font-weight: 600;
  font-size: 14px;
  color: var(--console-title, var(--console-text));
  line-height: 1.3;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  min-width: 0;
  flex: 1;
}
.node-sub {
  font-size: 12px;
  color: var(--console-muted);
  margin-top: 2px;
  line-height: 1.35;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.node-sub.muted {
  color: var(--console-muted);
}
.node-err,
.node-warn {
  margin-top: 4px;
  font-size: 11px;
  line-height: 1.3;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.node-err {
  color: var(--console-danger);
}
.node-warn {
  color: var(--console-warning);
}

.health-pill {
  display: inline-flex;
  align-items: center;
  height: 18px;
  padding: 0 6px;
  border-radius: var(--console-pill-radius, 999px);
  font-size: 11px;
  font-weight: 600;
  background: var(--console-block-bg);
  color: var(--console-muted);
  flex-shrink: 0;
}
.health-pill[data-health='ok'] {
  background: color-mix(in srgb, var(--console-success) 22%, var(--console-block-bg));
  color: var(--console-success);
}
.health-pill[data-health='failed'] {
  background: color-mix(in srgb, var(--console-danger) 22%, var(--console-block-bg));
  color: var(--console-danger);
}
.health-pill[data-health='zero'] {
  background: color-mix(in srgb, var(--console-warning) 22%, var(--console-block-bg));
  color: var(--console-warning);
}
.health-pill[data-health='running'] {
  background: color-mix(in srgb, var(--console-primary) 22%, var(--console-block-bg));
  color: var(--console-primary);
}

.node-actions {
  position: absolute;
  top: 8px;
  right: 8px;
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 4px;
}
.icon-btn {
  width: 26px;
  height: 26px;
  border-radius: 6px;
  border: 1px solid var(--console-card-border);
  background: color-mix(in srgb, var(--console-card-bg) 92%, transparent);
  color: var(--console-muted);
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  box-shadow: 0 1px 2px color-mix(in srgb, var(--console-title) 8%, transparent);
  transition: background 0.12s ease, border-color 0.12s ease, color 0.12s ease;
}
.icon-btn:hover:not(:disabled) {
  border-color: color-mix(in srgb, var(--console-primary) 50%, var(--console-card-border));
  color: var(--console-primary);
  background: color-mix(in srgb, var(--console-primary) 12%, var(--console-card-bg));
}
.icon-btn.primary {
  border-color: var(--console-primary);
  background: var(--console-primary);
  color: #fff;
}
.icon-btn.primary:hover:not(:disabled) {
  background: color-mix(in srgb, var(--console-primary) 82%, #0f172a);
  border-color: color-mix(in srgb, var(--console-primary) 82%, #0f172a);
  color: #fff;
}
.icon-btn.danger:hover:not(:disabled) {
  border-color: color-mix(in srgb, var(--console-danger) 45%, var(--console-card-border));
  background: color-mix(in srgb, var(--console-danger) 14%, var(--console-card-bg));
  color: var(--console-danger);
}
.icon-btn:disabled {
  opacity: 0.5;
  cursor: wait;
}

.hub-glyph {
  position: relative;
  width: 64px;
  height: 52px;
  border-radius: 12px;
  background: linear-gradient(
    180deg,
    color-mix(in srgb, var(--console-primary) 16%, var(--console-block-bg)),
    color-mix(in srgb, var(--console-primary) 28%, var(--console-card-bg))
  );
  border: 1px solid color-mix(in srgb, var(--console-primary) 35%, var(--console-card-border));
  display: flex;
  align-items: center;
  justify-content: center;
}
.hub-glyph-window {
  position: absolute;
  top: 8px;
  left: 10px;
  display: flex;
  gap: 3px;
}
.hub-glyph-window i {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: color-mix(in srgb, var(--console-primary) 55%, var(--console-muted));
  display: block;
}
/* Decorative traffic-light dots (brand glyph, not surface paint). */
.hub-glyph-window i:nth-child(1) { background: #fca5a5; }
.hub-glyph-window i:nth-child(2) { background: #fde68a; }
.hub-glyph-window i:nth-child(3) { background: #86efac; }
.hub-glyph-folder {
  width: 28px;
  height: 22px;
  margin-top: 6px;
  border-radius: 4px;
  background: var(--console-primary);
  box-shadow: 0 4px 10px color-mix(in srgb, var(--console-primary) 35%, transparent);
  position: relative;
}
.hub-glyph-folder::before {
  content: '';
  position: absolute;
  top: -5px;
  left: 2px;
  width: 12px;
  height: 6px;
  border-radius: 2px 2px 0 0;
  background: color-mix(in srgb, var(--console-primary) 70%, #fff);
}
.hub-text {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
}
.hub .node-name {
  flex: none;
  white-space: normal;
}
.hub .node-sub {
  margin-top: 0;
}

.node-plus {
  width: 56px;
  height: 56px;
  border-radius: 14px;
  border: 1.5px dashed color-mix(in srgb, var(--console-primary) 45%, var(--console-card-border));
  background: color-mix(in srgb, var(--console-block-bg) 90%, transparent);
  color: var(--console-primary);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  transition: background 0.12s ease, border-color 0.12s ease, transform 0.12s ease;
}
.node-plus:hover:not(:disabled) {
  background: color-mix(in srgb, var(--console-primary) 12%, var(--console-card-bg));
  border-color: var(--console-primary);
}
.node-plus.muted {
  opacity: 0.55;
  cursor: not-allowed;
  color: var(--console-muted);
  border-color: var(--console-card-border);
  background: var(--console-block-bg);
}
.lane-up[data-mode='tasks'] .node-plus--dock:hover:not(:disabled) {
  transform: translateX(-50%);
}

.picker {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.picker-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 16px;
  border: 1px solid var(--console-card-border);
  border-radius: 10px;
  background: var(--console-block-bg, var(--console-card-bg));
  cursor: pointer;
  text-align: left;
  color: var(--console-text);
}
.picker-item:hover {
  border-color: var(--console-primary);
  background: color-mix(in srgb, var(--console-primary) 10%, var(--console-card-bg));
}
.picker-icon {
  width: 36px;
  height: 36px;
  border-radius: 8px;
  background: var(--console-primary);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 12px;
  flex-shrink: 0;
}
.picker-text {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}
.picker-name {
  font-size: 14px;
  font-weight: 600;
  color: var(--console-title, var(--console-text));
}
.picker-type {
  font-size: 12px;
  color: var(--console-muted);
}
.picker-empty {
  padding: 32px 16px;
  text-align: center;
  color: var(--console-muted);
  font-size: 13px;
}
</style>
