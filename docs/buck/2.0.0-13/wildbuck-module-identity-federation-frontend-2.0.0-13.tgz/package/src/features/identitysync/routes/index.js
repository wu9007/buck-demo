export const identitysyncRoutes = [
  {
    id: 'identity-federation.identity-sync.center',
    featureKey: 'identitysync',
    path: '/identity-federation/identity-sync',
    title: '身份同步中心',
    abbr: '同',
    eyebrow: '系统管理 / 身份同步中心',
    summary: '',
    guide: {
      title: '身份同步中心',
      steps: [
        {
          anchor: 'topology',
          title: '添加上游',
          body: '',
        },
        {
          anchor: 'topology',
          title: '配置策略',
          body: '',
        },
        {
          anchor: 'topology',
          title: '预览写入',
          body: '',
        },
      ],
    },
    permission: 'identity-federation:identity-sync:view',
    component: () => import('../pages/IamIdentitySyncCenterPage.vue'),
  },
];
