export {
  IDENTITY_FEDERATION_MESSAGES,
  IDENTITY_FEDERATION_MESSAGES_EN_US,
  IDENTITY_FEDERATION_MESSAGES_ZH_CN,
  resolveIdentityFederationMessages,
  translateIdentityFederation,
  useIdentityFederationI18n,
} from './features/identity-federation-i18n.js';
