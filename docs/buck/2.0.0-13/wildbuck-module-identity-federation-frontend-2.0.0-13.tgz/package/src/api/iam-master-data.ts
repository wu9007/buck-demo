/**
 * 联邦模块只读消费 IAM 正式 HTTP API（不 compile 依赖 IAM 前端包）。
 * 路径与契约以 modules:iam 发布面为准。
 */
import { request as brickRequest } from '@wildbuck/core-api-frontend';

export type OrganizationTreeNode = {
  organizationId: string;
  organizationName?: string;
  children?: OrganizationTreeNode[];
  [key: string]: unknown;
};

export type EmployeeSearchRequest = {
  page?: number;
  size?: number;
  keyword?: string;
  [key: string]: unknown;
};

export type EmployeeSummary = {
  employeeId: string;
  employeeName?: string;
  username?: string;
  organizationName?: string;
  [key: string]: unknown;
};

export type PageEmployees = {
  records: EmployeeSummary[];
  total: number;
  [key: string]: unknown;
};

export function listOrganizations(): Promise<OrganizationTreeNode[]> {
  return brickRequest<OrganizationTreeNode[]>('/iam/organizations/tree', {
    method: 'POST',
    body: JSON.stringify(null),
  });
}

export function searchEmployees(request: EmployeeSearchRequest): Promise<PageEmployees> {
  return brickRequest<PageEmployees>('/iam/employees/search', {
    method: 'POST',
    body: JSON.stringify(request ?? {}),
  });
}
