declare const identityFederationModule: {
  name: string;
  register(): {
    routes: Array<{
      path: string;
      name: string;
      component: () => Promise<unknown>;
    }>;
  };
};

export default identityFederationModule;
export declare const brickModuleKey: "identity-federation";
export declare const brickModuleMeta: {
  displayName: string;
};
export declare const brickRoutes: Array<Record<string, unknown>>;
export declare const brickFeatureRegistry: Record<string, unknown>;
export declare const brickPermissionMap: Record<string, Record<string, string>>;
