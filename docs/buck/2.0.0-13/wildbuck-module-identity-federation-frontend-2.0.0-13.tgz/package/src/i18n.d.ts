import type { ComputedRef, Ref } from 'vue';

export declare const IDENTITY_FEDERATION_MESSAGES_ZH_CN: Readonly<Record<string, string>>;
export declare const IDENTITY_FEDERATION_MESSAGES_EN_US: Readonly<Record<string, string>>;
export declare const IDENTITY_FEDERATION_MESSAGES: Readonly<Record<string, Readonly<Record<string, string>>>>;

export declare function resolveIdentityFederationMessages(locale?: string): Readonly<Record<string, string>>;
export declare function translateIdentityFederation(
  runtime: unknown,
  key: string,
  params?: Record<string, unknown>,
  fallbackLocale?: string,
): string;

export declare function useIdentityFederationI18n(): {
  t: (key: string, params?: Record<string, unknown>) => string;
  i18n: unknown;
  locale: ComputedRef<string>;
  revision: Ref<number>;
};
