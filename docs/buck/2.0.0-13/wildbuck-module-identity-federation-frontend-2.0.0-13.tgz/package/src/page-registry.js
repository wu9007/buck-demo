export const brickRouteComponentLoaders = {
  'identity-federation.authsource.list': () =>
    import('./features/authsource/pages/IamAuthSourcesPage.vue'),
  'identity-federation.identity-sync.center': () =>
    import('./features/identitysync/pages/IamIdentitySyncCenterPage.vue'),
  'identity-federation.identity-link': () =>
    import('./features/identitylink/pages/IamIdentityLinkPage.vue'),
};
