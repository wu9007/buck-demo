import { createModuleUsageTracker } from '@wildbuck/core-usage-event-frontend';

export const IDENTITY_FEDERATION_USAGE_EVENT_MODULE_CODE = 'identity-federation';

export const identityFederationUsageEventMatrix = Object.freeze({
  pages: {
    authsource: {
      featureCode: 'authsource',
      pageCode: 'authsource-page',
      routeName: 'identity-federation.authsource.list',
    },
    identitysync: {
      featureCode: 'identitysync',
      pageCode: 'identitysync-page',
      routeName: 'identity-federation.identity-sync.center',
    },
    identitylink: {
      featureCode: 'identitylink',
      pageCode: 'identitylink-page',
      routeName: 'identity-federation.identity-link',
    },
  },
  features: {
    authsource: {
      featureCode: 'authsource',
      pageCode: 'authsource-page',
      routeName: 'identity-federation.authsource.list',
    },
    identitysync: {
      featureCode: 'identitysync',
      pageCode: 'identitysync-page',
      routeName: 'identity-federation.identity-sync.center',
    },
    identitylink: {
      featureCode: 'identitylink',
      pageCode: 'identitylink-page',
      routeName: 'identity-federation.identity-link',
    },
  },
});

export const identityFederationUsageTracker = createModuleUsageTracker(
  IDENTITY_FEDERATION_USAGE_EVENT_MODULE_CODE,
  identityFederationUsageEventMatrix,
);
