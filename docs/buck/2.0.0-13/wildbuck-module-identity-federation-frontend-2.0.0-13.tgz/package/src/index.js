import { authsourceFeature } from './features/authsource/index.js';
import { identitysyncFeature } from './features/identitysync/index.js';
import { identitylinkFeature } from './features/identitylink/index.js';
import registerIdentityFederationRoutes, { identityFederationRoutes } from './routes/index.js';

export const identityFederationFeatureRegistry = {
  authsource: authsourceFeature,
  identitysync: identitysyncFeature,
  identitylink: identitylinkFeature,
};

export const identityFederationPermissionMap = {
  authsource: authsourceFeature.permissions,
  identitysync: identitysyncFeature.permissions,
  identitylink: identitylinkFeature.permissions,
};

export default {
  name: 'identity-federation',
  register() {
    return {
      routes: registerIdentityFederationRoutes(),
    };
  },
};

export const brickModuleKey = 'identity-federation';
export const brickModuleMeta = {
  displayName: '身份联邦',
};
export const brickFeatureRegistry = identityFederationFeatureRegistry;
export const brickPermissionMap = identityFederationPermissionMap;
export const brickRoutes = identityFederationRoutes;

export { identityFederationRoutes };
