# 身份联邦 Frontend

该包由 `brick module scaffold` 创建，提供 身份联邦 的最小 route、feature registry 和 page-registry 骨架。
