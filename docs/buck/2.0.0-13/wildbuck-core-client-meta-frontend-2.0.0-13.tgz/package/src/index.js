import { request as brickRequest } from '@wildbuck/core-api-frontend';

export {
  DEFAULT_BRICK_SHELL_BRAND,
  applyBrickShellBrowserChrome,
  brickShellBrandToConsoleProps,
  resolveBrickShellBrand,
} from './shell-brand.js';

export const DEFAULT_CLIENT_META_ENDPOINT = '/brick/client-meta';

/** 与后端 BrickClientMeta.MAX_PUBLIC_IDENTITY_LENGTH 对齐。 */
export const MAX_PUBLIC_IDENTITY_LENGTH = 64;

const CLIENT_META_TOP_LEVEL_FIELDS = new Set([
  'schemaVersion',
  'appCode',
  'appVersion',
  'buildId',
  'brickVersion',
  'capabilities',
]);
const CAPABILITY_KEY_PATTERN = /^[A-Za-z][A-Za-z0-9_-]{0,63}$/;
const STABLE_APP_CODE_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const SENSITIVE_KEY_FRAGMENTS = [
  'secret',
  'token',
  'password',
  'credential',
  'connectionstring',
  'privatekey',
  'keymaterial',
  'requestbody',
  'responsebody',
  'formcontent',
  'businessobject',
];

export async function loadBrickClientMeta(options = {}) {
  if (options == null || typeof options !== 'object' || Array.isArray(options)) {
    throw new TypeError('Buck client meta options must be an object');
  }
  const endpoint = String(options.endpoint ?? DEFAULT_CLIENT_META_ENDPOINT);
  const requestClient = options.requestClient ?? brickRequest;
  const meta = await requestClient(endpoint, { method: 'GET' });
  return normalizeBrickClientMeta(meta);
}

export function bootstrapBrickClient(meta, handlers = {}) {
  const normalized = normalizeBrickClientMeta(meta);
  if (handlers == null || typeof handlers !== 'object' || Array.isArray(handlers)) {
    throw new TypeError('Buck client bootstrap handlers must be an object');
  }
  for (const [capabilityKey, handler] of Object.entries(handlers)) {
    if (typeof handler !== 'function') {
      continue;
    }
    if (Object.hasOwn(normalized.capabilities, capabilityKey)) {
      handler(normalized.capabilities[capabilityKey], normalized, capabilityKey);
    }
  }
  return normalized;
}

export function normalizeBrickClientMeta(meta) {
  if (!isPlainObject(meta)) {
    throw new TypeError('Buck client meta must be an object');
  }
  for (const field of Object.keys(meta)) {
    if (!CLIENT_META_TOP_LEVEL_FIELDS.has(field)) {
      throw new TypeError(`Buck client meta field is not allowed: ${field}`);
    }
  }

  const schemaVersion = normalizePositiveInteger(meta.schemaVersion, 'schemaVersion');
  const appCode = normalizeOptionalAppCode(meta.appCode);
  const appVersion = normalizeOptionalIdentityField(meta.appVersion, 'appVersion');
  const buildId = normalizeOptionalIdentityField(meta.buildId, 'buildId');
  const brickVersion = normalizeOptionalIdentityField(meta.brickVersion, 'brickVersion');
  const capabilities = normalizeCapabilities(meta.capabilities ?? {});
  return {
    schemaVersion,
    appCode,
    appVersion,
    buildId,
    brickVersion,
    capabilities,
  };
}

/**
 * 拼装登录页/关于页可见的业务版本文案。
 * 无 appVersion 时返回空字符串，调用方应隐藏版本条。
 *
 * @param {Pick<import('./index.d.ts').BrickClientMeta, 'appVersion' | 'buildId' | 'brickVersion' | 'appCode'> | null | undefined} meta
 * @param {{ versionLabel?: string, includeAppCode?: boolean, includeBrickVersion?: boolean }} [options]
 * @returns {string}
 */
export function formatBrickClientAppVersionLabel(meta, options = {}) {
  if (meta == null || typeof meta !== 'object' || Array.isArray(meta)) {
    return '';
  }
  const appVersion = typeof meta.appVersion === 'string' ? meta.appVersion.trim() : '';
  if (!appVersion) {
    return '';
  }
  const versionLabel = typeof options.versionLabel === 'string' && options.versionLabel.trim()
    ? options.versionLabel.trim()
    : '版本';
  const buildId = typeof meta.buildId === 'string' ? meta.buildId.trim() : '';
  const brickVersion = typeof meta.brickVersion === 'string' ? meta.brickVersion.trim() : '';
  const appCode = typeof meta.appCode === 'string' ? meta.appCode.trim() : '';

  const parts = [];
  if (options.includeAppCode && appCode) {
    parts.push(appCode);
  }
  parts.push(`${versionLabel} ${appVersion}`);
  if (buildId) {
    parts.push(buildId);
  }
  if (options.includeBrickVersion && brickVersion) {
    parts.push(`Buck ${brickVersion}`);
  }
  return parts.join(' · ');
}

function normalizeCapabilities(value) {
  if (!isPlainObject(value)) {
    throw new TypeError('Buck client meta capabilities must be an object');
  }
  const capabilities = {};
  for (const [key, capability] of Object.entries(value)) {
    if (!CAPABILITY_KEY_PATTERN.test(key)) {
      throw new TypeError(`Buck client meta capability key is invalid: ${key}`);
    }
    ensurePublicKey(key);
    capabilities[key] = normalizePublicValue(capability, key);
  }
  return capabilities;
}

function normalizePublicValue(value, key) {
  ensurePublicKey(key);
  if (value == null || typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
    return value;
  }
  if (Array.isArray(value)) {
    return value.map((item) => normalizePublicValue(item, key));
  }
  if (isPlainObject(value)) {
    const normalized = {};
    for (const [childKey, childValue] of Object.entries(value)) {
      ensurePublicKey(childKey);
      normalized[childKey] = normalizePublicValue(childValue, childKey);
    }
    return normalized;
  }
  throw new TypeError(`Buck client meta value type is not public: ${key}`);
}

function normalizePositiveInteger(value, fieldName) {
  if (!Number.isInteger(value) || value < 1) {
    throw new TypeError(`Buck client meta ${fieldName} must be a positive integer`);
  }
  return value;
}

function normalizeOptionalAppCode(value) {
  if (value == null) {
    return undefined;
  }
  if (typeof value !== 'string') {
    throw new TypeError('Buck client meta appCode must be a string');
  }
  const trimmed = value.trim();
  if (!trimmed) {
    return undefined;
  }
  if (!STABLE_APP_CODE_PATTERN.test(trimmed)) {
    throw new TypeError('Buck client meta appCode format is invalid');
  }
  return trimmed;
}

function normalizeOptionalIdentityField(value, fieldName) {
  if (value == null) {
    return undefined;
  }
  if (typeof value !== 'string') {
    throw new TypeError(`Buck client meta ${fieldName} must be a string`);
  }
  const trimmed = value.trim();
  if (!trimmed) {
    return undefined;
  }
  if (trimmed.length > MAX_PUBLIC_IDENTITY_LENGTH) {
    return trimmed.slice(0, MAX_PUBLIC_IDENTITY_LENGTH);
  }
  return trimmed;
}

function ensurePublicKey(key) {
  const normalized = String(key)
    .toLowerCase()
    .replaceAll('-', '')
    .replaceAll('_', '')
    .replaceAll('.', '');
  if (SENSITIVE_KEY_FRAGMENTS.some((fragment) => normalized.includes(fragment))) {
    throw new TypeError(`Buck client meta key is sensitive: ${key}`);
  }
}

function isPlainObject(value) {
  return value != null
    && typeof value === 'object'
    && !Array.isArray(value)
    && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
}
