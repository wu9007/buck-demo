/**
 * Deployment product brand from client-meta.capabilities.loginBrand.
 * Used by login page and post-login console shell (title, mark, logo, favicon).
 * Shell hosts must not invent a second product identity.
 */

export const DEFAULT_BRICK_SHELL_BRAND = Object.freeze({
  title: 'Buck',
  subtitle: 'Console',
  mark: 'B',
  logoUrl: '',
  faviconUrl: '',
  browserTitle: 'Buck',
  source: 'fallback',
});

/**
 * @typedef {object} BrickShellBrand
 * @property {string} title
 * @property {string} subtitle
 * @property {string} mark
 * @property {string} logoUrl
 * @property {string} faviconUrl
 * @property {string} browserTitle
 * @property {'loginBrand' | 'fallback'} source
 */

/**
 * Resolve shell/login product brand from client-meta or a raw loginBrand capability.
 *
 * @param {unknown} metaOrLoginBrand Full client-meta, or capabilities.loginBrand, or null
 * @param {{
 *   fallbackTitle?: string,
 *   fallbackSubtitle?: string,
 *   fallbackMark?: string,
 *   includeDescriptionAsSubtitle?: boolean,
 * }} [options]
 * @returns {BrickShellBrand}
 */
export function resolveBrickShellBrand(metaOrLoginBrand, options = {}) {
  const fallbackTitle = asText(options.fallbackTitle, 120) || DEFAULT_BRICK_SHELL_BRAND.title;
  const fallbackSubtitle = options.fallbackSubtitle === undefined
    ? DEFAULT_BRICK_SHELL_BRAND.subtitle
    : asText(options.fallbackSubtitle, 120);
  const fallbackMark = asText(options.fallbackMark, 8) || fallbackTitle.slice(0, 1) || DEFAULT_BRICK_SHELL_BRAND.mark;

  const loginBrand = extractLoginBrandCapability(metaOrLoginBrand);
  if (!loginBrand || !loginBrand.enabled) {
    return {
      title: fallbackTitle,
      subtitle: fallbackSubtitle,
      mark: fallbackMark,
      logoUrl: '',
      faviconUrl: '',
      browserTitle: fallbackTitle,
      source: 'fallback',
    };
  }

  const title = asText(loginBrand.systemName, 120)
    || asText(loginBrand.browserTitle, 120)
    || fallbackTitle;
  const logoUrl = asPublicUrl(loginBrand.logoUrl);
  const mark = asText(loginBrand.brandMark, 8) || title.slice(0, 1) || fallbackMark;
  // Product shell: title/logo from loginBrand; subtitle stays neutral unless caller opts in.
  const subtitle = options.includeDescriptionAsSubtitle
    ? asText(loginBrand.description, 120)
    : '';

  return {
    title,
    subtitle,
    mark,
    logoUrl,
    faviconUrl: logoUrl,
    browserTitle: title,
    source: 'loginBrand',
  };
}

/**
 * Props for BrickConsoleShell / sidebar from a resolved shell brand.
 * @param {BrickShellBrand} brand
 */
export function brickShellBrandToConsoleProps(brand) {
  const resolved = brand && typeof brand === 'object' ? brand : DEFAULT_BRICK_SHELL_BRAND;
  return {
    brandTitle: resolved.title || DEFAULT_BRICK_SHELL_BRAND.title,
    brandSubtitle: resolved.subtitle || '',
    brandMark: resolved.mark || DEFAULT_BRICK_SHELL_BRAND.mark,
    brandLogoUrl: resolved.logoUrl || '',
  };
}

/**
 * Apply document title + favicon for deployment product brand.
 * Returns a restore function (optional; prefer leaving product brand applied after login).
 *
 * @param {BrickShellBrand | null | undefined} brand
 * @param {{ fallbackTitle?: string }} [options]
 * @returns {() => void}
 */
export function applyBrickShellBrowserChrome(brand, options = {}) {
  if (typeof document === 'undefined') {
    return () => {};
  }

  const resolved = brand && brand.title
    ? brand
    : resolveBrickShellBrand(null, { fallbackTitle: options.fallbackTitle });

  const previousTitle = document.title;
  const title = resolved.browserTitle || resolved.title || options.fallbackTitle || DEFAULT_BRICK_SHELL_BRAND.browserTitle;
  if (title) {
    document.title = title;
  }

  const previousIcons = snapshotIconLinks();
  const faviconUrl = resolved.faviconUrl || resolved.logoUrl || '';
  if (faviconUrl) {
    applyFavicon(faviconUrl);
  }

  return () => {
    if (title) {
      document.title = previousTitle;
    }
    restoreIconLinks(previousIcons);
  };
}

function extractLoginBrandCapability(input) {
  if (input == null || typeof input !== 'object' || Array.isArray(input)) {
    return null;
  }
  if (Object.hasOwn(input, 'capabilities')) {
    const capability = input.capabilities?.loginBrand;
    return isPlainObject(capability) ? capability : null;
  }
  if (Object.hasOwn(input, 'enabled') || Object.hasOwn(input, 'systemName') || Object.hasOwn(input, 'logoUrl')) {
    return input;
  }
  return null;
}

function snapshotIconLinks() {
  return [...document.querySelectorAll("link[rel='icon'], link[rel='shortcut icon']")].map((link) => ({
    rel: link.getAttribute('rel') || 'icon',
    href: link.getAttribute('href') || '',
    type: link.getAttribute('type') || '',
    sizes: link.getAttribute('sizes') || '',
  }));
}

function restoreIconLinks(snapshot) {
  document.querySelectorAll("link[rel='icon'], link[rel='shortcut icon']").forEach((node) => node.remove());
  if (!snapshot?.length) {
    return;
  }
  for (const item of snapshot) {
    const link = document.createElement('link');
    link.rel = item.rel || 'icon';
    if (item.href) {
      link.href = item.href;
    }
    if (item.type) {
      link.type = item.type;
    }
    if (item.sizes) {
      link.sizes = item.sizes;
    }
    document.head.appendChild(link);
  }
}

function applyFavicon(logoUrl) {
  document.querySelectorAll("link[rel='icon'], link[rel='shortcut icon']").forEach((node) => node.remove());
  const href = withCacheBust(logoUrl);
  const type = guessImageType(logoUrl);

  // Prefetch so the tab swap prefers a warm cache (reduces blank→logo flicker).
  if (typeof Image !== 'undefined' && href && !href.startsWith('data:')) {
    try {
      const pre = new Image();
      pre.decoding = 'async';
      pre.src = href;
    } catch {
      // Ignore preload failures; link still applied below.
    }
  }

  const icon = document.createElement('link');
  icon.rel = 'icon';
  icon.type = type;
  icon.href = href;
  document.head.appendChild(icon);

  let apple = document.querySelector("link[rel='apple-touch-icon']");
  if (!apple) {
    apple = document.createElement('link');
    apple.rel = 'apple-touch-icon';
    document.head.appendChild(apple);
  }
  apple.href = href;
}

function withCacheBust(url) {
  if (!url) {
    return url;
  }
  if (url.includes('://') || url.startsWith('blob:') || url.startsWith('data:')) {
    return url;
  }
  const sep = url.includes('?') ? '&' : '?';
  return `${url}${sep}v=brand`;
}

function guessImageType(url) {
  const lower = String(url).toLowerCase();
  if (lower.includes('.svg')) {
    return 'image/svg+xml';
  }
  if (lower.includes('.jpg') || lower.includes('.jpeg')) {
    return 'image/jpeg';
  }
  if (lower.includes('.webp')) {
    return 'image/webp';
  }
  if (lower.includes('.gif')) {
    return 'image/gif';
  }
  return 'image/png';
}

function asText(value, max) {
  if (value == null) {
    return '';
  }
  const text = String(value).trim();
  if (!text) {
    return '';
  }
  return text.length > max ? text.slice(0, max) : text;
}

function asPublicUrl(value) {
  const text = asText(value, 512);
  if (!text) {
    return '';
  }
  const lower = text.toLowerCase();
  if (lower.startsWith('javascript:') || lower.startsWith('data:text') || lower.startsWith('vbscript:')) {
    return '';
  }
  if (text.startsWith('/') || lower.startsWith('https://') || lower.startsWith('http://')) {
    return text;
  }
  return '';
}

function isPlainObject(value) {
  return value != null && typeof value === 'object' && !Array.isArray(value);
}
