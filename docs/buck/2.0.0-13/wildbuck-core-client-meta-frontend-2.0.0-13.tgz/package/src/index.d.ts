export interface BrickClientMeta {
  schemaVersion: number;
  appCode?: string;
  /** 业务应用对外版本；未配置时省略。 */
  appVersion?: string;
  /** 可选构建标识（短 git sha / CI build）。 */
  buildId?: string;
  /** 可选 Brick 框架/BOM 版本。 */
  brickVersion?: string;
  capabilities: Record<string, unknown>;
}

export interface LoadBrickClientMetaOptions {
  endpoint?: string;
  requestClient?: (path: string, init: RequestInit) => Promise<unknown>;
}

export interface FormatBrickClientAppVersionLabelOptions {
  /** 版本前缀文案，默认「版本」。 */
  versionLabel?: string;
  /** 是否在文案前附加 appCode。 */
  includeAppCode?: boolean;
  /** 是否附加 Brick 框架版本。 */
  includeBrickVersion?: boolean;
}

export type BrickClientMetaBootstrapHandler = (
  capability: unknown,
  meta: BrickClientMeta,
  capabilityKey: string,
) => void;

export declare const DEFAULT_CLIENT_META_ENDPOINT: '/brick/client-meta';
export declare const MAX_PUBLIC_IDENTITY_LENGTH: 64;

export declare function loadBrickClientMeta(options?: LoadBrickClientMetaOptions): Promise<BrickClientMeta>;
export declare function normalizeBrickClientMeta(meta: unknown): BrickClientMeta;
export declare function bootstrapBrickClient(
  meta: unknown,
  handlers?: Record<string, BrickClientMetaBootstrapHandler>,
): BrickClientMeta;
export declare function formatBrickClientAppVersionLabel(
  meta: Pick<BrickClientMeta, 'appVersion' | 'buildId' | 'brickVersion' | 'appCode'> | null | undefined,
  options?: FormatBrickClientAppVersionLabelOptions,
): string;

/** Deployment product brand for login page + console shell (from capabilities.loginBrand). */
export interface BrickShellBrand {
  title: string;
  subtitle: string;
  mark: string;
  logoUrl: string;
  faviconUrl: string;
  browserTitle: string;
  source: 'loginBrand' | 'fallback';
}

export interface ResolveBrickShellBrandOptions {
  fallbackTitle?: string;
  fallbackSubtitle?: string;
  fallbackMark?: string;
  /** When true, map loginBrand.description to shell subtitle (default false). */
  includeDescriptionAsSubtitle?: boolean;
}

export declare const DEFAULT_BRICK_SHELL_BRAND: Readonly<BrickShellBrand>;

export declare function resolveBrickShellBrand(
  metaOrLoginBrand?: unknown,
  options?: ResolveBrickShellBrandOptions,
): BrickShellBrand;

export declare function brickShellBrandToConsoleProps(brand: BrickShellBrand | null | undefined): {
  brandTitle: string;
  brandSubtitle: string;
  brandMark: string;
  brandLogoUrl: string;
};

export declare function applyBrickShellBrowserChrome(
  brand?: BrickShellBrand | null,
  options?: { fallbackTitle?: string },
): () => void;
