# @wildbuck/core-client-meta-frontend

Buck 浏览器启动运行时元数据 helper。默认从 `GET /brick/client-meta` 读取公开配置，再把 `capabilities` 分发给各 core 前端包 bootstrap。

## 推荐：非阻塞 bootstrap

**不要**把 `await loadBrickClientMeta()` 放在应用 `mount` 的关键路径上。meta 挂起或失败时，整页不应白屏。先挂载壳，再异步加载并 bootstrap；失败时保持安全默认（例如 usage-event 保持 disabled）。

```js
import { bootstrapBrickClient, loadBrickClientMeta } from '@wildbuck/core-client-meta-frontend';

// 先 mount 业务壳 / 路由，再拉 meta（示意）
mountApp();

loadBrickClientMeta()
  .then((meta) => {
    bootstrapBrickClient(meta, {
      usageEvent(capability, clientMeta) {
        // 由 @wildbuck/core-usage-event-frontend 封装，业务壳通常不需要手写。
      },
    });
  })
  .catch(() => {
    // 无法读取 client-meta 时不阻断页面；各 capability 保持安全默认。
  });
```

若业务有强依赖“必须先拿到某段公开配置再渲染”的场景，可在页面内对**该能力**做局部等待，而不是阻塞整个应用壳。

## 与 options / 会话的关系

`client-meta` 是公开启动元数据；`POST /brick/options/list` **默认需登录后鉴权**。二者不是同级放行。完整时序见发布资料包 / 仓库文档 `docs/architecture/delivery/business-frontend-ui-reference.md` 章节「壳启动时序：client-meta 与 options 鉴权」。

`client-meta` 只用于公开浏览器启动配置，不承载 token、secret、连接串、内部安全策略明文、请求体、表单内容或业务对象明文。`/transport/meta` 仍是传输安全预检的兼容入口，不由本包替代。

## 部署级产品品牌（loginBrand → 登录页 + 壳）

`capabilities.loginBrand` 由 `modules:login-brand` 贡献。业务壳应：

```js
import {
  loadBrickClientMeta,
  resolveBrickShellBrand,
  applyBrickShellBrowserChrome,
  brickShellBrandToConsoleProps,
} from '@wildbuck/core-client-meta-frontend';

const meta = await loadBrickClientMeta().catch(() => null);
const brand = resolveBrickShellBrand(meta); // 未配置时中性 Buck
applyBrickShellBrowserChrome(brand);       // document.title + favicon
// <BrickConsoleShell v-bind="brickShellBrandToConsoleProps(brand)" />
```

不要在业务 i18n 或 validation 壳里写死第二套产品名/Logo。

## 业务版本字段（零配置）


顶层可选：`appVersion`、`buildId`、`brickVersion`。权威来自构建/流水线写入的
`META-INF/brick-app-identity.properties`（不是 application 手填）。登录页页脚：

```js
import {
  loadBrickClientMeta,
  formatBrickClientAppVersionLabel,
} from '@wildbuck/core-client-meta-frontend';

const meta = await loadBrickClientMeta();
const label = formatBrickClientAppVersionLabel(meta); // 无 appVersion 时为 ''
```
