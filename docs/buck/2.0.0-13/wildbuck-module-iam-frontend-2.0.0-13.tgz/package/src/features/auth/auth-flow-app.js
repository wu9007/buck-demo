const MISSING_STATE_MESSAGE = [
  'IamAuthFlowView 需要 :app="{ state, ...useAuthWorkspace() }"。',
  '不要只把 useAuthWorkspace() 的返回值传给 :app。',
  'IamAuthFlowView requires :app="{ state, ...useAuthWorkspace() }"; do not pass the workspace object alone.',
].join(' ');

export function describeIamAuthFlowAppError(app) {
  const root = app && typeof app === 'object' ? app : null;
  const state = root?.state;
  if (!state || typeof state !== 'object') {
    return MISSING_STATE_MESSAGE;
  }
  return '';
}
