# iam/frontend

IAM 的前端模块包。

## 结构

- `src/generated`
  - 合同生成的 SDK、类型和错误定义
- `src/features/current-principal`
  - 当前主体 feature 元数据（无管理页）；侧栏与权限投影由 workspace helper 承担
- `src/current-principal-workspace.js`
  - 提供上层业务壳可复用的当前主体工作台 helper（`/iam/current-principal/workspace`）：菜单投影、导航分组、头像和菜单图标资源解析
- `src/features/roles`
  - 角色页面、路由和权限映射
- `src/features/sessions`
  - 会话能力的前端 API 和权限映射
- `src/routes`
  - 模块级路由聚合出口

## 认证视图品牌

默认登录页通过公开包入口 `@wildbuck/module-iam-frontend/auth-view` 装配。`:app` 必须是 `{ state, ...useAuthWorkspace() }`，不要只传 workspace。轻量品牌用 props 配置，不要写死验证壳样例：

```vue
<AuthFlowView
  :app="{ state, ...authWorkspace }"
  brand-title="业务系统名称"
  brand-mark="业"
  brand-subtitle="生产环境"
  primary-button-type="primary"
/>
```

- `brandTitle` / `brandMark` / `brandSubtitle` 均为可选；全部为空时不渲染品牌条。
- `primaryButtonType` 默认 `primary`，不要把演示向 `danger` 当作默认可交付形态。
- **业务版本页脚**：从 `GET /brick/client-meta` 读取 `appVersion` / `buildId`（流水线写入 jar 内 identity，业务零配置）；props 可覆盖调试。无版本时不渲染页脚，meta 失败不阻断登录。
- **登录品牌/布局**：读取 `capabilities.loginBrand`（系统名、描述、logo、整页背景、`formPosition`、`brandPosition`）。位置为受控预设：表单 `CENTER|LEFT|RIGHT`；品牌 `ABOVE_FORM|BELOW_FORM|LEFT_PANEL|RIGHT_PANEL|TOP_BAR`。props `brandTitle/Mark/Subtitle` 仅作无配置时的回退。
- `useAuthWorkspace()` 的 `currentLoginMode` 等字段是 `ComputedRef`。组装 `app` 时用 `shallowRef` 或对象字面量持有 workspace 返回值，**不要** `ref({ ...useAuthWorkspace() })` 再深度展开。`IamAuthFlowView` 内部用 `unref` 兼容 Ref 与已解包对象，避免登录页白屏。
- 需要完全自定义版式时走整页自定义模式，状态与动作仍用 `auth-state` / `auth-workspace`。

## 原则

- 不承载最终应用壳
- 不直接写原始接口字符串
- 对外暴露稳定的模块路由、权限和 feature registry
