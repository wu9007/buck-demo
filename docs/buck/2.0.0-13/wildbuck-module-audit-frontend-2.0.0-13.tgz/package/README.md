# audit frontend

Buck 审计模块的前端实现区域。

## i18n

- 词条键：`module.audit.*`
- 公开入口：`@wildbuck/module-audit-frontend/i18n`（`resolveAuditMessages` / `useAuditI18n`）
- 上层壳：`registerMessages('module-audit', resolveAuditMessages(locale))`
