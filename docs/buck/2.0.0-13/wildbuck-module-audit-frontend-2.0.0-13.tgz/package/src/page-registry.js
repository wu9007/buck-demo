export const brickRouteComponentLoaders = {
  'audit.logs.list': () => import('./features/logs/pages/AuditLogPage.vue'),
};
