import { auditLogsFeature } from './features/logs/index.js';
import { auditRoutes } from './routes/index.js';

export const auditFeatureRegistry = {
  logs: auditLogsFeature,
};

export const auditPermissionMap = {
  logs: auditLogsFeature.permissions,
};

export const auditWorkbenchCards = [
  {
    cardId: 'audit.logs.summary',
    title: '最近审计事件',
    summary: '筛选近期高价值审计事件并快速进入详情。',
    routeId: 'audit.logs.list',
    priority: 40,
  },
];

export { auditRoutes };
export const brickModuleKey = 'audit';
export const brickModuleMeta = {
  displayName: '审计',
};
export const brickFeatureRegistry = auditFeatureRegistry;
export const brickPermissionMap = auditPermissionMap;
export const brickRoutes = auditRoutes;
export {
  AUDIT_USAGE_EVENT_MODULE_CODE,
  auditUsageEventMatrix,
  auditUsageTracker,
} from './usage-events.js';
