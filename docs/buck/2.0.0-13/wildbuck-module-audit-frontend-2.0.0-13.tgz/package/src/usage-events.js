import { createModuleUsageTracker } from '@wildbuck/core-usage-event-frontend';

export const AUDIT_USAGE_EVENT_MODULE_CODE = 'audit';

export const auditUsageEventMatrix = deepFreeze({
  pages: {
    logs: {
      featureCode: 'audit-log',
      pageCode: 'audit-log-page',
      routeName: 'audit.logs.list',
    },
  },
  features: {
    auditLogList: {
      featureCode: 'audit-log-list',
      pageCode: 'audit-log-page',
      routeName: 'audit.logs.list',
    },
    auditLogDetail: {
      featureCode: 'audit-log-detail',
      pageCode: 'audit-log-page',
      routeName: 'audit.logs.list',
    },
  },
});

export const auditUsageTracker = createModuleUsageTracker(
  AUDIT_USAGE_EVENT_MODULE_CODE,
  auditUsageEventMatrix,
);

function deepFreeze(value) {
  if (value == null || typeof value !== 'object') {
    return value;
  }
  for (const child of Object.values(value)) {
    deepFreeze(child);
  }
  return Object.freeze(value);
}
