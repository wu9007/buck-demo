export interface BrickFrontendRouteRecord {
  id: string;
  featureKey: string;
  path: string;
  title: string;
  abbr?: string;
  iconName?: string;
  iconText?: string;
  eyebrow?: string;
  summary?: string;
  messages?: Record<string, string>;
  permission: string;
  component: () => Promise<unknown>;
}

export interface BrickFrontendModuleMeta {
  displayName: string;
}

export interface BrickFrontendFeatureDefinition {
  featureKey: string;
  routes: BrickFrontendRouteRecord[];
  permissions: Record<string, string>;
}

export declare const auditFeatureRegistry: {
  logs: BrickFrontendFeatureDefinition;
};

export declare const auditPermissionMap: {
  logs: Record<string, string>;
};

export declare const auditRoutes: BrickFrontendRouteRecord[];
export declare const brickModuleKey: string;
export declare const brickModuleMeta: BrickFrontendModuleMeta;
export declare const brickFeatureRegistry: {
  logs: BrickFrontendFeatureDefinition;
};
export declare const brickPermissionMap: {
  logs: Record<string, string>;
};
export declare const brickRoutes: BrickFrontendRouteRecord[];

export type AuditUsageEventPageKey = 'logs';
export type AuditUsageEventFeatureKey = 'auditLogList' | 'auditLogDetail';
export type AuditUsageEventActionCode = 'search' | 'reset-filters' | 'open-detail';
export interface AuditUsageEventPageEntry {
  featureCode: string;
  pageCode: string;
  routeName: string;
}
export type AuditUsageEventFeatureEntry = AuditUsageEventPageEntry;
export declare const AUDIT_USAGE_EVENT_MODULE_CODE: 'audit';
export declare const auditUsageEventMatrix: Readonly<{
  pages: Record<AuditUsageEventPageKey, Readonly<AuditUsageEventPageEntry>>;
  features: Record<AuditUsageEventFeatureKey, Readonly<AuditUsageEventFeatureEntry>>;
}>;
export declare const auditUsageTracker: import('@wildbuck/core-usage-event-frontend').BrickModuleUsageTracker;
