export type AuditUsageEventPageKey = 'logs';
export type AuditUsageEventFeatureKey = 'auditLogList' | 'auditLogDetail';
export type AuditUsageEventActionCode = 'search' | 'reset-filters' | 'open-detail';

export interface AuditUsageEventPageEntry {
  featureCode: string;
  pageCode: string;
  routeName: string;
}

export type AuditUsageEventFeatureEntry = AuditUsageEventPageEntry;

export declare const AUDIT_USAGE_EVENT_MODULE_CODE: 'audit';
export declare const auditUsageEventMatrix: Readonly<{
  pages: Record<AuditUsageEventPageKey, Readonly<AuditUsageEventPageEntry>>;
  features: Record<AuditUsageEventFeatureKey, Readonly<AuditUsageEventFeatureEntry>>;
}>;
export declare const auditUsageTracker: import('@wildbuck/core-usage-event-frontend').BrickModuleUsageTracker;
