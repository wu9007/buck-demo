export {
  AUDIT_MESSAGES,
  AUDIT_MESSAGES_EN_US,
  AUDIT_MESSAGES_ZH_CN,
  resolveAuditMessages,
  translateAudit,
  useAuditI18n,
} from './features/audit-i18n.js';
