export const auditLogPermissions = {
  list: 'audit:log:list',
  detail: 'audit:log:list',
  export: 'audit:log:export',
};
