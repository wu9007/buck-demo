import { formatBrickCatalogError, resolveBrickErrorFromCatalog } from '@wildbuck/core-api-frontend';
import {
  createOptionRequest,
  loadBrickOptions,
  normalizeOptionItems,
  withAllOption,
} from '@wildbuck/core-option-frontend';
import { downloadTextFile } from '@wildbuck/core-ui-frontend/download';
import { computed, reactive, ref } from 'vue';
import { auditErrors } from '../../../generated/errors';
import type {
  AuditLogDetail,
  AuditLogSearchRequest,
  AuditLogSummary,
} from '../../../generated/types';
import {
  auditUsageTracker,
} from '../../../usage-events';
import { useAuditI18n } from '../../../i18n.js';
import { exportAuditLogCsv, loadAuditLogDetail, loadAuditLogs } from '../api/audit-log';
import {
  AUDIT_CSV_EXPORT_MAX_ROWS,
} from '../lib/audit-csv-export.js';
import {
  AUDIT_RELATED_TRACE_MAX,
  buildOperationChangeGroups,
  collectDictionaryProvidersFromGroups,
  parseAuditEntityGroups,
} from '../lib/audit-field-changes.js';
import { listActiveFilterChips } from '../lib/audit-metrics.js';
import {
  normalizeAuditDateTimeInput,
  resolveAuditTimePreset,
} from '../lib/audit-time-presets.js';

type OptionItem = { label: string; value: string };

const CATEGORY_OPTION_CODE = 'audit_log_category';
const RESULT_OPTION_CODE = 'audit_log_result';

const FALLBACK_CATEGORY_CODES = [
  'AUTHENTICATION', 'AUTHORIZATION', 'SECURITY_SETTING', 'PRINCIPAL_SECURITY', 'SESSION', 'DATA_CHANGE',
] as const;

const pageSizeOptions = [10, 20, 50, 100] as const;

export function useAuditLogWorkspace() {
  const { t } = useAuditI18n();

  const categoryOptions = ref<OptionItem[]>([]);
  const resultOptions = ref<OptionItem[]>([]);
  const filters = reactive({
    category: '',
    action: '',
    result: '',
    operatorKeyword: '',
    traceId: '',
    targetType: '',
    targetKeyword: '',
    eventTimeFrom: '',
    eventTimeTo: '',
  });
  const activeTimePreset = ref('');
  const page = ref(1);
  const pageSize = ref(20);
  const logs = ref<AuditLogSummary[]>([]);
  const total = ref(0);
  const loading = ref(true);
  const exporting = ref(false);
  const listError = ref('');
  const actionMessage = ref('');
  const selectedAuditLogId = ref('');
  const drawerVisible = ref(false);
  const activeTab = ref<'overview' | 'changes' | 'request'>('overview');
  const detailLoading = ref(false);
  const detail = ref<AuditLogDetail | null>(null);

  function emptyLabel() {
    return t('module.audit.common.emptyValue');
  }

  function fallbackCategoryOptions(): OptionItem[] {
    return [
      { label: t('module.audit.filter.categoryAll'), value: '' },
      ...FALLBACK_CATEGORY_CODES.map((code) => ({
        label: t(`module.audit.category.${code}`),
        value: code,
      })),
    ];
  }

  function fallbackResultOptions(): OptionItem[] {
    return [
      { label: t('module.audit.filter.resultAll'), value: '' },
      { label: t('module.audit.result.SUCCESS'), value: 'SUCCESS' },
      { label: t('module.audit.result.FAILURE'), value: 'FAILURE' },
    ];
  }

  const pageCount = computed(() => Math.max(1, Math.ceil(total.value / pageSize.value)));
  const paginationSummary = computed(() => t('module.audit.pagination.summary', {
    page: page.value,
    count: logs.value.length,
    total: total.value,
  }));
  const fieldChangesJson = computed(() => prettyAuditJson(detail.value?.fieldChangesJson));
  /** Option maps loaded for dictionaryProvider codes on the current detail (+ related). */
  const fieldDictionaryMaps = ref<Record<string, OptionItem[]>>({});
  /**
   * Sibling DATA_CHANGE details for the same traceId (multi-table / parent-child operation view).
   * Storage stays one log per entity; UI aggregates by traceId.
   */
  const relatedTraceDetails = ref<AuditLogDetail[]>([]);
  const relatedTraceLoading = ref(false);
  /** Sibling cap for current detail (increases on load-more). */
  const relatedTraceLimit = ref(AUDIT_RELATED_TRACE_MAX);
  const relatedTraceTruncated = ref(false);
  const relatedTraceTotalHint = ref(0);
  /**
   * Operation-level groups: primary entity fields + related tables from same traceId
   * and optional nested entities[] payload in fieldChangesJson.
   * Single display model (no parallel flat fieldChangeRows).
   */
  const operationChangeView = computed(() => buildOperationChangeGroups({
    primaryDetail: detail.value,
    relatedDetails: relatedTraceDetails.value,
    dictionaryMaps: fieldDictionaryMaps.value,
    // #426: localize static dictionary tokens (enabled/disabled, yes/no) via audit i18n.
    dictionaryOptions: { t },
    relatedTruncated: relatedTraceTruncated.value,
    relatedTotalHint: relatedTraceTotalHint.value,
  }));
  const changeEntityGroups = computed(() => operationChangeView.value.groups);
  const changeEntitySections = computed(() => operationChangeView.value.sections || []);
  const operationNarrative = computed(() => operationChangeView.value.narrative || null);
  const multiEntityOperation = computed(() => operationChangeView.value.multiEntity);
  const operationEntityCount = computed(() => operationChangeView.value.entityCount);
  const operationFieldCount = computed(() => operationChangeView.value.fieldCount);
  const operationHighlightFieldCount = computed(
    () => operationChangeView.value.highlightFieldCount || 0,
  );
  const targetDataJson = computed(() => prettyAuditJson(detail.value?.targetDataJson));
  const businessDataJson = computed(() => prettyAuditJson(detail.value?.businessDataJson));
  const categoryLabelMap = computed(() => new Map(categoryOptions.value.map((option) => [option.value, option.label])));
  const resultLabelMap = computed(() => new Map(resultOptions.value.map((option) => [option.value, option.label])));
  const activeFilterChips = computed(() => listActiveFilterChips(filters, {
    category: t('module.audit.list.column.category'),
    action: t('module.audit.list.column.action'),
    result: t('module.audit.list.column.result'),
    operatorKeyword: t('module.audit.list.column.operator'),
    traceId: t('module.audit.drawer.field.traceId'),
    targetType: t('module.audit.drawer.field.targetType'),
    targetKeyword: t('module.audit.filter.targetKeywordPlaceholder'),
    eventTimeFrom: t('module.audit.filter.eventTimeFrom'),
    eventTimeTo: t('module.audit.filter.eventTimeTo'),
  }));

  // Initialize fallback option labels for first paint before loadAuditOptions resolves.
  categoryOptions.value = fallbackCategoryOptions();
  resultOptions.value = fallbackResultOptions();

  async function initialize() {
    await loadAuditOptions();
    await search(true);
  }

  async function loadAuditOptions() {
    try {
      const options = await loadBrickOptions([
        createOptionRequest(CATEGORY_OPTION_CODE),
        createOptionRequest(RESULT_OPTION_CODE),
      ]);
      categoryOptions.value = withAllOption(
        { label: t('module.audit.filter.categoryAll'), value: '' },
        normalizeOptionItems(options[CATEGORY_OPTION_CODE]),
        fallbackCategoryOptions(),
      );
      resultOptions.value = withAllOption(
        { label: t('module.audit.filter.resultAll'), value: '' },
        normalizeOptionItems(options[RESULT_OPTION_CODE]),
        fallbackResultOptions(),
      );
    } catch {
      categoryOptions.value = fallbackCategoryOptions();
      resultOptions.value = fallbackResultOptions();
    }
  }

  async function search(resetSelection = false, actionCode?: 'search' | 'reset-filters' | 'export') {
    loading.value = true;
    listError.value = '';
    if (actionCode !== 'export') {
      actionMessage.value = '';
    }
    if (resetSelection) {
      selectedAuditLogId.value = '';
      detail.value = null;
      drawerVisible.value = false;
    }
    try {
      const request = buildSearchRequest();
      const auditPage = await loadAuditLogs(request);
      logs.value = auditPage.records;
      total.value = auditPage.total;
      if (!drawerVisible.value || !selectedAuditLogId.value) {
        trackSearchResult(actionCode, true);
        return;
      }
      const selected = auditPage.records.find((item) => item.auditLogId === selectedAuditLogId.value);
      if (!selected) {
        drawerVisible.value = false;
        detail.value = null;
        selectedAuditLogId.value = '';
        trackSearchResult(actionCode, true);
        return;
      }
      await loadDetail(selected.auditLogId);
      trackSearchResult(actionCode, true);
    } catch (error) {
      logs.value = [];
      total.value = 0;
      listError.value = resolveBrickErrorFromCatalog(error, auditErrors, {
        fallbackCode: 'AUDIT_LOG_NOT_FOUND',
        localeHint: 'zh-CN',
      }).text || formatBrickCatalogError(auditErrors.AUDIT_LOG_NOT_FOUND, { localeHint: 'zh-CN' });
      trackSearchResult(actionCode, false);
    } finally {
      loading.value = false;
    }
  }

  async function submitFilters() {
    page.value = 1;
    activeTimePreset.value = '';
    await search(true, 'search');
  }

  async function resetFilters() {
    filters.category = '';
    filters.action = '';
    filters.result = '';
    filters.operatorKeyword = '';
    filters.traceId = '';
    filters.targetType = '';
    filters.targetKeyword = '';
    filters.eventTimeFrom = '';
    filters.eventTimeTo = '';
    activeTimePreset.value = '';
    page.value = 1;
    pageSize.value = 20;
    await search(true, 'reset-filters');
  }

  async function applyTimePreset(code: string) {
    const range = resolveAuditTimePreset(code);
    filters.eventTimeFrom = range.eventTimeFrom;
    filters.eventTimeTo = range.eventTimeTo;
    activeTimePreset.value = code;
    page.value = 1;
    await search(true, 'search');
  }

  async function clearFilterChip(key: string) {
    if (key in filters) {
      (filters as Record<string, string>)[key] = '';
    }
    if (key === 'eventTimeFrom' || key === 'eventTimeTo') {
      activeTimePreset.value = '';
    }
    page.value = 1;
    await search(true, 'search');
  }

  async function changePage(nextPage: number) {
    if (nextPage === page.value) {
      return;
    }
    page.value = nextPage;
    await search(false);
  }

  async function changePageSize(nextSize: number) {
    if (nextSize === pageSize.value) {
      return;
    }
    pageSize.value = nextSize;
    page.value = 1;
    await search(false);
  }

  async function openAuditLog(auditLogId: string) {
    selectedAuditLogId.value = auditLogId;
    drawerVisible.value = true;
    activeTab.value = 'overview';
    actionMessage.value = '';
    try {
      await loadDetail(auditLogId);
      void auditUsageTracker.trackOpen('auditLogDetail', 'open-detail');
    } catch (error) {
      void auditUsageTracker.trackOpen('auditLogDetail', 'open-detail', 'FAILURE');
      throw error;
    }
  }

  function closeDrawer() {
    drawerVisible.value = false;
  }

  async function copyValue(value: string | undefined, label: string) {
    if (!value || !value.trim()) {
      return;
    }
    if (typeof navigator === 'undefined' || !navigator.clipboard?.writeText) {
      actionMessage.value = t('module.audit.copy.unsupported', { label });
      return;
    }
    await navigator.clipboard.writeText(value);
    actionMessage.value = t('module.audit.copy.success', { label });
  }

  async function exportCsv() {
    if (exporting.value) {
      return;
    }
    exporting.value = true;
    actionMessage.value = '';
    listError.value = '';
    try {
      const exported = await exportAuditLogCsv({
        ...buildSearchRequest(),
        page: 1,
        size: 200,
      });
      if (!exported.count) {
        actionMessage.value = t('module.audit.export.empty');
        void auditUsageTracker.trackActionResult('auditLogList', 'export', 'FAILURE');
        return;
      }
      const ok = downloadTextFile(exported.csvContent, exported.fileName);
      if (!ok) {
        actionMessage.value = t('module.audit.export.unsupported');
        void auditUsageTracker.trackActionResult('auditLogList', 'export', 'FAILURE');
        return;
      }
      actionMessage.value = exported.truncated
        ? t('module.audit.export.truncated', {
          count: exported.count,
          total: exported.total,
          max: exported.maxRows ?? AUDIT_CSV_EXPORT_MAX_ROWS,
        })
        : t('module.audit.export.success', { count: exported.count });
      void auditUsageTracker.trackActionResult('auditLogList', 'export', 'SUCCESS');
    } catch {
      listError.value = t('module.audit.export.failed');
      void auditUsageTracker.trackActionResult('auditLogList', 'export', 'FAILURE');
    } finally {
      exporting.value = false;
    }
  }

  function resolveCategoryLabel(value?: string) {
    if (!value) {
      return emptyLabel();
    }
    return categoryLabelMap.value.get(value) || value;
  }

  function resolveResultLabel(value?: string) {
    if (!value) {
      return emptyLabel();
    }
    return resultLabelMap.value.get(value) || value;
  }

  function resolveResultTone(value?: string) {
    return value === 'FAILURE' ? 'danger' : value === 'SUCCESS' ? 'success' : 'info';
  }

  function resolveActionLabel(value?: string) {
    if (!value || !value.trim()) {
      return emptyLabel();
    }
    const key = `module.audit.action.${value}`;
    const translated = t(key);
    return translated !== key ? translated : value;
  }

  function resolveTargetTypeLabel(value?: string) {
    if (!value || !value.trim()) {
      return emptyLabel();
    }
    const key = `module.audit.targetType.${value}`;
    const translated = t(key);
    return translated !== key ? translated : value;
  }

  /**
   * Human summary for ORM patterns:
   * - "{entityDisplayName}:{OPERATION}" → "员工：新增"
   * - "{entityDisplayName}「{instance}」:{OPERATION}" → "角色「系统管理员」：更新"
   * Free-text summaries (登录成功 etc.) pass through.
   */
  function resolveSummaryLabel(value?: string, _action?: string) {
    if (!value || !value.trim()) {
      return emptyLabel();
    }
    const text = value.trim();
    const colon = text.lastIndexOf(':');
    if (colon > 0 && colon < text.length - 1) {
      const head = text.slice(0, colon);
      const tail = text.slice(colon + 1);
      if (/^[A-Z][A-Z0-9_]*$/.test(tail)) {
        const actionLabel = resolveActionLabel(tail);
        if (actionLabel && actionLabel !== tail) {
          return `${head}：${actionLabel}`;
        }
      }
    }
    return text;
  }

  function display(value?: string) {
    return value && value.trim() ? value : emptyLabel();
  }

  async function loadDetail(auditLogId: string) {
    detailLoading.value = true;
    fieldDictionaryMaps.value = {};
    relatedTraceDetails.value = [];
    relatedTraceLimit.value = AUDIT_RELATED_TRACE_MAX;
    relatedTraceTruncated.value = false;
    relatedTraceTotalHint.value = 0;
    try {
      detail.value = await loadAuditLogDetail(auditLogId);
      await loadRelatedTraceDetails(detail.value);
      await loadFieldChangeDictionariesForOperation(detail.value, relatedTraceDetails.value);
    } finally {
      detailLoading.value = false;
    }
  }

  /**
   * Same request often writes multiple tables (parent + child). ORM emits one audit row
   * per entity with a shared traceId — load siblings so the Changes tab can show one operation.
   */
  async function loadRelatedTraceDetails(primary?: AuditLogDetail | null) {
    relatedTraceLoading.value = true;
    relatedTraceDetails.value = [];
    relatedTraceTruncated.value = false;
    relatedTraceTotalHint.value = 0;
    try {
      const traceId = primary?.traceId?.trim();
      if (!traceId || !primary?.auditLogId) {
        return;
      }
      const limit = Math.max(relatedTraceLimit.value, AUDIT_RELATED_TRACE_MAX);
      // Prefer DATA_CHANGE siblings; fall back to any same-trace events when category missing.
      const page = await loadAuditLogs({
        page: 1,
        size: limit + 2,
        traceId,
        category: primary.category === 'DATA_CHANGE' ? 'DATA_CHANGE' : undefined,
      });
      const allSiblings = (page?.records || [])
        .filter((item) => item.auditLogId && item.auditLogId !== primary.auditLogId);
      const totalHint = Math.max(
        allSiblings.length,
        // page.total includes primary when filtering by traceId
        Math.max(0, (page?.total || 0) - 1),
      );
      relatedTraceTotalHint.value = totalHint;
      relatedTraceTruncated.value = totalHint > limit || allSiblings.length > limit;
      const siblings = allSiblings.slice(0, limit);
      if (siblings.length === 0) {
        return;
      }
      const details = await Promise.all(
        siblings.map(async (item) => {
          try {
            return await loadAuditLogDetail(item.auditLogId);
          } catch {
            return null;
          }
        }),
      );
      relatedTraceDetails.value = details.filter((item): item is AuditLogDetail => item != null);
    } catch {
      relatedTraceDetails.value = [];
      relatedTraceTruncated.value = false;
      relatedTraceTotalHint.value = 0;
    } finally {
      relatedTraceLoading.value = false;
    }
  }

  async function loadMoreRelatedTrace() {
    if (!detail.value || relatedTraceLoading.value) {
      return;
    }
    relatedTraceLimit.value += AUDIT_RELATED_TRACE_MAX;
    await loadRelatedTraceDetails(detail.value);
    await loadFieldChangeDictionariesForOperation(detail.value, relatedTraceDetails.value);
  }

  /**
   * Load BrickOptionProvider maps for dictionaryProvider codes on primary + related field changes
   * (from @BrickChangeLogField.dictionaryProvider). Static dictionaries resolve client-side.
   * Single-pass parse via entity groups (#427).
   */
  async function loadFieldChangeDictionariesForOperation(
    primary?: AuditLogDetail | null,
    related: AuditLogDetail[] = [],
  ) {
    const nestedGroups = [
      ...parseAuditEntityGroups(primary?.fieldChangesJson, {
        auditLogId: primary?.auditLogId,
        entityType: primary?.targetType,
        entityId: primary?.targetId,
        entityName: primary?.targetName,
        operation: primary?.action,
      }),
      ...related.flatMap((item) => parseAuditEntityGroups(item.fieldChangesJson, {
        auditLogId: item.auditLogId,
        entityType: item.targetType,
        entityId: item.targetId,
        entityName: item.targetName,
        operation: item.action,
      })),
    ];
    const providers = collectDictionaryProvidersFromGroups(nestedGroups);
    if (providers.length === 0) {
      fieldDictionaryMaps.value = {};
      return;
    }
    try {
      const valuesByProvider = new Map<string, string[]>();
      for (const group of nestedGroups) {
        for (const row of group.changes || []) {
          if (!row.dictionaryProvider) {
            continue;
          }
          const list = valuesByProvider.get(row.dictionaryProvider) || [];
          const oldRaw = row.oldRaw ?? row.oldValue;
          const newRaw = row.newRaw ?? row.newValue;
          if (oldRaw !== undefined && oldRaw !== null && oldRaw !== '') {
            list.push(String(oldRaw));
          }
          if (newRaw !== undefined && newRaw !== null && newRaw !== '') {
            list.push(String(newRaw));
          }
          valuesByProvider.set(row.dictionaryProvider, list);
        }
      }
      const requests = providers.map((name) => {
        const values = [...new Set(valuesByProvider.get(name) || [])];
        return values.length > 0
          ? createOptionRequest(name, { values })
          : createOptionRequest(name);
      });
      const loaded = await loadBrickOptions(requests);
      const next: Record<string, OptionItem[]> = {};
      for (const name of providers) {
        next[name] = normalizeOptionItems(loaded?.[name]);
      }
      fieldDictionaryMaps.value = next;
    } catch {
      // Keep raw codes if option service is unavailable; UI still shows displayName + raw values.
      fieldDictionaryMaps.value = {};
    }
  }

  function buildSearchRequest(): AuditLogSearchRequest {
    return {
      page: page.value,
      size: pageSize.value,
      category: emptyToUndefined(filters.category),
      action: emptyToUndefined(filters.action),
      result: emptyToUndefined(filters.result),
      operatorKeyword: emptyToUndefined(filters.operatorKeyword),
      traceId: emptyToUndefined(filters.traceId),
      targetType: emptyToUndefined(filters.targetType),
      targetKeyword: emptyToUndefined(filters.targetKeyword),
      eventTimeFrom: normalizeAuditDateTimeInput(filters.eventTimeFrom),
      eventTimeTo: normalizeAuditDateTimeInput(filters.eventTimeTo),
    };
  }

  return {
    actionMessage,
    activeFilterChips,
    activeTab,
    activeTimePreset,
    applyTimePreset,
    businessDataJson,
    categoryOptions,
    changePage,
    changePageSize,
    clearFilterChip,
    closeDrawer,
    copyValue,
    detail,
    detailLoading,
    display,
    drawerVisible,
    exportCsv,
    exporting,
    changeEntityGroups,
    changeEntitySections,
    fieldChangesJson,
    filters,
    initialize,
    listError,
    loadMoreRelatedTrace,
    loading,
    logs,
    multiEntityOperation,
    openAuditLog,
    openRelatedAuditLog: openAuditLog,
    operationEntityCount,
    operationFieldCount,
    operationHighlightFieldCount,
    operationNarrative,
    relatedTraceLoading,
    relatedTraceTotalHint,
    relatedTraceTruncated,
    page,
    pageCount,
    pageSize,
    pageSizeOptions,
    paginationSummary,
    resetFilters,
    resolveActionLabel,
    resolveCategoryLabel,
    resolveResultLabel,
    resolveResultTone,
    resolveSummaryLabel,
    resolveTargetTypeLabel,
    resultOptions,
    search: submitFilters,
    selectedAuditLogId,
    submitFilters,
    targetDataJson,
    total,
  };
}

function trackSearchResult(actionCode: 'search' | 'reset-filters' | 'export' | undefined, success: boolean) {
  if (!actionCode || actionCode === 'export') {
    return;
  }
  void auditUsageTracker.trackActionResult('auditLogList', actionCode, success ? 'SUCCESS' : 'FAILURE');
}

function emptyToUndefined(value?: string) {
  return value && value.trim() ? value.trim() : undefined;
}

function prettyAuditJson(raw?: string) {
  if (!raw || !raw.trim()) {
    return '';
  }
  try {
    return JSON.stringify(JSON.parse(raw), null, 2);
  } catch {
    return raw;
  }
}
