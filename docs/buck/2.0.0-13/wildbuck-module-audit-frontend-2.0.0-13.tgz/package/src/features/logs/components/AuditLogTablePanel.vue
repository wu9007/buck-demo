<script setup lang="ts">
import { computed } from 'vue';
import { BrickEmptyState, BrickPaginationBar } from '@wildbuck/core-ui-frontend/patterns';
import type { AuditLogSummary } from '../../../generated/types';
import { useAuditI18n } from '../../../i18n.js';

const props = defineProps<{
  loading: boolean;
  logs: AuditLogSummary[];
  page: number;
  pageSize: number;
  pageSizeOptions: readonly number[];
  paginationSummary: string;
  resolveActionLabel: (value?: string) => string;
  resolveCategoryLabel: (value?: string) => string;
  resolveResultLabel: (value?: string) => string;
  resolveResultTone: (value?: string) => string;
  resolveSummaryLabel: (value?: string, action?: string) => string;
  selectedAuditLogId: string;
  total: number;
}>();

defineEmits<{
  open: [auditLogId: string];
  'update:page': [value: number];
  'update:pageSize': [value: number];
}>();

const { t } = useAuditI18n();
const hasRecords = computed(() => props.logs.length > 0);

function resolveOperator(log: AuditLogSummary) {
  return log.operatorName || log.operatorId || t('module.audit.common.emptyValue');
}

function rowClassName({ row }: { row: AuditLogSummary }) {
  return row.result === 'FAILURE' ? 'audit-row--failure' : '';
}
</script>

<template>
  <el-card shadow="never" class="audit-table-panel" data-guide-anchor="list">
    <template #header>
      <div class="audit-table-panel__header">
        <div>
          <h2>{{ t('module.audit.list.title') }}</h2>
          <p class="audit-table-panel__hint">{{ t('module.audit.list.hint') }}</p>
        </div>
      </div>
    </template>

    <BrickEmptyState
      v-if="!hasRecords && !loading"
      :title="t('module.audit.list.emptyTitle')"
      :description="t('module.audit.list.emptyDescription')"
      compact
    />

    <el-table
      v-else
      :data="logs"
      row-key="auditLogId"
      :highlight-current-row="true"
      :current-row-key="selectedAuditLogId"
      :row-class-name="rowClassName"
      v-loading="loading"
      @row-click="$emit('open', $event.auditLogId)"
    >
      <el-table-column :label="t('module.audit.list.column.category')" min-width="140">
        <template #default="{ row }">
          <el-tag effect="plain">{{ resolveCategoryLabel(row.category) }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column :label="t('module.audit.list.column.action')" min-width="170">
        <template #default="{ row }">
          {{ resolveActionLabel(row.action) }}
        </template>
      </el-table-column>
      <el-table-column :label="t('module.audit.list.column.result')" width="120">
        <template #default="{ row }">
          <el-tag :type="resolveResultTone(row.result)" effect="plain">{{ resolveResultLabel(row.result) }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column :label="t('module.audit.list.column.operator')" min-width="160">
        <template #default="{ row }">
          <span>{{ resolveOperator(row) }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="remoteAddress" :label="t('module.audit.list.column.clientIp')" min-width="150">
        <template #default="{ row }">
          {{ row.remoteAddress || t('module.audit.common.emptyValue') }}
        </template>
      </el-table-column>
      <el-table-column :label="t('module.audit.list.column.summary')" min-width="260" show-overflow-tooltip>
        <template #default="{ row }">
          {{ resolveSummaryLabel(row.summary, row.action) }}
        </template>
      </el-table-column>
      <el-table-column prop="eventTime" :label="t('module.audit.list.column.time')" min-width="180" />
      <el-table-column :label="t('module.audit.list.column.actions')" width="120" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click.stop="$emit('open', row.auditLogId)">{{ t('module.audit.list.viewDetail') }}</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="audit-table-panel__pagination">
      <BrickPaginationBar
        :page="page"
        :page-size="pageSize"
        :page-sizes="pageSizeOptions"
        :summary="paginationSummary"
        :total="total"
        @update:page="$emit('update:page', $event)"
        @update:page-size="$emit('update:pageSize', $event)"
      />
    </div>
  </el-card>
</template>

<style scoped>
.audit-table-panel {
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: var(--console-card-radius, 8px);
  background: var(--console-card-bg, #ffffff);
  box-shadow: var(--console-card-shadow, 0 1px 2px rgba(22, 67, 76, 0.04));
}

.audit-table-panel :deep(.el-card__header) {
  padding: var(--console-card-header-y, 14px) var(--console-card-header-x, 18px);
  border-bottom-color: var(--console-card-border, #e6ebf2);
}

.audit-table-panel :deep(.el-card__body) {
  padding: 0;
}

.audit-table-panel__header h2 {
  margin: 0;
  color: var(--console-title, #172033);
  font-size: 18px;
}

.audit-table-panel__hint {
  margin: 6px 0 0;
  color: var(--console-muted, #7e8ba0);
  font-size: 12px;
  line-height: 1.5;
}

/*
 * Failure tint must be opaque (color-mix into card bg), not rgba alpha.
 * Sticky fixed action columns inherit the cell bg — alpha lets time text bleed through.
 */
.audit-table-panel :deep(.audit-row--failure) {
  --el-table-tr-bg-color: color-mix(
    in srgb,
    var(--console-danger, #b91c1c) 6%,
    var(--console-card-bg, #ffffff)
  );
}

.audit-table-panel :deep(.audit-row--failure td.el-table__cell) {
  background: color-mix(
    in srgb,
    var(--console-danger, #b91c1c) 6%,
    var(--console-card-bg, #ffffff)
  ) !important;
}

.audit-table-panel__pagination {
  display: block;
}

@media (max-width: 760px) {
  .audit-table-panel__pagination {
    display: grid;
  }
}
</style>
