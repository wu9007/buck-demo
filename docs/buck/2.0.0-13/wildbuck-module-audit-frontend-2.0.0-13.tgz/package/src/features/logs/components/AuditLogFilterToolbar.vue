<script setup lang="ts">
import { BrickFilterToolbar } from '@wildbuck/core-ui-frontend/patterns';
import { useAuditI18n } from '../../../i18n.js';
import { AUDIT_TIME_PRESET_CODES } from '../lib/audit-time-presets.js';

defineProps<{
  activeTimePreset: string;
  categoryOptions: readonly { label: string; value: string }[];
  filters: {
    category: string;
    action: string;
    result: string;
    operatorKeyword: string;
    traceId: string;
    targetType: string;
    targetKeyword: string;
    eventTimeFrom: string;
    eventTimeTo: string;
  };
  resultOptions: readonly { label: string; value: string }[];
}>();

const emit = defineEmits<{
  'apply-time-preset': [code: string];
  reset: [];
  search: [];
}>();

const { t } = useAuditI18n();

function presetLabel(code: string) {
  return t(`module.audit.filter.preset.${code}`);
}
</script>

<template>
  <form class="audit-log-filter-form" @submit.prevent="emit('search')">
    <div class="audit-time-presets" data-guide-anchor="time-presets" role="group" :aria-label="t('module.audit.filter.presetGroup')">
      <button
        v-for="code in AUDIT_TIME_PRESET_CODES"
        :key="code"
        type="button"
        class="audit-time-presets__btn"
        :class="{ 'is-active': activeTimePreset === code }"
        @click="emit('apply-time-preset', code)"
      >
        {{ presetLabel(code) }}
      </button>
    </div>

    <BrickFilterToolbar class="audit-log-filter-toolbar" field-min-width="168px" data-guide-anchor="filters">
      <el-select v-model="filters.category" clearable :placeholder="t('module.audit.filter.categoryAll')">
        <el-option v-for="option in categoryOptions" :key="option.value" :label="option.label" :value="option.value" />
      </el-select>

      <el-input v-model="filters.action" clearable :placeholder="t('module.audit.filter.actionPlaceholder')" />

      <el-select v-model="filters.result" clearable :placeholder="t('module.audit.filter.resultAll')">
        <el-option v-for="option in resultOptions" :key="option.value" :label="option.label" :value="option.value" />
      </el-select>

      <el-input v-model="filters.operatorKeyword" clearable :placeholder="t('module.audit.filter.operatorPlaceholder')" />
      <el-input v-model="filters.traceId" clearable :placeholder="t('module.audit.filter.traceIdPlaceholder')" />
      <el-input v-model="filters.targetType" clearable :placeholder="t('module.audit.filter.targetTypePlaceholder')" />
      <el-input v-model="filters.targetKeyword" clearable :placeholder="t('module.audit.filter.targetKeywordPlaceholder')" />
      <el-date-picker
        v-model="filters.eventTimeFrom"
        type="datetime"
        value-format="YYYY-MM-DD HH:mm:ss"
        format="YYYY-MM-DD HH:mm:ss"
        :placeholder="t('module.audit.filter.eventTimeFrom')"
        clearable
      />
      <el-date-picker
        v-model="filters.eventTimeTo"
        type="datetime"
        value-format="YYYY-MM-DD HH:mm:ss"
        format="YYYY-MM-DD HH:mm:ss"
        :placeholder="t('module.audit.filter.eventTimeTo')"
        clearable
      />

      <template #actions>
        <el-button native-type="button" @click.prevent="emit('reset')">{{ t('module.audit.filter.reset') }}</el-button>
        <el-button type="primary" native-type="submit">{{ t('module.audit.filter.search') }}</el-button>
      </template>
    </BrickFilterToolbar>
  </form>
</template>

<style scoped>
.audit-log-filter-form {
  display: grid;
  gap: 12px;
  margin: 0;
}

.audit-time-presets {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.audit-time-presets__btn {
  min-height: 32px;
  padding: 0 12px;
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: 999px;
  color: var(--console-text, #4a5a70);
  background: var(--console-card-bg, #ffffff);
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
}

.audit-time-presets__btn:hover,
.audit-time-presets__btn.is-active {
  border-color: rgba(24, 129, 104, 0.35);
  color: var(--console-primary, #188168);
  background: var(--console-accent-soft, rgba(24, 129, 104, 0.08));
}
</style>
