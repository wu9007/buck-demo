<script setup lang="ts">
import { BrickConsoleDrawer } from '@wildbuck/core-ui-frontend/shell';
import { computed, reactive, ref, watch } from 'vue';
import type { AuditLogDetail } from '../../../generated/types';
import { useAuditI18n } from '../../../i18n.js';
import {
  AUDIT_FIELD_COLLAPSE_THRESHOLD,
  partitionFieldChanges,
  truncateAuditDisplayValue,
} from '../lib/audit-field-changes.js';

type FieldChangeRow = {
  id: string;
  fieldName: string;
  displayName: string;
  oldValue: string;
  newValue: string;
  highlighted?: boolean;
  sensitive?: boolean;
  unchanged?: boolean;
  dictionaryPending?: boolean;
};

type EntityGroup = {
  id: string;
  role: string;
  isCurrent?: boolean;
  source?: string;
  auditLogId?: string;
  entityType?: string;
  entityId?: string;
  entityName?: string;
  entityDisplayName?: string;
  operation?: string;
  changeCount?: number;
  highlightCount?: number;
  defaultExpanded?: boolean;
  identityChips?: readonly { id: string; label: string; value: string }[];
  changes: readonly FieldChangeRow[];
};

type EntitySection = {
  id: string;
  kind: string;
  role: string;
  entityType?: string;
  itemCount: number;
  fieldCount: number;
  defaultExpanded?: boolean;
  items: readonly EntityGroup[];
};

const props = defineProps<{
  activeTab: 'overview' | 'changes' | 'request';
  businessDataJson: string;
  changeEntityGroups: readonly EntityGroup[];
  changeEntitySections?: readonly EntitySection[];
  detail: AuditLogDetail | null;
  detailLoading: boolean;
  display: (value?: string) => string;
  fieldChangesJson: string;
  multiEntityOperation?: boolean;
  operationEntityCount?: number;
  operationFieldCount?: number;
  operationHighlightFieldCount?: number;
  operationNarrative?: {
    primaryTitle?: string;
    primaryType?: string;
    primaryOperation?: string;
    typeTally?: readonly { entityType: string; count: number }[];
    multiEntity?: boolean;
  } | null;
  relatedTraceLoading?: boolean;
  relatedTraceTruncated?: boolean;
  relatedTraceTotalHint?: number;
  resolveActionLabel: (value?: string) => string;
  resolveCategoryLabel: (value?: string) => string;
  resolveResultLabel: (value?: string) => string;
  resolveResultTone: (value?: string) => string;
  resolveSummaryLabel: (value?: string, action?: string) => string;
  resolveTargetTypeLabel: (value?: string) => string;
  selectedAuditLogId: string;
  targetDataJson: string;
  visible: boolean;
}>();

const emit = defineEmits<{
  close: [];
  copy: [value: string | undefined, label: string];
  'load-more-related': [];
  'open-related': [auditLogId: string];
  'update:activeTab': [value: 'overview' | 'changes' | 'request'];
}>();

const { t } = useAuditI18n();

const fieldKeyword = ref('');
const highlightOnly = ref(false);
const expandedEntities = reactive<Record<string, boolean>>({});
const showAllCommon = reactive<Record<string, boolean>>({});
const expandedValues = reactive<Record<string, boolean>>({});

watch(
  () => props.selectedAuditLogId,
  () => {
    fieldKeyword.value = '';
    highlightOnly.value = false;
    for (const key of Object.keys(expandedEntities)) {
      delete expandedEntities[key];
    }
    for (const key of Object.keys(showAllCommon)) {
      delete showAllCommon[key];
    }
    for (const key of Object.keys(expandedValues)) {
      delete expandedValues[key];
    }
  },
);

const displaySections = computed(() => {
  if (props.changeEntitySections && props.changeEntitySections.length > 0) {
    return props.changeEntitySections;
  }
  // Fallback: flat groups as a single primary section.
  if (!props.changeEntityGroups?.length) {
    return [];
  }
  return [{
    id: 'section-flat',
    kind: 'primary',
    role: 'primary',
    entityType: props.changeEntityGroups[0]?.entityType || '',
    itemCount: props.changeEntityGroups.length,
    fieldCount: props.operationFieldCount || 0,
    defaultExpanded: true,
    items: props.changeEntityGroups,
  }];
});

const relatedLoadedCount = computed(
  () => props.changeEntityGroups.filter((g) => !g.isCurrent && g.role !== 'primary').length,
);

const relatedRemaining = computed(() => {
  const total = props.relatedTraceTotalHint || 0;
  const loaded = relatedLoadedCount.value;
  return Math.max(0, total - loaded);
});

const narrativeLine = computed(() => {
  const n = props.operationNarrative;
  const detail = props.detail;
  if (!detail) {
    return t('module.audit.drawer.change.operationNarrativeSimple');
  }
  const title = n?.primaryTitle || detail.targetName || t('module.audit.drawer.change.unnamedEntity');
  const type = props.resolveTargetTypeLabel(n?.primaryType || detail.targetType);
  const action = props.resolveActionLabel(n?.primaryOperation || detail.action);
  const operator = detail.operatorName || detail.operatorId || t('module.audit.common.emptyValue');
  const time = detail.eventTime || t('module.audit.common.emptyValue');
  return t('module.audit.drawer.change.operationNarrative', {
    operator,
    time,
    action,
    type,
    title,
  });
});

const alsoAffectedLine = computed(() => {
  const tally = props.operationNarrative?.typeTally || [];
  if (tally.length <= 1) {
    return '';
  }
  const parts = tally
    .filter((item) => item.entityType !== props.operationNarrative?.primaryType)
    .map((item) => t('module.audit.drawer.change.typeCount', {
      type: props.resolveTargetTypeLabel(item.entityType),
      count: item.count,
    }));
  if (parts.length === 0) {
    return '';
  }
  return t('module.audit.drawer.change.alsoAffected', { summary: parts.join('，') });
});

function roleLabelKey(role?: string) {
  if (role === 'child') {
    return 'module.audit.drawer.change.role.child';
  }
  if (role === 'related') {
    return 'module.audit.drawer.change.role.related';
  }
  return 'module.audit.drawer.change.role.primary';
}

function sectionTitle(section: EntitySection) {
  const typeLabel = props.resolveTargetTypeLabel(section.entityType)
    || section.entityType
    || t('module.audit.drawer.change.unnamedEntity');
  if (section.kind === 'child') {
    return t('module.audit.drawer.change.sectionChild', { type: typeLabel });
  }
  if (section.kind === 'related') {
    return t('module.audit.drawer.change.sectionRelated', { type: typeLabel });
  }
  return t('module.audit.drawer.change.role.primary');
}

/**
 * Always GET expandedEntities[id] so Vue tracks the key.
 * hasOwnProperty-only checks never touch the property on first paint,
 * so toggle writes never re-render (expand/collapse appears dead).
 */
function isEntityExpanded(group: EntityGroup) {
  const override = expandedEntities[group.id];
  if (typeof override === 'boolean') {
    return override;
  }
  return Boolean(group.isCurrent || group.role === 'primary' || group.defaultExpanded);
}

function toggleEntity(group: EntityGroup) {
  expandedEntities[group.id] = !isEntityExpanded(group);
}

function isShowAllCommon(groupId: string) {
  return Boolean(showAllCommon[groupId]);
}

function toggleShowAllCommon(groupId: string) {
  showAllCommon[groupId] = !isShowAllCommon(groupId);
}

function fieldPartition(group: EntityGroup) {
  return partitionFieldChanges(group.changes || [], {
    keyword: fieldKeyword.value,
    highlightOnly: highlightOnly.value,
    threshold: isShowAllCommon(group.id) ? Number.MAX_SAFE_INTEGER : AUDIT_FIELD_COLLAPSE_THRESHOLD,
  });
}

function valueKey(groupId: string, fieldId: string, side: 'old' | 'new') {
  return `${groupId}:${fieldId}:${side}`;
}

function displayValue(groupId: string, fieldId: string, side: 'old' | 'new', raw: string) {
  const key = valueKey(groupId, fieldId, side);
  const expanded = Boolean(expandedValues[key]);
  const result = truncateAuditDisplayValue(raw || '');
  if (!result.truncated || expanded) {
    return {
      text: result.full || t('module.audit.drawer.change.empty'),
      truncated: result.truncated,
      expanded,
      key,
    };
  }
  return {
    text: result.text || t('module.audit.drawer.change.empty'),
    truncated: true,
    expanded: false,
    key,
  };
}

function toggleValue(key: string) {
  expandedValues[key] = !expandedValues[key];
}

function entityTitle(group: EntityGroup) {
  return group.entityName
    || props.resolveTargetTypeLabel(group.entityType)
    || t('module.audit.drawer.change.unnamedEntity');
}

function scrollToSection(sectionId: string) {
  if (typeof document === 'undefined') {
    return;
  }
  const el = document.querySelector(`[data-section-id="${sectionId}"]`);
  if (el && 'scrollIntoView' in el) {
    (el as HTMLElement).scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}
</script>

<template>
  <BrickConsoleDrawer
    :model-value="visible"
    size="52%"
    :destroy-on-close="false"
    class="audit-drawer"
    :eyebrow="t('module.audit.drawer.eyebrow')"
    :title="detail
      ? resolveSummaryLabel(detail.summary, detail.action)
      : (selectedAuditLogId ? t('module.audit.drawer.loading') : t('module.audit.drawer.noSelection'))"
    :description="selectedAuditLogId || t('module.audit.drawer.noSelection')"
    @close="$emit('close')"
  >
    <template #actions>
      <el-tag v-if="detail" :type="resolveResultTone(detail.result)" effect="plain">{{ resolveResultLabel(detail.result) }}</el-tag>
    </template>

    <p v-if="detailLoading" class="drawer-state-text">{{ t('module.audit.drawer.loading') }}</p>
    <p v-else-if="!detail" class="drawer-state-text">{{ t('module.audit.drawer.empty') }}</p>

    <el-tabs
      v-else
      :model-value="activeTab"
      class="audit-drawer__tabs"
      @update:model-value="$emit('update:activeTab', $event)"
    >
      <el-tab-pane :label="t('module.audit.drawer.tab.overview')" name="overview">
        <section class="detail-card">
          <div class="detail-grid">
            <div class="detail-item">
              <dt>{{ t('module.audit.drawer.field.category') }}</dt>
              <dd>{{ resolveCategoryLabel(detail.category) }}</dd>
            </div>
            <div class="detail-item">
              <dt>{{ t('module.audit.drawer.field.action') }}</dt>
              <dd>{{ resolveActionLabel(detail.action) }}</dd>
            </div>
            <div class="detail-item">
              <dt>{{ t('module.audit.drawer.field.result') }}</dt>
              <dd>{{ resolveResultLabel(detail.result) }}</dd>
            </div>
            <div class="detail-item">
              <dt>{{ t('module.audit.drawer.field.eventTime') }}</dt>
              <dd>{{ detail.eventTime }}</dd>
            </div>
            <div class="detail-item">
              <dt>{{ t('module.audit.drawer.field.operator') }}</dt>
              <dd>{{ display(detail.operatorName || detail.operatorId) }}</dd>
            </div>
            <div class="detail-item">
              <dt>{{ t('module.audit.drawer.field.traceId') }}</dt>
              <dd>
                <span>{{ display(detail.traceId) }}</span>
                <button
                  v-if="detail.traceId"
                  type="button"
                  class="copy-button"
                  @click="$emit('copy', detail.traceId, t('module.audit.drawer.field.traceId'))"
                >{{ t('module.audit.common.copy') }}</button>
              </dd>
            </div>
            <div class="detail-item">
              <dt>{{ t('module.audit.drawer.field.targetType') }}</dt>
              <dd>{{ resolveTargetTypeLabel(detail.targetType) }}</dd>
            </div>
            <div class="detail-item">
              <dt>{{ t('module.audit.drawer.field.targetName') }}</dt>
              <dd>{{ display(detail.targetName) }}</dd>
            </div>
            <div class="detail-item">
              <dt>{{ t('module.audit.drawer.field.targetId') }}</dt>
              <dd>
                <span class="entity-id">{{ display(detail.targetId) }}</span>
                <button
                  v-if="detail.targetId"
                  type="button"
                  class="copy-button"
                  @click="$emit('copy', detail.targetId, t('module.audit.drawer.field.targetId'))"
                >{{ t('module.audit.common.copy') }}</button>
              </dd>
            </div>
            <div class="detail-item wide">
              <dt>{{ t('module.audit.drawer.field.summary') }}</dt>
              <dd>{{ resolveSummaryLabel(detail.summary, detail.action) }}</dd>
            </div>
            <div class="detail-item wide">
              <dt>{{ t('module.audit.drawer.field.reason') }}</dt>
              <dd>{{ display(detail.reason) }}</dd>
            </div>
          </div>
        </section>
      </el-tab-pane>

      <el-tab-pane :label="t('module.audit.drawer.tab.request')" name="request">
        <section class="detail-card">
          <div class="detail-grid">
            <div class="detail-item">
              <dt>{{ t('module.audit.drawer.field.requestMethod') }}</dt>
              <dd>{{ display(detail.requestMethod) }}</dd>
            </div>
            <div class="detail-item wide">
              <dt>{{ t('module.audit.drawer.field.requestPath') }}</dt>
              <dd>
                <span>{{ display(detail.requestPath) }}</span>
                <button
                  v-if="detail.requestPath"
                  type="button"
                  class="copy-button"
                  @click="$emit('copy', detail.requestPath, t('module.audit.drawer.field.requestPath'))"
                >{{ t('module.audit.common.copy') }}</button>
              </dd>
            </div>
            <div class="detail-item">
              <dt>{{ t('module.audit.drawer.field.terminal') }}</dt>
              <dd>{{ display(detail.visitorTerminal) }}</dd>
            </div>
            <div class="detail-item">
              <dt>{{ t('module.audit.drawer.field.clientId') }}</dt>
              <dd>{{ display(detail.clientId) }}</dd>
            </div>
            <div class="detail-item">
              <dt>{{ t('module.audit.drawer.field.remoteAddress') }}</dt>
              <dd>{{ display(detail.remoteAddress) }}</dd>
            </div>
            <div class="detail-item">
              <dt>{{ t('module.audit.drawer.field.auditSource') }}</dt>
              <dd>{{ display(detail.auditSource) }}</dd>
            </div>
            <div class="detail-item wide">
              <dt>{{ t('module.audit.drawer.field.userAgent') }}</dt>
              <dd>{{ display(detail.userAgent) }}</dd>
            </div>
          </div>

          <div v-if="businessDataJson" class="json-block">
            <div class="json-block__header">
              <h3>{{ t('module.audit.drawer.businessData') }}</h3>
              <button type="button" class="copy-button" @click="$emit('copy', businessDataJson, t('module.audit.drawer.businessData'))">{{ t('module.audit.common.copy') }}</button>
            </div>
            <pre>{{ businessDataJson }}</pre>
          </div>
        </section>
      </el-tab-pane>

      <el-tab-pane :label="t('module.audit.drawer.tab.changes')" name="changes">
        <section class="detail-card">
          <div
            class="operation-banner"
            data-guide-anchor="operation-multi-entity"
          >
            <div class="operation-banner__text">
              <strong>{{ t('module.audit.drawer.change.operationTitle') }}</strong>
              <p class="operation-banner__narrative">{{ narrativeLine }}</p>
              <p>
                {{ t('module.audit.drawer.change.operationIntro', {
                  entities: operationEntityCount || changeEntityGroups.length,
                  fields: operationFieldCount || 0,
                  highlights: operationHighlightFieldCount || 0,
                }) }}
              </p>
              <p v-if="alsoAffectedLine" class="operation-banner__also">{{ alsoAffectedLine }}</p>
            </div>
            <span class="operation-banner__badge">
              {{ t('module.audit.drawer.change.entityCount', { count: operationEntityCount || changeEntityGroups.length }) }}
            </span>
          </div>

          <div
            v-if="displaySections.length > 1"
            class="change-toc"
          >
            <span class="change-toc__label">{{ t('module.audit.drawer.change.toc') }}</span>
            <button
              v-for="section in displaySections"
              :key="`toc-${section.id}`"
              type="button"
              class="change-toc__item"
              @click="scrollToSection(section.id)"
            >
              {{ sectionTitle(section) }}
              <span>×{{ section.itemCount }}</span>
            </button>
          </div>

          <div
            v-if="changeEntityGroups.length"
            class="change-toolbar"
          >
            <input
              v-model="fieldKeyword"
              type="search"
              class="change-toolbar__search"
              :placeholder="t('module.audit.drawer.change.filterPlaceholder')"
            >
            <label class="change-toolbar__check">
              <input v-model="highlightOnly" type="checkbox">
              <span>{{ t('module.audit.drawer.change.highlightOnly') }}</span>
            </label>
          </div>

          <p
            v-if="relatedTraceLoading"
            class="drawer-state-text related-loading"
          >{{ t('module.audit.drawer.change.loadingRelated') }}</p>

          <div
            v-if="relatedTraceTruncated"
            class="related-truncated"
            role="status"
          >
            <p>
              {{ t('module.audit.drawer.change.relatedTruncated', {
                remaining: relatedRemaining,
                loaded: relatedLoadedCount,
                total: relatedTraceTotalHint || relatedLoadedCount,
              }) }}
            </p>
            <button
              type="button"
              class="copy-button"
              :disabled="relatedTraceLoading"
              @click="emit('load-more-related')"
            >{{ t('module.audit.drawer.change.loadMoreRelated') }}</button>
          </div>

          <div
            v-if="displaySections.length"
            class="field-changes"
            data-guide-anchor="field-changes"
          >
            <div class="field-changes__header">
              <div>
                <h3>{{ t('module.audit.drawer.fieldChanges') }}</h3>
                <p class="field-changes__intro">
                  {{ multiEntityOperation
                    ? t('module.audit.drawer.change.introMulti')
                    : t('module.audit.drawer.change.intro') }}
                </p>
              </div>
              <span class="field-changes__count">
                {{ t('module.audit.drawer.change.count', {
                  count: operationFieldCount || 0,
                }) }}
              </span>
            </div>

            <section
              v-for="section in displaySections"
              :key="section.id"
              class="entity-section"
              :class="`is-${section.kind}`"
              :data-section-id="section.id"
            >
              <header
                v-if="section.kind !== 'primary' || multiEntityOperation"
                class="entity-section__header"
              >
                <h4>{{ sectionTitle(section) }}</h4>
                <span>{{ t('module.audit.drawer.change.count', { count: section.fieldCount }) }}</span>
              </header>

              <div
                v-for="group in section.items"
                :key="group.id"
                class="entity-change-group"
                :class="{
                  'is-current': group.isCurrent,
                  'is-child': group.role === 'child',
                  'is-related': group.role === 'related' || (!group.isCurrent && group.role !== 'primary'),
                  'is-collapsed': !isEntityExpanded(group),
                }"
                :data-entity-role="group.role"
                :data-entity-type="group.entityType || ''"
              >
                <header class="entity-change-group__header">
                  <div class="entity-change-group__titles">
                    <span class="entity-role-tag">{{ t(roleLabelKey(group.role)) }}</span>
                    <h4 class="entity-change-group__name">{{ entityTitle(group) }}</h4>
                    <p class="entity-change-group__meta">
                      <span v-if="group.entityType">{{ resolveTargetTypeLabel(group.entityType) }}</span>
                      <span v-if="group.operation">{{ resolveActionLabel(group.operation) }}</span>
                      <span
                        v-if="group.entityId"
                        class="entity-id"
                        :title="t('module.audit.drawer.change.entityIdSecondary')"
                      >{{ group.entityId }}</span>
                    </p>
                    <div
                      v-if="group.identityChips?.length"
                      class="identity-chips"
                      :aria-label="t('module.audit.drawer.change.identity')"
                    >
                      <span
                        v-for="chip in group.identityChips"
                        :key="chip.id"
                        class="identity-chip"
                      >
                        <span class="identity-chip__label">{{ chip.label }}</span>
                        <span class="identity-chip__value">{{ chip.value }}</span>
                      </span>
                    </div>
                  </div>
                  <div class="entity-change-group__actions">
                    <span class="entity-change-group__count">
                      {{ t('module.audit.drawer.change.count', { count: group.changeCount ?? group.changes.length }) }}
                    </span>
                    <button
                      type="button"
                      class="copy-button"
                      @click="toggleEntity(group)"
                    >
                      {{ isEntityExpanded(group)
                        ? t('module.audit.drawer.change.collapseEntity')
                        : t('module.audit.drawer.change.expandEntity') }}
                    </button>
                    <button
                      v-if="group.auditLogId && group.auditLogId !== selectedAuditLogId"
                      type="button"
                      class="copy-button"
                      @click="$emit('open-related', group.auditLogId)"
                    >{{ t('module.audit.drawer.change.openRelated') }}</button>
                  </div>
                </header>

                <template v-if="isEntityExpanded(group)">
                  <template v-if="group.changes.length">
                    <template v-if="fieldPartition(group).total > 0">
                      <div class="field-table-wrap">
                        <table class="field-table">
                          <thead>
                            <tr>
                              <th class="col-field">{{ t('module.audit.drawer.change.field') }}</th>
                              <th class="col-before">{{ t('module.audit.drawer.change.before') }}</th>
                              <th class="col-arrow" aria-hidden="true"></th>
                              <th class="col-after">{{ t('module.audit.drawer.change.after') }}</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr
                              v-for="row in fieldPartition(group).highlighted"
                              :key="`${group.id}-h-${row.id}`"
                              class="field-row is-highlighted"
                              :class="{ 'is-sensitive': row.sensitive }"
                              :aria-label="t('module.audit.drawer.change.fromToAria', {
                                field: row.displayName,
                                before: row.oldValue || t('module.audit.drawer.change.empty'),
                                after: row.newValue || t('module.audit.drawer.change.empty'),
                              })"
                            >
                              <td class="col-field">
                                <span class="field-name">{{ row.displayName }}</span>
                                <span
                                  v-if="row.dictionaryPending"
                                  class="field-code-badge"
                                >{{ t('module.audit.drawer.change.codeBadge') }}</span>
                              </td>
                              <td class="col-before">
                                <span
                                  class="cell-value cell-value--before"
                                  :title="row.oldValue || t('module.audit.drawer.change.empty')"
                                  @click="row.oldValue && row.oldValue.length > 48 && toggleValue(valueKey(group.id, row.id, 'old'))"
                                >{{ displayValue(group.id, row.id, 'old', row.oldValue).text || t('module.audit.drawer.change.empty') }}</span>
                              </td>
                              <td class="col-arrow" aria-hidden="true">→</td>
                              <td class="col-after">
                                <span
                                  class="cell-value cell-value--after"
                                  :title="row.newValue || t('module.audit.drawer.change.empty')"
                                  @click="row.newValue && row.newValue.length > 48 && toggleValue(valueKey(group.id, row.id, 'new'))"
                                >{{ displayValue(group.id, row.id, 'new', row.newValue).text || t('module.audit.drawer.change.empty') }}</span>
                              </td>
                            </tr>
                            <tr
                              v-for="row in fieldPartition(group).common"
                              :key="`${group.id}-c-${row.id}`"
                              class="field-row"
                              :class="{ 'is-sensitive': row.sensitive }"
                              :aria-label="t('module.audit.drawer.change.fromToAria', {
                                field: row.displayName,
                                before: row.oldValue || t('module.audit.drawer.change.empty'),
                                after: row.newValue || t('module.audit.drawer.change.empty'),
                              })"
                            >
                              <td class="col-field">
                                <span class="field-name">{{ row.displayName }}</span>
                                <span
                                  v-if="row.dictionaryPending"
                                  class="field-code-badge"
                                >{{ t('module.audit.drawer.change.codeBadge') }}</span>
                              </td>
                              <td class="col-before">
                                <span
                                  class="cell-value cell-value--before"
                                  :title="row.oldValue || t('module.audit.drawer.change.empty')"
                                  @click="row.oldValue && row.oldValue.length > 48 && toggleValue(valueKey(group.id, row.id, 'old'))"
                                >{{ displayValue(group.id, row.id, 'old', row.oldValue).text || t('module.audit.drawer.change.empty') }}</span>
                              </td>
                              <td class="col-arrow" aria-hidden="true">→</td>
                              <td class="col-after">
                                <span
                                  class="cell-value cell-value--after"
                                  :title="row.newValue || t('module.audit.drawer.change.empty')"
                                  @click="row.newValue && row.newValue.length > 48 && toggleValue(valueKey(group.id, row.id, 'new'))"
                                >{{ displayValue(group.id, row.id, 'new', row.newValue).text || t('module.audit.drawer.change.empty') }}</span>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                        <button
                          v-if="fieldPartition(group).collapsedCount > 0 || isShowAllCommon(group.id)"
                          type="button"
                          class="show-more-fields"
                          @click="toggleShowAllCommon(group.id)"
                        >
                          {{ isShowAllCommon(group.id)
                            ? t('module.audit.drawer.change.showLessFields')
                            : t('module.audit.drawer.change.showMoreFields', {
                              count: fieldPartition(group).collapsedCount,
                            }) }}
                        </button>
                      </div>
                    </template>
                    <p
                      v-else
                      class="entity-change-group__empty"
                    >{{ t('module.audit.drawer.change.noFilterMatch') }}</p>
                  </template>
                  <p
                    v-else
                    class="entity-change-group__empty"
                  >{{ t('module.audit.drawer.change.entityNoFields') }}</p>
                </template>
              </div>
            </section>
          </div>

          <p
            v-else
            class="drawer-state-text"
          >{{ t('module.audit.drawer.noChanges') }}</p>

          <details
            v-if="fieldChangesJson || targetDataJson"
            class="technical-raw"
          >
            <summary>{{ t('module.audit.drawer.change.technicalRaw') }}</summary>
            <div v-if="fieldChangesJson" class="json-block">
              <div class="json-block__header">
                <h3>{{ t('module.audit.drawer.fieldChangesRaw') }}</h3>
                <button
                  type="button"
                  class="copy-button"
                  @click="$emit('copy', fieldChangesJson, t('module.audit.drawer.fieldChangesRaw'))"
                >{{ t('module.audit.common.copy') }}</button>
              </div>
              <pre>{{ fieldChangesJson }}</pre>
            </div>
            <div v-if="targetDataJson" class="json-block">
              <div class="json-block__header">
                <h3>{{ t('module.audit.drawer.targetData') }}</h3>
                <button
                  type="button"
                  class="copy-button"
                  @click="$emit('copy', targetDataJson, t('module.audit.drawer.targetData'))"
                >{{ t('module.audit.common.copy') }}</button>
              </div>
              <pre>{{ targetDataJson }}</pre>
            </div>
          </details>
        </section>
      </el-tab-pane>
    </el-tabs>
  </BrickConsoleDrawer>
</template>

<style>
@import './audit-log-drawer-panel.css';
</style>
