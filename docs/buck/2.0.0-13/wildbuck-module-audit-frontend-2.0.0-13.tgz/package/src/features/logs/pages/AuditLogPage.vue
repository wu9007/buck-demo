<script setup lang="ts">
import { onMounted } from 'vue';
import { BrickListPageActions, BrickPageHeader } from '@wildbuck/core-ui-frontend/patterns';
import AuditLogDrawerPanel from '../components/AuditLogDrawerPanel.vue';
import AuditLogFilterToolbar from '../components/AuditLogFilterToolbar.vue';
import AuditLogTablePanel from '../components/AuditLogTablePanel.vue';
import { useAuditLogWorkspace } from '../composables/useAuditLogWorkspace';
import { auditUsageTracker } from '../../../usage-events';
import { useAuditI18n } from '../../../i18n.js';

const { t } = useAuditI18n();

const {
  actionMessage,
  activeFilterChips,
  activeTab,
  activeTimePreset,
  applyTimePreset,
  businessDataJson,
  categoryOptions,
  changePage,
  changePageSize,
  clearFilterChip,
  closeDrawer,
  copyValue,
  detail,
  detailLoading,
  display,
  drawerVisible,
  exportCsv,
  exporting,
  changeEntityGroups,
  changeEntitySections,
  fieldChangesJson,
  filters,
  initialize,
  listError,
  loadMoreRelatedTrace,
  loading,
  logs,
  multiEntityOperation,
  openAuditLog,
  operationEntityCount,
  operationFieldCount,
  operationHighlightFieldCount,
  operationNarrative,
  page,
  pageSize,
  pageSizeOptions,
  paginationSummary,
  relatedTraceLoading,
  relatedTraceTotalHint,
  relatedTraceTruncated,
  resetFilters,
  resolveActionLabel,
  resolveCategoryLabel,
  resolveResultLabel,
  resolveResultTone,
  resolveSummaryLabel,
  resolveTargetTypeLabel,
  resultOptions,
  selectedAuditLogId,
  submitFilters,
  targetDataJson,
  total,
} = useAuditLogWorkspace();

onMounted(() => {
  void auditUsageTracker.trackPage('logs');
  initialize();
});
</script>

<template>
  <article class="audit-log-page">
    <BrickPageHeader
      :eyebrow="t('module.audit.page.eyebrow')"
      :title="t('module.audit.page.title')"
      :description="t('module.audit.page.description')"
    >
      <template #actions>
        <BrickListPageActions>
          <template #export>
            <!-- primary+plain = outline CTA: readable text under console themes; not solid create primary -->
            <el-button
              type="primary"
              plain
              :loading="exporting"
              data-guide-anchor="export"
              @click="exportCsv"
            >
              {{ t('module.audit.export.button') }}
            </el-button>
          </template>
        </BrickListPageActions>
      </template>
    </BrickPageHeader>

    <AuditLogFilterToolbar
      :active-time-preset="activeTimePreset"
      :category-options="categoryOptions"
      :filters="filters"
      :result-options="resultOptions"
      @apply-time-preset="applyTimePreset"
      @reset="resetFilters"
      @search="submitFilters"
    />

    <div v-if="activeFilterChips.length" class="audit-active-filters" data-guide-anchor="active-filters">
      <span class="audit-active-filters__label">{{ t('module.audit.filter.activeLabel') }}</span>
      <button
        v-for="chip in activeFilterChips"
        :key="`${chip.key}-${chip.value}`"
        type="button"
        class="audit-active-filters__chip"
        @click="clearFilterChip(chip.key)"
      >
        <span>{{ chip.label }}: {{ chip.value }}</span>
        <span aria-hidden="true">×</span>
      </button>
    </div>

    <p v-if="listError" class="state-text state-error" role="alert">{{ listError }}</p>
    <p v-if="actionMessage" class="state-text state-success" role="status">{{ actionMessage }}</p>

    <AuditLogTablePanel
      :loading="loading"
      :logs="logs"
      :page="page"
      :page-size="pageSize"
      :page-size-options="pageSizeOptions"
      :pagination-summary="paginationSummary"
      :resolve-action-label="resolveActionLabel"
      :resolve-category-label="resolveCategoryLabel"
      :resolve-result-label="resolveResultLabel"
      :resolve-result-tone="resolveResultTone"
      :resolve-summary-label="resolveSummaryLabel"
      :selected-audit-log-id="selectedAuditLogId"
      :total="total"
      @open="openAuditLog"
      @update:page="changePage"
      @update:page-size="changePageSize"
    />

    <AuditLogDrawerPanel
      :visible="drawerVisible"
      :active-tab="activeTab"
      :business-data-json="businessDataJson"
      :change-entity-groups="changeEntityGroups"
      :change-entity-sections="changeEntitySections"
      :detail="detail"
      :detail-loading="detailLoading"
      :display="display"
      :field-changes-json="fieldChangesJson"
      :multi-entity-operation="multiEntityOperation"
      :operation-entity-count="operationEntityCount"
      :operation-field-count="operationFieldCount"
      :operation-highlight-field-count="operationHighlightFieldCount"
      :operation-narrative="operationNarrative"
      :related-trace-loading="relatedTraceLoading"
      :related-trace-total-hint="relatedTraceTotalHint"
      :related-trace-truncated="relatedTraceTruncated"
      :resolve-action-label="resolveActionLabel"
      :resolve-category-label="resolveCategoryLabel"
      :resolve-result-label="resolveResultLabel"
      :resolve-result-tone="resolveResultTone"
      :resolve-summary-label="resolveSummaryLabel"
      :resolve-target-type-label="resolveTargetTypeLabel"
      :selected-audit-log-id="selectedAuditLogId"
      :target-data-json="targetDataJson"
      @close="closeDrawer"
      @copy="copyValue"
      @load-more-related="loadMoreRelatedTrace"
      @open-related="openAuditLog"
      @update:active-tab="activeTab = $event"
    />
  </article>
</template>

<style scoped>
.audit-log-page {
  display: grid;
  gap: var(--console-page-gap, 18px);
  padding: 4px 0 12px;
  background: var(--console-page-bg, #f6f8f8);
}

.audit-active-filters {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
}

.audit-active-filters__label {
  color: var(--console-muted, #7e8ba0);
  font-size: 12px;
  font-weight: 700;
}

.audit-active-filters__chip {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  min-height: 30px;
  padding: 0 12px;
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: 999px;
  color: var(--console-title, #172033);
  background: var(--console-card-bg, #ffffff);
  font-size: 12px;
  cursor: pointer;
}

.audit-active-filters__chip:hover {
  border-color: rgba(24, 129, 104, 0.35);
  color: var(--console-primary, #188168);
}

.state-text {
  margin: 0;
  padding: var(--console-card-body-y, 18px) var(--console-card-body-x, 18px);
  border: 1px solid var(--console-card-border, #e6ebf2);
  border-radius: var(--console-card-radius, 8px);
  color: var(--console-text, #4a5a70);
  background: var(--console-card-bg, #ffffff);
  box-shadow: var(--console-card-shadow, 0 1px 2px rgba(22, 67, 76, 0.04));
}

.state-error {
  color: var(--console-danger, #b4232f);
}

.state-success {
  color: var(--console-primary, #188168);
  background: var(--console-accent-soft, rgba(24, 129, 104, 0.08));
}
</style>
