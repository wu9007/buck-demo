import { auditLogPermissions } from './permission/index.js';
import { auditLogRoutes } from './routes/index.js';

export const auditLogsFeature = {
  featureKey: 'logs',
  routes: auditLogRoutes,
  permissions: auditLogPermissions,
};
