import { exportAuditLogs, getAuditLog, searchAuditLogs, summarizeAuditLogs } from '../../../generated/sdk';
import type {
  AuditLogAggregateSummary,
  AuditLogDetail,
  AuditLogExportResult,
  AuditLogSearchRequest,
  AuditLogSummary,
  Page,
} from '../../../generated/types';

export async function loadAuditLogs(input: AuditLogSearchRequest): Promise<Page<AuditLogSummary>> {
  return searchAuditLogs(input);
}

export async function loadAuditLogSummary(
  input: AuditLogSearchRequest,
): Promise<AuditLogAggregateSummary> {
  return summarizeAuditLogs(input);
}

export async function loadAuditLogDetail(auditLogId: string): Promise<AuditLogDetail> {
  return getAuditLog(auditLogId, undefined);
}

export async function exportAuditLogCsv(input: AuditLogSearchRequest): Promise<AuditLogExportResult> {
  return exportAuditLogs(input);
}
