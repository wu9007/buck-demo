import { formatBrickI18nMessage, normalizeBrickLocale } from '@wildbuck/core-i18n-frontend';
import {
  useBrickConsoleI18n,
} from '@wildbuck/core-ui-frontend/i18n';
import {
  AUDIT_MESSAGES,
  AUDIT_MESSAGES_EN_US,
  AUDIT_MESSAGES_ZH_CN,
} from './audit-i18n-messages.js';

/**
 * @param {unknown} locale
 * @returns {Readonly<Record<string, string>>}
 */
export function resolveAuditMessages(locale) {
  const normalized = normalizeBrickLocale(locale);
  return AUDIT_MESSAGES[normalized] ?? AUDIT_MESSAGES_ZH_CN;
}

/**
 * @param {unknown} runtime
 * @param {string} key
 * @param {Record<string, unknown>} [params]
 * @param {string} [fallbackLocale]
 */
export function translateAudit(runtime, key, params = {}, fallbackLocale = 'zh-CN') {
  const messageKey = String(key ?? '');
  if (!messageKey) {
    return '';
  }
  if (runtime && typeof runtime.t === 'function') {
    const resolved = runtime.t(messageKey, params);
    if (resolved != null && resolved !== '' && resolved !== messageKey) {
      return String(resolved);
    }
  }
  const locale = normalizeBrickLocale(
    typeof runtime?.getLocale === 'function' ? runtime.getLocale() : fallbackLocale,
    fallbackLocale,
  );
  const pack = resolveAuditMessages(locale);
  const template = pack[messageKey] ?? AUDIT_MESSAGES_ZH_CN[messageKey];
  if (typeof template === 'string') {
    return formatBrickI18nMessage(template, params);
  }
  return messageKey;
}

export function useAuditI18n() {
  const { i18n, revision, locale, t: consoleT } = useBrickConsoleI18n();

  function t(key, params) {
    void revision.value;
    const fromRuntime = consoleT(key, params);
    if (fromRuntime != null && fromRuntime !== '' && fromRuntime !== key) {
      return fromRuntime;
    }
    return translateAudit(i18n, key, params, locale.value);
  }

  return {
    i18n,
    revision,
    locale,
    t,
  };
}

export {
  AUDIT_MESSAGES,
  AUDIT_MESSAGES_EN_US,
  AUDIT_MESSAGES_ZH_CN,
};
