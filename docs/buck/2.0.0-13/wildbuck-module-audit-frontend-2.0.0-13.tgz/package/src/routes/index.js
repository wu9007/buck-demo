import { auditLogRoutes } from '../features/logs/routes/index.js';

export const auditRoutes = [
  ...auditLogRoutes,
];
