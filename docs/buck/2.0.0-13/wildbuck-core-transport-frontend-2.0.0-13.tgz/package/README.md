# core/transport/frontend

Buck 前端传输安全辅助包。

当前范围：

- 生成与 `core:transport` 后端一致的请求摘要头。
- 生成和打开与后端 `BrickTransportEnvelope` 一致的 `version/timestamp/nonce/data/tag` 传输信封。
- 保持摘要 canonical 规则和后端 `DefaultBrickTransportDigestService` 对齐。
- 浏览器原生默认支持 `SHA256`。`SM3` 需要上层应用注入摘要实现，避免框架强依赖具体前端国密库。
- 加解密算法由上层应用注入，避免框架在浏览器侧绑定具体 AES/SM4/硬件密码实现。

## 使用示例

```ts
import { withBrickRequestDigest } from '@wildbuck/core-transport-frontend';

const init = await withBrickRequestDigest(
  {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'client-id': 'admin-web',
    },
    body: JSON.stringify({ ok: true }),
  },
  {
    algorithm: 'SHA256',
    protectedHeaders: ['client-id'],
  },
);
```

如果启用 `SM3`，需要由上层应用提供摘要实现：

```ts
await withBrickRequestDigest(requestInit, {
  algorithm: 'SM3',
  protectedHeaders: ['authorization', 'client-id'],
  digest: (raw) => sm3(raw),
});
```

## 传输信封

```ts
import {
  createBrickTransportEnvelope,
  openBrickTransportEnvelope,
} from '@wildbuck/core-transport-frontend';

const envelope = await createBrickTransportEnvelope(JSON.stringify({ ok: true }), {
  version: 'v1',
  timestamp: Date.now(),
  nonce: crypto.randomUUID().replaceAll('-', ''),
  encrypt: async (plaintext) => productEncrypt(plaintext),
  tag: async ({ version, timestamp, nonce, data }) => productTag({ version, timestamp, nonce, data }),
});

const plaintext = await openBrickTransportEnvelope(envelope, {
  tag: async ({ version, timestamp, nonce, data }) => productTag({ version, timestamp, nonce, data }),
  decrypt: async (data) => productDecrypt(data),
});
```

`tag` 规则与后端 `DefaultTransportEnvelopeCryptoService` 保持一致：上层应用对
`version + "\\n" + timestamp + "\\n" + nonce + "\\n" + data`
计算完整性校验值，并通过 `tag` 回调注入前端包。
