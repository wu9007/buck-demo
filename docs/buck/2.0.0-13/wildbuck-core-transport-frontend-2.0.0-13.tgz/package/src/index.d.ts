export type BrickTransportDigestAlgorithm = 'SHA256' | 'SHA-256' | 'SM3';

export interface BrickRequestDigestOptions {
  algorithm?: BrickTransportDigestAlgorithm;
  headers?: HeadersInit;
  protectedHeaders?: readonly string[];
  body?: string | null;
  digest?: (raw: string, algorithm: BrickTransportDigestAlgorithm) => string | Promise<string>;
}

export interface BrickRequestDigestInitOptions extends Omit<BrickRequestDigestOptions, 'headers' | 'body'> {
  headerName?: string;
}

export interface BrickTransportEnvelope {
  version: string;
  timestamp: number;
  nonce: string;
  data: string | null;
  tag: string | null;
}

export interface BrickTransportEnvelopeOptions {
  version?: string;
  timestamp?: number;
  nonce?: string;
  tag?: (
    envelope: Pick<BrickTransportEnvelope, 'version' | 'timestamp' | 'nonce' | 'data'>,
    options: BrickTransportEnvelopeOptions,
  ) => string | Promise<string>;
  encrypt?: (plaintext: string, options: BrickTransportEnvelopeOptions) => string | Promise<string>;
  decrypt?: (data: string, options: BrickTransportEnvelopeOptions) => string | Promise<string>;
}

export declare function createBrickRequestDigest(options?: BrickRequestDigestOptions): Promise<string>;

export declare function withBrickRequestDigest<T extends RequestInit>(
  init?: T,
  options?: BrickRequestDigestInitOptions,
): Promise<T & { headers: Record<string, string> }>;

export declare function createBrickTransportEnvelope(
  plaintext: string | null | undefined,
  options?: BrickTransportEnvelopeOptions,
): Promise<BrickTransportEnvelope>;

export declare function verifyBrickTransportEnvelope(
  envelope: BrickTransportEnvelope | null | undefined,
  options?: BrickTransportEnvelopeOptions,
): Promise<boolean>;

export declare function openBrickTransportEnvelope(
  envelope: BrickTransportEnvelope | null | undefined,
  options?: BrickTransportEnvelopeOptions,
): Promise<string | null>;
