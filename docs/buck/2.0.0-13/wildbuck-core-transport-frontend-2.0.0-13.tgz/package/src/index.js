function normalizeAlgorithm(algorithm) {
  const value = String(algorithm ?? 'SHA256').toUpperCase();
  if (value === 'SHA-256') return 'SHA256';
  if (value === 'SHA256' || value === 'SM3') return value;
  throw new TypeError(`Unsupported Buck transport digest algorithm: ${algorithm}`);
}

function normalizeEnvelopeVersion(version) {
  return String(version ?? 'v1');
}

function normalizeEnvelopeTimestamp(timestamp) {
  return timestamp == null ? Date.now() : Number(timestamp);
}

function normalizeEnvelopeNonce(nonce) {
  if (nonce != null && String(nonce).trim() !== '') {
    return String(nonce);
  }
  if (globalThis.crypto?.getRandomValues) {
    const bytes = new Uint8Array(16);
    globalThis.crypto.getRandomValues(bytes);
    return [...bytes].map((byte) => byte.toString(16).padStart(2, '0')).join('');
  }
  return `nonce-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function normalizeHeaders(headers) {
  if (headers == null) {
    return {};
  }
  if (headers instanceof Headers) {
    return Object.fromEntries([...headers.entries()]);
  }
  if (Array.isArray(headers)) {
    return Object.fromEntries(headers);
  }
  return { ...headers };
}

function canonicalHeaders(headers, protectedHeaders) {
  const source = normalizeHeaders(headers);
  const values = {};
  for (const headerName of protectedHeaders ?? []) {
    const normalizedName = String(headerName).toLowerCase();
    const matchedKey = Object.keys(source).find((key) => key.toLowerCase() === normalizedName);
    const value = matchedKey == null ? undefined : source[matchedKey];
    if (value != null && String(value).trim() !== '') {
      values[normalizedName] = String(value);
    }
  }
  if (Object.keys(values).length === 0) {
    return '';
  }
  return JSON.stringify(
    Object.fromEntries(Object.entries(values).sort(([left], [right]) => left.localeCompare(right))),
  );
}

function compactJsonIfPossible(body) {
  if (body == null || typeof body !== 'string' || body.trim() === '') {
    return body;
  }
  try {
    return JSON.stringify(JSON.parse(body));
  } catch {
    return body;
  }
}

function isMultipartBody(body) {
  return typeof FormData !== 'undefined' && body instanceof FormData;
}

async function sha256Hex(raw) {
  if (!globalThis.crypto?.subtle) {
    throw new Error('SHA-256 digest requires Web Crypto support');
  }
  const bytes = new TextEncoder().encode(raw);
  const digest = await globalThis.crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

export async function createBrickRequestDigest(options = {}) {
  const algorithm = normalizeAlgorithm(options.algorithm);
  const raw = createDigestSource(options.headers, options.protectedHeaders, options.body);

  if (algorithm === 'SHA256') {
    return sha256Hex(raw);
  }
  if (typeof options.digest === 'function') {
    return options.digest(raw, algorithm);
  }
  throw new Error('SM3 digest requires a custom digest provider on the frontend');
}

function createDigestSource(headers, protectedHeaders, body) {
  const normalizedBody = body == null || isMultipartBody(body) ? undefined : String(body);
  return canonicalHeaders(headers, protectedHeaders)
    + (normalizedBody == null ? '' : `&${compactJsonIfPossible(normalizedBody)}`);
}

export async function withBrickRequestDigest(init = {}, options = {}) {
  const headers = normalizeHeaders(init.headers);
  const headerName = options.headerName ?? 'rd';
  return {
    ...init,
    headers: {
      ...headers,
      [headerName]: await createBrickRequestDigest({
        ...options,
        headers,
        body: init.body,
      }),
    },
  };
}

export async function createBrickTransportEnvelope(plaintext, options = {}) {
  const version = normalizeEnvelopeVersion(options.version);
  const timestamp = normalizeEnvelopeTimestamp(options.timestamp);
  const nonce = normalizeEnvelopeNonce(options.nonce);
  const body = plaintext == null ? null : String(plaintext);
  if (body == null || body === '') {
    return {
      version,
      timestamp,
      nonce,
      data: body,
      tag: null,
    };
  }
  if (typeof options.encrypt !== 'function') {
    throw new Error('Buck transport envelope encryption requires an encrypt provider on the frontend');
  }
  const data = await options.encrypt(body, options);
  const envelope = {
    version,
    timestamp,
    nonce,
    data,
    tag: null,
  };
  const tag = await createBrickTransportTag(envelope, options);
  return {
    ...envelope,
    tag,
  };
}

export async function verifyBrickTransportEnvelope(envelope, options = {}) {
  if (envelope == null) {
    return false;
  }
  if (envelope.data == null || envelope.data === '') {
    return true;
  }
  const expectedTag = await createBrickTransportTag(envelope, options);
  return String(envelope.tag ?? '').toLowerCase() === expectedTag.toLowerCase();
}

export async function openBrickTransportEnvelope(envelope, options = {}) {
  if (envelope == null || envelope.data == null || envelope.data === '') {
    return envelope == null ? null : envelope.data;
  }
  if (!(await verifyBrickTransportEnvelope(envelope, options))) {
    throw new Error('Buck transport envelope tag verification failed');
  }
  if (typeof options.decrypt !== 'function') {
    throw new Error('Buck transport envelope decryption requires a decrypt provider on the frontend');
  }
  return options.decrypt(String(envelope.data), options);
}

async function createBrickTransportTag(envelope, options = {}) {
  if (typeof options.tag !== 'function') {
    throw new Error('Buck transport envelope tag generation requires a tag provider on the frontend');
  }
  return options.tag(
    {
      version: String(envelope.version ?? normalizeEnvelopeVersion(options.version)),
      timestamp: Number(envelope.timestamp ?? normalizeEnvelopeTimestamp(options.timestamp)),
      nonce: String(envelope.nonce ?? normalizeEnvelopeNonce(options.nonce)),
      data: envelope.data == null ? null : String(envelope.data),
    },
    options,
  );
}
