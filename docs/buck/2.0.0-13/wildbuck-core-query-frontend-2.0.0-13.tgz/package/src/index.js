export const QueryOperator = Object.freeze({
  EQUALS: 'eq',
  NOT_EQUALS: 'neq',
  GREATER_THAN: 'gt',
  GREATER_THAN_EQUALS: 'gte',
  LESS_THAN: 'lt',
  LESS_THAN_EQUALS: 'lte',
  LIKE_LEFT: 'lkl',
  LIKE_RIGHT: 'lkr',
  LIKE: 'lk',
  NOT_LIKE: 'notlk',
  IS_NULL: 'isn',
  IS_NOT_NULL: 'notn',
  BETWEEN: 'btw',
  IN: 'in',
  NOT_IN: 'notin',
});

export const QueryDirection = Object.freeze({
  ASC: 'ASC',
  DESC: 'DESC',
});

export const queryFilter = Object.freeze({
  eq: (property, value) => createQueryFilter(property, QueryOperator.EQUALS, value),
  neq: (property, value) => createQueryFilter(property, QueryOperator.NOT_EQUALS, value),
  gt: (property, value) => createQueryFilter(property, QueryOperator.GREATER_THAN, value),
  gte: (property, value) => createQueryFilter(property, QueryOperator.GREATER_THAN_EQUALS, value),
  lt: (property, value) => createQueryFilter(property, QueryOperator.LESS_THAN, value),
  lte: (property, value) => createQueryFilter(property, QueryOperator.LESS_THAN_EQUALS, value),
  like: (property, value) => createQueryFilter(property, QueryOperator.LIKE, value),
  likeLeft: (property, value) => createQueryFilter(property, QueryOperator.LIKE_LEFT, value),
  likeRight: (property, value) => createQueryFilter(property, QueryOperator.LIKE_RIGHT, value),
  notLike: (property, value) => createQueryFilter(property, QueryOperator.NOT_LIKE, value),
  isNull: (property) => createQueryFilter(property, QueryOperator.IS_NULL, null),
  isNotNull: (property) => createQueryFilter(property, QueryOperator.IS_NOT_NULL, null),
  between: (property, from, to) => createQueryFilter(property, QueryOperator.BETWEEN, [from, to]),
  in: (property, values) => createQueryFilter(property, QueryOperator.IN, values),
  notIn: (property, values) => createQueryFilter(property, QueryOperator.NOT_IN, values),
});

export const querySorter = Object.freeze({
  asc: (property) => createQuerySorter(property, QueryDirection.ASC),
  desc: (property) => createQuerySorter(property, QueryDirection.DESC),
});

export function createQueryCriteria(options = {}) {
  const queryCode = requiredText(options.queryCode, 'queryCode');
  const filterGroups = normalizeFilterGroups(options.filterGroups ?? options.filters ?? []);
  const sorters = normalizeSorters(options.sorters ?? options.querySorters ?? []);
  const criteria = {
    queryCode,
    topFilterType: normalizeTopFilterType(options.topFilterType),
    aggregatorList: [],
    memory: options.memory ?? true,
    withSignature: options.withSignature ?? false,
  };

  if (filterGroups.length > 0) {
    criteria.filtersGroup = filterGroups;
  }
  if (sorters.length > 0) {
    criteria.querySorters = sorters;
  }
  if (options.pager !== false) {
    criteria.queryPager = createQueryPager({
      current: options.current ?? options.pageNo ?? options.page ?? options.pager?.current ?? 1,
      size: options.size ?? options.pageSize ?? options.pager?.size ?? 20,
    });
  }
  const columns = normalizeTextArray(options.columns ?? options.specifyColumns ?? []);
  if (columns.length > 0) {
    criteria.specifyColumns = columns;
  }
  if (options.extended != null) {
    criteria.extended = options.extended;
  }
  return criteria;
}

export function createQueryFilter(property, operator = QueryOperator.EQUALS, value = null) {
  return {
    property: requiredText(property, 'property'),
    operator: requiredText(operator, 'operator').toLowerCase(),
    value: normalizeFilterValue(operator, value),
  };
}

export function createQuerySorter(property, direction = QueryDirection.ASC) {
  const normalized = String(direction ?? QueryDirection.ASC).trim().toUpperCase();
  if (!Object.values(QueryDirection).includes(normalized)) {
    throw new TypeError(`Unsupported query sorter direction: ${direction}`);
  }
  return {
    property: requiredText(property, 'property'),
    direction: normalized,
  };
}

export function createQueryPager({ current = 1, size = 20 } = {}) {
  const normalizedCurrent = positiveInteger(current, 'current');
  const normalizedSize = positiveInteger(size, 'size');
  return {
    current: normalizedCurrent,
    size: normalizedSize,
  };
}

export function createFilterGroup(...filters) {
  return filters.flat().filter(Boolean).map(normalizeFilter);
}

function normalizeFilterGroups(groups) {
  if (!Array.isArray(groups)) {
    throw new TypeError('filterGroups must be an array');
  }
  if (groups.length === 0) {
    return [];
  }
  const normalized = groups.every((item) => item && !Array.isArray(item))
    ? [groups]
    : groups;
  return normalized
    .map((group) => createFilterGroup(group))
    .filter((group) => group.length > 0);
}

function normalizeFilter(filter) {
  if (filter == null || typeof filter !== 'object') {
    throw new TypeError('query filter must be an object');
  }
  return createQueryFilter(filter.property, filter.operator, filter.value);
}

function normalizeSorters(sorters) {
  if (!Array.isArray(sorters)) {
    throw new TypeError('sorters must be an array');
  }
  return sorters.filter(Boolean).map((sorter) => createQuerySorter(sorter.property, sorter.direction));
}

function normalizeFilterValue(operator, value) {
  const normalizedOperator = String(operator ?? QueryOperator.EQUALS).toLowerCase();
  if (normalizedOperator === QueryOperator.BETWEEN) {
    if (!Array.isArray(value) || value.length !== 2 || value.some((item) => item == null)) {
      throw new TypeError('between filter value must contain exactly two values');
    }
    return value;
  }
  if ([QueryOperator.IN, QueryOperator.NOT_IN].includes(normalizedOperator)) {
    return Array.isArray(value) ? value : [value];
  }
  return value;
}

function normalizeTopFilterType(value) {
  const normalized = String(value ?? 'and').trim().toLowerCase();
  if (!['and', 'or'].includes(normalized)) {
    throw new TypeError(`Unsupported topFilterType: ${value}`);
  }
  return normalized;
}

function normalizeTextArray(values) {
  if (!Array.isArray(values)) {
    throw new TypeError('columns must be an array');
  }
  return values.map((value) => requiredText(value, 'column'));
}

function requiredText(value, name) {
  const text = String(value ?? '').trim();
  if (!text) {
    throw new TypeError(`Query ${name} must not be blank`);
  }
  return text;
}

function positiveInteger(value, name) {
  const number = Number(value);
  if (!Number.isInteger(number) || number <= 0) {
    throw new TypeError(`Query pager ${name} must be a positive integer`);
  }
  return number;
}
