export declare const QueryOperator: Readonly<{
  EQUALS: 'eq';
  NOT_EQUALS: 'neq';
  GREATER_THAN: 'gt';
  GREATER_THAN_EQUALS: 'gte';
  LESS_THAN: 'lt';
  LESS_THAN_EQUALS: 'lte';
  LIKE_LEFT: 'lkl';
  LIKE_RIGHT: 'lkr';
  LIKE: 'lk';
  NOT_LIKE: 'notlk';
  IS_NULL: 'isn';
  IS_NOT_NULL: 'notn';
  BETWEEN: 'btw';
  IN: 'in';
  NOT_IN: 'notin';
}>;

export declare const QueryDirection: Readonly<{
  ASC: 'ASC';
  DESC: 'DESC';
}>;

export interface QueryFilter {
  property: string;
  operator: string;
  value: unknown;
}

export interface QuerySorter {
  property: string;
  direction: 'ASC' | 'DESC';
}

export interface QueryPager {
  current: number;
  size: number;
}

export interface QueryCriteria {
  queryCode: string;
  filtersGroup?: QueryFilter[][];
  topFilterType: 'and' | 'or';
  aggregatorList: unknown[];
  querySorters?: QuerySorter[];
  queryPager?: QueryPager;
  specifyColumns?: string[];
  memory: boolean;
  extended?: Record<string, unknown>;
  withSignature: boolean;
}

export interface CreateQueryCriteriaOptions {
  queryCode: string;
  filters?: QueryFilter[] | QueryFilter[][];
  filterGroups?: QueryFilter[] | QueryFilter[][];
  sorters?: QuerySorter[];
  querySorters?: QuerySorter[];
  pager?: false | Partial<QueryPager>;
  page?: number;
  pageNo?: number;
  pageSize?: number;
  current?: number;
  size?: number;
  columns?: string[];
  specifyColumns?: string[];
  topFilterType?: 'and' | 'or';
  memory?: boolean;
  withSignature?: boolean;
  extended?: Record<string, unknown>;
}

export declare const queryFilter: Readonly<{
  eq(property: string, value: unknown): QueryFilter;
  neq(property: string, value: unknown): QueryFilter;
  gt(property: string, value: unknown): QueryFilter;
  gte(property: string, value: unknown): QueryFilter;
  lt(property: string, value: unknown): QueryFilter;
  lte(property: string, value: unknown): QueryFilter;
  like(property: string, value: unknown): QueryFilter;
  likeLeft(property: string, value: unknown): QueryFilter;
  likeRight(property: string, value: unknown): QueryFilter;
  notLike(property: string, value: unknown): QueryFilter;
  isNull(property: string): QueryFilter;
  isNotNull(property: string): QueryFilter;
  between(property: string, from: unknown, to: unknown): QueryFilter;
  in(property: string, values: unknown[]): QueryFilter;
  notIn(property: string, values: unknown[]): QueryFilter;
}>;

export declare const querySorter: Readonly<{
  asc(property: string): QuerySorter;
  desc(property: string): QuerySorter;
}>;

export declare function createQueryCriteria(options: CreateQueryCriteriaOptions): QueryCriteria;
export declare function createQueryFilter(property: string, operator?: string, value?: unknown): QueryFilter;
export declare function createQuerySorter(property: string, direction?: string): QuerySorter;
export declare function createQueryPager(options?: Partial<QueryPager>): QueryPager;
export declare function createFilterGroup(...filters: Array<QueryFilter | QueryFilter[]>): QueryFilter[];
