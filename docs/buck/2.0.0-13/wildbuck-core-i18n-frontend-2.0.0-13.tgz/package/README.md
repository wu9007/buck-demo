# @wildbuck/core-i18n-frontend

`@wildbuck/core-i18n-frontend` 是 `core:i18n` 的前端入口：提供 **locale 归一**、**词条 runtime（`t`）**、**请求级 locale 头** 与 Element Plus locale 选择辅助。

它不维护业务页面文案全集，也不替代后端 `MessageSource`。业务错误正文仍优先展示服务端已按请求 locale 本地化后的 `message`。

## 产品边界

| 项 | 约定 |
| --- | --- |
| 用户偏好真源（本里程碑） | 前端 `appearance.locale`（本机），不做账号 DB |
| 生效 locale | i18n runtime `getLocale()` |
| 前后端一致 | 每个 HTTP 请求带 `Accept-Language` + `X-Brick-Locale` |
| 词条覆盖 | core 基线 ← 模块 `registerMessages` ← 业务覆盖 |
| 未迁词条的页面 | 可能仍中文，属覆盖度，不是协议失败 |
| 侧栏菜单 title | **业务数据原文**（菜单管理录入 / 导航 API）；**不**做框架自动 i18n，禁止壳内菜单译文表 |

## 最小接入

```js
import {
  BRICK_DEFAULT_LOCALE,
  applyBrickDocumentLang,
  createBrickI18nRuntime,
  createBrickLocaleAwarePrepareRequest,
  normalizeBrickLocale,
  pickBrickElementPlusLocale,
} from '@wildbuck/core-i18n-frontend';
import { configureHttp } from '@wildbuck/core-api-frontend';
import { readBrickConsoleAppearancePreference } from '@wildbuck/core-ui-frontend/appearance';
import en from 'element-plus/es/locale/lang/en';
import zhCn from 'element-plus/es/locale/lang/zh-cn';

const appearance = readBrickConsoleAppearancePreference();
const i18n = createBrickI18nRuntime({
  locale: appearance.locale,
  messages: {
    'core.ui.userMenu.logout': '退出登录',
  },
});

// 与 appearance 联动：setAppearance({ locale }) 后调用 i18n.setLocale(locale)
applyBrickDocumentLang(i18n.getLocale());

configureHttp({
  baseUrl: '',
  // 也可只设 localeProvider（见 @wildbuck/core-api-frontend），二选一或组合
  prepareRequest: createBrickLocaleAwarePrepareRequest({
    getLocale: () => i18n.getLocale(),
    prepareRequest: (path, init) => ({
      ...init,
      headers: {
        ...init.headers,
        // Authorization: ...
      },
    }),
  }),
});

const elementLocale = pickBrickElementPlusLocale(i18n.getLocale(), { zhCn, en });
i18n.t('core.ui.userMenu.logout');
normalizeBrickLocale('en'); // -> en-US
```

## 与 appearance 的关系

- `createBrickConsoleAppearanceRuntime` 负责持久化 `locale` 偏好。
- `createBrickI18nRuntime` 负责生效文案与 `t()`。
- 壳层在 `setAppearance({ locale })` 时同步 `i18n.setLocale`、`applyBrickDocumentLang`、Element Plus `ElConfigProvider`。
- 不要在业务页面各自 `watch(locale)` 拼翻译 if 分支。

## 模块词条

```js
i18n.registerMessages('module-iam', {
  'module.iam.auth.loginSuccess': '登录成功',
});
```

key 建议：`core.*` / `module.<moduleId>.*` / 业务自有前缀。稳定、可 AI 生成，避免用中文当 key。
