export type BrickLocaleName = 'zh-CN' | 'en-US';

export declare const BRICK_LOCALE_NAMES: readonly BrickLocaleName[];
export declare const BRICK_DEFAULT_LOCALE: BrickLocaleName;
export declare const BRICK_LOCALE_HEADER: 'X-Brick-Locale';

export interface BrickI18nSnapshot {
  locale: BrickLocaleName;
  messages: Record<string, unknown>;
  revision: number;
}

export interface BrickI18nRuntime {
  t(key: string, params?: Record<string, unknown>): string;
  /** True when key resolves to a non-object message value. */
  has(key: string): boolean;
  /** Keys from requiredKeys that are missing in the composed dictionary. */
  listMissingKeys(requiredKeys?: string[]): string[];
  setLocale(locale?: string): BrickI18nSnapshot;
  getLocale(): BrickLocaleName;
  getRevision(): number;
  registerMessages(source: string, dict?: Record<string, unknown> | null): BrickI18nSnapshot;
  getMessages(): Record<string, unknown>;
  read(): BrickI18nSnapshot;
  /** Notify hosts (e.g. Vue) when locale or message layers change. */
  subscribe(listener: (snapshot: BrickI18nSnapshot) => void): () => void;
}

export interface BrickI18nCatalogDiff {
  primaryOnly: string[];
  secondaryOnly: string[];
  emptyKeys: string[];
  placeholderMismatches: Array<{ key: string; primary: string[]; secondary: string[] }>;
  identicalValues: string[];
}

export interface BrickI18nRuntimeOptions {
  locale?: string;
  fallbackLocale?: string;
  messages?: Record<string, unknown>;
  onChange?: (snapshot: BrickI18nSnapshot) => void;
  missingReturnsKey?: boolean;
}

export interface BrickLocaleAwarePrepareRequestOptions {
  getLocale?: () => string;
  prepareRequest?: (
    path: string,
    init: RequestInit,
  ) => RequestInit | Promise<RequestInit>;
}

export declare function normalizeBrickLocale(value?: unknown, fallback?: string): BrickLocaleName;
export declare function toBrickHtmlLang(locale?: unknown): string;
export declare function buildBrickLocaleHeaders(locale?: unknown): Readonly<Record<string, string>>;
export declare function mergeBrickI18nMessages(...layers: Array<Record<string, unknown> | null | undefined>): Record<string, unknown>;
export declare function formatBrickI18nMessage(template: string, params?: Record<string, unknown>): string;
export declare function resolveBrickI18nMessage(messages: Record<string, unknown>, key: string): unknown;
export declare function createBrickI18nRuntime(options?: BrickI18nRuntimeOptions): BrickI18nRuntime;
export declare function applyBrickLocaleHeaders(
  headers?: Record<string, string>,
  locale?: unknown,
): Record<string, string>;
export declare function createBrickLocaleAwarePrepareRequest(
  options?: BrickLocaleAwarePrepareRequestOptions,
): (path: string, init?: RequestInit) => Promise<RequestInit>;
export declare function pickBrickElementPlusLocale(
  locale: unknown,
  packs: { zhCn?: object; en?: object },
): object | null;
export declare function applyBrickDocumentLang(locale?: unknown): void;
export declare function extractBrickI18nPlaceholders(template?: unknown): string[];
export declare function flattenBrickI18nMessages(
  messages?: Record<string, unknown>,
  prefix?: string,
): Record<string, string>;
export declare function compareBrickI18nCatalogs(
  primary?: Record<string, unknown>,
  secondary?: Record<string, unknown>,
): BrickI18nCatalogDiff;
export declare function createBrickPseudoLocaleMessages(
  messages?: Record<string, unknown>,
  options?: { expandRatio?: number; prefix?: string; suffix?: string },
): Record<string, string>;
export declare function hasBrickI18nMessage(messages: Record<string, unknown>, key: string): boolean;
