/** Canonical Buck UI locales. Keep aligned with core-ui appearance and backend supported locales. */
export const BRICK_LOCALE_NAMES = Object.freeze(['zh-CN', 'en-US']);
export const BRICK_DEFAULT_LOCALE = 'zh-CN';
export const BRICK_LOCALE_HEADER = 'X-Brick-Locale';

/**
 * Normalize free-form locale tags to a Buck canonical locale.
 * @param {unknown} value
 * @param {string} [fallback=BRICK_DEFAULT_LOCALE]
 * @returns {'zh-CN'|'en-US'}
 */
export function normalizeBrickLocale(value, fallback = BRICK_DEFAULT_LOCALE) {
  const raw = String(value ?? '').trim();
  if (!raw) {
    return BRICK_LOCALE_NAMES.includes(fallback) ? fallback : BRICK_DEFAULT_LOCALE;
  }
  const normalized = raw.replace(/_/g, '-');
  const lower = normalized.toLowerCase();
  if (lower === 'zh-cn' || lower === 'zh-hans' || lower === 'zh-hans-cn' || lower === 'zh') {
    return 'zh-CN';
  }
  if (lower === 'en-us' || lower === 'en' || lower.startsWith('en-')) {
    return 'en-US';
  }
  if (BRICK_LOCALE_NAMES.includes(normalized)) {
    return normalized;
  }
  return BRICK_LOCALE_NAMES.includes(fallback) ? fallback : BRICK_DEFAULT_LOCALE;
}

/**
 * HTML lang attribute for document.documentElement.
 * @param {unknown} locale
 * @returns {string}
 */
export function toBrickHtmlLang(locale) {
  const normalized = normalizeBrickLocale(locale);
  return normalized === 'en-US' ? 'en' : 'zh-CN';
}

/**
 * Build request headers that bind the active locale for backend MessageSource.
 * @param {unknown} locale
 * @returns {Record<string, string>}
 */
export function buildBrickLocaleHeaders(locale) {
  const normalized = normalizeBrickLocale(locale);
  return Object.freeze({
    'Accept-Language': normalized,
    [BRICK_LOCALE_HEADER]: normalized,
  });
}

/**
 * Deep-merge message dictionaries. Later layers override earlier keys.
 * Nested plain objects are merged; arrays and primitives replace.
 * @param {...Record<string, unknown>} layers
 * @returns {Record<string, unknown>}
 */
export function mergeBrickI18nMessages(...layers) {
  const result = {};
  for (const layer of layers) {
    if (layer == null || typeof layer !== 'object' || Array.isArray(layer)) {
      continue;
    }
    deepMergeInto(result, layer);
  }
  return result;
}

/**
 * Interpolate `{name}` placeholders in a message template.
 * @param {string} template
 * @param {Record<string, unknown>} [params]
 * @returns {string}
 */
export function formatBrickI18nMessage(template, params = {}) {
  const source = String(template ?? '');
  if (!params || typeof params !== 'object') {
    return source;
  }
  return source.replace(/\{([A-Za-z_]\w*)\}/g, (match, key) => {
    if (!Object.prototype.hasOwnProperty.call(params, key) || params[key] == null) {
      return match;
    }
    return String(params[key]);
  });
}

/**
 * Resolve a message key. Prefers an exact flat key, then nested dotted path.
 * @param {Record<string, unknown>} messages
 * @param {string} key
 * @returns {unknown}
 */
export function resolveBrickI18nMessage(messages, key) {
  if (messages == null || typeof messages !== 'object') {
    return undefined;
  }
  const fullKey = String(key ?? '');
  if (!fullKey) {
    return undefined;
  }
  if (Object.prototype.hasOwnProperty.call(messages, fullKey)) {
    return messages[fullKey];
  }
  const path = fullKey.split('.').filter(Boolean);
  if (path.length === 0) {
    return undefined;
  }
  let current = messages;
  for (const segment of path) {
    if (current == null || typeof current !== 'object' || Array.isArray(current)) {
      return undefined;
    }
    current = current[segment];
  }
  return current;
}

/**
 * Create a locale + dictionary runtime for shells and modules.
 * @param {object} [options]
 * @param {string} [options.locale]
 * @param {string} [options.fallbackLocale]
 * @param {Record<string, unknown>} [options.messages]
 * @param {(snapshot: { locale: string, messages: Record<string, unknown> }) => void} [options.onChange]
 * @param {boolean} [options.missingReturnsKey=true]
 */
export function createBrickI18nRuntime({
  locale = BRICK_DEFAULT_LOCALE,
  fallbackLocale = BRICK_DEFAULT_LOCALE,
  messages = {},
  onChange,
  missingReturnsKey = true,
} = {}) {
  const emit = typeof onChange === 'function' ? onChange : null;
  let activeLocale = normalizeBrickLocale(locale, fallbackLocale);
  let revision = 0;
  /** @type {Set<(snapshot: { locale: string, messages: Record<string, unknown>, revision: number }) => void>} */
  const listeners = new Set();
  /** @type {Map<string, Record<string, unknown>>} */
  const layers = new Map();
  if (messages && typeof messages === 'object' && !Array.isArray(messages)) {
    layers.set('default', { ...messages });
  }

  function composedMessages() {
    return mergeBrickI18nMessages(...layers.values());
  }

  function snapshot() {
    return Object.freeze({
      locale: activeLocale,
      messages: composedMessages(),
      revision,
    });
  }

  function notify() {
    revision += 1;
    const next = snapshot();
    if (emit) {
      emit(next);
    }
    for (const listener of listeners) {
      try {
        listener(next);
      } catch {
        // Subscriber failures must not break locale updates.
      }
    }
  }

  function t(key, params) {
    const dict = composedMessages();
    const resolved = resolveBrickI18nMessage(dict, key);
    if (typeof resolved === 'string') {
      return formatBrickI18nMessage(resolved, params);
    }
    if (resolved != null && typeof resolved !== 'object') {
      return String(resolved);
    }
    return missingReturnsKey ? String(key ?? '') : '';
  }

  function has(key) {
    return hasBrickI18nMessage(composedMessages(), key);
  }

  /**
   * @param {string[]} requiredKeys
   * @returns {string[]}
   */
  function listMissingKeys(requiredKeys = []) {
    if (!Array.isArray(requiredKeys)) {
      return [];
    }
    const dict = composedMessages();
    return requiredKeys
      .map((key) => String(key ?? ''))
      .filter((key) => key && !hasBrickI18nMessage(dict, key));
  }

  function setLocale(nextLocale) {
    const normalized = normalizeBrickLocale(nextLocale, fallbackLocale);
    if (normalized === activeLocale) {
      return snapshot();
    }
    activeLocale = normalized;
    notify();
    return snapshot();
  }

  function getLocale() {
    return activeLocale;
  }

  function getRevision() {
    return revision;
  }

  /**
   * Register or replace a named message layer (e.g. core-ui, module-iam, app).
   * @param {string} source
   * @param {Record<string, unknown>} dict
   */
  function registerMessages(source, dict) {
    const name = String(source ?? '').trim() || 'anonymous';
    if (dict == null || typeof dict !== 'object' || Array.isArray(dict)) {
      layers.delete(name);
    } else {
      layers.set(name, { ...dict });
    }
    notify();
    return snapshot();
  }

  function getMessages() {
    return composedMessages();
  }

  /**
   * Subscribe to locale / message-table changes so Vue (or other hosts) can re-render.
   * @param {(snapshot: { locale: string, messages: Record<string, unknown>, revision: number }) => void} listener
   * @returns {() => void} unsubscribe
   */
  function subscribe(listener) {
    if (typeof listener !== 'function') {
      return () => {};
    }
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }

  return Object.freeze({
    t,
    has,
    listMissingKeys,
    setLocale,
    getLocale,
    getRevision,
    registerMessages,
    getMessages,
    read: snapshot,
    subscribe,
  });
}

/**
 * Apply Buck locale headers onto a RequestInit-like headers bag.
 * Existing Accept-Language / X-Brick-Locale from the caller win.
 * @param {Record<string, string>} headers
 * @param {unknown} locale
 * @returns {Record<string, string>}
 */
export function applyBrickLocaleHeaders(headers = {}, locale) {
  const localeHeaders = buildBrickLocaleHeaders(locale);
  const next = { ...headers };
  if (!hasHeader(next, 'Accept-Language')) {
    next['Accept-Language'] = localeHeaders['Accept-Language'];
  }
  if (!hasHeader(next, BRICK_LOCALE_HEADER)) {
    next[BRICK_LOCALE_HEADER] = localeHeaders[BRICK_LOCALE_HEADER];
  }
  return next;
}

/**
 * Compose prepareRequest hooks so locale headers are always injected.
 * @param {object} [options]
 * @param {() => string} [options.getLocale]
 * @param {(path: string, init: RequestInit) => RequestInit|Promise<RequestInit>} [options.prepareRequest]
 */
export function createBrickLocaleAwarePrepareRequest({
  getLocale = () => BRICK_DEFAULT_LOCALE,
  prepareRequest,
} = {}) {
  return async function prepareBrickLocaleRequest(path, init = {}) {
    const baseInit = typeof prepareRequest === 'function'
      ? await prepareRequest(path, init)
      : init;
    const headers = normalizeHeaderRecord(baseInit?.headers);
    const locale = typeof getLocale === 'function' ? getLocale() : BRICK_DEFAULT_LOCALE;
    return {
      ...baseInit,
      headers: applyBrickLocaleHeaders(headers, locale),
    };
  };
}

/**
 * Map Buck locale to a static Element Plus locale pack supplied by the app.
 * @param {unknown} locale
 * @param {{ zhCn: object, en: object }} packs
 */
export function pickBrickElementPlusLocale(locale, packs) {
  const normalized = normalizeBrickLocale(locale);
  if (normalized === 'en-US') {
    return packs?.en ?? packs?.zhCn ?? null;
  }
  return packs?.zhCn ?? packs?.en ?? null;
}

/**
 * Sync documentElement.lang when running in a browser.
 * @param {unknown} locale
 */
export function applyBrickDocumentLang(locale) {
  if (typeof document === 'undefined' || !document.documentElement) {
    return;
  }
  document.documentElement.lang = toBrickHtmlLang(locale);
}

/**
 * Extract `{name}` placeholder ids from a message template (sorted unique).
 * @param {unknown} template
 * @returns {string[]}
 */
export function extractBrickI18nPlaceholders(template) {
  const source = String(template ?? '');
  const found = new Set();
  for (const match of source.matchAll(/\{([A-Za-z_]\w*)\}/g)) {
    found.add(match[1]);
  }
  return [...found].sort();
}

/**
 * Compare two flat/nested message catalogs for production catalog quality.
 * @param {Record<string, unknown>} primary
 * @param {Record<string, unknown>} secondary
 * @returns {{
 *   primaryOnly: string[],
 *   secondaryOnly: string[],
 *   emptyKeys: string[],
 *   placeholderMismatches: Array<{ key: string, primary: string[], secondary: string[] }>,
 *   identicalValues: string[],
 * }}
 */
export function compareBrickI18nCatalogs(primary = {}, secondary = {}) {
  const primaryFlat = flattenBrickI18nMessages(primary);
  const secondaryFlat = flattenBrickI18nMessages(secondary);
  const primaryKeys = new Set(Object.keys(primaryFlat));
  const secondaryKeys = new Set(Object.keys(secondaryFlat));
  const primaryOnly = [...primaryKeys].filter((key) => !secondaryKeys.has(key)).sort();
  const secondaryOnly = [...secondaryKeys].filter((key) => !primaryKeys.has(key)).sort();
  const emptyKeys = [...primaryKeys]
    .filter((key) => {
      const left = String(primaryFlat[key] ?? '').trim();
      const right = String(secondaryFlat[key] ?? '').trim();
      return !left || !right;
    })
    .sort();
  const placeholderMismatches = [];
  const identicalValues = [];
  for (const key of primaryKeys) {
    if (!secondaryKeys.has(key)) {
      continue;
    }
    const left = String(primaryFlat[key] ?? '');
    const right = String(secondaryFlat[key] ?? '');
    const leftPlaceholders = extractBrickI18nPlaceholders(left);
    const rightPlaceholders = extractBrickI18nPlaceholders(right);
    if (leftPlaceholders.join(',') !== rightPlaceholders.join(',')) {
      placeholderMismatches.push({
        key,
        primary: leftPlaceholders,
        secondary: rightPlaceholders,
      });
    }
    // Identical user-facing copy across locales is usually a localization miss
    // (except short proper nouns / brand tokens).
    if (left && right && left === right && left.length > 2 && !/^[\d\s.,:;/+_-]+$/.test(left)) {
      identicalValues.push(key);
    }
  }
  return {
    primaryOnly,
    secondaryOnly,
    emptyKeys,
    placeholderMismatches,
    identicalValues,
  };
}

/**
 * Flatten nested message objects into dotted keys for catalog audits.
 * @param {Record<string, unknown>} messages
 * @param {string} [prefix]
 * @returns {Record<string, string>}
 */
export function flattenBrickI18nMessages(messages = {}, prefix = '') {
  const result = {};
  if (messages == null || typeof messages !== 'object' || Array.isArray(messages)) {
    return result;
  }
  for (const [key, value] of Object.entries(messages)) {
    const path = prefix ? `${prefix}.${key}` : key;
    if (value != null && typeof value === 'object' && !Array.isArray(value)) {
      Object.assign(result, flattenBrickI18nMessages(value, path));
    } else if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
      result[path] = String(value);
    }
  }
  return result;
}

/**
 * Build pseudo-localized strings for layout expansion checks (UX i18n practice).
 * Expands length and wraps with markers so missing localizations stand out.
 * @param {Record<string, unknown>} messages
 * @param {{ expandRatio?: number, prefix?: string, suffix?: string }} [options]
 * @returns {Record<string, string>}
 */
export function createBrickPseudoLocaleMessages(messages = {}, options = {}) {
  const expandRatio = Number(options.expandRatio ?? 1.35);
  const prefix = options.prefix ?? '⟦';
  const suffix = options.suffix ?? '⟧';
  const flat = flattenBrickI18nMessages(messages);
  const result = {};
  for (const [key, value] of Object.entries(flat)) {
    const source = String(value);
    // Preserve placeholders while expanding surrounding text.
    const placeholders = [];
    const withoutPlaceholders = source.replace(/\{([A-Za-z_]\w*)\}/g, (match) => {
      placeholders.push(match);
      return `\u0000${placeholders.length - 1}\u0000`;
    });
    const targetLength = Math.max(source.length, Math.ceil(source.length * expandRatio));
    let expanded = withoutPlaceholders;
    const filler = '··';
    while (expanded.length < targetLength) {
      expanded += filler;
    }
    expanded = expanded.slice(0, targetLength);
    const restored = expanded.replace(/\u0000(\d+)\u0000/g, (_, index) => placeholders[Number(index)] ?? '');
    result[key] = `${prefix}${restored}${suffix}`;
  }
  return result;
}

/**
 * Whether a message key resolves to a string (or non-object primitive) in the catalog.
 * @param {Record<string, unknown>} messages
 * @param {string} key
 * @returns {boolean}
 */
export function hasBrickI18nMessage(messages, key) {
  const resolved = resolveBrickI18nMessage(messages, key);
  return resolved != null && typeof resolved !== 'object';
}

function deepMergeInto(target, source) {
  for (const [key, value] of Object.entries(source)) {
    if (value != null && typeof value === 'object' && !Array.isArray(value)
      && target[key] != null && typeof target[key] === 'object' && !Array.isArray(target[key])) {
      deepMergeInto(target[key], value);
    } else {
      target[key] = value;
    }
  }
}

function hasHeader(headers, name) {
  const target = String(name).toLowerCase();
  return Object.keys(headers).some((key) => key.toLowerCase() === target);
}

function normalizeHeaderRecord(headers) {
  if (headers == null) {
    return {};
  }
  if (typeof Headers !== 'undefined' && headers instanceof Headers) {
    return Object.fromEntries([...headers.entries()]);
  }
  if (Array.isArray(headers)) {
    return Object.fromEntries(headers);
  }
  return { ...headers };
}
