<script setup>
/**
 * Login appearance admin feature page.
 * Production UX rounds: named templates, live preview (desktop/mobile),
 * dirty-state + beforeunload, factory reset confirm,
 * usage-event tracking, client validation, retry on load failure.
 */
import { computed, inject, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { ElMessageBox } from 'element-plus';
import { showBrickStatus } from '@wildbuck/core-ui-frontend/status';
import { BrickPageHeader } from '@wildbuck/core-ui-frontend';
import {
  BrickColorField,
  BrickImageUploadField,
  createBrickLocalImagePreview,
  revokeBrickImagePreview,
  uploadBrickImageResource,
} from '@wildbuck/core-ui-frontend/fields';
import '@wildbuck/core-ui-frontend/settings-page.css';
import {
  BRICK_CONSOLE_I18N_INJECTION_KEY,
  BRICK_CONSOLE_I18N_INJECTION_KEY_STRING,
} from '@wildbuck/core-ui-frontend/i18n';
import { resolveLoginBrandMessages } from '../../../i18n.js';
import { loginBrandUsageTracker } from '../../../usage-events.js';
import {
  loadLoginBrandSetting,
  resetLoginBrandSetting,
  saveLoginBrandSetting,
} from '../api/login-brand-appearance.js';
import {
  LAYOUT_TEMPLATES,
  PRIMARY_COLOR_MODE_CUSTOM,
  PRIMARY_COLOR_MODE_FOLLOW_THEME,
  applyLayoutTemplate,
  applyPrimaryColorMode,
  applySettingToForm,
  createEmptyForm,
  isDirty,
  toUpdatePayload,
  validateForm,
} from '../lib/login-brand-form.js';

const injectedI18n = inject(BRICK_CONSOLE_I18N_INJECTION_KEY, null)
  || inject(BRICK_CONSOLE_I18N_INJECTION_KEY_STRING, null);

function t(key) {
  if (injectedI18n?.t) {
    const value = injectedI18n.t(key);
    if (value && value !== key) {
      return value;
    }
  }
  const pack = resolveLoginBrandMessages(injectedI18n?.getLocale?.() || 'zh-CN');
  return pack[key] || key;
}

const loading = ref(true);
const loadError = ref('');
const saving = ref(false);
const logoUploading = ref(false);
const backgroundUploading = ref(false);
const previewDevice = ref('desktop');
const form = ref(createEmptyForm());
const baseline = ref(createEmptyForm());
/** Local object URLs for unsaved uploads — <img> cannot use authenticated /file-resources/.../content. */
const localObjectUrls = ref([]);

function trackLocalObjectUrl(url) {
  if (url && String(url).startsWith('blob:')) {
    localObjectUrls.value.push(url);
  }
  return url;
}

function revokeLocalObjectUrls() {
  for (const url of localObjectUrls.value) {
    revokeBrickImagePreview(url);
  }
  localObjectUrls.value = [];
}

const dirty = computed(() => isDirty(form.value, baseline.value));
const clientValidationKey = computed(() => validateForm(form.value));
const canSave = computed(() => dirty.value && !clientValidationKey.value && !saving.value);
const primaryColorModeOptions = computed(() => ([
  { value: PRIMARY_COLOR_MODE_FOLLOW_THEME, label: t('module.login-brand.option.primary.FOLLOW_THEME') },
  { value: PRIMARY_COLOR_MODE_CUSTOM, label: t('module.login-brand.option.primary.CUSTOM') },
]));

function onPrimaryColorModeChange(mode) {
  form.value = applyPrimaryColorMode(form.value, mode);
}

const backgroundModeOptions = computed(() => ([
  { value: 'NONE', label: t('module.login-brand.option.background.NONE') },
  { value: 'SOLID', label: t('module.login-brand.option.background.SOLID') },
  { value: 'IMAGE', label: t('module.login-brand.option.background.IMAGE') },
  { value: 'SOFT_GRADIENT', label: t('module.login-brand.option.background.SOFT_GRADIENT') },
]));
const formPositionOptions = computed(() => ([
  { value: 'CENTER', label: t('module.login-brand.option.form.CENTER') },
  { value: 'LEFT', label: t('module.login-brand.option.form.LEFT') },
  { value: 'RIGHT', label: t('module.login-brand.option.form.RIGHT') },
]));
const brandPositionOptions = computed(() => ([
  { value: 'ABOVE_FORM', label: t('module.login-brand.option.brand.ABOVE_FORM') },
  { value: 'BELOW_FORM', label: t('module.login-brand.option.brand.BELOW_FORM') },
  { value: 'LEFT_PANEL', label: t('module.login-brand.option.brand.LEFT_PANEL') },
  { value: 'RIGHT_PANEL', label: t('module.login-brand.option.brand.RIGHT_PANEL') },
  { value: 'TOP_BAR', label: t('module.login-brand.option.brand.TOP_BAR') },
]));
const templateOptions = computed(() => ([
  {
    id: 'MINIMAL_CENTER',
    label: t('module.login-brand.template.MINIMAL_CENTER'),
    hint: t('module.login-brand.template.MINIMAL_CENTER.hint'),
  },
  {
    id: 'GOV_SPLIT_LEFT',
    label: t('module.login-brand.template.GOV_SPLIT_LEFT'),
    hint: t('module.login-brand.template.GOV_SPLIT_LEFT.hint'),
  },
  {
    id: 'FORM_LEFT_BRAND_RIGHT',
    label: t('module.login-brand.template.FORM_LEFT_BRAND_RIGHT'),
    hint: t('module.login-brand.template.FORM_LEFT_BRAND_RIGHT.hint'),
  },
]));

/** Fallback mark when no logo: first character of system name (brandMark field removed from UI). */
const displayBrandMark = computed(() => {
  const mark = String(form.value.brandMark || '').trim();
  if (mark) {
    return mark.slice(0, 2);
  }
  const name = String(form.value.systemName || '').trim();
  return name ? name.slice(0, 1) : '';
});

/** High-fidelity preview shell style — mirrors IamAuthFlowView shellStyle + primary button token. */
const previewShellStyle = computed(() => {
  const style = {};
  if (form.value.primaryColorMode === PRIMARY_COLOR_MODE_CUSTOM && form.value.primaryColor) {
    const primary = form.value.primaryColor;
    const hover = `color-mix(in srgb, ${primary} 88%, #000)`;
    // Match live login brand primary override (IamAuthFlowView shellStyle).
    style['--auth-primary'] = primary;
    style['--el-color-primary'] = primary;
    style['--primary-button-bg'] = primary;
    style['--primary-button-border'] = primary;
    style['--primary-button-hover'] = hover;
  } else {
    // Follow console-root appearance theme tokens already set on the shell.
    style['--auth-primary'] = 'var(--primary-button-bg, var(--el-color-primary, #2563eb))';
  }
  if (form.value.backgroundMode === 'SOLID' && form.value.backgroundColor) {
    style.background = form.value.backgroundColor;
  } else if (form.value.backgroundMode === 'SOFT_GRADIENT') {
    const base = form.value.backgroundColor || '#0f172a';
    style.background = `linear-gradient(145deg, ${base} 0%, color-mix(in srgb, ${base} 55%, #1e293b) 48%, #020617 100%)`;
  } else if (form.value.backgroundMode === 'IMAGE' && form.value.backgroundImageUrl) {
    style.backgroundImage = `linear-gradient(180deg, rgba(15,23,42,0.35), rgba(15,23,42,0.55)), url(${JSON.stringify(form.value.backgroundImageUrl).slice(1, -1)})`;
    style.backgroundSize = 'cover';
    style.backgroundPosition = 'center';
    style.backgroundRepeat = 'no-repeat';
  } else {
    // NONE: leave CSS --lp-stage-bg (layered page surface). Do not force a hard light hex.
    // Inline background would override the layered token stack on .lp-shell.
  }
  return style;
});

const previewIsSplit = computed(() => (
  form.value.brandPosition === 'LEFT_PANEL' || form.value.brandPosition === 'RIGHT_PANEL'
));
const previewBrandInCard = computed(() => (
  form.value.brandPosition === 'ABOVE_FORM' || form.value.brandPosition === 'BELOW_FORM'
));
const previewShowBrand = computed(() => Boolean(
  form.value.systemName || form.value.description || form.value.logoUrl || displayBrandMark.value,
));

const previewShellClass = computed(() => ([
  'lp-shell',
  `lp-form-${String(form.value.formPosition || 'CENTER').toLowerCase()}`,
  `lp-brand-${String(form.value.brandPosition || 'ABOVE_FORM').toLowerCase().replaceAll('_', '-')}`,
  previewIsSplit.value ? 'lp-shell-split' : 'lp-shell-single',
  `lp-device-${previewDevice.value}`,
  !form.value.enabled ? 'lp-shell-is-disabled' : '',
]));


watch(
  () => [form.value.brandPosition, form.value.formPosition],
  () => {
    if (form.value.layoutTemplate !== 'CUSTOM') {
      const match = LAYOUT_TEMPLATES.find(
        (item) => item.brandPosition === form.value.brandPosition
          && item.formPosition === form.value.formPosition,
      );
      form.value.layoutTemplate = match?.id || 'CUSTOM';
    }
  },
);

function onBeforeUnload(event) {
  if (!dirty.value) {
    return;
  }
  event.preventDefault();
  event.returnValue = '';
}

function applySetting(setting) {
  revokeLocalObjectUrls();
  const next = applySettingToForm(setting);
  form.value = next;
  baseline.value = { ...next };
  loadError.value = '';
}

async function reload() {
  loading.value = true;
  loadError.value = '';
  try {
    applySetting(await loadLoginBrandSetting());
  } catch (error) {
    loadError.value = error?.message || t('module.login-brand.status.loadFailed');
    showBrickStatus(loadError.value, 'error');
  } finally {
    loading.value = false;
  }
}

async function onLogoUpload(file) {
  logoUploading.value = true;
  try {
    const result = await uploadBrickImageResource(file, 'LOGIN_BRAND_LOGO');
    form.value.logoResourceId = result.resourceId || '';
    // Local blob preview — never bind authenticated contentUrl to <img>.
    form.value.logoUrl = trackLocalObjectUrl(createBrickLocalImagePreview(file));
  } catch (error) {
    showBrickStatus(error?.message || t('module.login-brand.status.saveFailed'), 'error');
  } finally {
    logoUploading.value = false;
  }
}

function onLogoClear() {
  form.value.logoResourceId = '';
  form.value.logoUrl = '';
}

async function onBackgroundUpload(file) {
  backgroundUploading.value = true;
  try {
    const result = await uploadBrickImageResource(file, 'LOGIN_BRAND_BACKGROUND');
    form.value.backgroundResourceId = result.resourceId || '';
    form.value.backgroundImageUrl = trackLocalObjectUrl(createBrickLocalImagePreview(file));
    form.value.backgroundMode = 'IMAGE';
  } catch (error) {
    showBrickStatus(error?.message || t('module.login-brand.status.saveFailed'), 'error');
  } finally {
    backgroundUploading.value = false;
  }
}

function onBackgroundClear() {
  form.value.backgroundResourceId = '';
  form.value.backgroundImageUrl = '';
  if (form.value.backgroundMode === 'IMAGE') {
    form.value.backgroundMode = 'NONE';
  }
}

function onApplyTemplate(templateId) {
  form.value = applyLayoutTemplate(form.value, templateId);
  void loginBrandUsageTracker.trackActionResult('appearanceTemplate', 'apply', 'SUCCESS');
}

async function onSave() {
  if (!dirty.value) {
    return;
  }
  const validationKey = validateForm(form.value);
  if (validationKey) {
    showBrickStatus(t(validationKey), 'warning');
    return;
  }
  saving.value = true;
  try {
    const saved = await loginBrandUsageTracker.trackAction('appearanceConfig', 'save', () =>
      saveLoginBrandSetting(toUpdatePayload(form.value)));
    applySetting(saved);
    showBrickStatus(t('module.login-brand.status.saved'), 'success');
  } catch (error) {
    showBrickStatus(error?.message || t('module.login-brand.status.saveFailed'), 'error');
  } finally {
    saving.value = false;
  }
}

async function onFactoryReset() {
  try {
    await ElMessageBox.confirm(
      t('module.login-brand.reset.confirmBody'),
      t('module.login-brand.reset.confirmTitle'),
      {
        type: 'warning',
        confirmButtonText: t('module.login-brand.action.factoryReset'),
        cancelButtonText: t('module.login-brand.action.cancel'),
      },
    );
  } catch {
    void loginBrandUsageTracker.trackActionResult('appearanceReset', 'reset', 'CANCELLED');
    return;
  }
  saving.value = true;
  try {
    const reset = await loginBrandUsageTracker.trackAction('appearanceReset', 'reset', () =>
      resetLoginBrandSetting());
    applySetting(reset);
    showBrickStatus(t('module.login-brand.status.reset'), 'success');
  } catch (error) {
    showBrickStatus(error?.message || t('module.login-brand.status.saveFailed'), 'error');
  } finally {
    saving.value = false;
  }
}

function onDiscard() {
  form.value = { ...baseline.value };
}

onMounted(() => {
  void loginBrandUsageTracker.trackPage('appearance');
  window.addEventListener('beforeunload', onBeforeUnload);
  reload();
});

onBeforeUnmount(() => {
  window.removeEventListener('beforeunload', onBeforeUnload);
  revokeLocalObjectUrls();
});
</script>

<template>
  <section class="login-brand-page" v-loading="loading">
    <BrickPageHeader
      :title="t('module.login-brand.page.title')"
      :summary="t('module.login-brand.page.summary')"
    />

    <el-alert
      v-if="loadError"
      class="status-alert"
      type="error"
      :closable="false"
      :title="loadError"
      show-icon
    >
      <el-button size="small" type="primary" @click="reload">
        {{ t('module.login-brand.action.retry') }}
      </el-button>
    </el-alert>

    <el-alert
      v-if="dirty"
      class="status-alert"
      type="warning"
      :closable="false"
      :title="t('module.login-brand.status.dirty')"
      show-icon
    />

    <div class="template-bar" data-testid="login-brand-templates" role="group" :aria-label="t('module.login-brand.template.group')">
      <span class="template-bar__label">{{ t('module.login-brand.template.group') }}</span>
      <div class="template-chips">
        <button
          v-for="item in templateOptions"
          :key="item.id"
          type="button"
          class="template-chip"
          :class="{ 'is-active': form.layoutTemplate === item.id }"
          :title="item.hint"
          @click="onApplyTemplate(item.id)"
        >
          {{ item.label }}
        </button>
      </div>
    </div>

    <div class="login-brand-layout">
      <el-card shadow="never" class="login-brand-editor">
        <el-form label-position="top" class="login-brand-form brick-detail-form" @submit.prevent="onSave">
          <el-form-item class="brick-detail-form__full compact-switch" :label="t('module.login-brand.field.enabled')">
            <el-switch v-model="form.enabled" />
          </el-form-item>

          <el-form-item class="brick-detail-form__full" :label="t('module.login-brand.field.systemName')">
            <el-input v-model.trim="form.systemName" maxlength="120" show-word-limit />
          </el-form-item>

          <el-form-item class="brick-detail-form__full" :label="t('module.login-brand.field.description')">
            <el-input v-model.trim="form.description" type="textarea" :rows="1" maxlength="120" show-word-limit />
          </el-form-item>

          <el-form-item class="brick-detail-form__full" :label="t('module.login-brand.field.footerText')">
            <el-input
              v-model.trim="form.footerText"
              maxlength="255"
              show-word-limit
              :placeholder="t('module.login-brand.field.footerText.placeholder')"
            />
          </el-form-item>

          <el-form-item class="brick-detail-form__full compact-switch" :label="t('module.login-brand.field.showMobileBackendUrl')">
            <el-switch v-model="form.showMobileBackendUrl" />
            <p class="field-hint">{{ t('module.login-brand.tip.showMobileBackendUrl') }}</p>
          </el-form-item>

          <div class="brick-detail-form__full field-block">
            <BrickImageUploadField
              :label="t('module.login-brand.field.logo')"
              :preview-url="form.logoUrl"
              :uploading="logoUploading"
              :clear-disabled="!form.logoUrl || logoUploading"
              :preview-size="48"
              @upload="onLogoUpload"
              @clear="onLogoClear"
            />
          </div>

          <el-form-item :label="t('module.login-brand.field.backgroundMode')">
            <el-select v-model="form.backgroundMode" class="field-control" size="default">
              <el-option v-for="item in backgroundModeOptions" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>

          <el-form-item
            v-if="form.backgroundMode === 'SOLID' || form.backgroundMode === 'SOFT_GRADIENT'"
            :label="t('module.login-brand.field.backgroundColor')"
          >
            <BrickColorField v-model="form.backgroundColor" placeholder="#0f172a" />
          </el-form-item>

          <div v-if="form.backgroundMode === 'IMAGE'" class="brick-detail-form__full field-block">
            <BrickImageUploadField
              :label="t('module.login-brand.field.backgroundImage')"
              :preview-url="form.backgroundImageUrl"
              :uploading="backgroundUploading"
              :clear-disabled="!form.backgroundImageUrl || backgroundUploading"
              :preview-size="72"
              @upload="onBackgroundUpload"
              @clear="onBackgroundClear"
            />
          </div>

          <el-form-item :label="t('module.login-brand.field.brandPosition')">
            <el-select v-model="form.brandPosition" class="field-control">
              <el-option v-for="item in brandPositionOptions" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>

          <el-form-item
            v-if="form.brandPosition === 'ABOVE_FORM' || form.brandPosition === 'BELOW_FORM' || form.brandPosition === 'TOP_BAR'"
            :label="t('module.login-brand.field.formPosition')"
          >
            <el-select v-model="form.formPosition" class="field-control">
              <el-option v-for="item in formPositionOptions" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>

          <div class="brick-detail-form__full field-block primary-color-field">
            <span class="primary-color-field__label">{{ t('module.login-brand.field.primaryColorMode') }}</span>
            <el-radio-group
              class="primary-color-mode-group"
              :model-value="form.primaryColorMode"
              size="small"
              @update:model-value="onPrimaryColorModeChange"
            >
              <el-radio-button
                v-for="item in primaryColorModeOptions"
                :key="item.value"
                :label="item.value"
              >
                {{ item.label }}
              </el-radio-button>
            </el-radio-group>
            <BrickColorField
              v-if="form.primaryColorMode === 'CUSTOM'"
              v-model="form.primaryColor"
              placeholder="#0d9488"
            />
            <p v-else class="field-hint">{{ t('module.login-brand.tip.primaryFollowTheme') }}</p>
          </div>

          <el-alert
            v-if="clientValidationKey && dirty"
            class="brick-detail-form__full form-alert"
            type="error"
            :closable="false"
            :title="t(clientValidationKey)"
            show-icon
          />

          <div class="brick-detail-form__full editor-actions">
            <el-button size="small" :disabled="!dirty || saving" @click="onDiscard">
              {{ t('module.login-brand.action.discard') }}
            </el-button>
            <el-button size="small" :loading="saving" @click="onFactoryReset">
              {{ t('module.login-brand.action.factoryReset') }}
            </el-button>
            <el-button size="small" type="primary" :loading="saving" :disabled="!canSave" native-type="submit">
              {{ t('module.login-brand.action.save') }}
            </el-button>
          </div>
        </el-form>
      </el-card>

      <el-card shadow="never" class="login-brand-preview-card">
        <template #header>
          <div class="preview-header">
            <div>
              <strong>{{ t('module.login-brand.preview.title') }}</strong>
              <span class="preview-header-hint">{{ t('module.login-brand.preview.hint') }}</span>
            </div>
            <div class="preview-device-toggle" role="group" :aria-label="t('module.login-brand.preview.deviceGroup')">
              <button
                type="button"
                class="preview-device-btn"
                :class="{ 'is-active': previewDevice === 'desktop' }"
                @click="previewDevice = 'desktop'"
              >
                {{ t('module.login-brand.preview.desktop') }}
              </button>
              <button
                type="button"
                class="preview-device-btn"
                :class="{ 'is-active': previewDevice === 'mobile' }"
                @click="previewDevice = 'mobile'"
              >
                {{ t('module.login-brand.preview.mobile') }}
              </button>
            </div>
          </div>
        </template>

        <!-- High-fidelity shell: structure mirrors modules/iam IamAuthFlowView -->
        <div
          :class="previewShellClass"
          :style="previewShellStyle"
          data-testid="login-brand-preview"
        >
          <!--
            Do NOT dim the whole preview with opacity/filter when disabled — that reads as a frosted mask.
            Show an explicit badge instead; colors stay crisp for accurate brand judgment.
          -->
          <div
            v-if="!form.enabled"
            class="lp-disabled-badge"
            data-testid="login-brand-preview-disabled-badge"
          >
            {{ t('module.login-brand.preview.disabledBadge') }}
          </div>
          <div
            v-if="form.brandPosition === 'TOP_BAR' && previewShowBrand"
            class="lp-top-bar"
          >
            <img v-if="form.logoUrl" :src="form.logoUrl" alt="" class="lp-logo lp-logo-bar">
            <span v-else-if="displayBrandMark" class="lp-mark">{{ displayBrandMark }}</span>
            <div class="lp-top-bar-copy">
              <strong v-if="form.systemName">{{ form.systemName }}</strong>
              <span v-if="form.description">{{ form.description }}</span>
            </div>
          </div>

          <div class="lp-stage-frame">
            <aside
              v-if="previewIsSplit && previewShowBrand"
              class="lp-brand-panel"
            >
              <img v-if="form.logoUrl" :src="form.logoUrl" alt="" class="lp-logo lp-logo-panel">
              <span v-else-if="displayBrandMark" class="lp-mark lp-mark-lg">{{ displayBrandMark }}</span>
              <h2 v-if="form.systemName" class="lp-panel-title">{{ form.systemName }}</h2>
              <p v-if="form.description" class="lp-panel-desc">{{ form.description }}</p>
            </aside>

            <section class="lp-stage-layout">
              <div class="lp-card">
                <div
                  v-if="previewBrandInCard && form.brandPosition === 'ABOVE_FORM' && previewShowBrand"
                  class="lp-brand-strip"
                >
                  <img v-if="form.logoUrl" :src="form.logoUrl" alt="" class="lp-logo lp-logo-inline">
                  <span v-else-if="displayBrandMark" class="lp-mark">{{ displayBrandMark }}</span>
                  <div v-if="form.systemName || form.description" class="lp-brand-copy">
                    <strong v-if="form.systemName">{{ form.systemName }}</strong>
                    <span v-if="form.description">{{ form.description }}</span>
                  </div>
                </div>

                <div class="lp-form">
                  <label class="lp-field">
                    <span class="lp-label">{{ t('module.login-brand.preview.field.username') }}</span>
                    <span class="lp-input">{{ t('module.login-brand.preview.field.usernamePh') }}</span>
                  </label>
                  <label class="lp-field">
                    <span class="lp-label">{{ t('module.login-brand.preview.field.password') }}</span>
                    <span class="lp-input lp-input-password">••••••••</span>
                  </label>
                  <button type="button" class="lp-submit" tabindex="-1">
                    {{ t('module.login-brand.preview.field.submit') }}
                  </button>
                </div>

                <div
                  v-if="previewBrandInCard && form.brandPosition === 'BELOW_FORM' && previewShowBrand"
                  class="lp-brand-strip lp-brand-below"
                >
                  <strong v-if="form.systemName">{{ form.systemName }}</strong>
                  <span v-if="form.description">{{ form.description }}</span>
                </div>

                <p v-if="form.footerText" class="lp-footer">{{ form.footerText }}</p>
                <p class="lp-version">{{ t('module.login-brand.preview.versionSample') }}</p>
              </div>
            </section>
          </div>
        </div>
      </el-card>
    </div>
  </section>
</template>

<style scoped>
.login-brand-page {
  display: flex;
  flex-direction: column;
  gap: 10px;
  max-height: calc(100vh - 88px);
  overflow: auto;
  color: var(--console-text);
}
.status-alert { margin-bottom: 0; }
.template-bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px 12px;
  padding: 8px 12px;
  border: 1px solid var(--console-card-border);
  border-radius: 8px;
  background: var(--console-card-bg);
}
.template-bar__label {
  flex: 0 0 auto;
  font-size: 12px;
  font-weight: 600;
  color: var(--console-muted);
}
.template-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.template-chip {
  margin: 0;
  padding: 4px 10px;
  border: 1px solid var(--console-card-border);
  border-radius: 999px;
  background: var(--console-block-bg, var(--console-card-bg));
  color: var(--console-text);
  font-size: 12px;
  line-height: 1.4;
  cursor: pointer;
}
.template-chip:hover {
  border-color: color-mix(in srgb, var(--console-primary) 40%, var(--console-card-border));
  background: color-mix(in srgb, var(--console-primary) 8%, var(--console-card-bg));
}
.template-chip.is-active {
  border-color: var(--console-primary, var(--el-color-primary));
  background: color-mix(in srgb, var(--console-primary, var(--el-color-primary)) 12%, var(--console-card-bg));
  color: var(--console-primary, var(--el-color-primary));
  font-weight: 600;
}
.login-brand-layout {
  display: grid;
  grid-template-columns: minmax(280px, 400px) minmax(280px, 1fr);
  gap: 12px;
  align-items: start;
  min-height: 0;
  flex: 1;
}
.login-brand-editor,
.login-brand-preview-card {
  border: 1px solid var(--console-card-border);
  min-height: 0;
  background: var(--console-card-bg);
}
.login-brand-editor :deep(.el-card__body),
.login-brand-preview-card :deep(.el-card__body) {
  padding: 12px 14px;
}
.login-brand-preview-card :deep(.el-card__header) {
  padding: 10px 14px;
  background: var(--console-card-bg);
  border-bottom-color: var(--console-card-border);
  color: var(--console-text);
}
.login-brand-form.brick-detail-form {
  gap: 10px 12px;
}
.login-brand-form :deep(.el-form-item__label) {
  margin-bottom: 2px !important;
  text-transform: none;
  letter-spacing: 0;
  font-weight: 600;
  color: var(--console-title, var(--console-text));
}
.field-block { display: flex; flex-direction: column; gap: 4px; min-width: 0; }
.field-control { width: 100%; }
.field-hint {
  margin: 0;
  font-size: 12px;
  line-height: 1.45;
  color: var(--console-muted);
}
.primary-color-field {
  gap: 8px;
}
.primary-color-field__label {
  font-size: 13px;
  font-weight: 600;
  color: var(--console-title, var(--console-text));
}
.primary-color-mode-group {
  display: flex;
  flex-wrap: wrap;
}
.form-alert { margin: 0; }
.editor-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin-top: 2px;
  flex-wrap: wrap;
}
.login-brand-form :deep(.brick-image-upload-field) { width: 100%; }
.login-brand-form :deep(.brick-image-upload-field__body) { align-items: flex-start; }
.preview-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 10px;
}
.preview-header strong {
  display: block;
  font-size: 13px;
  color: var(--console-title, var(--console-text));
}
.preview-header-hint {
  display: block;
  margin-top: 2px;
  font-size: 11px;
  color: var(--console-muted);
  font-weight: 400;
  line-height: 1.4;
}
.preview-device-toggle {
  display: inline-flex;
  flex: 0 0 auto;
  border: 1px solid var(--console-card-border);
  border-radius: 6px;
  overflow: hidden;
  background: var(--console-block-bg, var(--console-card-bg));
}
.preview-device-btn {
  margin: 0;
  padding: 4px 10px;
  border: 0;
  background: transparent;
  color: var(--console-muted);
  font-size: 12px;
  line-height: 1.4;
  cursor: pointer;
}
.preview-device-btn + .preview-device-btn {
  border-left: 1px solid var(--console-card-border);
}
.preview-device-btn.is-active {
  background: var(--console-card-bg);
  color: var(--console-primary, var(--el-color-primary));
  font-weight: 600;
}

/* ===== High-fidelity login preview (IamAuthFlowView structure) ===== */
/*
 * Layer tokens (theme-safe, light + night):
 * stage (page) → card (elevated) → field (inset).
 * Do not bind field bg to --console-field-bg alone: in light theme it equals card white
 * and the right-side form becomes unreadable.
 */
.lp-shell {
  --auth-primary: var(--console-primary, var(--el-color-primary, #2563eb));
  /*
   * Solid layered surfaces (no whole-preview opacity).
   * stage = page tint, card = solid card, field = mild inset — crisp, not frosted.
   */
  --lp-stage-bg: var(--console-page-bg, var(--console-block-bg));
  --lp-card-bg: var(--console-card-bg);
  --lp-card-border: var(--console-card-border);
  --lp-field-bg: color-mix(in srgb, var(--console-muted) 10%, var(--console-card-bg));
  --lp-field-border: var(--console-card-border);
  --lp-text: var(--console-title, var(--console-text));
  --lp-muted: var(--console-muted);
  --lp-placeholder: var(--console-muted);
  position: relative;
  box-sizing: border-box;
  min-height: 420px;
  padding: 20px clamp(16px, 4vw, 40px);
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  /* Default stage; overridden by previewShellStyle for SOLID/GRADIENT/IMAGE. */
  background: var(--lp-stage-bg);
  color: var(--lp-text);
  border: 1px solid var(--lp-card-border);
}
/* Disabled: badge only — never opacity/filter on the whole shell (reads as a mask). */
.lp-shell-is-disabled {
  /* keep full color fidelity for brand judgment */
}
.lp-disabled-badge {
  position: absolute;
  top: 12px;
  left: 12px;
  z-index: 2;
  padding: 4px 10px;
  border-radius: var(--console-pill-radius, 999px);
  border: 1px solid var(--console-card-border);
  background: var(--console-card-bg);
  color: var(--console-muted);
  font-size: 12px;
  font-weight: 600;
  line-height: 1.3;
  box-shadow: 0 1px 2px color-mix(in srgb, var(--console-title) 8%, transparent);
  pointer-events: none;
}
.lp-device-mobile { max-width: 380px; margin: 0 auto; padding: 16px 12px; min-height: 360px; }

.lp-shell-single { align-items: stretch; }
.lp-shell-single.lp-form-center { align-items: center; }
.lp-shell-single.lp-form-left { align-items: flex-start; }
.lp-shell-single.lp-form-right { align-items: flex-end; }

.lp-stage-frame {
  width: 100%;
  max-width: 1080px;
  margin-left: auto;
  margin-right: auto;
  display: flex;
  gap: 16px;
  align-items: stretch;
}
.lp-shell-single .lp-stage-frame {
  max-width: 360px;
  display: block;
}
.lp-shell-single.lp-form-left .lp-stage-frame { margin-left: 0; margin-right: auto; }
.lp-shell-single.lp-form-right .lp-stage-frame { margin-left: auto; margin-right: 0; }
.lp-shell-single.lp-form-center .lp-stage-frame { margin-left: auto; margin-right: auto; }

.lp-shell-split .lp-stage-frame { min-height: 320px; }
.lp-brand-left-panel .lp-stage-frame { flex-direction: row; }
.lp-brand-right-panel .lp-stage-frame { flex-direction: row-reverse; }

.lp-brand-panel {
  flex: 1 1 48%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 8px;
  padding: 20px 18px;
  border-radius: 16px;
  color: #f8fafc;
  background: color-mix(in srgb, var(--auth-primary) 22%, rgba(15, 23, 42, 0.72));
  border: 1px solid color-mix(in srgb, #fff 12%, transparent);
}
.lp-panel-title {
  margin: 0;
  font-size: 20px;
  line-height: 1.25;
  font-weight: 650;
}
.lp-panel-desc {
  margin: 0;
  font-size: 12px;
  line-height: 1.5;
  opacity: 0.9;
}

.lp-stage-layout {
  flex: 0 1 360px;
  width: 100%;
}
.lp-shell-single .lp-stage-layout { max-width: 360px; }

.lp-card {
  background: var(--lp-card-bg);
  border-radius: 12px;
  padding: 20px 20px 16px;
  /* Stronger elevation so the form card separates from stage in light mode. */
  box-shadow:
    0 1px 2px color-mix(in srgb, var(--lp-text) 8%, transparent),
    0 12px 32px color-mix(in srgb, var(--lp-text) 10%, transparent);
  border: 1px solid var(--lp-card-border);
  color: var(--lp-text);
}

.lp-top-bar {
  width: min(100%, 1080px);
  margin: 0 auto 12px;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 12px;
  border-radius: 10px;
  background: color-mix(in srgb, var(--lp-card-bg) 92%, transparent);
  border: 1px solid var(--lp-card-border);
}
.lp-top-bar-copy { display: flex; flex-direction: column; gap: 1px; min-width: 0; }
.lp-top-bar-copy strong { font-size: 13px; color: var(--lp-text); }
.lp-top-bar-copy span { font-size: 11px; color: var(--lp-muted); }

.lp-brand-strip {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 14px;
}
.lp-brand-below {
  margin-top: 12px;
  margin-bottom: 0;
  flex-direction: column;
  align-items: flex-start;
  color: var(--lp-muted);
  font-size: 12px;
}
.lp-brand-copy { display: flex; flex-direction: column; gap: 1px; min-width: 0; }
.lp-brand-copy strong { font-size: 14px; color: var(--lp-text); }
.lp-brand-copy span { font-size: 12px; color: var(--lp-muted); }

.lp-logo { object-fit: contain; display: block; border-radius: 8px; }
.lp-logo-inline { width: 36px; height: 36px; }
.lp-logo-panel {
  width: 48px;
  height: 48px;
  padding: 6px;
  background: color-mix(in srgb, #fff 12%, transparent);
  border-radius: 12px;
}
.lp-logo-bar { width: 28px; height: 28px; }
.lp-mark {
  width: 36px;
  height: 36px;
  border-radius: 8px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: var(--lp-field-bg);
  border: 1px solid var(--lp-field-border);
  font-weight: 650;
  font-size: 13px;
  color: var(--lp-text);
}
.lp-mark-lg {
  width: 48px;
  height: 48px;
  font-size: 16px;
  background: color-mix(in srgb, #fff 16%, transparent);
  color: #f8fafc;
  border-color: transparent;
}

.lp-form { display: flex; flex-direction: column; gap: 12px; }
.lp-field { display: flex; flex-direction: column; gap: 6px; }
.lp-label {
  font-size: 13px;
  font-weight: 600;
  color: var(--lp-muted);
}
.lp-input {
  display: flex;
  align-items: center;
  min-height: 40px;
  padding: 0 12px;
  border-radius: 6px;
  border: 1px solid var(--lp-field-border);
  background: var(--lp-field-bg);
  color: var(--lp-placeholder);
  font-size: 13px;
}
.lp-input-password { letter-spacing: 0.12em; }
.lp-submit {
  margin-top: 2px;
  width: 100%;
  min-height: 40px;
  border: 0;
  border-radius: 6px;
  background: var(--auth-primary);
  color: #fff;
  font-size: 14px;
  font-weight: 600;
  cursor: default;
  pointer-events: none;
}

.lp-footer {
  margin: 12px 0 0;
  padding-top: 10px;
  border-top: 1px solid var(--lp-card-border);
  text-align: center;
  font-size: 11px;
  color: var(--lp-muted);
  line-height: 1.4;
}
.lp-version {
  margin: 6px 0 0;
  text-align: center;
  font-size: 11px;
  color: var(--lp-muted);
  font-variant-numeric: tabular-nums;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}

@media (max-width: 960px) {
  .login-brand-layout { grid-template-columns: 1fr; }
  .lp-brand-left-panel .lp-stage-frame,
  .lp-brand-right-panel .lp-stage-frame { flex-direction: column; }
}
</style>
