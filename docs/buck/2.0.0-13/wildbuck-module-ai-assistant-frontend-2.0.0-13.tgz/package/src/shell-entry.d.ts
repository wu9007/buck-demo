import type { Component } from 'vue';

export declare const AiAssistantConsoleShell: Component;
