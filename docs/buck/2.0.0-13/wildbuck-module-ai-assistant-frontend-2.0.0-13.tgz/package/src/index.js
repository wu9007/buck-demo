import { aiAssistantConversationFeature } from './features/conversation/index.js';
import { aiAssistantModelServiceFeature } from './features/model-service/index.js';
import { aiAssistantRoutes } from './routes/index.js';

export const aiAssistantFeatureRegistry = {
  conversation: aiAssistantConversationFeature,
  modelService: aiAssistantModelServiceFeature,
};

export const aiAssistantPermissionMap = {
  conversation: aiAssistantConversationFeature.permissions,
  modelService: aiAssistantModelServiceFeature.permissions,
};

export const brickModuleKey = 'ai-assistant';
export const brickModuleMeta = {
  displayName: 'AI 助手',
};
export const brickFeatureRegistry = aiAssistantFeatureRegistry;
export const brickPermissionMap = aiAssistantPermissionMap;
export const brickRoutes = aiAssistantRoutes;

export { aiAssistantRoutes };
