import AiAssistantConsoleShell from './components/AiAssistantConsoleShell.vue';

export { AiAssistantConsoleShell };
