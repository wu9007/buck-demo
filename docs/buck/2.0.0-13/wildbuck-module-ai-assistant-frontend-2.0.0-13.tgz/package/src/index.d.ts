export interface BrickFrontendRouteRecord {
  id: string;
  featureKey: string;
  path: string;
  title: string;
  abbr?: string;
  eyebrow?: string;
  summary?: string;
  messages?: Record<string, string>;
  permission: string;
  component: () => Promise<unknown>;
}

export interface BrickFrontendModuleMeta {
  displayName: string;
}

export interface BrickFrontendFeatureDefinition {
  featureKey: string;
  routes: BrickFrontendRouteRecord[];
  permissions: Record<string, string>;
}

export declare const aiAssistantFeatureRegistry: {
  conversation: BrickFrontendFeatureDefinition;
  modelService: BrickFrontendFeatureDefinition;
};
export declare const aiAssistantPermissionMap: {
  conversation: Record<string, string>;
  modelService: Record<string, string>;
};
export declare const aiAssistantRoutes: BrickFrontendRouteRecord[];
export declare const brickModuleKey: 'ai-assistant';
export declare const brickModuleMeta: BrickFrontendModuleMeta;
export declare const brickFeatureRegistry: {
  conversation: BrickFrontendFeatureDefinition;
  modelService: BrickFrontendFeatureDefinition;
};
export declare const brickPermissionMap: {
  conversation: Record<string, string>;
  modelService: Record<string, string>;
};
export declare const brickRoutes: BrickFrontendRouteRecord[];
