export {
  AI_ASSISTANT_MESSAGES,
  AI_ASSISTANT_MESSAGES_EN_US,
  AI_ASSISTANT_MESSAGES_ZH_CN,
  resolveAiAssistantMessages,
  translateAiAssistant,
  useAiAssistantI18n,
} from './features/ai-assistant-i18n.js';
