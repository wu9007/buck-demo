import type { Component } from 'vue';

export declare const AiAssistantPanel: Component;
