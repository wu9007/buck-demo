export const aiAssistantModelServicePermissions = {
  manage: 'ai-assistant:model-service:manage',
};
