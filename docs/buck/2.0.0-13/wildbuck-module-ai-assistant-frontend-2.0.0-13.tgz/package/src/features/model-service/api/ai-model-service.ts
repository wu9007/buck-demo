import {
  deleteAiModelService,
  getAiModelService,
  listAiModelServices,
  saveAiModelService,
  testAiModelService,
} from '../../../generated/sdk';

export const aiModelServiceApi = {
  listAiModelServices,
  getAiModelService,
  saveAiModelService,
  deleteAiModelService,
  testAiModelService,
};
