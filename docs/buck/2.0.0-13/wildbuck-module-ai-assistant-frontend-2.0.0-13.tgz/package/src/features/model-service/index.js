import { aiAssistantModelServicePermissions } from './permission/index.js';
import { aiAssistantModelServiceRoutes } from './routes/index.js';

export const aiAssistantModelServiceFeature = {
  featureKey: 'model-service',
  routes: aiAssistantModelServiceRoutes,
  permissions: aiAssistantModelServicePermissions,
};
