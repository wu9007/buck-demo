export const aiAssistantModelServiceRoutes = [
  {
    id: 'ai-assistant.model-services',
    featureKey: 'model-service',
    path: '/ai-assistant/model-services',
    title: 'AI 服务',
    abbr: 'AI',
    eyebrow: 'AI 助手 / AI 服务',
    summary: '管理智能助手可使用的服务。',
    guide: {
      title: 'AI 服务管理',
      steps: [
        {
          anchor: 'model-service-list',
          title: '查看服务',
          body: '查看已经保存的 AI 服务。',
        },
        {
          anchor: 'model-service-form',
          title: '新增或编辑',
          body: '在抽屉中维护名称、类型和访问密钥。',
        },
        {
          anchor: 'model-service-test',
          title: '验证服务',
          body: '验证当前 AI 服务是否可用。',
        },
      ],
    },
    messages: {
      viewTitle: 'AI 服务',
      primaryActionLabel: '保存',
      testActionLabel: '验证服务',
    },
    permission: 'ai-assistant:model-service:manage',
    component: () => import('../pages/AiModelServicePage.vue'),
  },
];
