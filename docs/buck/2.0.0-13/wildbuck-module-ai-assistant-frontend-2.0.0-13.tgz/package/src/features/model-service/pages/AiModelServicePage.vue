<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { BrickConsoleDrawer } from '@wildbuck/core-ui-frontend/shell';
import { BrickActionBar, BrickPageBlock, BrickRiskConfirm } from '@wildbuck/core-ui-frontend/patterns';
import { BrickManagedSecretInput, resolveBrickManagedSecretField } from '@wildbuck/core-ui-frontend/fields';
import { showBrickStatus, validateBrickRequiredFields } from '@wildbuck/core-ui-frontend/status';
import { aiAssistantErrors } from '../../../generated/errors';
import type {
  AiModelServiceDetail,
  AiModelServiceSummary,
  SaveAiModelServiceRequest,
} from '../../../generated/types';
import { aiModelServiceApi } from '../api/ai-model-service';
import { notifyAiModelServiceCatalogChanged } from '../model-service-catalog-events.js';
import { useAiAssistantI18n } from '../../../i18n.js';

type ServiceKind = 'deepseek' | 'ollama';

type ServiceKindOption = {
  value: ServiceKind;
  label: string;
  defaultName: string;
  baseUrl: string;
  defaultModel: string;
};

type ModelServiceForm = {
  modelServiceId: string;
  serviceCode: string;
  serviceName: string;
  providerCode: ServiceKind;
  baseUrl: string;
  defaultModel: string;
  apiKey: string;
  enabled: boolean;
};

const { t } = useAiAssistantI18n();

const serviceKindOptions = computed<ServiceKindOption[]>(() => [
  {
    value: 'deepseek',
    label: t('module.ai-assistant.modelService.kind.deepseek'),
    defaultName: 'DeepSeek',
    baseUrl: 'https://api.deepseek.com',
    defaultModel: 'deepseek-chat',
  },
  {
    value: 'ollama',
    label: t('module.ai-assistant.modelService.kind.ollama'),
    defaultName: t('module.ai-assistant.modelService.kind.ollamaDefaultName'),
    baseUrl: 'http://127.0.0.1:11434',
    defaultModel: 'qwen2.5:7b',
  },
]);

const serviceRows = ref<AiModelServiceSummary[]>([]);
const loading = ref(false);
const saving = ref(false);
const testing = ref(false);
const detailLoading = ref(false);
const deletingModelServiceId = ref('');
const keyword = ref('');
const total = ref(0);
const drawerVisible = ref(false);
const drawerMode = ref<'create' | 'edit'>('create');
const currentDetail = ref<AiModelServiceDetail | null>(null);
const form = ref<ModelServiceForm>(createForm());
const serviceNameInputRef = ref();
const serviceKindInputRef = ref();
const baseUrlInputRef = ref();
const defaultModelInputRef = ref();
const apiKeyInputRef = ref();

const hasRows = computed(() => serviceRows.value.length > 0);
const pageSummary = computed(() => t('module.ai-assistant.modelService.page.summary', { total: total.value }));
const drawerTitle = computed(() => (drawerMode.value === 'create'
  ? t('module.ai-assistant.modelService.drawer.create')
  : t('module.ai-assistant.modelService.drawer.edit')));
const selectedKind = computed(() => serviceKindOptions.value.find((option) => option.value === form.value.providerCode)
  || serviceKindOptions.value[0]);
const shouldShowSecretField = computed(() => form.value.providerCode === 'deepseek');
const apiKeyField = computed(() => resolveBrickManagedSecretField({
  label: t('module.ai-assistant.modelService.field.apiKey'),
  configured: Boolean(currentDetail.value?.credentialMasked),
  value: shouldShowSecretField.value ? form.value.apiKey : '',
  unconfiguredPlaceholder: t('module.ai-assistant.modelService.field.apiKeyPlaceholder'),
}));
const hasUnsavedFormChanges = computed(() => {
  if (!currentDetail.value) {
    return true;
  }
  const savedForm = formFromDetail(currentDetail.value);
  return normalizedText(form.value.serviceName) !== normalizedText(savedForm.serviceName)
    || form.value.providerCode !== savedForm.providerCode
    || normalizedText(form.value.baseUrl) !== normalizedText(savedForm.baseUrl)
    || normalizedText(form.value.defaultModel) !== normalizedText(savedForm.defaultModel)
    || Boolean(form.value.enabled) !== Boolean(savedForm.enabled)
    || Boolean(normalizedText(form.value.apiKey));
});

onMounted(() => {
  void reloadServices();
});

async function reloadServices() {
  loading.value = true;
  try {
    const page = await aiModelServiceApi.listAiModelServices({
      keyword: normalizedText(keyword.value) || undefined,
      page: 1,
      size: 50,
      sortProperty: 'serviceCode',
      sortDirection: 'ASC',
    });
    serviceRows.value = page.records || [];
    total.value = page.total || 0;
  } catch (error) {
    showBrickStatus(t('module.ai-assistant.modelService.status.loadFailed'), 'error');
  } finally {
    loading.value = false;
  }
}

function openCreateDrawer() {
  drawerMode.value = 'create';
  currentDetail.value = null;
  form.value = createForm();
  drawerVisible.value = true;
}

async function openEditDrawer(row: AiModelServiceSummary) {
  drawerMode.value = 'edit';
  drawerVisible.value = true;
  detailLoading.value = true;
  try {
    currentDetail.value = await aiModelServiceApi.getAiModelService(row.modelServiceId);
    form.value = formFromDetail(currentDetail.value);
  } catch (error) {
    drawerVisible.value = false;
    showBrickStatus(t('module.ai-assistant.modelService.status.detailLoadFailed'), 'error');
  } finally {
    detailLoading.value = false;
  }
}

function closeDrawer() {
  drawerVisible.value = false;
}

function handleKindChange() {
  const option = selectedKind.value;
  const currentName = normalizedText(form.value.serviceName);
  form.value.baseUrl = option.baseUrl;
  form.value.defaultModel = option.defaultModel;
  if (!currentName || serviceKindOptions.value.some((item) => item.defaultName === currentName)) {
    form.value.serviceName = option.defaultName;
  }
  if (drawerMode.value === 'create') {
    const serviceCode = createServiceCode(option.value);
    form.value.serviceCode = serviceCode;
    form.value.modelServiceId = serviceCode;
  }
}

async function handleSave() {
  const saved = await saveConfiguration(true);
  if (saved) {
    drawerVisible.value = false;
  }
}

async function handleTest() {
  if (!currentDetail.value?.modelServiceId || hasUnsavedFormChanges.value) {
    showBrickStatus(t('module.ai-assistant.modelService.status.saveFirst'), 'warning');
    return;
  }
  testing.value = true;
  try {
    await aiModelServiceApi.testAiModelService(currentDetail.value.modelServiceId, { prompt: 'ping' });
    showBrickStatus(t('module.ai-assistant.modelService.status.testPassed'), 'success');
  } catch (error) {
    showBrickStatus(t('module.ai-assistant.modelService.status.testFailed'), 'error');
  } finally {
    testing.value = false;
  }
}

async function handleDelete(row: AiModelServiceSummary) {
  if (!row.modelServiceId || deletingModelServiceId.value) {
    return;
  }
  deletingModelServiceId.value = row.modelServiceId;
  const deletedName = normalizedText(row.serviceName) || row.modelServiceId;
  try {
    await aiModelServiceApi.deleteAiModelService(row.modelServiceId);
    if (currentDetail.value?.modelServiceId === row.modelServiceId) {
      currentDetail.value = null;
      drawerVisible.value = false;
      form.value = createForm();
    }
    await reloadServices();
    notifyAiModelServiceCatalogChanged();
    showBrickStatus(t('module.ai-assistant.modelService.status.deleted', { name: deletedName }), 'success');
  } catch (error) {
    showBrickStatus(resolveModelServiceErrorMessage(error), 'error');
  } finally {
    deletingModelServiceId.value = '';
  }
}

async function saveConfiguration(showSuccess: boolean) {
  if (!validateForm()) {
    return null;
  }
  saving.value = true;
  try {
    const modelServiceId = form.value.modelServiceId || form.value.serviceCode || createServiceCode(form.value.providerCode);
    const saved = await aiModelServiceApi.saveAiModelService(modelServiceId, buildRequest());
    currentDetail.value = saved;
    form.value = formFromDetail(saved);
    await reloadServices();
    notifyAiModelServiceCatalogChanged();
    if (showSuccess) {
      showBrickStatus(t('module.ai-assistant.modelService.status.saved'), 'success');
    }
    return saved;
  } catch (error) {
    showBrickStatus(t('module.ai-assistant.modelService.status.saveFailed'), 'error');
    return null;
  } finally {
    saving.value = false;
  }
}

function validateForm() {
  const result = validateBrickRequiredFields([
    {
      label: t('module.ai-assistant.modelService.field.serviceName'),
      value: form.value.serviceName,
      focusTarget: serviceNameInputRef.value,
    },
    {
      label: t('module.ai-assistant.modelService.field.serviceKind'),
      value: form.value.providerCode,
      focusTarget: serviceKindInputRef.value,
    },
    {
      label: t('module.ai-assistant.modelService.field.baseUrl'),
      value: form.value.baseUrl,
      focusTarget: baseUrlInputRef.value,
    },
    {
      label: t('module.ai-assistant.modelService.field.defaultModel'),
      value: form.value.defaultModel,
      focusTarget: defaultModelInputRef.value,
    },
    {
      label: t('module.ai-assistant.modelService.field.apiKey'),
      value: shouldShowSecretField.value ? apiKeyField.value.validationValue : '__hidden__',
      focusTarget: apiKeyInputRef.value,
    },
  ]);
  return result.ok;
}

function buildRequest(): SaveAiModelServiceRequest {
  const option = selectedKind.value;
  return {
    serviceCode: normalizedText(form.value.serviceCode)
      || normalizedText(form.value.modelServiceId)
      || createServiceCode(option.value),
    serviceName: normalizedText(form.value.serviceName) || option.defaultName,
    providerCode: option.value,
    baseUrl: normalizedText(form.value.baseUrl) || option.baseUrl,
    defaultModel: normalizedText(form.value.defaultModel) || option.defaultModel,
    apiKey: shouldShowSecretField.value ? apiKeyField.value.submitValue : undefined,
    enabled: Boolean(form.value.enabled),
  };
}

function createForm(providerCode: ServiceKind = 'deepseek'): ModelServiceForm {
  const option = serviceKindOptions.value.find((item) => item.value === providerCode) || serviceKindOptions.value[0];
  const serviceCode = createServiceCode(option.value);
  return {
    modelServiceId: serviceCode,
    serviceCode,
    serviceName: option.defaultName,
    providerCode: option.value,
    baseUrl: option.baseUrl,
    defaultModel: option.defaultModel,
    apiKey: '',
    enabled: true,
  };
}

function formFromDetail(detail: AiModelServiceDetail): ModelServiceForm {
  const providerCode = normalizeProviderCode(detail.providerCode);
  const option = serviceKindOptions.value.find((item) => item.value === providerCode) || serviceKindOptions.value[0];
  return {
    modelServiceId: detail.modelServiceId || '',
    serviceCode: detail.serviceCode || detail.modelServiceId || createServiceCode(option.value),
    serviceName: detail.serviceName || option.defaultName,
    providerCode: option.value,
    baseUrl: detail.baseUrl || option.baseUrl,
    defaultModel: detail.defaultModel || option.defaultModel,
    apiKey: '',
    enabled: Boolean(detail.enabled),
  };
}

function normalizeProviderCode(value: string | undefined): ServiceKind {
  return value === 'ollama' ? 'ollama' : 'deepseek';
}

function serviceKindLabel(value: string | undefined) {
  const providerCode = normalizeProviderCode(value);
  return serviceKindOptions.value.find((option) => option.value === providerCode)?.label || t('module.ai-assistant.common.aiService');
}

function isDeletingModelService(modelServiceId: string | undefined) {
  return Boolean(modelServiceId) && deletingModelServiceId.value === modelServiceId;
}

function createServiceCode(providerCode: ServiceKind) {
  return `${providerCode}-${Date.now().toString(36)}`;
}

function normalizedText(value: string | undefined | null) {
  return typeof value === 'string' && value.trim() ? value.trim() : '';
}

function resolveModelServiceErrorMessage(error: unknown) {
  const detail = extractErrorDetails(error);
  if (detail.code && detail.code in aiAssistantErrors) {
    const matched = aiAssistantErrors[detail.code as keyof typeof aiAssistantErrors];
    return `${matched.message}，${matched.recovery}`;
  }
  if (detail.message) {
    return detail.recovery ? `${detail.message}，${detail.recovery}` : detail.message;
  }
  return t('module.ai-assistant.modelService.status.deleteFailed');
}

function extractErrorDetails(error: unknown) {
  const candidate = collectErrorCandidate(error, new Set<unknown>());
  return {
    code: typeof candidate?.code === 'string' ? candidate.code : '',
    message:
      typeof candidate?.message === 'string'
        ? candidate.message
        : typeof error === 'object' && error !== null && 'message' in error
          ? String(error.message)
          : '',
    recovery: typeof candidate?.recovery === 'string' ? candidate.recovery : '',
  };
}

function collectErrorCandidate(value: unknown, seen: Set<unknown>): { code?: string; message?: string; recovery?: string } | null {
  if (value == null) {
    return null;
  }
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed.startsWith('{') || !trimmed.endsWith('}')) {
      return null;
    }
    try {
      return collectErrorCandidate(JSON.parse(trimmed), seen);
    } catch {
      return null;
    }
  }
  if (typeof value !== 'object') {
    return null;
  }
  if (seen.has(value)) {
    return null;
  }
  seen.add(value);
  for (const key of ['payload', 'body', 'response', 'data', 'cause', 'error']) {
    if (!(key in value)) {
      continue;
    }
    const nested = collectErrorCandidate((value as Record<string, unknown>)[key], seen);
    if (nested) {
      return nested;
    }
  }
  if ('code' in value || 'message' in value || 'recovery' in value) {
    return value as { code?: string; message?: string; recovery?: string };
  }
  return null;
}
</script>

<template>
  <article class="console-settings-page ai-model-service-page">
    <BrickPageBlock
      :eyebrow="t('module.ai-assistant.modelService.page.eyebrow')"
      :title="t('module.ai-assistant.modelService.page.title')"
      :description="t('module.ai-assistant.modelService.page.description')"
      :loading="loading && !hasRows"
      :loading-text="t('module.ai-assistant.modelService.page.loading')"
    >
      <template #actions>
        <BrickActionBar>
          <template #secondary>
            <el-button plain :loading="loading" @click="reloadServices">{{ t('module.ai-assistant.common.refresh') }}</el-button>
          </template>
          <template #primary>
            <el-button type="primary" @click="openCreateDrawer">{{ t('module.ai-assistant.common.create') }}</el-button>
          </template>
        </BrickActionBar>
      </template>
    </BrickPageBlock>

    <section class="footer-actions">
      <el-input
        v-model="keyword"
        clearable
        :placeholder="t('module.ai-assistant.modelService.searchPlaceholder')"
        style="max-width: 320px"
        @keyup.enter="reloadServices"
      />
      <el-button :loading="loading" type="primary" @click="reloadServices">{{ t('module.ai-assistant.common.query') }}</el-button>
      <span class="state-text">{{ pageSummary }}</span>
    </section>

    <section class="setting-card" data-guide-anchor="model-service-list">
      <el-table
        v-loading="loading"
        :data="serviceRows"
        row-key="modelServiceId"
        :empty-text="t('module.ai-assistant.modelService.empty')"
      >
        <el-table-column prop="serviceName" :label="t('module.ai-assistant.modelService.column.name')" min-width="180" show-overflow-tooltip />
        <el-table-column :label="t('module.ai-assistant.modelService.column.type')" min-width="150">
          <template #default="{ row }">
            {{ serviceKindLabel(row.providerCode) }}
          </template>
        </el-table-column>
        <el-table-column :label="t('module.ai-assistant.modelService.column.status')" width="110">
          <template #default="{ row }">
            <el-tag :type="row.enabled ? 'success' : 'info'" effect="plain">
              {{ row.enabled ? t('module.ai-assistant.common.enabled') : t('module.ai-assistant.common.disabled') }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column :label="t('module.ai-assistant.modelService.column.actions')" width="180" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="openEditDrawer(row)">{{ t('module.ai-assistant.common.edit') }}</el-button>
            <BrickRiskConfirm
              :title="t('module.ai-assistant.modelService.delete.title')"
              :description="t('module.ai-assistant.modelService.delete.description')"
              :impact="[t('module.ai-assistant.modelService.delete.impact1'), t('module.ai-assistant.modelService.delete.impact2')]"
              :confirm-text="t('module.ai-assistant.modelService.delete.confirm')"
              @confirm="handleDelete(row)"
            >
              <template #trigger>
                <el-button
                  link
                  type="danger"
                  :disabled="Boolean(deletingModelServiceId) && !isDeletingModelService(row.modelServiceId)"
                  :loading="isDeletingModelService(row.modelServiceId)"
                >
                  {{ t('module.ai-assistant.common.delete') }}
                </el-button>
              </template>
            </BrickRiskConfirm>
          </template>
        </el-table-column>
      </el-table>
    </section>

    <BrickConsoleDrawer
      v-model="drawerVisible"
      class="ai-model-service-drawer"
      size="min(560px, calc(100vw - 24px))"
      :title="drawerTitle"
      :loading="detailLoading"
      :destroy-on-close="false"
      data-guide-anchor="model-service-form"
    >
      <el-form class="page-form brick-required-form" label-position="top">
        <el-form-item :label="t('module.ai-assistant.modelService.field.serviceNameRequired')" required>
          <el-input ref="serviceNameInputRef" v-model="form.serviceName" :placeholder="t('module.ai-assistant.modelService.field.serviceNamePlaceholder')" />
        </el-form-item>

        <el-form-item :label="t('module.ai-assistant.modelService.field.serviceKindRequired')" required>
          <el-select ref="serviceKindInputRef" v-model="form.providerCode" @change="handleKindChange">
            <el-option
              v-for="option in serviceKindOptions"
              :key="option.value"
              :label="option.label"
              :value="option.value"
            />
          </el-select>
        </el-form-item>

        <el-form-item :label="t('module.ai-assistant.modelService.field.baseUrlRequired')" required>
          <el-input ref="baseUrlInputRef" v-model="form.baseUrl" :placeholder="t('module.ai-assistant.modelService.field.baseUrlPlaceholder')" />
        </el-form-item>

        <el-form-item :label="t('module.ai-assistant.modelService.field.defaultModelRequired')" required>
          <el-input ref="defaultModelInputRef" v-model="form.defaultModel" :placeholder="t('module.ai-assistant.modelService.field.defaultModelPlaceholder')" />
        </el-form-item>

        <el-form-item
          v-if="shouldShowSecretField"
          :label="apiKeyField.labelText"
          :required="apiKeyField.required"
        >
          <BrickManagedSecretInput
            ref="apiKeyInputRef"
            v-model="form.apiKey"
            :aria-label="t('module.ai-assistant.modelService.field.apiKey')"
            :configured="apiKeyField.configured"
            :unconfigured-placeholder="t('module.ai-assistant.modelService.field.apiKeyPlaceholder')"
          />
        </el-form-item>

        <el-form-item :label="t('module.ai-assistant.modelService.field.enabledRequired')" required>
          <el-switch v-model="form.enabled" inline-prompt :active-text="t('module.ai-assistant.common.enabled')" :inactive-text="t('module.ai-assistant.common.disabled')" />
        </el-form-item>
      </el-form>

      <template #footer>
        <BrickActionBar :loading="saving || testing">
          <template #secondary>
            <el-button @click="closeDrawer">{{ t('module.ai-assistant.common.cancel') }}</el-button>
          </template>
          <el-button :loading="testing" data-guide-anchor="model-service-test" @click="handleTest">
            {{ t('module.ai-assistant.modelService.action.test') }}
          </el-button>
          <template #primary>
            <el-button type="primary" :loading="saving" @click="handleSave">{{ t('module.ai-assistant.common.save') }}</el-button>
          </template>
        </BrickActionBar>
      </template>
    </BrickConsoleDrawer>
  </article>
</template>

<style>
@import "@wildbuck/core-ui-frontend/settings-page.css";
</style>
