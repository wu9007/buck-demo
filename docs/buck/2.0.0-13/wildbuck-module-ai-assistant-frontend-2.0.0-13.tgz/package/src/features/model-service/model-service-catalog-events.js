export const AI_MODEL_SERVICE_CATALOG_CHANGED_EVENT = 'brick:ai-assistant:model-service-catalog-changed';

export function notifyAiModelServiceCatalogChanged() {
  if (typeof window === 'undefined') {
    return;
  }
  window.dispatchEvent(new CustomEvent(AI_MODEL_SERVICE_CATALOG_CHANGED_EVENT));
}

export function onAiModelServiceCatalogChanged(listener) {
  if (typeof window === 'undefined') {
    return () => {};
  }
  window.addEventListener(AI_MODEL_SERVICE_CATALOG_CHANGED_EVENT, listener);
  return () => window.removeEventListener(AI_MODEL_SERVICE_CATALOG_CHANGED_EVENT, listener);
}
