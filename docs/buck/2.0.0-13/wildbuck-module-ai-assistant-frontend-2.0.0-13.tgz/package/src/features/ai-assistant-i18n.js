import { formatBrickI18nMessage, normalizeBrickLocale } from '@wildbuck/core-i18n-frontend';
import {
  useBrickConsoleI18n,
} from '@wildbuck/core-ui-frontend/i18n';
import {
  AI_ASSISTANT_MESSAGES,
  AI_ASSISTANT_MESSAGES_EN_US,
  AI_ASSISTANT_MESSAGES_ZH_CN,
} from './ai-assistant-i18n-messages.js';

/**
 * @param {unknown} locale
 * @returns {Readonly<Record<string, string>>}
 */
export function resolveAiAssistantMessages(locale) {
  const normalized = normalizeBrickLocale(locale);
  return AI_ASSISTANT_MESSAGES[normalized] ?? AI_ASSISTANT_MESSAGES_ZH_CN;
}

/**
 * @param {unknown} runtime
 * @param {string} key
 * @param {Record<string, unknown>} [params]
 * @param {string} [fallbackLocale]
 */
export function translateAiAssistant(runtime, key, params = {}, fallbackLocale = 'zh-CN') {
  const messageKey = String(key ?? '');
  if (!messageKey) {
    return '';
  }
  if (runtime && typeof runtime.t === 'function') {
    const resolved = runtime.t(messageKey, params);
    if (resolved != null && resolved !== '' && resolved !== messageKey) {
      return String(resolved);
    }
  }
  const locale = normalizeBrickLocale(
    typeof runtime?.getLocale === 'function' ? runtime.getLocale() : fallbackLocale,
    fallbackLocale,
  );
  const pack = resolveAiAssistantMessages(locale);
  const template = pack[messageKey] ?? AI_ASSISTANT_MESSAGES_ZH_CN[messageKey];
  if (typeof template === 'string') {
    return formatBrickI18nMessage(template, params);
  }
  return messageKey;
}

/**
 * Vue inject helper for AI assistant SFCs.
 * Tracks runtime revision so setLocale / registerMessages re-render templates that call t().
 */
export function useAiAssistantI18n() {
  const { i18n, revision, locale, t: consoleT } = useBrickConsoleI18n();

  function t(key, params) {
    void revision.value;
    const fromRuntime = consoleT(key, params);
    if (fromRuntime != null && fromRuntime !== '' && fromRuntime !== key) {
      return fromRuntime;
    }
    return translateAiAssistant(i18n, key, params, locale.value);
  }

  return {
    i18n,
    revision,
    locale,
    t,
  };
}

export {
  AI_ASSISTANT_MESSAGES,
  AI_ASSISTANT_MESSAGES_EN_US,
  AI_ASSISTANT_MESSAGES_ZH_CN,
};
