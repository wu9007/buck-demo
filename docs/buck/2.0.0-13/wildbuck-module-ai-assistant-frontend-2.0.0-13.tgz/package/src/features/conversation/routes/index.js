export const aiAssistantConversationRoutes = [
  {
    id: 'ai-assistant.conversation',
    featureKey: 'conversation',
    path: '/ai-assistant/conversation',
    title: 'AI 助手',
    abbr: 'AI',
    eyebrow: 'AI 助手 / 会话',
    summary: '在右侧打开助手，按场景分标签交流，并确认需要执行的操作。',
    guide: {
      title: 'AI 助手任务路径',
      steps: [
        {
          anchor: 'assistant-entry',
          title: '从顶部栏打开助手',
          body: '助手会从右侧打开，不会遮挡当前页面。',
        },
        {
          anchor: 'assistant-tabs',
          title: '按助手创建标签',
          body: '安全、身份和应用助手各自保留聊天内容，不互相覆盖。',
        },
        {
          anchor: 'assistant-input',
          title: '选择服务后发送',
          body: '发送前可切换 AI 服务；需要执行的操作会按你的权限处理。',
        },
      ],
    },
    messages: {
      viewTitle: 'AI 助手',
      openSidebarLabel: '打开 AI 助手侧栏',
      modelSelectLabel: 'AI 服务',
    },
    permission: 'authenticated',
    component: () => import('../pages/AiAssistantConversationPage.vue'),
  },
];
