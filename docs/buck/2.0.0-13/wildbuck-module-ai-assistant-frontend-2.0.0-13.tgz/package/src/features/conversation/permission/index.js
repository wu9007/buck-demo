export const aiAssistantConversationPermissions = {
  use: 'authenticated',
};
