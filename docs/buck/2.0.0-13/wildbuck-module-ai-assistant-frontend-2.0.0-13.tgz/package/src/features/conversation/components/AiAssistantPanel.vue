<script setup>
import { computed, nextTick, onMounted, ref, watch } from 'vue';
import { BrickConsoleContextHeader, BrickEmptyState } from '@wildbuck/core-ui-frontend';
import { aiAssistantConversationApi } from '../api/ai-assistant-conversation';
import { useAiAssistantSidebarWorkspace } from '../composables/useAiAssistantSidebarWorkspace.js';
import AiAssistantPanelCollapseIcon from '../../../components/AiAssistantPanelCollapseIcon.vue';
import { useAiAssistantI18n } from '../../../i18n.js';

const props = defineProps({
  api: { type: Object, default: undefined },
});

const emit = defineEmits(['close']);

const { t } = useAiAssistantI18n();
const workspace = useAiAssistantSidebarWorkspace({
  api: props.api || aiAssistantConversationApi,
  t,
});

const hasTabs = computed(() => workspace.tabs.value.length > 0);
const hasMessages = computed(() => (workspace.activeTab.value?.messages?.length || 0) > 0);
const canSend = computed(() => !workspace.actionLoading.value && Boolean(workspace.draftMessage.value.trim()));
const messagesViewport = ref(null);
const latestMessageKey = computed(() => {
  const tab = workspace.activeTab.value;
  if (!tab) {
    return '';
  }
  const lastMessage = lastItem(tab.messages);
  const lastToolCall = lastItem(tab.toolCalls);
  return [
    tab.id,
    tab.messages.length,
    lastMessage?.id || '',
    lastMessage?.content || '',
    lastMessage?.thinking === true ? 'thinking' : '',
    tab.toolCalls.length,
    lastToolCall?.toolCallId || '',
    lastToolCall?.status || '',
  ].join('|');
});

watch(latestMessageKey, () => {
  void scrollMessagesToLatest();
}, { flush: 'post' });

function openAssistant(assistantCode) {
  void workspace.openAssistant(assistantCode);
}

function sendMessage() {
  void workspace.sendMessage();
}

function retryInitialize() {
  void workspace.initialize();
}

function approveToolCall(toolCallId) {
  void workspace.approveToolCall(toolCallId);
}

function rejectToolCall(toolCallId) {
  void workspace.rejectToolCall(toolCallId);
}

function clearConversation() {
  void workspace.clearActiveConversation();
}

async function scrollMessagesToLatest() {
  await nextTick();
  const viewport = messagesViewport.value;
  if (!viewport) {
    return;
  }
  viewport.scrollTop = viewport.scrollHeight;
}

function lastItem(items) {
  return items.length > 0 ? items[items.length - 1] : null;
}

onMounted(() => {
  void workspace.initialize();
});
</script>

<template>
  <section class="ai-assistant-panel" :aria-label="t('module.ai-assistant.panel.aria')">
    <BrickConsoleContextHeader
      class="ai-assistant-panel__tabs"
      :aria-label="t('module.ai-assistant.panel.headerAria')"
      data-guide-anchor="assistant-tabs"
    >
      <template #leading>
        <button
          class="shell-icon-button ai-assistant-panel__plus"
          type="button"
          :title="t('module.ai-assistant.panel.openTabsTitle')"
          :aria-label="t('module.ai-assistant.panel.openTabsTitle')"
          :aria-expanded="workspace.assistantMenuOpen.value ? 'true' : 'false'"
          @click="workspace.toggleAssistantMenu"
        >
          +
        </button>
      </template>

      <div v-if="hasTabs" class="ai-assistant-panel__tab-list" role="tablist" :aria-label="t('module.ai-assistant.panel.tabListAria')">
        <button
          v-for="tab in workspace.tabs.value"
          :key="tab.id"
          class="ai-assistant-panel__tab"
          :class="{ 'is-active': tab.id === workspace.activeTabId.value }"
          type="button"
          role="tab"
          :aria-selected="tab.id === workspace.activeTabId.value ? 'true' : 'false'"
          @click="workspace.activateTab(tab.id)"
        >
          <span class="ai-assistant-panel__tab-title">{{ tab.title }}</span>
          <span
            class="ai-assistant-panel__tab-close"
            role="button"
            tabindex="0"
            :aria-label="t('module.ai-assistant.panel.closeTabAria')"
            @click.stop="workspace.closeTab(tab.id)"
            @keydown.enter.stop.prevent="workspace.closeTab(tab.id)"
          >
            ×
          </span>
        </button>
      </div>

      <template #trailing>
        <button
          class="shell-icon-button ai-assistant-panel__close"
          type="button"
          :title="t('module.ai-assistant.panel.collapseAria')"
          :aria-label="t('module.ai-assistant.panel.collapseAria')"
          @click="emit('close')"
        >
          <AiAssistantPanelCollapseIcon />
        </button>
      </template>

      <div v-if="workspace.assistantMenuOpen.value" class="ai-assistant-panel__plus-menu" role="menu">
        <p v-if="workspace.loading.value" class="ai-assistant-panel__menu-state">{{ t('module.ai-assistant.panel.loadingAssistants') }}</p>
        <button
          v-else-if="workspace.loadError.value"
          class="ai-assistant-panel__menu-state is-action"
          type="button"
          @click="retryInitialize"
        >
          {{ t('module.ai-assistant.panel.reloadAssistants') }}
        </button>
        <template v-else>
          <button
            v-for="assistant in workspace.assistants.value"
            :key="assistant.code"
            class="ai-assistant-panel__menu-item"
            type="button"
            role="menuitem"
            @click="openAssistant(assistant.code)"
          >
            <span class="ai-assistant-panel__mark">{{ assistant.mark }}</span>
            <span>
              <strong>{{ assistant.name }}</strong>
              <small v-if="assistant.summary">{{ assistant.summary }}</small>
            </span>
          </button>
        </template>
      </div>
    </BrickConsoleContextHeader>

    <div v-if="!hasTabs" class="ai-assistant-panel__empty" data-guide-anchor="assistant-entry">
      <BrickEmptyState
        v-if="workspace.loading.value"
        class="ai-assistant-panel__empty-state"
        compact
        :title="t('module.ai-assistant.panel.loadingTitle')"
        :description="t('module.ai-assistant.panel.loadingDescription')"
        icon-text="…"
      />
      <BrickEmptyState
        v-else-if="workspace.loadError.value"
        class="ai-assistant-panel__empty-state"
        compact
        variant="error"
        :title="t('module.ai-assistant.panel.loadFailedTitle')"
        :description="workspace.loadError.value"
        :action-text="t('module.ai-assistant.common.retry')"
        icon-text="!"
        @action="retryInitialize"
      />
      <BrickEmptyState
        v-else-if="workspace.assistants.value.length === 0"
        class="ai-assistant-panel__empty-state"
        compact
        :title="t('module.ai-assistant.panel.emptyTitle')"
        :description="t('module.ai-assistant.panel.emptyDescription')"
        icon-text="AI"
      />
      <div v-else class="ai-assistant-panel__entry">
        <header class="ai-assistant-panel__entry-header">
          <h2>{{ t('module.ai-assistant.panel.pickTitle') }}</h2>
          <p>{{ t('module.ai-assistant.panel.pickDescription') }}</p>
        </header>
        <div class="ai-assistant-panel__assistant-list" :aria-label="t('module.ai-assistant.panel.assistantListAria')">
          <button
            v-for="assistant in workspace.assistants.value"
            :key="assistant.code"
            class="ai-assistant-panel__assistant-card"
            type="button"
            @click="openAssistant(assistant.code)"
          >
            <span class="ai-assistant-panel__assistant-mark">{{ assistant.mark }}</span>
            <span class="ai-assistant-panel__assistant-copy">
              <strong>{{ assistant.name }}</strong>
              <small v-if="assistant.summary">{{ assistant.summary }}</small>
            </span>
          </button>
        </div>
      </div>
    </div>

    <template v-else>
      <div class="ai-assistant-panel__conversation">
        <div class="ai-assistant-panel__conversation-toolbar" :aria-label="t('module.ai-assistant.panel.conversationToolbarAria')">
          <div class="ai-assistant-panel__conversation-heading">
            <strong>{{ workspace.activeTab.value.assistant.name }}</strong>
            <span v-if="workspace.activeTab.value.assistant.summary">
              {{ workspace.activeTab.value.assistant.summary }}
            </span>
          </div>
          <button
            class="ai-assistant-panel__text-button"
            type="button"
            :disabled="workspace.actionLoading.value"
            @click="clearConversation"
          >
            {{ t('module.ai-assistant.panel.clearConversation') }}
          </button>
        </div>

        <div
          ref="messagesViewport"
          class="ai-assistant-panel__messages"
          aria-live="polite"
          data-guide-anchor="assistant-messages"
        >
          <BrickEmptyState
            v-if="!hasMessages && workspace.activeTab.value.toolCalls.length === 0"
            class="ai-assistant-panel__thread-empty"
            compact
            :title="t('module.ai-assistant.panel.startTitle')"
            :description="t('module.ai-assistant.panel.startDescription', { name: workspace.activeTab.value.assistant.name })"
            icon-text="AI"
          />

          <article
            v-for="message in workspace.activeTab.value.messages"
            :key="message.id"
            class="ai-assistant-panel__message"
            :class="[`is-${message.role}`, { 'is-thinking': message.thinking }]"
          >
            <span v-if="message.role === 'assistant'" class="ai-assistant-panel__mark">
              {{ workspace.activeTab.value.assistant.mark }}
            </span>
            <div
              v-if="message.role === 'assistant'"
              class="ai-assistant-panel__message-copy"
              v-html="message.htmlContent"
            ></div>
            <p v-else class="ai-assistant-panel__message-copy">{{ message.content }}</p>
          </article>

          <section
            v-if="workspace.activeTab.value.toolCalls.length > 0"
            class="ai-assistant-panel__tool-strip"
            :aria-label="t('module.ai-assistant.panel.actionStatusAria')"
          >
            <article
              v-for="tool in workspace.activeTab.value.toolCalls"
              :key="tool.toolCallId"
              class="ai-assistant-panel__tool-card"
            >
              <header>
                <strong>{{ tool.displayName }}</strong>
                <span>{{ tool.statusLabel }} · {{ t('module.ai-assistant.panel.toolRisk', { level: tool.riskLevelLabel }) }}</span>
              </header>
              <p v-if="tool.argumentsSummary" class="ai-assistant-panel__tool-summary">{{ tool.argumentsSummary }}</p>
              <div v-if="tool.canApprove" class="ai-assistant-panel__tool-actions">
                <button
                  class="ai-assistant-panel__button is-primary"
                  type="button"
                  :disabled="workspace.actionLoading.value"
                  @click="approveToolCall(tool.toolCallId)"
                >
                  {{ t('module.ai-assistant.common.execute') }}
                </button>
                <button
                  class="ai-assistant-panel__button"
                  type="button"
                  :disabled="workspace.actionLoading.value"
                  @click="rejectToolCall(tool.toolCallId)"
                >
                  {{ t('module.ai-assistant.common.cancel') }}
                </button>
              </div>
              <p v-if="tool.failureReason" class="ai-assistant-panel__tool-error">{{ tool.failureReason }}</p>
            </article>
          </section>
        </div>
      </div>

      <footer class="ai-assistant-panel__composer" data-guide-anchor="assistant-input">
        <textarea
          v-model="workspace.draftMessage.value"
          rows="3"
          :placeholder="t('module.ai-assistant.panel.inputPlaceholder', { name: workspace.activeTab.value.assistant.name })"
          @keyup.enter.exact.prevent="sendMessage"
        />
        <div class="ai-assistant-panel__composer-actions">
          <el-select
            v-model="workspace.activeModel.value"
            class="ai-assistant-panel__model-select"
            size="small"
            :aria-label="t('module.ai-assistant.panel.modelSelectAria')"
          >
            <el-option
              v-for="model in workspace.modelOptions.value"
              :key="model.value"
              :label="model.label"
              :value="model.value"
            />
          </el-select>
          <span class="ai-assistant-panel__spacer" />
          <button
            class="ai-assistant-panel__send"
            type="button"
            :aria-label="t('module.ai-assistant.panel.sendAria')"
            :disabled="!canSend"
            @click="sendMessage"
          >
            {{ t('module.ai-assistant.common.send') }}
          </button>
        </div>
        <p v-if="workspace.actionError.value" class="ai-assistant-panel__action-error">
          {{ workspace.actionError.value }}
        </p>
      </footer>
    </template>
  </section>
</template>

<style>
.ai-assistant-panel {
  min-width: 0;
  min-height: 0;
  height: 100%;
  max-height: 100dvh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: var(--console-card-bg, #ffffff);
  color: var(--console-text, #1f2937);
}

/* Geometry comes from .shell-context-header; keep only panel-local overlays here. */
.ai-assistant-panel__tabs {
  position: relative;
}

.ai-assistant-panel__send {
  width: var(--console-control-height, 36px);
  height: var(--console-control-height, 36px);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: 0 0 auto;
  padding: 0;
  border: 1px solid var(--console-field-border, #dbe3ef);
  border-radius: 6px;
  background: var(--console-field-bg, #ffffff);
  color: var(--console-text, #334155);
  cursor: pointer;
  font: inherit;
}

.ai-assistant-panel__plus:hover,
.ai-assistant-panel__close:hover {
  color: var(--console-primary, #2563eb);
}

.ai-assistant-panel__tab-list {
  min-width: 0;
  display: flex;
  align-items: center;
  gap: var(--console-space-2, 8px);
  overflow-x: auto;
}

.ai-assistant-panel__tab,
.ai-assistant-panel__menu-item,
.ai-assistant-panel__assistant-card {
  min-width: 0;
  display: flex;
  align-items: center;
  border: 0;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font: inherit;
  text-align: left;
}

.ai-assistant-panel__tab {
  max-width: 180px;
  min-height: 28px;
  gap: 6px;
  padding: 2px 8px;
  border: 1px solid var(--console-field-border, #dbe3ef);
  border-radius: 6px;
  background: var(--console-block-bg, #f8fafc);
}

.ai-assistant-panel__tab.is-active {
  border-color: var(--console-primary, #2563eb);
  background: color-mix(in srgb, var(--console-primary, #2563eb) 8%, var(--console-card-bg, #ffffff));
}

.ai-assistant-panel__tab-title {
  min-width: 0;
  overflow: hidden;
  color: var(--console-title, #172033);
  font-size: var(--console-caption-size, 12px);
  font-weight: 700;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ai-assistant-panel__tab-close {
  color: var(--console-muted, #64748b);
  line-height: 1;
}

.ai-assistant-panel__mark,
.ai-assistant-panel__assistant-mark {
  width: 22px;
  height: 22px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: 0 0 auto;
  border-radius: 6px;
  background: var(--console-primary, #2563eb);
  color: #ffffff;
  font-size: 12px;
  font-weight: 700;
}

.ai-assistant-panel__plus-menu {
  position: absolute;
  z-index: 45;
  top: calc(100% + 6px);
  left: 12px;
  width: min(320px, calc(100vw - 40px));
  padding: 6px;
  border: 1px solid var(--console-card-border, #dbe3ef);
  border-radius: 8px;
  background: var(--console-card-bg, #ffffff);
  box-shadow: var(--console-card-shadow, 0 10px 30px rgba(15, 23, 42, 0.12));
}

.ai-assistant-panel__menu-item {
  width: 100%;
  gap: 10px;
  padding: 8px;
  border-radius: 6px;
}

.ai-assistant-panel__menu-state {
  width: 100%;
  margin: 0;
  padding: 8px;
  border: 0;
  border-radius: 6px;
  background: transparent;
  color: var(--console-muted, #64748b);
  font: inherit;
  text-align: left;
}

.ai-assistant-panel__menu-state.is-action {
  cursor: pointer;
}

.ai-assistant-panel__menu-item:hover,
.ai-assistant-panel__assistant-card:hover,
.ai-assistant-panel__menu-state.is-action:hover {
  background: var(--console-block-bg, #f8fafc);
}

.ai-assistant-panel__menu-item span:last-child,
.ai-assistant-panel__assistant-copy {
  min-width: 0;
  display: grid;
  gap: 2px;
}

.ai-assistant-panel__menu-item strong,
.ai-assistant-panel__assistant-copy strong {
  color: var(--console-title, #172033);
  font-size: var(--console-body-size, 14px);
}

.ai-assistant-panel__menu-item small,
.ai-assistant-panel__assistant-copy small {
  overflow: hidden;
  color: var(--console-muted, #64748b);
  font-size: var(--console-caption-size, 12px);
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ai-assistant-panel__empty {
  min-height: 0;
  flex: 1;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding: var(--console-space-5, 20px);
  overflow-y: auto;
  background: var(--console-page-bg, #f8fafc);
}

.ai-assistant-panel__entry {
  width: min(420px, 100%);
  display: grid;
  gap: var(--console-space-4, 16px);
}

.ai-assistant-panel__entry-header h2 {
  margin: 0;
  color: var(--console-title, #172033);
  font-size: 16px;
  font-weight: 650;
  line-height: 1.35;
}

.ai-assistant-panel__entry-header p {
  margin: 6px 0 0;
  color: var(--console-muted, #64748b);
  font-size: var(--console-caption-size, 12px);
  line-height: 1.55;
}

.ai-assistant-panel__assistant-list {
  width: 100%;
  display: grid;
  gap: 8px;
}

.ai-assistant-panel__empty-state {
  width: min(420px, 100%);
}

.ai-assistant-panel__assistant-card {
  width: 100%;
  gap: 12px;
  padding: 12px 14px;
  border: 1px solid var(--console-card-border, #dbe3ef);
  border-radius: 8px;
  background: var(--console-card-bg, #ffffff);
  box-shadow: var(--console-card-shadow, 0 1px 2px rgba(15, 23, 42, 0.04));
  transition: border-color 0.14s ease, background 0.14s ease;
}

.ai-assistant-panel__assistant-card:hover {
  border-color: color-mix(in srgb, var(--console-primary, #2563eb) 28%, var(--console-card-border, #dbe3ef));
  background: color-mix(in srgb, var(--console-primary, #2563eb) 4%, var(--console-card-bg, #ffffff));
}

.ai-assistant-panel__assistant-mark {
  width: 28px;
  height: 28px;
}

.ai-assistant-panel__conversation {
  min-height: 0;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 0;
  overflow: hidden;
  background: var(--console-page-bg, #f8fafc);
}

.ai-assistant-panel__conversation-toolbar {
  flex: 0 0 auto;
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 16px;
  border-bottom: 1px solid var(--console-card-border, #dbe3ef);
  background: var(--console-card-bg, #ffffff);
}

.ai-assistant-panel__conversation-heading {
  min-width: 0;
  display: grid;
  gap: 2px;
}

.ai-assistant-panel__conversation-heading strong {
  color: var(--console-title, #172033);
  font-size: 14px;
  font-weight: 650;
  line-height: 1.35;
}

.ai-assistant-panel__conversation-heading span {
  overflow: hidden;
  color: var(--console-muted, #64748b);
  font-size: var(--console-caption-size, 12px);
  line-height: 1.45;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ai-assistant-panel__text-button {
  flex: 0 0 auto;
  min-height: 28px;
  padding: 0 8px;
  border: 0;
  border-radius: 6px;
  background: transparent;
  color: var(--console-muted, #64748b);
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  font-weight: 600;
}

.ai-assistant-panel__text-button:hover:not(:disabled) {
  color: var(--console-primary, #2563eb);
  background: color-mix(in srgb, var(--console-primary, #2563eb) 8%, transparent);
}

.ai-assistant-panel__text-button:disabled {
  cursor: not-allowed;
  opacity: 0.5;
}

.ai-assistant-panel__messages {
  min-height: 0;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 14px 16px;
  overflow-y: auto;
}

.ai-assistant-panel__thread-empty {
  margin: auto 0;
  width: 100%;
  border-style: solid;
  background: var(--console-card-bg, #ffffff);
}

.ai-assistant-panel__message {
  max-width: 92%;
  display: flex;
  align-items: flex-start;
  gap: 8px;
}

.ai-assistant-panel__message-copy {
  min-width: 0;
  margin: 0;
  padding: 10px 12px;
  border: 1px solid var(--console-card-border, #dbe3ef);
  border-radius: 10px;
  background: var(--console-card-bg, #ffffff);
  color: var(--console-text, #334155);
  line-height: 1.65;
  overflow-wrap: anywhere;
  box-shadow: none;
}

.ai-assistant-panel__message-copy > * {
  margin: 0 0 8px;
}

.ai-assistant-panel__message-copy > :last-child {
  margin-bottom: 0;
}

.ai-assistant-panel__message-copy ul,
.ai-assistant-panel__message-copy ol {
  padding-left: 18px;
}

.ai-assistant-panel__message-copy strong {
  color: var(--console-title, #172033);
  font-weight: 700;
}

.ai-assistant-panel__message.is-user {
  align-self: flex-end;
}

.ai-assistant-panel__message.is-user .ai-assistant-panel__message-copy {
  border-color: color-mix(in srgb, var(--console-primary, #2563eb) 22%, var(--console-card-border, #dbe3ef));
  background: color-mix(in srgb, var(--console-primary, #2563eb) 8%, var(--console-card-bg, #ffffff));
  color: var(--console-title, #172033);
  white-space: pre-wrap;
}

.ai-assistant-panel__message.is-thinking .ai-assistant-panel__message-copy {
  color: var(--console-muted, #64748b);
  font-style: italic;
}

.ai-assistant-panel__tool-strip {
  display: grid;
  gap: 8px;
  margin-top: 2px;
}

.ai-assistant-panel__tool-card {
  display: grid;
  gap: 8px;
  padding: 12px;
  border: 1px solid var(--console-card-border, #dbe3ef);
  border-radius: 8px;
  background: var(--console-card-bg, #ffffff);
}

.ai-assistant-panel__tool-card header {
  min-width: 0;
  display: grid;
  gap: 2px;
}

.ai-assistant-panel__tool-card strong {
  color: var(--console-title, #172033);
  font-size: var(--console-body-size, 14px);
  overflow-wrap: anywhere;
}

.ai-assistant-panel__tool-card span {
  color: var(--console-muted, #64748b);
  font-size: var(--console-caption-size, 12px);
}

.ai-assistant-panel__tool-summary {
  margin: 0;
  color: var(--console-muted, #64748b);
  font-size: var(--console-caption-size, 12px);
}

.ai-assistant-panel__tool-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.ai-assistant-panel__button {
  min-height: 30px;
  padding: 4px 12px;
  border: 1px solid var(--console-field-border, #dbe3ef);
  border-radius: 6px;
  background: var(--console-field-bg, #ffffff);
  color: var(--console-text, #334155);
  cursor: pointer;
  font: inherit;
  font-size: 13px;
  font-weight: 600;
}

.ai-assistant-panel__button.is-primary {
  border-color: var(--console-primary, #2563eb);
  background: var(--console-primary, #2563eb);
  color: #ffffff;
}

.ai-assistant-panel__button:hover:not(:disabled) {
  border-color: color-mix(in srgb, var(--console-primary, #2563eb) 35%, var(--console-field-border, #dbe3ef));
}

.ai-assistant-panel__button.is-primary:hover:not(:disabled) {
  background: color-mix(in srgb, var(--console-primary, #2563eb) 88%, #0f172a);
}

.ai-assistant-panel__button:disabled,
.ai-assistant-panel__send:disabled {
  cursor: not-allowed;
  opacity: 0.58;
}

.ai-assistant-panel__tool-error,
.ai-assistant-panel__action-error {
  margin: 0;
  color: var(--console-danger, #dc2626);
  font-size: var(--console-caption-size, 12px);
}

.ai-assistant-panel__composer {
  flex: 0 0 auto;
  display: grid;
  gap: 8px;
  margin: 0;
  padding: 12px 16px 14px;
  border: 0;
  border-top: 1px solid var(--console-card-border, #dbe3ef);
  border-radius: 0;
  background: var(--console-card-bg, #ffffff);
  box-shadow: none;
}

.ai-assistant-panel__composer textarea {
  width: 100%;
  min-width: 0;
  min-height: 72px;
  resize: none;
  padding: 10px 12px;
  border: 1px solid var(--console-field-border, #dbe3ef);
  border-radius: 8px;
  outline: 0;
  background: var(--console-field-bg, #ffffff);
  color: var(--console-text, #334155);
  font: inherit;
  line-height: 1.55;
}

.ai-assistant-panel__composer textarea:focus {
  border-color: color-mix(in srgb, var(--console-primary, #2563eb) 45%, var(--console-field-border, #dbe3ef));
  box-shadow: 0 0 0 2px color-mix(in srgb, var(--console-primary, #2563eb) 12%, transparent);
}

.ai-assistant-panel__composer-actions {
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 8px;
}

.ai-assistant-panel__model-select {
  width: 168px;
}

.ai-assistant-panel__spacer {
  flex: 1;
}

.ai-assistant-panel__send {
  min-height: 32px;
  min-width: 64px;
  padding: 0 14px;
  border: 1px solid var(--console-primary, #2563eb);
  border-radius: 6px;
  background: var(--console-primary, #2563eb);
  color: #ffffff;
  cursor: pointer;
  font: inherit;
  font-size: 13px;
  font-weight: 650;
}

.ai-assistant-panel__send:hover:not(:disabled) {
  background: color-mix(in srgb, var(--console-primary, #2563eb) 88%, #0f172a);
}

.ai-assistant-panel__action-error {
  padding: 0 2px;
}

@media (max-width: 900px) {
  .ai-assistant-panel {
    min-height: min(72vh, 720px);
  }

  .ai-assistant-panel__model-select {
    width: min(42vw, 156px);
  }
}
</style>
