<script setup>
import AiAssistantPanel from '../components/AiAssistantPanel.vue';
</script>

<template>
  <section class="ai-assistant-conversation-page console-page">
    <AiAssistantPanel />
  </section>
</template>

<style>
.ai-assistant-conversation-page {
  min-height: calc(100vh - 56px - var(--console-page-gap, 20px) * 2);
  overflow: hidden;
  border: 1px solid var(--console-card-border, #dbe3ef);
  border-radius: 8px;
  background: var(--console-card-bg, #ffffff);
}
</style>
