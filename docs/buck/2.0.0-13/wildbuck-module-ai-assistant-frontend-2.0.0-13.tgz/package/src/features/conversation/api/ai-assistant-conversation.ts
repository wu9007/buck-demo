import {
  approveAiToolCall,
  clearAiConversation,
  createAiConversation,
  deleteAiConversation,
  editAiToolCall,
  getAiConversation,
  listAvailableAiAssistants,
  listAvailableAiModelServices,
  openAiConversation,
  rejectAiToolCall,
  sendAiConversationMessage,
} from '../../../generated/sdk';

export const aiAssistantConversationApi = {
  listAvailableAiAssistants,
  listAvailableAiModelServices,
  createAiConversation,
  openAiConversation,
  sendAiConversationMessage,
  getAiConversation,
  clearAiConversation,
  deleteAiConversation,
  approveAiToolCall,
  editAiToolCall,
  rejectAiToolCall,
};
