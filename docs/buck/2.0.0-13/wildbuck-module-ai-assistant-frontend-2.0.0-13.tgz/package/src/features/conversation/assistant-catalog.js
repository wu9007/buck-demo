import { translateAiAssistant } from '../../i18n.js';

const toolCallStatusKeys = {
  PENDING_APPROVAL: 'module.ai-assistant.toolStatus.PENDING_APPROVAL',
  APPROVED: 'module.ai-assistant.toolStatus.APPROVED',
  EDITED: 'module.ai-assistant.toolStatus.EDITED',
  REJECTED: 'module.ai-assistant.toolStatus.REJECTED',
  EXECUTING: 'module.ai-assistant.toolStatus.EXECUTING',
  SUCCEEDED: 'module.ai-assistant.toolStatus.SUCCEEDED',
  FAILED: 'module.ai-assistant.toolStatus.FAILED',
  EXPIRED: 'module.ai-assistant.toolStatus.EXPIRED',
};

const riskLevelKeys = {
  LOW: 'module.ai-assistant.risk.LOW',
  MEDIUM: 'module.ai-assistant.risk.MEDIUM',
  HIGH: 'module.ai-assistant.risk.HIGH',
  CRITICAL: 'module.ai-assistant.risk.CRITICAL',
};

const toolCallDisplayNameKeys = {
  'security.login.read': 'module.ai-assistant.tool.security.login.read',
  'security.login.explain': 'module.ai-assistant.tool.security.login.explain',
  'security.login.proposeUpdate': 'module.ai-assistant.tool.security.login.proposeUpdate',
  'security.login.applyUpdate': 'module.ai-assistant.tool.security.login.applyUpdate',
  'security.password.read': 'module.ai-assistant.tool.security.password.read',
  'security.password.explain': 'module.ai-assistant.tool.security.password.explain',
  'security.password.proposeUpdate': 'module.ai-assistant.tool.security.password.proposeUpdate',
  'security.password.applyUpdate': 'module.ai-assistant.tool.security.password.applyUpdate',
  'security.transport.read': 'module.ai-assistant.tool.security.transport.read',
  'security.transport.explain': 'module.ai-assistant.tool.security.transport.explain',
  'security.transport.proposeUpdate': 'module.ai-assistant.tool.security.transport.proposeUpdate',
  'security.transport.applyUpdate': 'module.ai-assistant.tool.security.transport.applyUpdate',
  'security.audit.summarize': 'module.ai-assistant.tool.security.audit.summarize',
};

function defaultTranslate(key, params) {
  return translateAiAssistant(null, key, params);
}

export function normalizeAssistantSummary(summary) {
  const code = trimText(summary?.assistantCode) || trimText(summary?.assistantId) || 'assistant';
  const name = trimText(summary?.assistantName) || code;
  return {
    assistantId: trimText(summary?.assistantId),
    code,
    name,
    mark: createAssistantMark(name, code),
    summary: trimText(summary?.description),
    enabled: summary?.enabled !== false,
  };
}

export function normalizeModelServiceSummary(summary, translate = defaultTranslate) {
  const defaultModel = trimText(summary?.defaultModel);
  const modelServiceId = trimText(summary?.modelServiceId);
  const serviceName = trimText(summary?.serviceName) || translate('module.ai-assistant.common.aiService');
  return {
    value: modelServiceId || trimText(summary?.serviceCode) || defaultModel,
    label: serviceName,
    providerCode: trimText(summary?.providerCode),
    modelServiceId,
    serviceCode: trimText(summary?.serviceCode),
    defaultModel,
    enabled: summary?.enabled !== false,
  };
}

export function findAssistantByCode(code, assistants = []) {
  return assistants.find((assistant) => assistant.code === code) || null;
}

export function getToolCallStatusLabel(status, translate = defaultTranslate) {
  const key = toolCallStatusKeys[status];
  if (key) {
    return translate(key);
  }
  return status || translate('module.ai-assistant.common.unknown');
}

export function getRiskLevelLabel(riskLevel, translate = defaultTranslate) {
  const key = riskLevelKeys[riskLevel];
  if (key) {
    return translate(key);
  }
  return riskLevel || translate('module.ai-assistant.common.unknown');
}

export function getToolCallDisplayName(toolCode, translate = defaultTranslate) {
  const key = toolCallDisplayNameKeys[toolCode];
  if (key) {
    return translate(key);
  }
  return translate('module.ai-assistant.tool.defaultName');
}

function createAssistantMark(name, fallback) {
  const candidate = Array.from(name || fallback || 'AI').find((char) => char.trim().length > 0);
  return candidate || 'AI';
}

function trimText(value) {
  return typeof value === 'string' ? value.trim() : '';
}
