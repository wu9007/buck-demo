import { aiAssistantConversationPermissions } from './permission/index.js';
import { aiAssistantConversationRoutes } from './routes/index.js';

export const aiAssistantConversationFeature = {
  featureKey: 'conversation',
  routes: aiAssistantConversationRoutes,
  permissions: aiAssistantConversationPermissions,
};
