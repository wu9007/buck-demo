import { computed, getCurrentScope, onScopeDispose, ref } from 'vue';
import {
  findAssistantByCode,
  getRiskLevelLabel,
  getToolCallDisplayName,
  getToolCallStatusLabel,
  normalizeAssistantSummary,
  normalizeModelServiceSummary,
} from '../assistant-catalog.js';
import { onAiModelServiceCatalogChanged } from '../../model-service/model-service-catalog-events.js';
import { translateAiAssistant } from '../../../i18n.js';

function defaultTranslate(key, params) {
  return translateAiAssistant(null, key, params);
}

let tabSequence = 0;
let optimisticMessageSequence = 0;

export function useAiAssistantSidebarWorkspace(options = {}) {
  const api = options.api || createMissingConversationApi();
  const t = typeof options.t === 'function'
    ? options.t
    : (key, params) => translateAiAssistant(null, key, params);
  const assistants = ref([]);
  const modelOptions = ref([]);
  const tabs = ref([]);
  const activeTabId = ref('');
  const draftMessage = ref('');
  const assistantMenuOpen = ref(false);
  const activeModel = ref('');
  const loading = ref(false);
  const actionLoading = ref(false);
  const loadError = ref('');
  const actionError = ref('');

  const activeTab = computed(() => tabs.value.find((tab) => tab.id === activeTabId.value) || null);
  if (getCurrentScope()) {
    const stopModelServiceCatalogListener = onAiModelServiceCatalogChanged(() => {
      void refreshModelOptions();
    });
    onScopeDispose(stopModelServiceCatalogListener);
  }

  async function initialize() {
    loading.value = true;
    loadError.value = '';
    actionError.value = '';
    const [availableAssistants, availableModelServices] = await Promise.allSettled([
      api.listAvailableAiAssistants(undefined),
      api.listAvailableAiModelServices(undefined),
    ]);
    try {
      if (availableAssistants.status === 'fulfilled') {
        assistants.value = records(availableAssistants.value)
          .filter((assistant) => assistant.enabled !== false)
          .map(normalizeAssistantSummary);
      } else {
        assistants.value = [];
        loadError.value = resolveErrorMessage(availableAssistants.reason, t);
      }
      modelOptions.value = availableModelServices.status === 'fulfilled'
        ? normalizeModelOptions(availableModelServices.value, t)
        : [];
      reconcileActiveModelSelection();
    } finally {
      loading.value = false;
    }
  }

  async function refreshModelOptions() {
    try {
      const availableModelServices = await api.listAvailableAiModelServices(undefined);
      modelOptions.value = normalizeModelOptions(availableModelServices, t);
    } catch (_error) {
      modelOptions.value = [];
    }
    reconcileActiveModelSelection();
  }

  async function openAssistant(assistantCode) {
    const assistant = findAssistantByCode(assistantCode, assistants.value);
    if (!assistant) {
      return null;
    }
    const openedTab = findTabByAssistant(assistant);
    if (openedTab) {
      activeTabId.value = openedTab.id;
      assistantMenuOpen.value = false;
      return openedTab;
    }
    actionLoading.value = true;
    actionError.value = '';
    try {
      const conversation = await api.openAiConversation({
        assistantId: assistant.assistantId,
        title: assistant.name,
      });
      const tab = createConversationTab(conversation, assistant, { t });
      tabs.value = [...tabs.value, tab];
      activeTabId.value = tab.id;
      assistantMenuOpen.value = false;
      return tab;
    } catch (error) {
      actionError.value = resolveErrorMessage(error, t);
      return null;
    } finally {
      actionLoading.value = false;
    }
  }

  function findTabByAssistant(assistant) {
    return tabs.value.find((tab) =>
      tab.assistant.assistantId === assistant.assistantId || tab.assistant.code === assistant.code,
    ) || null;
  }

  function activateTab(tabId) {
    if (tabs.value.some((tab) => tab.id === tabId)) {
      activeTabId.value = tabId;
    }
  }

  function closeTab(tabId) {
    const closingIndex = tabs.value.findIndex((tab) => tab.id === tabId);
    if (closingIndex < 0) {
      return;
    }
    const nextTabs = tabs.value.filter((tab) => tab.id !== tabId);
    tabs.value = nextTabs;
    if (activeTabId.value !== tabId) {
      return;
    }
    const fallbackTab = nextTabs[Math.max(0, closingIndex - 1)] || nextTabs[0] || null;
    activeTabId.value = fallbackTab?.id || '';
  }

  function toggleAssistantMenu() {
    assistantMenuOpen.value = !assistantMenuOpen.value;
  }

  function closeAssistantMenu() {
    assistantMenuOpen.value = false;
  }

  async function sendMessage() {
    const content = draftMessage.value.trim();
    const tab = activeTab.value;
    if (!content || !tab) {
      return;
    }
    const tabId = tab.id;
    actionLoading.value = true;
    actionError.value = '';
    draftMessage.value = '';
    const optimisticUserMessageId = appendOptimisticMessage(tabId, {
      role: 'user',
      content,
    });
    const thinkingMessageId = appendOptimisticMessage(tabId, {
      role: 'assistant',
      content: t('module.ai-assistant.panel.thinking'),
      thinking: true,
    });
    try {
      const modelOption = selectedModelOption(activeModel.value) || modelOptions.value[0] || null;
      const result = await api.sendAiConversationMessage(tab.conversationId, {
        content,
        modelServiceId: modelOption?.modelServiceId || undefined,
        model: modelOption?.defaultModel || undefined,
      });
      applyConversationDetail(result.conversation, {
        toolCalls: result.toolCalls,
        tabId,
      });
    } catch (error) {
      removeOptimisticMessages(tabId, [optimisticUserMessageId, thinkingMessageId]);
      if (!draftMessage.value) {
        draftMessage.value = content;
      }
      actionError.value = resolveErrorMessage(error, t);
    } finally {
      actionLoading.value = false;
    }
  }

  async function refreshActiveConversation() {
    const tab = activeTab.value;
    if (!tab) {
      return null;
    }
    const conversation = await api.getAiConversation(tab.conversationId, undefined);
    applyConversationDetail(conversation);
    return conversation;
  }

  async function clearActiveConversation() {
    const tab = activeTab.value;
    if (!tab) {
      return null;
    }
    const previousTab = tab;
    tabs.value = tabs.value.map((candidate) =>
      candidate.id === tab.id
        ? { ...candidate, messages: [], toolCalls: [] }
        : candidate,
    );
    actionLoading.value = true;
    actionError.value = '';
    try {
      const conversation = await api.clearAiConversation(tab.conversationId, undefined);
      applyConversationDetail(conversation, { tabId: tab.id });
      return conversation;
    } catch (error) {
      tabs.value = tabs.value.map((candidate) => (candidate.id === tab.id ? previousTab : candidate));
      actionError.value = resolveErrorMessage(error, t);
      return null;
    } finally {
      actionLoading.value = false;
    }
  }

  async function deleteActiveConversation() {
    const tab = activeTab.value;
    if (!tab) {
      return false;
    }
    actionLoading.value = true;
    actionError.value = '';
    try {
      await api.deleteAiConversation(tab.conversationId, undefined);
      closeTab(tab.id);
      return true;
    } catch (error) {
      actionError.value = resolveErrorMessage(error, t);
      return false;
    } finally {
      actionLoading.value = false;
    }
  }

  async function approveToolCall(toolCallId, reason = '') {
    await runToolCallAction(() => api.approveAiToolCall(toolCallId, normalizeDecisionInput(reason)));
  }

  async function editToolCall(toolCallId, editedArgumentsJson, reason = '') {
    await runToolCallAction(() =>
      api.editAiToolCall(toolCallId, {
        editedArgumentsJson,
        ...normalizeDecisionInput(reason),
      }),
    );
  }

  async function rejectToolCall(toolCallId, reason = '') {
    await runToolCallAction(() => api.rejectAiToolCall(toolCallId, normalizeDecisionInput(reason)));
  }

  async function runToolCallAction(action) {
    actionLoading.value = true;
    actionError.value = '';
    try {
      await action();
      await refreshActiveConversation();
    } catch (error) {
      actionError.value = resolveErrorMessage(error, t);
    } finally {
      actionLoading.value = false;
    }
  }

  function applyConversationDetail(conversation, options = {}) {
    if (!conversation) {
      return;
    }
    const tab = tabs.value.find((candidate) => candidate.id === options.tabId) || activeTab.value;
    if (!tab) {
      return;
    }
    const nextTab = createConversationTab(conversation, tab.assistant, {
      id: tab.id,
      fallbackToolCalls: options.toolCalls,
      t,
    });
    tabs.value = tabs.value.map((candidate) => (candidate.id === tab.id ? nextTab : candidate));
  }

  function appendOptimisticMessage(tabId, message) {
    const messageId = `pending-message-${++optimisticMessageSequence}`;
    const normalizedMessage = normalizeConversationMessage({
      role: message.role,
      content: message.content,
      thinking: message.thinking === true,
      pending: true,
    }, messageId);
    tabs.value = tabs.value.map((tab) =>
      tab.id === tabId
        ? {
            ...tab,
            messages: [
              ...tab.messages,
              normalizedMessage,
            ],
          }
        : tab,
    );
    return messageId;
  }

  function removeOptimisticMessages(tabId, messageIds) {
    const pendingMessageIds = new Set(messageIds);
    tabs.value = tabs.value.map((tab) =>
      tab.id === tabId
        ? {
            ...tab,
            messages: tab.messages.filter((message) => !pendingMessageIds.has(message.id)),
          }
        : tab,
    );
  }

  function selectedModelOption(value) {
    const selectedValue = trimText(value);
    if (!selectedValue) {
      return null;
    }
    return modelOptions.value.find((option) =>
      option.value === selectedValue
      || option.modelServiceId === selectedValue
      || option.defaultModel === selectedValue,
    ) || null;
  }

  function reconcileActiveModelSelection() {
    if (!selectedModelOption(activeModel.value)) {
      activeModel.value = modelOptions.value[0]?.value || '';
    }
  }

  return {
    assistants,
    modelOptions,
    tabs,
    activeTab,
    activeTabId,
    draftMessage,
    assistantMenuOpen,
    activeModel,
    loading,
    actionLoading,
    loadError,
    actionError,
    initialize,
    openAssistant,
    activateTab,
    closeTab,
    toggleAssistantMenu,
    closeAssistantMenu,
    sendMessage,
    refreshActiveConversation,
    clearActiveConversation,
    deleteActiveConversation,
    approveToolCall,
    editToolCall,
    rejectToolCall,
  };
}

function createConversationTab(conversation, assistant, options = {}) {
  const translate = typeof options.t === 'function' ? options.t : defaultTranslate;
  const id = options.id || `assistant-tab-${++tabSequence}`;
  const messages = normalizeMessages(conversation.messages);
  const toolCalls = normalizeToolCalls(
    conversation.pendingToolCalls?.length ? conversation.pendingToolCalls : options.fallbackToolCalls,
    translate,
  );
  const assistantName = conversation.assistantName || assistant.name || conversation.title || translate('module.ai-assistant.common.aiAssistant');
  return {
    id,
    conversationId: conversation.conversationId,
    title: assistantName,
    assistant: {
      ...assistant,
      assistantId: conversation.assistantId || assistant.assistantId,
      name: assistantName,
    },
    status: conversation.status,
    messages,
    toolCalls,
  };
}

function normalizeModelOptions(modelServices, translate = defaultTranslate) {
  return records(modelServices)
    .filter((service) => service.enabled !== false)
    .map((summary) => normalizeModelServiceSummary(summary, translate))
    .filter((model) => model.value)
    // Prefer tool-calling friendly providers for security assistant workflows.
    .sort((left, right) => {
      const rankDelta = modelProviderPreferenceRank(left.providerCode) - modelProviderPreferenceRank(right.providerCode);
      if (rankDelta !== 0) {
        return rankDelta;
      }
      return String(left.label || '').localeCompare(String(right.label || ''), 'zh-CN');
    });
}

function modelProviderPreferenceRank(providerCode) {
  const provider = String(providerCode || '').trim().toLowerCase();
  if (provider === 'deepseek') {
    return 0;
  }
  if (provider === 'openai' || provider === 'openai-compatible' || provider === 'openrouter') {
    return 1;
  }
  if (provider === 'ollama') {
    return 9;
  }
  return 5;
}

function normalizeMessages(messages = []) {
  return messages
    .map((message, index) => normalizeConversationMessage(message, message.messageId || `message-${index + 1}`))
    .filter((message) => message.role !== 'tool' && message.content.trim());
}

function normalizeConversationMessage(message, fallbackId) {
  const role = normalizeRole(message.role);
  const content = role === 'assistant'
    ? sanitizeAssistantMessageContent(message.content || '')
    : message.content || '';
  return {
    id: fallbackId,
    messageId: message.messageId,
    conversationId: message.conversationId,
    role,
    content,
    htmlContent: role === 'assistant' ? renderAssistantMessageHtml(content) : '',
    toolCallId: message.toolCallId,
    createTime: message.createTime,
    thinking: message.thinking === true,
    pending: message.pending === true,
  };
}

function normalizeToolCalls(toolCalls = [], translate = defaultTranslate) {
  return toolCalls.map((toolCall) => {
    const status = toolCall.status || '';
    const argumentsPreview = toolCall.proposedArgumentsJson || toolCall.argumentsJson || '';
    return {
      ...toolCall,
      displayName: getToolCallDisplayName(toolCall.toolCode, translate),
      statusLabel: getToolCallStatusLabel(status, translate),
      riskLevelLabel: getRiskLevelLabel(toolCall.riskLevel, translate),
      argumentsPreview,
      argumentsSummary: summarizeToolArguments(toolCall.toolCode, argumentsPreview, translate),
      canApprove: status === 'PENDING_APPROVAL',
    };
  });
}

function summarizeToolArguments(toolCode, argumentsPreview, translate = defaultTranslate) {
  if (!argumentsPreview || !argumentsPreview.trim()) {
    return defaultToolSummary(toolCode, translate);
  }
  const payload = parseJsonObject(argumentsPreview);
  if (!payload) {
    return defaultToolSummary(toolCode, translate);
  }
  if (toolCode?.startsWith('security.login.')) {
    return summarizeLoginToolArguments(toolCode, payload, translate);
  }
  if (toolCode?.startsWith('security.password.')) {
    return toolCode.endsWith('.read') || toolCode.endsWith('.explain')
      ? translate('module.ai-assistant.toolSummary.password.read')
      : translate('module.ai-assistant.toolSummary.password.write');
  }
  if (toolCode?.startsWith('security.transport.')) {
    return toolCode.endsWith('.read') || toolCode.endsWith('.explain')
      ? translate('module.ai-assistant.toolSummary.transport.read')
      : translate('module.ai-assistant.toolSummary.transport.write');
  }
  if (toolCode?.startsWith('security.audit.')) {
    return translate('module.ai-assistant.toolSummary.audit');
  }
  return defaultToolSummary(toolCode, translate);
}

function summarizeLoginToolArguments(toolCode, payload, translate = defaultTranslate) {
  if (toolCode.endsWith('.read') || toolCode.endsWith('.explain')) {
    return translate('module.ai-assistant.toolSummary.login.read');
  }
  const patch = payload.patch && typeof payload.patch === 'object'
    ? payload.patch
    : payload;
  const captchaEnabled = firstBoolean(
    patch.captchaEnabled,
    patch.captcha?.captchaEnabled,
    patch.setting?.captchaEnabled,
    patch.setting?.captcha?.captchaEnabled,
  );
  if (captchaEnabled === false) {
    return translate('module.ai-assistant.toolSummary.login.captchaOff');
  }
  if (captchaEnabled === true) {
    return translate('module.ai-assistant.toolSummary.login.captchaOn');
  }
  return translate('module.ai-assistant.toolSummary.login.write');
}

function defaultToolSummary(toolCode, translate = defaultTranslate) {
  if (toolCode?.endsWith('.read') || toolCode?.endsWith('.explain')) {
    return translate('module.ai-assistant.toolSummary.defaultRead');
  }
  return translate('module.ai-assistant.toolSummary.defaultWrite');
}

function parseJsonObject(value) {
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : null;
  } catch (_error) {
    return null;
  }
}

function firstBoolean(...values) {
  return values.find((value) => typeof value === 'boolean');
}

function normalizeRole(role) {
  const normalizedRole = String(role || '').toLowerCase();
  if (normalizedRole === 'user' || normalizedRole === 'assistant' || normalizedRole === 'tool') {
    return normalizedRole;
  }
  return 'assistant';
}

function sanitizeAssistantMessageContent(content) {
  if (!content || !content.trim()) {
    return '';
  }
  const ranges = jsonObjectCandidates(content)
    .filter((candidate) => isPseudoToolCallJson(candidate.node));
  const withoutToolJson = removeJsonRanges(content, ranges);
  return withoutToolSentinels(withoutToolJson);
}

function renderAssistantMessageHtml(content) {
  const normalized = trimText(content);
  if (!normalized) {
    return '';
  }
  const blocks = [];
  let paragraphLines = [];
  let listType = '';
  let listItems = [];

  const flushParagraph = () => {
    if (paragraphLines.length === 0) {
      return;
    }
    blocks.push(`<p>${paragraphLines.map(renderInlineMarkdown).join('<br>')}</p>`);
    paragraphLines = [];
  };

  const flushList = () => {
    if (!listType || listItems.length === 0) {
      return;
    }
    blocks.push(`<${listType}>${listItems.map((item) => `<li>${item}</li>`).join('')}</${listType}>`);
    listType = '';
    listItems = [];
  };

  const rawLines = normalized.split('\n');
  for (let index = 0; index < rawLines.length; index += 1) {
    const rawLine = rawLines[index];
    const line = rawLine.trim();
    if (!line) {
      flushParagraph();
      flushList();
      continue;
    }
    // DeepSeek and similar providers often answer with pipe tables without a blank line separator.
    const nextLine = rawLines[index + 1]?.trim() || '';
    if (isMarkdownTableHeader(line) && isMarkdownTableSeparatorLine(nextLine)) {
      flushParagraph();
      flushList();
      const headerCells = splitMarkdownTableCells(line);
      const bodyRows = [];
      while (index + 2 < rawLines.length) {
        const candidate = rawLines[index + 2].trim();
        if (!candidate || !isMarkdownTableRow(candidate) || isMarkdownTableSeparatorLine(candidate)) {
          break;
        }
        bodyRows.push(splitMarkdownTableCells(candidate));
        index += 1;
      }
      index += 1;
      blocks.push(renderMarkdownTableHtml(headerCells, bodyRows));
      continue;
    }
    const orderedMatch = line.match(/^\d+\.\s+(.*)$/);
    const unorderedMatch = line.match(/^[-*]\s+(.*)$/);
    if (orderedMatch || unorderedMatch) {
      flushParagraph();
      const nextListType = orderedMatch ? 'ol' : 'ul';
      if (listType && listType !== nextListType) {
        flushList();
      }
      listType = nextListType;
      listItems.push(renderInlineMarkdown((orderedMatch || unorderedMatch)[1]));
      continue;
    }
    flushList();
    paragraphLines.push(line);
  }

  flushParagraph();
  flushList();
  return blocks.length > 0 ? blocks.join('') : `<p>${renderInlineMarkdown(normalized)}</p>`;
}

function renderMarkdownTableHtml(headerCells, bodyRows) {
  const tableStyle = 'width:100%;border-collapse:collapse';
  const headerHtml = renderMarkdownTableRow('th', headerCells);
  const bodyHtml = bodyRows.length > 0
    ? `<tbody>${bodyRows.map((row) => renderMarkdownTableRow('td', row)).join('')}</tbody>`
    : '';
  return `<table style="${tableStyle}"><thead>${headerHtml}</thead>${bodyHtml}</table>`;
}

function renderMarkdownTableRow(tagName, cells) {
  const cellStyle = tagName === 'th'
    ? 'padding:6px 8px;border:1px solid var(--console-card-border, #dbe3ef);background:var(--console-block-bg, #f8fafc);font-weight:700;text-align:left;vertical-align:top'
    : 'padding:6px 8px;border:1px solid var(--console-card-border, #dbe3ef);text-align:left;vertical-align:top';
  return `<tr>${cells.map((cell) => `<${tagName} style="${cellStyle}">${renderInlineMarkdown(cell)}</${tagName}>`).join('')}</tr>`;
}

function isMarkdownTableHeader(line) {
  return isMarkdownTableRow(line);
}

function isMarkdownTableRow(line) {
  const cells = splitMarkdownTableCells(line);
  return cells.length >= 2 && cells.some((cell) => cell.length > 0);
}

function isMarkdownTableSeparatorLine(line) {
  const cells = splitMarkdownTableCells(line);
  return cells.length >= 2 && cells.every((cell) => /^:?-{3,}:?$/.test(cell));
}

function splitMarkdownTableCells(line) {
  const normalized = String(line || '')
    .trim()
    .replace(/^\|+/, '')
    .replace(/\|+$/, '');
  if (!normalized.includes('|')) {
    return [];
  }
  return normalized.split('|').map((cell) => cell.trim());
}

function renderInlineMarkdown(text) {
  return escapeHtml(text)
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
}

function escapeHtml(text) {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function isPseudoToolCallJson(node) {
  if (!node || typeof node !== 'object' || Array.isArray(node)) {
    return false;
  }
  const functionNode = node.function && typeof node.function === 'object' && !Array.isArray(node.function)
    ? node.function
    : null;
  const toolCode = String(node.name || functionNode?.name || '');
  const hasArguments = Object.prototype.hasOwnProperty.call(node, 'arguments')
    || (functionNode && Object.prototype.hasOwnProperty.call(functionNode, 'arguments'));
  return hasArguments && looksLikeToolCode(toolCode);
}

function looksLikeToolCode(toolCode) {
  return /^[A-Za-z0-9_.:-]+\.[A-Za-z0-9_.:-]+$/.test(toolCode);
}

function removeJsonRanges(content, ranges) {
  if (ranges.length === 0) {
    return content;
  }
  let cursor = 0;
  let output = '';
  ranges.forEach((range) => {
    if (range.start < cursor) {
      return;
    }
    output += content.slice(cursor, range.start);
    cursor = range.end + 1;
  });
  return output + content.slice(cursor);
}

function withoutToolSentinels(content) {
  return content
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .split('\n')
    .map((line) => line.replace(/<\/?tool_call>/gi, '').trim())
    .filter((line) => line && !/^(uxtapose|porr|tool_call)$/i.test(line))
    .join('\n')
    .trim();
}

function jsonObjectCandidates(content) {
  const candidates = [];
  for (let start = 0; start < content.length; start += 1) {
    if (content[start] !== '{') {
      continue;
    }
    const end = findJsonObjectEnd(content, start);
    if (end < 0) {
      continue;
    }
    try {
      const node = JSON.parse(content.slice(start, end + 1));
      if (node && typeof node === 'object' && !Array.isArray(node)) {
        candidates.push({ start, end, node });
        start = end;
      }
    } catch (_error) {
      // Local models may mix prose and malformed tool JSON; invalid candidates are display noise.
    }
  }
  return candidates;
}

function findJsonObjectEnd(content, start) {
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let index = start; index < content.length; index += 1) {
    const current = content[index];
    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (current === '\\') {
        escaped = true;
      } else if (current === '"') {
        inString = false;
      }
      continue;
    }
    if (current === '"') {
      inString = true;
      continue;
    }
    if (current === '{') {
      depth += 1;
      continue;
    }
    if (current === '}') {
      depth -= 1;
      if (depth === 0) {
        return index;
      }
    }
  }
  return -1;
}

function normalizeDecisionInput(reason) {
  const normalizedReason = typeof reason === 'string' ? reason.trim() : '';
  return normalizedReason ? { reason: normalizedReason } : {};
}

function records(value) {
  if (Array.isArray(value)) {
    return value;
  }
  return Array.isArray(value?.records) ? value.records : [];
}

function resolveErrorMessage(error, translate = defaultTranslate) {
  const payloadMessage = readPayloadMessage(error?.payload);
  if (payloadMessage) {
    return payloadMessage;
  }
  const status = Number(error?.status);
  if (status === 401) {
    return translate('module.ai-assistant.error.sessionExpired');
  }
  if (status === 403 || status === 404) {
    return translate('module.ai-assistant.error.forbidden');
  }
  if (typeof error?.message === 'string' && error.message.trim()) {
    return error.message.trim();
  }
  return translate('module.ai-assistant.error.requestFailed');
}

function readPayloadMessage(payload) {
  if (payload == null || typeof payload !== 'object' || Array.isArray(payload)) {
    return '';
  }
  return trimPayloadMessage(payload.message)
    || trimPayloadMessage(payload.recovery)
    || trimPayloadMessage(payload.error);
}

function trimPayloadMessage(value) {
  return typeof value === 'string' ? value.trim() : '';
}

function trimText(value) {
  return typeof value === 'string' ? value.trim() : '';
}

function createMissingConversationApi() {
  return new Proxy({}, {
    get(_target, property) {
      return () => {
        throw new Error(defaultTranslate('module.ai-assistant.error.apiMissing', { property: String(property) }));
      };
    },
  });
}
