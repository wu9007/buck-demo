import { aiAssistantConversationRoutes } from '../features/conversation/routes/index.js';
import { aiAssistantModelServiceRoutes } from '../features/model-service/routes/index.js';

export const aiAssistantRoutes = [
  ...aiAssistantConversationRoutes,
  ...aiAssistantModelServiceRoutes,
];
