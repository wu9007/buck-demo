<template>
  <svg
    class="ai-assistant-panel-collapse-icon"
    width="16"
    height="14"
    viewBox="0 0 16 14"
    fill="none"
    aria-hidden="true"
  >
    <rect x="1.5" y="1.5" width="13" height="11" rx="3" stroke="currentColor" stroke-width="1.6" />
    <path d="M5 3.5v7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" />
  </svg>
</template>
