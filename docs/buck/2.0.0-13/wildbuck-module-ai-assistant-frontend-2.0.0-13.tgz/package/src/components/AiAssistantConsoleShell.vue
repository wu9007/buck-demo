<script setup>
import { computed, ref, useAttrs } from 'vue';
import { BrickConsoleShell } from '@wildbuck/core-ui-frontend/shell';
import { AiAssistantPanel } from '../assistant-panel.js';
import AiAssistantSidebarIcon from './AiAssistantSidebarIcon.vue';
import { useAiAssistantI18n } from '../i18n.js';

defineOptions({ inheritAttrs: false });

const props = defineProps({
  assistantPanelOpen: { type: Boolean, default: undefined },
  assistantApi: { type: Object, default: undefined },
});

const emit = defineEmits([
  'update:assistantPanelOpen',
]);

const attrs = useAttrs();
const { t } = useAiAssistantI18n();
const internalAssistantPanelOpen = ref(false);

function resolveForwardedShellAttrs() {
  // useAttrs() 会在渲染时反映最新透传属性，但不适合放进 computed 缓存。
  const {
    contextPanelOpen: _contextPanelOpen,
    ['context-panel-open']: _contextPanelOpenKebab,
    ['onUpdate:contextPanelOpen']: _onUpdateContextPanelOpen,
    ['onUpdate:context-panel-open']: _onUpdateContextPanelOpenKebab,
    ...rest
  } = attrs;
  return rest;
}

const resolvedAssistantPanelOpen = computed({
  get: () => (props.assistantPanelOpen === undefined
    ? internalAssistantPanelOpen.value
    : props.assistantPanelOpen),
  set: (value) => {
    if (props.assistantPanelOpen === undefined) {
      internalAssistantPanelOpen.value = value;
    }
    emit('update:assistantPanelOpen', value);
  },
});

const assistantTriggerLabel = computed(() => (
  resolvedAssistantPanelOpen.value
    ? t('module.ai-assistant.shell.closePanel')
    : t('module.ai-assistant.shell.openPanel')
));

function openAssistantPanel() {
  resolvedAssistantPanelOpen.value = true;
}

function closeAssistantPanel() {
  resolvedAssistantPanelOpen.value = false;
}

function toggleAssistantPanel() {
  resolvedAssistantPanelOpen.value = !resolvedAssistantPanelOpen.value;
}

function updateContextPanelOpen(value) {
  resolvedAssistantPanelOpen.value = value;
}
</script>

<template>
  <BrickConsoleShell
    v-bind="resolveForwardedShellAttrs()"
    :context-panel-open="resolvedAssistantPanelOpen"
    @update:context-panel-open="updateContextPanelOpen"
  >
    <template v-if="$slots['sidebar-brand-mark']" #sidebar-brand-mark="slotProps">
      <slot name="sidebar-brand-mark" v-bind="slotProps" />
    </template>
    <template v-if="$slots['sidebar-collapse-toggle']" #sidebar-collapse-toggle="slotProps">
      <slot name="sidebar-collapse-toggle" v-bind="slotProps" />
    </template>
    <template v-if="$slots['sidebar-route-icon']" #sidebar-route-icon="slotProps">
      <slot name="sidebar-route-icon" v-bind="slotProps" />
    </template>
    <template v-if="$slots['sidebar-nav-before']" #sidebar-nav-before="slotProps">
      <slot name="sidebar-nav-before" v-bind="slotProps" />
    </template>
    <template v-if="$slots['sidebar-extra']" #sidebar-extra>
      <slot name="sidebar-extra" />
    </template>
    <template v-if="$slots['topbar-primary']" #topbar-primary="slotProps">
      <slot name="topbar-primary" v-bind="slotProps" />
    </template>
    <template v-if="$slots['topbar-title']" #topbar-title="slotProps">
      <slot name="topbar-title" v-bind="slotProps" />
    </template>
    <template v-if="$slots['topbar-actions']" #topbar-actions>
      <slot name="topbar-actions" />
    </template>
    <template #topbar-trailing-actions>
      <slot
        name="topbar-trailing-actions"
        :assistant-panel-open="resolvedAssistantPanelOpen"
        :open-assistant-panel="openAssistantPanel"
        :close-assistant-panel="closeAssistantPanel"
        :toggle-assistant-panel="toggleAssistantPanel"
      />
      <slot
        name="assistant-trigger"
        v-if="!resolvedAssistantPanelOpen"
        :assistant-panel-open="resolvedAssistantPanelOpen"
        :open-assistant-panel="openAssistantPanel"
        :close-assistant-panel="closeAssistantPanel"
        :toggle-assistant-panel="toggleAssistantPanel"
      >
        <button
          class="shell-icon-button ai-assistant-console-shell__trigger"
          type="button"
          :title="assistantTriggerLabel"
          :aria-label="assistantTriggerLabel"
          @click="toggleAssistantPanel"
        >
          <AiAssistantSidebarIcon />
        </button>
      </slot>
    </template>

    <slot />

    <template #context-panel>
      <slot
        name="context-panel"
        :assistant-panel-open="resolvedAssistantPanelOpen"
        :close-assistant-panel="closeAssistantPanel"
      >
        <slot
          name="assistant-panel"
          :assistant-panel-open="resolvedAssistantPanelOpen"
          :close-assistant-panel="closeAssistantPanel"
        >
          <AiAssistantPanel
            :api="assistantApi"
            @close="closeAssistantPanel"
          />
        </slot>
      </slot>
    </template>
  </BrickConsoleShell>
</template>

<style scoped>
.ai-assistant-console-shell__trigger {
  min-width: 30px;
  padding: 0;
  border: 0;
  background: transparent;
}

.ai-assistant-console-shell__trigger:hover {
  background: transparent;
}
</style>
