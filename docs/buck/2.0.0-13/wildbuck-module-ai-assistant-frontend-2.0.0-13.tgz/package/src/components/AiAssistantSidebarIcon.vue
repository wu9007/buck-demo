<template>
  <span class="ai-assistant-sidebar-icon" aria-hidden="true"></span>
</template>

<style scoped>
.ai-assistant-sidebar-icon {
  position: relative;
  width: 15px;
  height: 13px;
  display: inline-block;
  border: 1.6px solid currentColor;
  border-radius: 4px;
}

.ai-assistant-sidebar-icon::after {
  position: absolute;
  top: 2px;
  right: 3px;
  bottom: 2px;
  width: 1.6px;
  border-radius: 1px;
  background: currentColor;
  content: '';
}
</style>
