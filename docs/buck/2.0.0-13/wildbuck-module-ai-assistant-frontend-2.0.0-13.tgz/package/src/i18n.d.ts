import type { ComputedRef, Ref } from 'vue';

export declare const AI_ASSISTANT_MESSAGES_ZH_CN: Readonly<Record<string, string>>;
export declare const AI_ASSISTANT_MESSAGES_EN_US: Readonly<Record<string, string>>;
export declare const AI_ASSISTANT_MESSAGES: Readonly<Record<string, Readonly<Record<string, string>>>>;

export declare function resolveAiAssistantMessages(locale?: string): Readonly<Record<string, string>>;
export declare function translateAiAssistant(
  runtime: unknown,
  key: string,
  params?: Record<string, unknown>,
  fallbackLocale?: string,
): string;

export declare function useAiAssistantI18n(): {
  t: (key: string, params?: Record<string, unknown>) => string;
  i18n: unknown;
  locale: ComputedRef<string>;
  revision: Ref<number>;
};
