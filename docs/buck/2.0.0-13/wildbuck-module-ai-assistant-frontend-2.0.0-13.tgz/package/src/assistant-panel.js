import AiAssistantPanel from './features/conversation/components/AiAssistantPanel.vue';

export { AiAssistantPanel };
