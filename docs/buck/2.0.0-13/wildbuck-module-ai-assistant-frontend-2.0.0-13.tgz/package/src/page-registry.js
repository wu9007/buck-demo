export const brickRouteComponentLoaders = {
  'ai-assistant.conversation': () => import('./features/conversation/pages/AiAssistantConversationPage.vue'),
  'ai-assistant.model-services': () => import('./features/model-service/pages/AiModelServicePage.vue'),
};
