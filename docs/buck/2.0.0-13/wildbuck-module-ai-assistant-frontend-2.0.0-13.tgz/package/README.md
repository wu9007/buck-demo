# @wildbuck/module-ai-assistant-frontend

`@wildbuck/module-ai-assistant-frontend` 提供 Buck AI 助手的正式前端入口，包括右侧上下文侧栏、多标签助手会话、控制台壳集成组件和模块路由注册。

## 边界

- 侧栏、助手目录、模型选择、会话 UI 和标准控制台壳入口归 `modules:ai-assistant/frontend`。
- 通用右侧上下文宿主归 `core:ui`，业务验证壳只装配入口。
- 登录安全、密码策略、传输安全、审计日志等业务规则不在本模块实现；相关工具由对应正式模块通过 AI tool SPI 贡献。

## 正式公开入口

- `@wildbuck/module-ai-assistant-frontend/page-registry`：会话页和模型服务页 route loader。
- `@wildbuck/module-ai-assistant-frontend/shell-entry`：标准 `BrickConsoleShell` 壳集成入口，默认提供顶部触发按钮和右侧 AI 助手上下文面板，业务壳只需要传递原有 shell props 与页面内容。
- `@wildbuck/module-ai-assistant-frontend/assistant-panel`：纯右侧面板组件，只在已有自定义宿主时按需装配。
- `@wildbuck/module-ai-assistant-frontend/i18n`：`resolveAiAssistantMessages` / `useAiAssistantI18n`；词条键 `module.ai-assistant.*`，上层壳 `registerMessages('module-ai-assistant', ...)`。
